"""Keep the selected parent's act/target/held; delegate only F source methods."""
from d_supervisor import DSupervisor
import copy
import numpy as np
from source_view import source_evidence, observation_outcome
from f_parent_rule_controller import RuleController as ParentController
from f_source_controller import RuleController as SourceController, FixedRobotPitchSearch

class RuleController(DSupervisor, ParentController):

    def reset(self, context=None):
        super().reset(context)
        self._f_planner = None
        self._f_selected_pitch = None
        self._f_pinch_height = 0.01
        self._f_search_key = None
        self._f_pitch_results = None
        self._source_view_history = []
        self._source_view_active_packet = None
        self._source_observe_waypoints = []
        self._source_view_arrival_step = None
        self._source_view_stable_frames = 0

    def perception_request(self):
        request = super().perception_request()
        required = []
        if self._f_search_key is not None and self._f_search_key[0] == self.batch_index:
            candidates = [c for c in (self._f_pitch_results or {}).get('candidates', []) if c.get('path_state') == 'unknown' and (c.get('source_coverage') or {}).get('unknown_hypotheses')]
            if candidates:
                best = min(candidates, key=lambda c: len(c['source_coverage']['unknown_hypotheses']))
                required = best['source_coverage']['unknown_hypotheses']
        request.update(source_path_observation_request=dict(unknown_hypotheses=required, object_scope='source_spatial_hypotheses_in_actual_low_swept_pieces'), source_view_history=copy.deepcopy(self._source_view_history), source_view_active=self._source_view_active_packet is not None)
        return request

    def prepare_fixed_robot_search(self, model, path_checker=None):
        self._f_planner = FixedRobotPitchSearch(model, self.config, path_checker)

    def _source_observation_target(self, scene):
        plan = scene.get('source_observation') or {}
        if plan.get('needed'):
            if not plan.get('valid'):
                self._rule_reason = plan.get('reason', 'source evidence remains unknown')
                return None
            self._source_view_active_packet = copy.deepcopy(plan)
            self._source_observe_waypoints = [(np.asarray(p['position'], float), np.asarray(p['rotation'], float)) for p in plan['waypoints']]
            self._source_view_arrival_step = None
            self._source_view_stable_frames = 0
            self._source_observe_basis = dict(kind='source_fov_ik_path', view_id=plan['view_id'], context_key=plan['context_key'], expected_evidence=plan['expected_evidence'], required_object_ids=plan.get('required_object_ids', []))
            return (np.asarray(plan['eef_position'], float), np.asarray(plan['eef_rotation'], float))
        return SourceController._source_observation_target(self, scene)

    def act(self, obs, scene):
        plan = scene.get('source_observation') or {}
        if self.stage != 'SOURCE_OBSERVE' or not (plan.get('needed') or self._source_view_active_packet is not None):
            return super().act(obs, scene)
        self.total_steps += 1
        self.phase_steps += 1
        self._obs, self._scene = (obs, scene)
        self.actual_opening = float(np.asarray(obs['observation.state'])[7])
        self._inventory = copy.deepcopy(scene.get('object_inventory') or {})
        if self.finished:
            return self._hold()
        self._remember_source_path(obs)
        if self._source_view_active_packet is None:
            if self._source_observation_target(scene) is None:
                self._source_view_history.append(dict(context_key=plan.get('context_key'), view_id='unreachable_source_search', outcome='unreachable', reason=plan.get('reason')))
                self._f_search_key = None
                self._advance('SELECT')
                return self._hold()
        active = self._source_view_active_packet
        if self._source_observe_waypoints:
            destination, rotation = self._source_observe_waypoints[0]
            pose = np.asarray(obs['observation.eef_pose'], float)[:3]
            distance = float(np.linalg.norm(destination - pose))
            speed = 0.015 if pose[2] >= destination[2] - 0.003 and distance > 0.02 else 0.003
            action, reached = self._servo(obs, destination, rotation, speed)
            if reached:
                self._source_observe_waypoints.pop(0)
                if not self._source_observe_waypoints:
                    self._source_view_arrival_step = source_evidence(scene, self.count).get('measurement_step')
                    self._source_view_stable_frames = 0
            elif self._metric is not None and self.total_steps - self._last_progress > 35:
                self._source_view_history.append(dict(context_key=active['context_key'], view_id=active['view_id'], eef_position=active['eef_position'], eef_rotation=active['eef_rotation'], outcome='unreachable', reason='public pose feedback stopped progressing to planned view'))
                self._source_view_active_packet = None
                self._source_observe_waypoints = []
                self._f_search_key = None
                self._advance('SELECT')
            return action
        current = source_evidence(scene, self.count)
        self._source_view_stable_frames += 1
        fresh = current.get('measurement_step') is not None and (self._source_view_arrival_step is None or current['measurement_step'] > self._source_view_arrival_step)
        if fresh or self._source_view_stable_frames >= 3:
            outcome = observation_outcome(active.get('evidence', {}), current) if fresh else 'uninformative'
            self._source_view_history.append(dict(context_key=active['context_key'], view_id=active['view_id'], eef_position=active['eef_position'], eef_rotation=active['eef_rotation'], outcome=outcome, measurement_id=current.get('measurement_id'), measurement_step=current.get('measurement_step'), before=active.get('evidence'), after=current))
            self._source_view_active_packet = None
            self._f_search_key = None
            self._rule_reason = 'source path-region observation ' + outcome
            self._advance('SELECT')
        return self._hold()

    def _select(self, scene):
        return SourceController._select(self, scene)

    def _apply_group_geometry(self, group):
        return SourceController._apply_group_geometry(self, group)

    def _confirm_observed_grasp(self, valid_count, obs):
        return SourceController._confirm_observed_grasp(self, valid_count, obs)

    @property
    def public_evidence(self):
        result = super().public_evidence
        result['finite_pitch_search'] = copy.deepcopy(self._f_pitch_results)
        return result
