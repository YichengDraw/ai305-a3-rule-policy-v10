"""Public RGB/CAD source frame and current neighbouring-object hypotheses.

The initial twenty-row identity frame is older evidence. Each occupancy result
is measured again from the current RGB; a layout position alone is never marked
as a currently verified object. No episode environment or seed is accepted.
"""
from __future__ import annotations
import copy
import cv2
import numpy as np
from scipy.signal import find_peaks

def calibrated_source_cameras(vision, observation):
    cameras = vision._robot_cameras(observation)
    cameras['left_wrist'] = vision._v6_wrist_camera(cameras['left_wrist'], observation)
    return {name: vision._adjust_camera(camera, vision.camera_adjustments.get(name, np.zeros(7))) for name, camera in cameras.items()}

def _project(points, camera, shape):
    h, w = shape[:2]
    f = h / 2 / np.tan(np.deg2rad(camera['fovy']) / 2)
    p = (np.asarray(points) - camera['pos']) @ camera['rotation']
    d = np.maximum(-p[:, 2], 1e-05)
    return (np.column_stack([(w - 1) / 2 + f * p[:, 0] / d, (h - 1) / 2 - f * p[:, 1] / d]), -p[:, 2])

class SourceGeometry:

    def __init__(self, config):
        self.scene = getattr(config, 'cookie_transfer', config)
        self.layout = np.asarray(self.scene.cookie_source_positions_m, float)
        self.columns = np.unique(self.layout[:, 0])
        self.half = np.asarray(self.scene.cookie_half_size_m, float)
        self.reset()

    def reset(self):
        self.broad_anchors = {}
        self.free_cells = {}; self.space_signature = None
        self.occupied_evidence = {}; self.occupied_signature = None

    def _merge_occupied_evidence(self, objects, signature, measurement_step):
        """Combine actual RGB views while contact and calibration stay fixed."""
        if signature != self.occupied_signature:
            self.occupied_evidence = {}
            self.occupied_signature = copy.deepcopy(signature)
        for obj in objects:
            key = obj['object_id']
            obj['verified_current_RGB'] = bool(obj.get('verified'))
            if obj['verified_current_RGB']:
                self.occupied_evidence[key] = copy.deepcopy(obj)
                continue
            previous = self.occupied_evidence.get(key)
            if previous is None:
                continue
            if obj.get('precise_camera') is not None:
                axis = np.asarray(previous['rotation_world'], float)[:, 1]
                change = abs(float((np.asarray(obj['center_world'])-
                                    np.asarray(previous['center_world'])) @ axis))
                uncertainty = float((obj.get('uncertainty_m') or {}).get('row', .004)) + float((previous.get('uncertainty_m') or {}).get('row', .004))
                if change > uncertainty:
                    self.occupied_evidence.pop(key, None)
                    obj['retained_evidence_rejected'] = 'current precise row contradicts stored occupancy beyond combined row uncertainty'
                    continue
            # The selected unit changes between requests, not in the camera.
            selected = obj.get('part_of_selected_source_unit', False)
            current = {k: copy.deepcopy(obj.get(k)) for k in
                       ('state', 'cameras', 'precise_camera', 'measurement_id',
                        'measurement_step', 'center_world')}
            obj.update(copy.deepcopy(previous))
            obj.update(part_of_selected_source_unit=selected,
                       verified_current_RGB=False,
                       retained_in_unchanged_contact_epoch=True,
                       current_view_evidence=current,
                       age_steps=int(measurement_step)-int(previous['measurement_step']),
                       occupancy_evidence_basis='measured RGB occupancy retained in unchanged contact/calibration/frame epoch')

    def estimate(self, observation, scene, cameras, *, measurement_step, color_mask, vision=None, request=None):
        frame, rows, measured_rows = self._identity_frame(scene)
        if frame is None:
            return dict(state='unknown', reason='measured full or front-anchored partial source frame not yet observed', source_box=scene.get('source_box'), protected_objects=[], objects=[], coverage={'state':'unknown','reason':'no bounded source row identity evidence'})
        column = int(frame['source_column'])
        axis = np.asarray(frame['row_axis_world'], float)
        broad = np.asarray(frame['broad_axis_world'], float)
        rotation = np.column_stack([broad, axis, np.cross(broad, axis)])
        nominal = self.layout[np.isclose(self.layout[:, 0], self.columns[column - 1])]
        nominal = nominal[np.argsort(nominal[:, 1])]
        base = np.r_[np.asarray(self.scene.source_bin_center_m, float), 0.0]
        measured_along = rows @ axis
        nominal_along = np.column_stack([nominal, np.full(20, self.scene.cookie_model_z_m)]) @ axis
        row_translation = float(np.median((measured_along - nominal_along)[measured_rows]))
        group = scene.get('group') or {}
        edge = group.get('broad_measurement') or (scene.get('local_align') or {}).get('broad_measurement') or {}
        key = (column, frame.get('calibration_generation'))
        if key not in self.broad_anchors and edge.get('observable') and edge.get('outer_edge_observed') and (float(edge.get('confidence', 0.0) or 0.0) >= 0.65) and (edge.get('center_world') is not None):
            self.broad_anchors[key] = copy.deepcopy(edge)
        edge = self.broad_anchors.get(key)
        original = copy.deepcopy(scene.get('source_box') or {})
        box_center = np.asarray(original.get('center', base), float).copy()
        box_center += axis * (float(base @ axis) + row_translation - float(box_center @ axis))
        if edge is not None:
            nominal_broad = float(np.mean(nominal[:, 0]))
            box_broad = float(np.asarray(edge['center_world']) @ broad) - nominal_broad + float(base @ broad)
            box_center += broad * (box_broad - float(box_center @ broad))
        geometry_version = {'source_row_measurement_id': frame['measurement_id'], 'broad_measurement_id': None if edge is None else edge.get('measurement_id'), 'calibration_generation': frame.get('calibration_generation'), 'identity_observed_rows': int(measured_rows.sum()), 'full_twenty_observed': bool(np.all(measured_rows))}
        identity_basis = 'initial full twenty RGB rows' if np.all(measured_rows) else 'historical front-anchored RGB prefix; trailing rows remain hypotheses'
        box = {**original, 'center': box_center.tolist(), 'rotation': rotation.tolist(), 'geometry_version': geometry_version, 'measurement_id': 'source_frame:' + str(frame['measurement_id']) + ':' + str(None if edge is None else edge.get('measurement_id')), 'measurement_step': frame['measurement_step'], 'row_axis_verified': True, 'broad_axis_verified': edge is not None, 'wall_pose_state': 'measured_RGB_row_identity_and_visible_outer_edge' if edge is not None else 'row_axis_only; broad_wall_prior_uncertain', 'row_axis_correction_m': float(row_translation), 'position_uncertainty_m': {'row': frame.get('row_uncertainty_m', 0.0015), 'broad': frame.get('broad_uncertainty_m', 0.006) if edge is None else edge.get('uncertainty_m', 0.002)}, 'basis': identity_basis + ' + fixed source layout; outer edge supplies broad translation when observed'}
        row_values = rows @ axis
        lo, hi = (float(row_values.min() - 0.014), float(row_values.max() + 0.014))
        yy = np.linspace(lo, hi, 900)
        dy = float(yy[1] - yy[0])
        xx = np.linspace(-self.half[0] * 0.45, self.half[0] * 0.45, 20)
        midpoint = np.asarray(box['center'], float)
        base_broad = float(midpoint @ broad)
        top = float(self.scene.cookie_model_z_m + self.half[2])
        objects = []
        per_camera = {}
        selected = (group.get('source_unit') or {}).get('object_hypotheses', [])
        selected_centers = [np.asarray(o['center'], float) for o in selected if o.get('center') is not None]
        for col in range(1, len(self.columns) + 1):
            bx = base_broad + float(self.columns[col - 1] - self.scene.source_bin_center_m[0])
            points = np.asarray([broad * (bx + x) + axis * y + [0, 0, top] for y in yy for x in xx])
            views = []
            for name, camera in cameras.items():
                if 'observation.images.' + name not in observation:
                    continue
                image = np.asarray(observation['observation.images.' + name])
                uv, depth = _project(points, camera, image.shape)
                valid = ((depth > 0) & (uv[:, 0] > 2) & (uv[:, 0] < image.shape[1] - 3) & (uv[:, 1] > 2) & (uv[:, 1] < image.shape[0] - 3)).reshape(len(yy), len(xx))
                patch = cv2.remap(image, uv[:, 0].astype(np.float32).reshape(len(yy), len(xx)), uv[:, 1].astype(np.float32).reshape(len(yy), len(xx)), cv2.INTER_LINEAR)
                hsv = cv2.cvtColor(patch, cv2.COLOR_RGB2HSV)
                colored = (color_mask(patch) > 0) & valid
                coverage = valid.mean(1)
                fraction = colored.sum(1) / np.maximum(valid.sum(1), 1)
                visible = (coverage > 0.95) & (np.mean(hsv[:, :, 2] < 28, axis=1) < 0.2)
                signal = np.mean(hsv[:, :, 2].astype(float) * np.where(colored, 1.0, 0.12), axis=1)
                signal = cv2.GaussianBlur(signal.astype(np.float32)[:, None], (1, 5), 0).ravel()
                peaks, _ = find_peaks(signal, prominence=max(5.0, float(np.std(signal[visible])) * 0.2 if np.any(visible) else 5.0), distance=max(4, int(0.0047 / dy)))
                peaks = np.asarray([i for i in peaks if visible[i] and fraction[i] > 0.35], int)
                test = np.asarray([broad * bx + axis * y + [0, 0, top] for y in (float(row_values[0]), float(row_values[0] + 0.0088333333))])
                pix, _ = _project(test, camera, image.shape)
                pitch_px = float(np.linalg.norm(pix[1] - pix[0]))
                positions = yy[peaks]
                views.append((name, positions, pitch_px, fraction, visible))
                per_camera[f'{col}:{name}'] = dict(row_positions_world_axis_m=positions.tolist(), pixels_per_pitch=pitch_px, visible_fraction=float(np.mean(visible)))
            for row, y in enumerate(row_values):
                high = []
                support = []
                for name, positions, pixels, fraction, visible in views:
                    j = int(np.argmin(abs(yy - y)))
                    center_support = bool(visible[j] and fraction[j] > 0.35)
                    if center_support:
                        support.append(name)
                    if pixels >= 4 and len(positions):
                        closest = float(positions[np.argmin(abs(positions - y))])
                        if abs(closest - y) < 0.0025:
                            high.append((pixels, name, closest))
                best = max(high, default=None)
                measured_y = float(y if best is None else best[2])
                center = broad * bx + axis * measured_y + [0, 0, self.scene.cookie_model_z_m]
                verified = bool(best is not None and len(support) >= 2 and (edge is not None))
                own = col == column and any((abs(float((center - c) @ axis)) < 0.004 for c in selected_centers))
                objects.append(dict(object_id=f'source_spatial_hypothesis:{col}:{row}', object_scope='individual_objects', identity_state='unconfirmed_layout_row_hypothesis', source_column=col, row_hypothesis=row, frame='world', box_key='source_box', center_world=center.tolist(), rotation_world=rotation.tolist(), half_size=self.half.tolist(), geometry_version=geometry_version, measurement_id=f'source_neighbour:{col}:{row}:{measurement_step}', measurement_step=int(measurement_step), state='verified_current_RGB_occupancy' if verified else 'single_view_RGB_supported' if best is not None else 'unobserved_layout_hypothesis', verified=verified, cameras=support, precise_camera=None if best is None else best[1], part_of_selected_source_unit=own, uncertainty_m={'row': 0.0015 if best is not None else 0.004, 'broad': box['position_uncertainty_m']['broad']}))
        occupied_signature = (frame.get('measurement_id'), repr(geometry_version),
            repr(scene.get('source_wrist_calibration',scene.get('wrist_calibration'))),
            repr(scene.get('source_camera_calibration',scene.get('camera_calibration'))),
            (scene.get('source_frontier') or {}).get('contact_epoch',frame.get('current_contact_epoch')))
        self._merge_occupied_evidence(objects, occupied_signature, measurement_step)
        space = self._space_states(observation,scene,cameras,box,frame,objects,measurement_step=measurement_step,color_mask=color_mask,vision=vision,request=request)
        protected = [o for o in objects if o['verified'] and (not o['part_of_selected_source_unit'])]
        return dict(state='measured' if edge is not None else 'partial', source_box=box, objects=objects, protected_objects=protected, measurement_id=f'source_geometry:{column}:{measurement_step}', measurement_step=int(measurement_step), geometry_version=geometry_version, current_contact_epoch=frame.get('current_contact_epoch'), identity_measurement_id=frame['measurement_id'], source_space=space, identity_scope=dict(measured_rows=int(measured_rows.sum()),unobserved_rows=int((~measured_rows).sum()),original_measurement_id=frame['measurement_id']), coverage=dict(state='current_RGB_partial', verified_count=sum((o['verified'] for o in objects)), protected_count=len(protected), unknown_hypotheses=[o['object_id'] for o in objects if not o.get('space_coverage_verified')], observed_free_count=sum(o['state']=='observed_free' for o in objects), selected_source_column=column, note='unobserved layout hypotheses are not current empty space'), per_camera=per_camera)

    def _identity_frame(self, scene):
        """Return a measured full frame or a bounded historical front prefix."""
        frame=scene.get('source_row_frame') or (scene.get('object_inventory') or {}).get('source_row_frame')
        if frame is not None:
            rows=np.asarray(frame.get('row_centres_world',[]),float)
            if rows.shape==(20,3) and frame.get('created_contact_epoch')==0:
                return frame,rows,np.ones(20,bool)
        anchor=scene.get('source_partial_anchor') or (scene.get('object_inventory') or {}).get('source_partial_anchor')
        if anchor is None or anchor.get('created_contact_epoch')!=0 or not anchor.get('front_clear_band_observed'):
            return None,None,None
        prefix=anchor.get('observed_prefix') or []
        observed=np.asarray([o['center'] for o in prefix if o.get('center') is not None],float)
        if len(observed)<2 or len(observed)>20:return None,None,None
        axis=np.asarray(anchor['row_axis_world'],float);axis/=max(np.linalg.norm(axis),1e-12)
        spacings=np.diff(observed@axis);pitch=float(np.median(spacings))
        if not .0045<pitch<.014:return None,None,None
        rows=observed[0]+np.arange(20)[:,None]*pitch*axis
        rows[:len(observed)]=observed
        frame=dict(anchor,kind='historical_partial_front_prefix',row_axis_world=axis.tolist(),
            broad_axis_world=anchor.get('broad_axis_world',[axis[1],-axis[0],0.]),
            observed_row_count=len(observed),full_twenty_observed=False,
            trailing_rows_state='unobserved spatial hypotheses',
            current_contact_epoch=(scene.get('source_frontier') or {}).get('contact_epoch'))
        known=np.arange(20)<len(observed)
        return frame,rows,known

    def _wall_visibility(self, camera_position, points, box):
        """Fixed source walls may hide floor pixels even when inside the image."""
        rotation=np.asarray(box['rotation'],float);center=np.asarray(box['center'],float)
        start=(np.asarray(camera_position)-center)@rotation
        end=(np.asarray(points)-center)@rotation;direction=end-start
        half=np.asarray(self.scene.source_bin_half_size_m,float);thick=float(self.scene.bin_wall_thickness_m)
        z0=float(self.scene.source_wall_base_z_m)-center[2];z1=z0+float(self.scene.source_bin_wall_height_m)
        slabs=[([-half[0],-half[1],z0],[-half[0]+thick,half[1],z1]),
               ([half[0]-thick,-half[1],z0],[half[0],half[1],z1]),
               ([-half[0],-half[1],z0],[half[0],-half[1]+thick,z1]),
               ([-half[0],half[1]-thick,z0],[half[0],half[1],z1])]
        visible=np.ones(len(points),bool)
        for lo,hi in slabs:
            lo=np.asarray(lo);hi=np.asarray(hi);low=np.zeros(len(points));high=np.ones(len(points))
            possible=np.ones(len(points),bool)
            for j in range(3):
                parallel=np.abs(direction[:,j])<1e-12
                possible&=~parallel|((start[j]>=lo[j])&(start[j]<=hi[j]))
                d=np.where(parallel,1.,direction[:,j]);a=(lo[j]-start[j])/d;b=(hi[j]-start[j])/d
                low=np.maximum(low,np.where(parallel,-np.inf,np.minimum(a,b)))
                high=np.minimum(high,np.where(parallel,np.inf,np.maximum(a,b)))
            visible&=~(possible&(low<=high)&(high>1e-6)&(low<1-1e-6))
        return visible

    def _space_states(self, observation, scene, cameras, box, frame, objects, *, measurement_step, color_mask, vision=None, request=None):
        """Classify measured spatial cells, preserving original evidence time."""
        rotation=np.asarray(box['rotation'],float);floor=float(self.scene.source_floor_z_m+self.scene.bin_wall_thickness_m/2)
        top=float(self.scene.cookie_model_z_m+self.half[2]);cells=[];allpoints=[]
        for obj in objects:
            center=np.asarray(obj['center_world'],float)
            for tile in range(5):
                xx=np.linspace(-self.half[0]+tile*2*self.half[0]/5,-self.half[0]+(tile+1)*2*self.half[0]/5,5)
                yy=np.linspace(-self.half[1],self.half[1],5)
                floorpoints=np.array([center+rotation@np.array([x,y,0.]) for y in yy for x in xx]);floorpoints[:,2]=floor
                toppoints=floorpoints.copy();toppoints[:,2]=top
                start=len(allpoints);allpoints.extend(floorpoints);allpoints.extend(toppoints)
                local_x=(xx[0]+xx[-1])/2
                cellcenter=center+rotation[:,0]*local_x;cellcenter[2]=(floor+top)/2
                cells.append(dict(object_id=obj['object_id'],source_column=obj['source_column'],row_hypothesis=obj['row_hypothesis'],tile=tile,
                    center_world=cellcenter.tolist(),rotation_world=rotation.tolist(),half_size=[(xx[-1]-xx[0])/2,self.half[1],(top-floor)/2],
                    point_start=start,point_count=50,state='unknown',evidence=[],measurement_id=None))
        allpoints=np.asarray(allpoints,float)
        signature=(frame.get('measurement_id'),repr(box['geometry_version']),
            repr(scene.get('source_wrist_calibration',scene.get('wrist_calibration'))),
            repr(scene.get('source_camera_calibration',scene.get('camera_calibration'))),
            (scene.get('source_frontier') or {}).get('contact_epoch',frame.get('current_contact_epoch')))
        if signature!=getattr(self,'space_signature',None):self.free_cells={};self.space_signature=signature
        if vision is not None and len(allpoints):
            from public_visibility import sample_visibility
            for name,camera in cameras.items():
                key='observation.images.'+name
                if key not in observation:continue
                image=np.asarray(observation[key]);h,w=image.shape[:2]
                visible=sample_visibility(vision,observation,camera,allpoints,image.shape,held=scene.get('held'),request=request)
                uv=np.asarray(visible['uv']);d=np.asarray(visible['depth']);inside=np.asarray(visible['in_frame'],bool)
                clear=np.asarray(visible['visible'],bool)&self._wall_visibility(camera['pos'],allpoints,box)
                xy=np.rint(uv).astype(int);xy[:,0]=np.clip(xy[:,0],0,w-1);xy[:,1]=np.clip(xy[:,1],0,h-1)
                rgb=image[xy[:,1],xy[:,0]];mx=rgb.max(1).astype(float);mn=rgb.min(1).astype(float)
                floorgray=(mx-mn<38)&(mx>65)&(mx<250)&(rgb[:,2].astype(float)+10>=rgb[:,0].astype(float))
                colors=(color_mask(image)>0)[xy[:,1],xy[:,0]]
                primary=name!='right_wrist' or (getattr(vision,'right_wrist_calibration',{}) or {}).get('state')=='fitted'
                for cell in cells:
                    s=cell['point_start'];sl=slice(s,s+50);fl=slice(s,s+25)
                    center=np.asarray(cell['center_world']);probe=np.array([center,center+rotation[:,1]*.008833333333333])
                    pix,_=_project(probe,camera,image.shape);pixels=float(np.linalg.norm(pix[1]-pix[0]))
                    report=dict(camera=name,in_frame_fraction=float(inside[sl].mean()),unoccluded_fraction=float(clear[sl].mean()),
                        floor_gray_fraction=float(floorgray[fl].mean()),cookie_fraction=float(colors[sl].mean()),pixels_per_pitch=pixels,
                        metric_camera_eligible=primary, payload_projection_known=bool(visible.get('payload_projection_known',True)))
                    report['observed_free']=bool(primary and pixels>=4. and np.all(clear[sl]) and report['payload_projection_known']
                        and report['floor_gray_fraction']>=.9 and report['cookie_fraction']<=.02 and box.get('broad_axis_verified'))
                    cell['evidence'].append(report)
        byid={o['object_id']:o for o in objects};free=[]
        for obj in objects:
            own=[c for c in cells if c['object_id']==obj['object_id']]
            if (obj.get('retained_in_unchanged_contact_epoch') and own
                    and all(any(e.get('observed_free') for e in c['evidence']) for c in own)):
                # A fully observed empty footprint supersedes older occupancy.
                self.occupied_evidence.pop(obj['object_id'],None)
                current=obj['current_view_evidence']
                obj.update(copy.deepcopy(current),verified=False,
                    retained_in_unchanged_contact_epoch=False,
                    retained_evidence_rejected='current fully visible footprint is observed free')
        for cell in cells:
            obj=byid[cell['object_id']];key=(cell['source_column'],cell['row_hypothesis'],cell['tile'])
            previous=self.free_cells.get(key)
            # A visible object is contradictory evidence, even if its identity is uncertain.
            positive=obj.get('verified') or obj.get('precise_camera') is not None and bool(obj.get('cameras'))
            if positive:
                cell['state']='occupied';self.free_cells.pop(key,None)
            elif any(e['observed_free'] for e in cell['evidence']):
                cell.update(state='observed_free',measurement_id='source_free:{}:{}:{}:{}'.format(*key,measurement_step),measurement_step=int(measurement_step),
                    geometry_version=box['geometry_version'],contact_epoch=signature[-1],age_steps=0)
                self.free_cells[key]=copy.deepcopy(cell)
            elif previous is not None and np.allclose(previous['center_world'],cell['center_world'],rtol=0,atol=1e-9):
                current=cell['evidence'];cell.update(copy.deepcopy(previous));cell['current_view_evidence']=current
                cell['age_steps']=int(measurement_step)-int(cell['measurement_step']);cell['retained_in_unchanged_contact_epoch']=True
            elif any(e['in_frame_fraction']>.95 and e['unoccluded_fraction']<.95 for e in cell['evidence']):cell['state']='occluded'
            if cell['state']=='observed_free':free.append(cell)
        for obj in objects:
            own=[c for c in cells if c['object_id']==obj['object_id']];states=[c['state'] for c in own]
            obj['state']='occupied' if 'occupied' in states else 'observed_free' if states and all(s=='observed_free' for s in states) else 'occluded' if 'occluded' in states else 'unknown'
            obj['space_coverage_verified']=obj['state']=='observed_free' or bool(obj.get('verified'))
            obj['space_cells']=[dict(tile=c['tile'],state=c['state'],measurement_id=c.get('measurement_id')) for c in own]
        return dict(states=('occupied','observed_free','occluded','unknown'),cells=cells,observed_free_regions=free,
            measurement_id='source_space:'+str(measurement_step),measurement_step=int(measurement_step),contact_epoch=signature[-1],
            geometry_version=box['geometry_version'],uncertainty_calibrated=False,
            interpretation='free means current calibrated RGB floor support with full unoccluded footprint; retained evidence keeps its original ID/time within unchanged contact/calibration epoch')


def source_planning_scene(scene, evidence):
    """Return a planning copy. The original perception box is preserved."""
    return {**scene, 'source_box': evidence.get('source_box', scene.get('source_box')), 'source_geometry': evidence, 'source_neighbours': evidence.get('protected_objects', [])}

def source_path_coverage(checker, observation, waypoints, evidence):
    """Require evidence only where individual low CAD sweeps meet a hypothesis.

    Use the D checker's convex endpoint sweep and <=2 degree rotation steps.
    Slice each physical piece at the possible cookie height before the SAT
    query, so a high palm cannot widen a lower finger's observation corridor.
    The independent D checker still decides collisions against known objects.
    """
    from scipy.spatial.transform import Rotation, Slerp
    from path_feasibility import _poly, _z_slice, _separation, _corners
    if evidence.get('state') == 'unknown' or not (evidence.get('source_box') or {}).get('broad_axis_verified'):
        return dict(state='unknown', reason='source broad-axis wall geometry not yet verified', unknown_hypotheses=[])
    unknown = [o for o in evidence.get('objects', []) if not o.get('verified') and o.get('state')!='observed_free' and (not o.get('part_of_selected_source_unit'))]
    free_regions=(evidence.get('source_space') or {}).get('observed_free_regions',[])
    relevant = set()
    details = {}
    objects = []
    for obj in unknown:
        center = np.asarray(obj['center_world'], float)
        rotation = np.asarray(obj['rotation_world'], float)
        poly = _poly(_corners(obj['half_size']) @ rotation.T + center)
        objects.append((obj, poly, poly.vertices.min(0), poly.vertices.max(0)))
    if not objects:
        return dict(state='covered', unknown_hypotheses=[], reason='no unknown nonselected source hypotheses', corridor_basis='per_piece_low_swept_convex_SAT')
    low = min(float(item[2][2]) for item in objects)
    high = max(float(item[3][2]) for item in objects)
    epsilon = float(checker.collision_epsilon_m)
    queried = set()
    sliced_pieces = 0
    nodes = [p for p in waypoints if p.get('box_key') == 'source_box']
    for segment, (start, end) in enumerate(zip(nodes[:-1], nodes[1:])):
        ra = np.asarray(start['rotation'], float)
        rb = np.asarray(end['rotation'], float)
        angle = float(Rotation.from_matrix(ra.T @ rb).magnitude())
        parts = max(1, int(np.ceil(angle / np.deg2rad(2.0))))
        slerp = Slerp([0.0, 1.0], Rotation.from_matrix([ra, rb]))
        for sub in range(parts):
            endpoints = []
            for t in (sub / parts, (sub + 1) / parts):
                rot = slerp(t).as_matrix()
                pos = (1 - t) * np.asarray(start['position']) + t * np.asarray(end['position'])
                opening = (1 - t) * start['opening'] + t * end['opening']
                endpoints.append({name: vertices @ rot.T + pos for name, vertices in checker.gripper_vertices_tool(observation, opening).items()})
            for piece in endpoints[0]:
                sweep = _poly(np.vstack([endpoints[0][piece], endpoints[1][piece]]))
                clipped = _z_slice(sweep, low - epsilon, high + epsilon)
                if not len(clipped):
                    continue
                sliced_pieces += 1
                # At an exactly tangential height the slice may be planar.
                # Retain the original convex sweep for that boundary query.
                sliced = _poly(clipped) if len(clipped) >= 4 and np.linalg.matrix_rank(clipped - clipped[0]) == 3 else sweep
                lo, hi = clipped.min(0), clipped.max(0)
                for obj, poly, obj_lo, obj_hi in objects:
                    if np.any(obj_hi < lo - epsilon) or np.any(obj_lo > hi + epsilon):
                        continue
                    oid = obj['object_id']
                    queried.add(oid)
                    separation = _separation(sliced, poly)
                    if separation > epsilon:
                        continue
                    intersection_lo = np.maximum(lo, obj_lo)
                    intersection_hi = np.minimum(hi, obj_hi)
                    # A positive separation within the existing CAD epsilon is
                    # still unknown, rather than a fabricated free intersection.
                    free = np.all(intersection_hi >= intersection_lo) and _free_region_union_covers(intersection_lo, intersection_hi, free_regions)
                    if not free:
                        relevant.add(oid)
                        if oid not in details or separation < details[oid]['separation_m']:
                            details[oid] = dict(segment=segment, name=end.get('name'), subsegment=sub, piece=piece, separation_m=separation)
    return dict(state='covered' if not relevant else 'unknown', unknown_hypotheses=sorted(relevant), reason='current RGB covers the individual low swept pieces' if not relevant else 'current RGB has not verified hypotheses intersecting individual low swept pieces', corridor_basis='per_piece_low_swept_convex_SAT', low_height_band_m=[low, high], sliced_piece_count=sliced_pieces, aabb_queried_hypotheses=sorted(queried), relevant_details=details)


def _free_region_union_covers(low,high,regions):
    """Cover only the queried low-path intersection, not an entire unseen row."""
    boxes=[]
    for entry in regions:
        center=np.asarray(entry['center_world'],float);rotation=np.asarray(entry['rotation_world'],float);half=np.asarray(entry['half_size'],float)
        # Source yaw is fixed in this task. Use inscribed world bounds for a
        # nonzero yaw rather than declaring the larger AABB to be measured free.
        inverse=np.linalg.inv(np.abs(rotation)+np.eye(3)*1e-15)
        inner=inverse@half
        if np.any(inner<0):continue
        lo=np.maximum(low,center-inner);hi=np.minimum(high,center+inner)
        if np.all(hi>=lo-1e-9):boxes.append((lo,hi))
    if not boxes:return False
    grids=[np.unique(np.asarray([low[j],high[j]]+[b[k][j] for b in boxes for k in (0,1)])) for j in range(3)]
    samples=[(g[:-1]+g[1:])/2 if len(g)>1 else g for g in grids]
    for x in samples[0]:
        for y in samples[1]:
            for z in samples[2]:
                p=np.array([x,y,z])
                if not any(np.all(p>=lo-1e-9) and np.all(p<=hi+1e-9) for lo,hi in boxes):return False
    return True
