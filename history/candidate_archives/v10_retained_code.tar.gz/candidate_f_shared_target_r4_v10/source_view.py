"""Finite source-camera views from public kinematics and observed source geometry."""
from __future__ import annotations
import numpy as np
import cv2
from scipy.spatial.transform import Rotation
from path_feasibility import PathFeasibility
import mujoco


def _project(points, camera, shape):
    h,w=shape[:2]; f=h/2/np.tan(np.deg2rad(camera['fovy'])/2)
    p=(np.asarray(points)-camera['pos'])@camera['rotation']; depth=-p[:,2]
    d=np.maximum(depth,1e-5)
    return np.column_stack([(w-1)/2+f*p[:,0]/d,(h-1)/2-f*p[:,1]/d]),depth


def source_evidence(scene, count):
    """Describe measured information, independently of the measurement ID."""
    front=scene.get('source_frontier') or {}; local=scene.get('local_align') or {}
    raw=front.get('coarse_current_observation') or front
    objects=raw.get('objects') or []
    selected=int(front.get('selected_count',0) or 0)
    solved=bool(front.get('geometry_valid') and selected==int(count)
                and front.get('selection_state')=='contiguous_measured_unit'
                and not front.get('requires_wrist_view'))
    ranges=[]
    for camera,data in (raw.get('per_camera') or {}).items():
        positions=np.asarray(data.get('row_positions_local_m',[]),float)
        ranges.append((camera, len(positions), bool(data.get('front_clear_band')),
            bool(data.get('rear_clear_band')),bool(data.get('all_twenty_resolved')),
            None if not len(positions) else [float(positions.min()),float(positions.max())]))
    gap=local.get('gap_width_m')
    evidence=scene.get('source_geometry') or {}
    required=set((scene.get('source_path_observation_request') or {}).get('unknown_hypotheses',[]))
    verified={o['object_id'] for o in evidence.get('objects',[]) if o.get('verified') or o.get('state')=='observed_free'}
    if required:solved=required<=verified
    return dict(resolved=solved, measurement_id=evidence.get('measurement_id',raw.get('measurement_id')) if required else raw.get('measurement_id'),measurement_step=evidence.get('measurement_step',raw.get('measurement_step')) if required else raw.get('measurement_step'),
        coverage_required_ids=sorted(required),coverage_verified_ids=sorted(required&verified),coverage_unknown_ids=sorted(required-verified),
        geometry_valid=bool(front.get('geometry_valid')),selected_count=selected,
        object_count=len(objects),front_clear=bool(raw.get('front_clear_band')),
        rear_clear=bool(raw.get('rear_clear_band')),identity_anchor=bool(front.get('identity_anchor_valid')),
        row_ranges=ranges,gap_measured=gap is not None,
        gap_insertable=gap is not None and float(gap)>.001,
        local_state=local.get('state'),source_state=front.get('state'))


def observation_outcome(before, after):
    if after.get('resolved'):return 'resolved'
    gained=bool(set(after.get('coverage_verified_ids',[]))-set(before.get('coverage_verified_ids',[])))
    gained=gained or any(bool(after.get(k)) and not before.get(k) for k in ('front_clear','rear_clear','identity_anchor','gap_measured'))
    gained=gained or int(after.get('object_count',0))>int(before.get('object_count',0))
    old={r[0]:r for r in before.get('row_ranges',[])}
    for r in after.get('row_ranges',[]):
        a=old.get(r[0])
        if a is None and r[1]:gained=True
        elif a is not None and r[1]>a[1]:gained=True
        elif a is not None and r[5] is not None and a[5] is not None:
            # Existing source measurement uncertainty is 1.5mm. Movement below
            # that scale is not new spatial coverage.
            if r[5][0]<a[5][0]-.0015 or r[5][1]>a[5][1]+.0015:gained=True
    return 'informative_but_incomplete' if gained else 'uninformative'


class SourceViewPlanner:
    def __init__(self, vision):
        self.vision=vision
        self.checker=ObservationPathFeasibility(vision.config)
        self.ik=PublicPathIK(vision.robot_model,vision.config)
        self.reset()

    def reset(self):
        self.active=None

    def _regions(self, scene, request):
        v=self.vision; box=scene['source_box'];front=scene.get('source_frontier') or {}
        required=set((scene.get('source_path_observation_request') or {}).get('unknown_hypotheses',[]))
        objects=[o for o in (scene.get('source_geometry') or {}).get('objects',[]) if o.get('object_id') in required]
        if objects:
            regions=[]
            for col in sorted({o['source_column'] for o in objects}):
                entries=sorted([o for o in objects if o['source_column']==col],key=lambda o:o['row_hypothesis'])
                chunks=[]
                for o in entries:
                    if not chunks or o['row_hypothesis']>chunks[-1][-1]['row_hypothesis']+1:chunks.append([])
                    chunks[-1].append(o)
                for chunk in chunks:
                    rr=np.asarray(chunk[0]['rotation_world'],float);corners=[];samples=[]
                    for obj in chunk:
                        center=np.asarray(obj['center_world'],float);half=np.asarray(obj['half_size'],float)
                        uncertainty=obj.get('uncertainty_m') or {};hy=half[1]+float(uncertainty.get('row',.004));hx=half[0]+float(uncertainty.get('broad',.006))
                        corners.extend(np.array([[x,y,z] for x in (-hx,hx) for y in (-hy,hy) for z in (-half[2],half[2])])@rr.T+center)
                        samples.extend(np.array([[x,y,half[2]] for x in np.linspace(-hx,hx,7) for y in np.linspace(-hy,hy,7)])@rr.T+center)
                    regions.append(dict(name='path_neighbours:{}:{}-{}'.format(col,chunk[0]['row_hypothesis'],chunk[-1]['row_hypothesis']),
                        corners=np.asarray(corners),samples=np.asarray(samples),world_axis=rr[:,1],column=col,
                        object_ids=[o['object_id'] for o in chunk],expected_evidence=['current_neighbour_occupancy','row_centers','broad_edges','tilt_and_gap'],
                        basis='actual low swept pieces intersect these unverified public spatial hypotheses'))
            return regions
        c=np.asarray(box['center'],float);yaw=float(box.get('yaw',0.));co,si=np.cos(yaw),np.sin(yaw)
        rot=np.array([[co,-si,0.],[si,co,0.],[0.,0.,1.]])
        col=int(request.get('source_column',1));count=int(request.get('count',0));pitch=.008833333333333
        x=float(v.columns[col-1]-v.scene.source_bin_center_m[0]);top=float(v.scene.cookie_model_z_m+v.cookie_half[2])
        half=np.asarray(v.scene.source_bin_half_size_m,float)
        identity=front.get('observation_scope')=='full_column_identity' or not front.get('identity_anchor_valid',False)
        if front.get('frontier_center') is not None:
            first=float((np.asarray(front['frontier_center'])-np.r_[c[:2],0.])@rot[:,1])
        else:
            rows=v.layout[np.isclose(v.layout[:,0],v.columns[col-1])];first=float(rows[:,1].min()-v.scene.source_bin_center_m[1])
            first+=int(request.get('source_start_index',0))*pitch
        rear=first+max(count-1,0)*pitch
        boxes=[]
        def add(name,xlo,xhi,ylo,yhi,expected):
            corners=np.array([[xx,yy,zz] for zz in (top-.005,top+.005)
                for xx in (xlo,xhi) for yy in (ylo,yhi)])@rot.T+np.r_[c[:2],0.]
            sample=np.array([[xx,yy,top] for yy in np.linspace(ylo,yhi,24)
                for xx in np.linspace(xlo,xhi,7)])@rot.T+np.r_[c[:2],0.]
            boxes.append(dict(name=name,corners=corners,samples=sample,expected_evidence=expected,
                column=col,first_row_prior=first,world_axis=rot[:,1]))
        if identity:
            add('column_identity',-half[0]-.006,half[0]+.006,-half[1]-.015,half[1]+.015,
                ['source_box_walls','column_context','front_empty_band','ordered_row_prefix'])
        add('front_and_batch_end',x-v.cookie_half[0]-.006,x+v.cookie_half[0]+.006,first-.016,rear+pitch+.012,
            ['front_empty_band','first_object','batch_end','protected_rear_neighbour'])
        add('front_prefix',x-v.cookie_half[0]-.006,x+v.cookie_half[0]+.006,first-.018,first+min(count+1,8)*pitch+.012,
            ['front_empty_band','overlapping_ordered_prefix'])
        add('rear_gap',x-v.cookie_half[0]-.006,x+v.cookie_half[0]+.006,rear-.020,rear+pitch+.014,
            ['batch_end','protected_rear_neighbour','insertion_gap'])
        return boxes

    def _protected(self, scene):
        objects=[]
        for key,entry in (scene.get('target_occupancy') or {}).items():
            bounds=entry.get('bounds')
            if bounds is None or entry.get('occluded'):continue
            b=np.asarray(bounds,float)
            if b.shape!=(3,2):continue
            yaw=float(entry.get('box_yaw',(scene.get('target_box') or {}).get('yaw',0.)))
            rr=Rotation.from_rotvec([0.,0.,yaw]).as_matrix()
            center=np.asarray(entry.get('box_center',scene['target_box']['center']))+rr@b.mean(1)
            objects.append(dict(object_id='observed_target_column:'+str(key),frame='world',
                center_world=center,rotation_world=rr,half_size=np.diff(b,axis=1).ravel()/2))
        # Current source objects are obstacles for an empty-hand camera path.
        # The old layout frame supplies hypotheses, never empty-space evidence.
        front=scene.get('source_frontier') or {}
        if front.get('contact_epoch')==self.vision.v9_source_contact_epoch:
            for item in front.get('objects') or []:
                objects.append(dict(object_id=item.get('spatial_id','source_object'),frame='world',
                    center_world=item['center'],rotation_world=np.eye(3),half_size=self.vision.cookie_half))
        # Camera motion stays above the whole possible cookie volume. This
        # is a fixed-CAD observation keep-out prior, not claimed occupancy or
        # inferred empty space at unobserved source rows.
        box=scene.get('source_box') or {}
        if box.get('center') is not None:
            sourcehalf=np.asarray(self.vision.scene.source_bin_half_size_m,float)
            center=np.asarray(box['center'],float).copy();center[2]=float(self.vision.scene.cookie_model_z_m)
            yaw=float(box.get('yaw',0.));rr=Rotation.from_rotvec([0.,0.,yaw]).as_matrix()
            objects.append(dict(object_id='source_observation_CAD_occupied_volume_prior',frame='world',
                center_world=center,rotation_world=rr,
                half_size=[sourcehalf[0]+.025,sourcehalf[1]+.025,float(self.vision.cookie_half[2])],
                basis='possible cookie region for high observation motion; occupancy unknown'))
        return objects

    def plan(self, observation, cameras, scene, request):
        v=self.vision;stage=str(request.get('stage','')).upper();front=scene.get('source_frontier') or {}
        needed=bool(stage=='SOURCE_OBSERVE' or (scene.get('source_path_observation_request') or {}).get('unknown_hypotheses') or stage=='SELECT' and
            (front.get('requires_wrist_view') or float((scene.get('group') or {}).get('confidence',0.) or 0.)<.15))
        key=(int(request.get('source_column',1)),request.get('batch_index'),request.get('source_start_index'),
            int(request.get('count',0)),int(v.v9_source_contact_epoch),int(v.calibration_generation),
            tuple(np.round(np.asarray(v.wrist_mount,float),8)))
        key=key+(tuple(sorted((scene.get('source_path_observation_request') or {}).get('unknown_hypotheses',[]))),)
        context=repr(key);result=dict(needed=needed,valid=False,context_key=context,
            object_scope='source_observation_plan',measurement_id='source_view_plan:'+str(v.step),measurement_step=v.step,measurement_time=float(observation.get('time',0.)),
            camera='left_wrist',evidence=source_evidence(scene,request.get('count',0)))
        if not needed:return dict(result,reason='current source geometry is available')
        if stage=='SOURCE_OBSERVE' and request.get('source_view_active') and self.active is not None:
            return {**self.active,'evidence':result['evidence']}
        held=scene.get('held') or {};touch=np.asarray(observation.get('observation.force',np.zeros(18)))[12:14]
        if held.get('currently_held') is True or max(touch)>.15:
            return dict(result,reason='source observation needs current object-location/empty-hand evidence',outcome='partial')
        image=np.asarray(observation['observation.images.left_wrist']);camera=cameras['left_wrist']
        position,rotation=v._eef_rotation(observation);h,w=image.shape[:2]
        mask,_=v._v6_gripper_silhouette(camera,image.shape);mask=cv2.dilate(mask,np.ones((3,3),np.uint8))
        done={x.get('view_id') for x in request.get('source_view_history',[]) if x.get('context_key')==context and x.get('outcome') in ('informative_but_incomplete','uninformative','unreachable')}
        failures=[x for x in request.get('source_view_history',[]) if x.get('context_key')==context]
        reassociate=len(failures)>=3 and all(x.get('outcome') in ('uninformative','unreachable') for x in failures[-3:])
        result['escalation']='new_observation_direction_and_column_association_review' if reassociate else None
        result['development_escalation_default']=3
        canonical=np.array([[0.,0.,1.],[-1.,0.,0.],[0.,-1.,0.]])
        pitch=(0.,-15.,-35.,-35.)[key[0]-1];base=Rotation.from_rotvec([0.,np.deg2rad(pitch),0.]).as_matrix()@canonical
        rotations=[rotation,base]+[Rotation.from_rotvec([0.,0.,a]).as_matrix()@base for a in (-.18,.18)]
        if reassociate:rotations=[Rotation.from_rotvec([0.,0.,a]).as_matrix()@base for a in (-.35,.35,-.5,.5)]+rotations
        f=h/2/np.tan(np.deg2rad(camera['fovy'])/2)
        lower=np.array([(8-(w-1)/2)/f,((h-1)/2-(h-9))/f]);upper=np.array([((w-9)-(w-1)/2)/f,((h-1)/2-8)/f])
        candidates=[]
        for region_index,region in enumerate(self._regions(scene,request)):
            corners=region['corners'];look=corners.mean(0)
            for ri,rr in enumerate(rotations):
                change=rr@rotation.T;camrot=change@camera['rotation'];campos=position+change@(camera['pos']-position)
                relative=(corners-look)@camrot
                for ray_index,(ix,iy) in enumerate(((.5,.22),(.32,.30),(.68,.30),(.5,.40))):
                    rayxy=np.array([(ix*w-(w-1)/2)/f,((h-1)/2-iy*h)/f]);required=max(.07,float(relative[:,2].max()+.015))
                    for axis in range(2):
                        q=relative[:,axis];z=relative[:,2]
                        required=max(required,float(np.max((q+upper[axis]*z)/(upper[axis]-rayxy[axis]))),float(np.max(-(q+lower[axis]*z)/(rayxy[axis]-lower[axis]))))
                    for scale_index,scale in enumerate((1.05,1.2)):
                        view_id='{}:{}:{}:{}'.format(region['name'],ri,ray_index,scale_index)
                        if view_id in done:continue
                        depth=required*scale;desiredcam=look-camrot@np.r_[rayxy*depth,-depth];target=position+desiredcam-campos
                        if not np.all(np.isfinite(target)) or not .79<target[2]<1.10:continue
                        # Different labels can describe the same reached camera
                        # pose. Reuse the existing observation servo tolerance.
                        repeated=False
                        for prior in failures:
                            if prior.get('eef_position') is None or prior.get('eef_rotation') is None:continue
                            same_position=np.linalg.norm(target-np.asarray(prior['eef_position']))<=.0025
                            same_rotation=Rotation.from_matrix(np.asarray(prior['eef_rotation']).T@rr).magnitude()<=.07
                            if same_position and same_rotation:repeated=True;break
                        if repeated:continue
                        view=dict(camera,pos=desiredcam,rotation=camrot)
                        uv,z=_project(corners,view,image.shape)
                        if not np.all((z>0)&(uv[:,0]>8)&(uv[:,0]<w-9)&(uv[:,1]>8)&(uv[:,1]<h-9)):continue
                        sample,sd=_project(region['samples'],view,image.shape);ixy=np.rint(sample).astype(int)
                        inside=(sd>0)&(ixy[:,0]>=0)&(ixy[:,0]<w)&(ixy[:,1]>=0)&(ixy[:,1]<h)
                        visible=inside.copy();visible[inside]&=mask[ixy[inside,1],ixy[inside,0]]==0
                        coverage=float(visible.mean())
                        checkpitch=np.array([look,look+region['world_axis']*.008833333333333]);puv,_=_project(checkpitch,view,image.shape)
                        pixels=float(np.linalg.norm(puv[1]-puv[0]))
                        if coverage<.85 or pixels<4.:continue
                        cost=float(np.linalg.norm(target-position))+.05*float(Rotation.from_matrix(rotation.T@rr).magnitude())
                        candidates.append((region_index,cost,-coverage,view_id,target,rr,view,region,pixels))
        protected=self._protected(scene);checked=[];opening=float(np.asarray(observation['observation.state'])[7])
        pathscene={**scene,'path_scope':'empty_hand_observation'}
        for _,cost,negcoverage,view_id,target,rr,view,region,pixels in sorted(candidates,key=lambda a:a[:3]):
            high=max(float(position[2]),float(target[2]));rise=position.copy();rise[2]=high;above=target.copy();above[2]=high
            nodes=[dict(name='source_view_rise',position=rise,rotation=rotation,opening=opening,carrying=False,box_key='source_box'),
                dict(name='source_view_translate',position=above,rotation=rr,opening=opening,carrying=False,box_key='source_box')]
            if abs(target[2]-high)>.0001:nodes.append(dict(name='source_view_settle',position=target,rotation=rr,opening=opening,carrying=False,box_key='source_box'))
            sweep=self.checker.check_path(observation,nodes,None,pathscene,protected_objects=protected)
            receipt=dict(view_id=view_id,path_state=sweep['state'],reason=sweep.get('reason'),conflicts=sweep.get('conflicts',[])[:2])
            if sweep['state']!='feasible':checked.append(receipt);continue
            ik=self.ik.check_ik_path(observation,nodes,position_tolerance_m=.0025,rotation_tolerance_rad=.07);receipt['ik']=ik
            if ik['state']!='reachable':checked.append(receipt);continue
            actual=self.ik.last_fk_path[-1];acamera=dict(camera,pos=actual['position']+actual['rotation']@rotation.T@(camera['pos']-position),rotation=actual['rotation']@rotation.T@camera['rotation'])
            uv,z=_project(region['corners'],acamera,image.shape)
            if not np.all((z>0)&(uv[:,0]>8)&(uv[:,0]<w-9)&(uv[:,1]>8)&(uv[:,1]<h-9)):
                checked.append(dict(receipt,reason='actual FK view clips required source region'));continue
            actualnodes=[dict(**node,opening=opening,carrying=False,box_key='source_box') for node in self.ik.last_fk_path]
            actualsweep=self.checker.check_path(observation,actualnodes,None,pathscene,protected_objects=protected)
            if actualsweep['state']!='feasible':checked.append(dict(receipt,actual_fk_path=actualsweep['state']));continue
            result.update(valid=True,issue=region['name'],view_id=view_id,expected_evidence=region['expected_evidence'],
                eef_position=target.tolist(),eef_rotation=rr.tolist(),required_object_ids=region.get('object_ids',[]),region_world_corners=region['corners'].tolist(),
                waypoints=[dict(name=node['name'],position=np.asarray(node['position']).tolist(),rotation=np.asarray(node['rotation']).tolist()) for node in nodes],
                predicted_unoccluded_fraction=-negcoverage,pixels_per_pitch=pixels,actual_fk_complete=True,
                path_state=sweep['state'],actual_fk_path_state=actualsweep['state'],ik=ik,candidate_checks=checked,
                reason='source evidence region fits calibrated camera FOV and reachable full empty-hand path')
            self.active=dict(result);return result
        return dict(result,reason='finite source views lack a reachable clear evidence region',outcome='unreachable',candidate_count=len(candidates),candidate_checks=checked)


class ObservationPathFeasibility(PathFeasibility):
    """Keep the original physical sweep; empty-hand views need no release chain."""
    def check_path(self, observation, waypoints, actual_envelope, public_scene, **kwargs):
        report=super().check_path(observation,waypoints,actual_envelope,public_scene,**kwargs)
        missing="supplied path omits a descend, release-opening or post-release withdrawal segment"
        empty=bool(waypoints) and all(not p.get("carrying",True) for p in waypoints)
        if public_scene.get("path_scope")=="empty_hand_observation" and empty and actual_envelope is None and report.get("state")=="unknown" and report.get("reason")==missing:
            report.update(state="feasible",status="feasible",reason="complete empty-hand observation sweep clears supplied geometry",full_path_status="observation_path_checked",next_action="execute_and_verify")
        return report

class PublicPathIK:
    """Official fixed-model IK over an entire public-observation path."""
    def __init__(self,model,config,path_checker=None):
        from a3_dual_arm_sim.sim.actions import CartesianDeltaAdapter
        from a3_dual_arm_sim.contracts import LEFT_JOINTS,RIGHT_JOINTS
        self.model=model;self.config=config;self.path_checker=path_checker
        self.adapter=CartesianDeltaAdapter(model,config)
        self.qids=[int(model.jnt_qposadr[mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_JOINT,n)]) for n in (*LEFT_JOINTS,*RIGHT_JOINTS)]
        self.fingers=[[int(model.jnt_qposadr[mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_JOINT,f'{side}_finger_{finger}_joint')]) for finger in ('inner','outer')] for side in ('L','R')]
        self.site=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_SITE,'L_eef')
        self.base=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_GEOM,'L_2f85_base_collision')

    def public_kinematics(self,observation):
        state=np.asarray(observation['observation.state'],float)
        work=self.adapter._work
        work.qpos[self.qids]=np.r_[state[:7],state[8:15]]
        for i,opening in enumerate((state[7],state[15])):work.qpos[self.fingers[i]]=(1-np.clip(opening,0,1))*.0425
        mujoco.mj_kinematics(self.model,work)
        return work,state[:7].copy()

    def check_ik_path(self,observation,waypoints,*,position_tolerance_m=.0008,rotation_tolerance_rad=.015):
        from scipy.spatial.transform import Rotation,Slerp
        work,q=self.public_kinematics(observation);max_position=max_angle=max_joint_delta=0.;samples=0;self.last_fk_path=[]
        if not waypoints:return dict(state='unknown',reason='no waypoints supplied')
        public=np.asarray(observation['observation.eef_pose'],float)[:7]
        nodes=[dict(name='public_current',position=public[:3],rotation=Rotation.from_quat(np.r_[public[4:7],public[3]]).as_matrix())]
        nodes.extend({**point,'name':point.get('name',f'waypoint_{i}'),
            'position':np.asarray(point['position'],float),'rotation':np.asarray(point['rotation'],float).reshape(3,3)} for i,point in enumerate(waypoints))
        for start,end in zip(nodes[:-1],nodes[1:]):
            length=float(np.linalg.norm(end['position']-start['position']))
            angle=float(np.linalg.norm(Rotation.from_matrix(start['rotation'].T@end['rotation']).as_rotvec()))
            steps=max(1,int(np.ceil(length/.012)),int(np.ceil(angle/.08)))
            slerp=Slerp([0.,1.],Rotation.from_matrix(np.array([start['rotation'],end['rotation']])))
            for t in np.linspace(0.,1.,steps+1)[1:]:
                position=(1-t)*start['position']+t*end['position'];rotation=slerp(t).as_matrix();quat=np.empty(4)
                mujoco.mju_mat2Quat(quat,rotation.ravel());previous=q.copy();q=self.adapter.solve(position,quat,q)
                work.qpos[list(self.adapter._qpos_ids[0])]=q;mujoco.mj_kinematics(self.model,work)
                actual=np.empty(4);error=np.empty(3);mujoco.mju_mat2Quat(actual,work.site_xmat[self.site]);mujoco.mju_subQuat(error,quat,actual)
                position_error=float(np.linalg.norm(work.site_xpos[self.site]-position));angle_error=float(np.linalg.norm(error));samples+=1
                max_position=max(max_position,position_error);max_angle=max(max_angle,angle_error);max_joint_delta=max(max_joint_delta,float(np.max(abs(q-previous))))
                self.last_fk_path.append(dict(name=f'actual_ik_{samples}',position=work.site_xpos[self.site].copy(),rotation=work.site_xmat[self.site].reshape(3,3).copy()))
                if not np.all(np.isfinite(q)) or position_error>position_tolerance_m or angle_error>rotation_tolerance_rad:
                    return dict(state='unreachable',segment=[start['name'],end['name']],position_error_m=position_error,
                        rotation_error_rad=angle_error,samples=samples,criterion=f'position {position_tolerance_m}m / rotation {rotation_tolerance_rad}rad FK residual')
        return dict(state='reachable',max_position_error_m=max_position,max_rotation_error_rad=max_angle,
            max_sample_joint_delta_rad=max_joint_delta,samples=samples,criterion=f'sampled path: {position_tolerance_m}m / {rotation_tolerance_rad}rad; fixed kinematics only')

