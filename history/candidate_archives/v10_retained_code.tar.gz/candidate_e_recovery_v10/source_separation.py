"""One-millimetre source-side contact primitive from public evidence.

The retained source-fit envelope is an attachment hypothesis, never a held-pose
measurement. This branch preserves the parent's count/held/target estimators.
"""
from __future__ import annotations
import itertools
import copy
import numpy as np
from scipy.spatial.transform import Rotation
from public_visibility import (public_gripper_meshes, triangle_occlusion,
                               _camera_points, _project_camera, BOX_FACES)
from legacy.path_feasibility import PublicPathIK

DISTANCE_M=.001
POSITION_TOLERANCE_M=.00015


def pose(observation):
    p=np.asarray(observation['observation.eef_pose'],float)[:7]
    return p[:3],Rotation.from_quat(np.r_[p[4:7],p[3]]).as_matrix()


def capture_attachment(observation,scene,request,cookie_half):
    group=scene.get('group') or {}
    if int(request.get('source_column',0))!=1 or int(request.get('count',0))!=5:return None
    if group.get('center') is None or float(group.get('confidence',0.) or 0.)<.6:return None
    p,r=pose(observation);rotation=np.asarray(group.get('rotation',np.eye(3)),float)
    center=np.asarray(group['center'],float)
    half=np.asarray(cookie_half,float).copy();half[1]=float(group.get('width_m',5*2*half[1]))/2
    return dict(center_tool=r.T@(center-p),rotation_tool=r.T@rotation,half_size=half,
        source_box=scene.get('source_box'),batch_index=int(request['batch_index']),
        source_column=1,measurement_id=group.get('measurement_id'),
        measurement_time=observation.get('time'),source_fit_confidence=float(group['confidence']),
        geometry_version=group.get('geometry_version'),grasp_eef_position=p.copy(),
        basis='RGB source-group fit at actual closing EEF; rigid attachment hypothesis under verified count and bilateral touch',
        pose_state='attachment_hypothesis',position_error_m=group.get('position_error_m'))


class SourceSeparation:
    def __init__(self,vision,checker):
        self.vision=vision;self.checker=checker
        self.ik=PublicPathIK(vision.robot_model,vision.config,checker)
        self.source_spaces={}

    def _outside_space(self,observation,box,world,error):
        yaw=float(box.get('yaw',0.));c,s=np.cos(yaw),np.sin(yaw)
        frame=np.asarray(box.get('rotation',[[c,-s,0],[s,c,0],[0,0,1]]),float)
        origin=np.asarray(box['center'],float)
        local=(world-origin)@frame
        floor=float(self.vision.scene.source_floor_z_m)
        inner=np.asarray(self.vision.scene.source_bin_half_size_m,float)[:2]-float(self.vision.scene.bin_wall_thickness_m)
        # Floor strip immediately outside the observed body. The conservative
        # retained payload hull is included in occlusion without invented confidence.
        xs=local[:,0].min()-np.array([.002,.004,.006])
        ys=np.linspace(local[:,1].min(),local[:,1].max(),7)
        sample=np.array([[x,y,floor+.0005-origin[2]] for x in xs for y in ys])
        inside=(sample[:,0]>-inner[0]+.0005)&(np.abs(sample[:,1])<inner[1]-.0005)
        points=sample@frame.T+origin
        cameras=self.vision._robot_cameras(observation)
        cameras['left_wrist']=self.vision._v6_wrist_camera(cameras['left_wrist'],observation)
        cameras={name:self.vision._adjust_camera(camera,self.vision.camera_adjustments.get(name,np.zeros(7)))
                 for name,camera in cameras.items()}
        cover=(np.asarray(list(itertools.product((-1.,1.),repeat=3)))*
            ((world.max(0)-world.min(0))/2+error)+world.mean(0))
        meshes=public_gripper_meshes(self.vision,observation)+[(cover,BOX_FACES)]
        free=np.zeros(len(points),bool);visible=np.zeros(len(points),bool);views=[]
        for name in ('front','left_wrist','right_wrist'):
            key='observation.images.'+name
            if key not in observation:continue
            image=np.asarray(observation[key]);camera=cameras[name]
            uv,depth=_project_camera(_camera_points(points,camera),camera,image.shape)
            valid=inside&(depth>1e-4)&(uv[:,0]>1)&(uv[:,0]<image.shape[1]-2)&(uv[:,1]>1)&(uv[:,1]<image.shape[0]-2)
            ids=np.flatnonzero(valid)
            if not len(ids):continue
            occ=triangle_occlusion(uv[ids],depth[ids],meshes,camera,image.shape)
            ids=ids[~occ]
            if not len(ids):continue
            pixel=np.rint(uv[ids]).astype(int);rgb=image[pixel[:,1],pixel[:,0]].astype(float)
            # Gray source-floor appearance; yellow/cocoa/green cookie pixels do
            # not certify free space. Black/shadow and CAD-occluded samples remain unknown.
            gray=(np.ptp(rgb,axis=1)<=.22*np.maximum(rgb.max(1),1))&(rgb.mean(1)>65)
            visible[ids]=True;free[ids[gray]]=True
            views.append(dict(camera=name,visible_samples=len(ids),floor_supported_samples=int(gray.sum())))
        supported_rows=np.unique(np.flatnonzero(free)%len(ys))
        certificate=dict(samples=len(points),visible_samples=int(visible.sum()),floor_supported_samples=int(free.sum()),
            supported_rows=len(supported_rows),views=views,unknown_samples=int((~visible).sum()),
            payload_occlusion_basis='conservative retained source attachment hull, not a new held measurement')
        return certificate

    def remember_source_space(self,observation,scene,request):
        group=scene.get('group') or {};box=scene.get('source_box') or {}
        if (int(request.get('source_column',0))!=1 or int(request.get('count',0))!=5 or
                group.get('center') is None or float(group.get('confidence',0.) or 0.)<.6 or
                box.get('center') is None or float(box.get('confidence',0.) or 0.)<.6):return None
        half=np.asarray(self.vision.cookie_half,float).copy()
        half[1]=float(group.get('width_m',5*2*half[1]))/2
        world=(np.asarray(list(itertools.product((-1.,1.),repeat=3)))*half)@np.asarray(group.get('rotation',np.eye(3)),float).T+np.asarray(group['center'],float)
        error=max(0.,float(group.get('position_error_m') or 0.))
        certificate=self._outside_space(observation,box,world,error)
        broad=group.get('broad_measurement') or {}
        edge_supported=(broad.get('observable') is True and broad.get('outer_edge_observed') is True and
            float(broad.get('confidence',0.) or 0.)>=.6 and int(broad.get('observed_rows',0))>=2)
        certificate.update(measurement_time=observation.get('time'),measurement_step=self.vision.step,
            measurement_id=group.get('measurement_id'),observation_stage=request.get('stage'),
            outer_edge_supported=edge_supported,outer_edge_measurement=copy.deepcopy(broad),
            support_kind='observed_outer_edge_contact_corridor' if edge_supported else 'floor_strip',
            basis='same-batch RGB source outer-edge transition and fixed outer-column layout; floor visibility recorded separately; bounded contact primitive')
        if edge_supported or certificate['supported_rows']>=4 and certificate['floor_supported_samples']>=6:
            self.source_spaces[int(request['batch_index'])]=dict(group=copy.deepcopy(group),box=copy.deepcopy(box),
                certificate=certificate,world_vertices=world.copy(),position_error_m=error)
        return certificate

    def attachment(self,observation,scene,request):
        cached=self.source_spaces.get(int(request['batch_index']))
        if cached is None:return capture_attachment(observation,scene,request,self.vision.cookie_half)
        attachment=capture_attachment(observation,{**scene,'group':cached['group']},request,self.vision.cookie_half)
        if attachment is not None:
            attachment.update(source_geometry_measurement_time=cached['certificate']['measurement_time'],
                source_geometry_measurement_step=cached['certificate']['measurement_step'])
        return attachment

    def plan(self,observation,scene,request,attachment):
        result=dict(valid=False,reason='source separation is not applicable',requested_m=DISTANCE_M,
                    basis=None if attachment is None else attachment['basis'],pose_state='attachment_hypothesis')
        if int(request.get('source_column',0))!=1 or int(request.get('count',0))!=5:return result
        if attachment is None or attachment['batch_index']!=int(request['batch_index']):return result
        held=scene.get('held') or {};touch=np.maximum(np.asarray(observation.get('observation.force',np.zeros(18)))[12:14],0)
        if held.get('count')!=5 or float(held.get('count_confidence',0.) or 0.)<.6 or min(touch)<.1:
            return {**result,'reason':'count-follow and bilateral touch do not support the attachment hypothesis'}
        box=scene.get('source_box') or attachment.get('source_box') or {}
        if box.get('center') is None or float(box.get('confidence',0.) or 0.)<.6:
            return {**result,'reason':'source box frame is unobserved'}
        yaw=float(box.get('yaw',0.));c,s=np.cos(yaw),np.sin(yaw)
        frame=np.asarray(box.get('rotation',[[c,-s,0],[s,c,0],[0,0,1]]),float)
        origin=np.asarray(box['center'],float);outward=-frame[:,0]
        p,r=pose(observation);target=p+DISTANCE_M*outward
        corners=np.asarray(list(itertools.product((-1.,1.),repeat=3)))*attachment['half_size']
        tool=corners@attachment['rotation_tool'].T+attachment['center_tool']
        world=tool@r.T+p;local=(world-origin)@frame
        floor=float(self.vision.scene.source_floor_z_m)
        if local[:,2].min()>floor+2*float(self.vision.cookie_half[2]):
            return {**result,'reason':'current group is outside the low source-lift contact region'}
        inner=np.asarray(self.vision.scene.source_bin_half_size_m,float)[:2]-float(self.vision.scene.bin_wall_thickness_m)
        if local[:,0].min()-DISTANCE_M<=-inner[0]:
            return {**result,'reason':'source outer wall leaves no requested separation space'}
        certificate=self._outside_space(observation,box,world,max(0.,float(attachment.get('position_error_m') or 0.)))
        cached=self.source_spaces.get(int(request['batch_index']))
        if (certificate['supported_rows']<4 or certificate['floor_supported_samples']<6) and cached is not None:
            old=cached['world_vertices']
            shift=float(np.linalg.norm(world.mean(0)[:2]-old.mean(0)[:2]))
            if shift<=max(cached['position_error_m'],float(attachment.get('position_error_m') or 0.)):
                certificate={**copy.deepcopy(cached['certificate']),'retained_same_batch':True,
                    'current_xy_shift_from_observed_m':shift,'current_occluded_support':certificate}
        result.update(outer_space=certificate,outward_world=outward,target=target,rotation=r,
            attachment=attachment,touch=touch,source_frame=frame,source_box=box)
        if not certificate.get('outer_edge_supported') and (certificate['supported_rows']<4 or certificate['floor_supported_samples']<6):
            return {**result,'reason':'outside floor strip lacks current unoccluded RGB support'}
        opening=float(np.asarray(observation['observation.state'])[7])
        node=dict(position=target,rotation=r,opening=opening,carrying=True,box_key='source_box',name='source_outward_separation')
        high=request.get('source_lift_target')
        if high is None:
            high=np.asarray(request['preinsert_position'],float)+[0,0,max(.04,float(self.vision.scene.source_bin_wall_height_m)+.014)-.024]
        lift_position=target.copy();lift_position[2]=float(np.asarray(high,float)[2])
        lift={**node,'position':lift_position,'rotation':np.asarray(request['preinsert_rotation'],float),
            'name':'source_separated_lift'}
        envelope=dict(center_tool=attachment['center_tool'],rotation_tool=attachment['rotation_tool'],half_size=attachment['half_size'])
        geometry=self.checker.check_path(observation,[node,lift],envelope,
            dict(source_box=box,path_scope='loaded_source_separation'),protected_objects=[])
        ik=self.ik.check_ik_path(observation,[node,lift],position_tolerance_m=.0008,rotation_tolerance_rad=.015)
        result.update(path=geometry,ik=ik)
        if geometry['state']!='feasible' or ik['state']!='reachable':
            return {**result,'reason':'short source separation has no verified CAD/IK path'}
        return {**result,'valid':True,'reason':'observed source outer-edge corridor and short loaded CAD/IK path support limited contact separation'}
