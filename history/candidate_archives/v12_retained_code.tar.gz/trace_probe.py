#!/usr/bin/env python3
"""Compact probe over an A3 rule-policy policy_trace JSONL (read-only).

Usage: python trace_probe.py TRACE.jsonl [START] [END] [--full]
Prints one line per row: step, phase, stage, batch, count, target column,
held flag, occupancy entries (count / y-bounds / measurement step), action
prefix, and selected diagnostics (held slip, path/recovery reasons).
"""
import json
import sys


def bound_y(entry):
    bounds = entry.get('bounds') if isinstance(entry, dict) else None
    if not bounds:
        return None
    return (round(float(bounds[1][0]), 3), round(float(bounds[1][1]), 3))


def main():
    path = sys.argv[1]
    start = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    end = int(sys.argv[3]) if len(sys.argv) > 3 else 10 ** 9
    with open(path) as handle:
        for index, line in enumerate(handle):
            if index < start:
                continue
            if index > end:
                break
            row = json.loads(line)
            perception = row.get('perception') or {}
            request = row.get('request') or {}
            held = perception.get('held') or {}
            occupancy = perception.get('target_occupancy') or {}
            occ_fmt = {}
            for key, entry in occupancy.items():
                if isinstance(entry, dict):
                    occ_fmt[key] = (entry.get('count'), bound_y(entry), entry.get('measurement_step'), entry.get('camera'))
                else:
                    occ_fmt[key] = entry
            action = row.get('action')
            if isinstance(action, list):
                action_fmt = [round(float(a), 3) for a in action[:7]]
            else:
                action_fmt = action
            placement = perception.get('placement') or {}
            line_out = dict(
                i=index, step=row.get('step'), phase=row.get('phase'),
                stage=request.get('stage'), batch=request.get('batch_index'),
                count=request.get('count'), tcol=request.get('target_column'),
                held=held.get('currently_held'), slip=perception.get('slip_m'),
                occ=occ_fmt, act=action_fmt,
                place=(placement.get('count'), placement.get('confidence')),
                loc=(perception.get('object_location') or {}).get('state'),
            )
            print(json.dumps(line_out, ensure_ascii=False))


if __name__ == '__main__':
    main()
