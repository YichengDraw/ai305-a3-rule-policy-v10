#!/usr/bin/env python3
"""Analyze the W1b 127-case expansion replay against the frozen-V10 (NoYCommon)
parent 127-case CPU results.

Parent source: source_broad_r3_related127_NoY_parent_raw.json (groups with
cases[].result). Candidate source: the replay root (case dirs with result.json,
labels from protocol.json jobs).

Emits per-case deltas, gained/lost successes, quantity regressions, W1b write-
protocol trigger counts (creation gate / ROI refutation / conflict states), and
a markdown summary. Read-only: writes only into the output directory given.

Usage: python analyze_w1b_expand127.py REPLAY_ROOT PARENT_RAW_JSON OUT_DIR
"""
import json
import sys
from pathlib import Path

TRIGGER_STATES = (
    'creation_requires_conflict_free_support',
    'prior_refuted_by_independent_roi_free',
    'conflicting_views',
    'empty_requires_independent_confirmation',
    'partially_observed',
)


def load_parent(path):
    rows = {}
    data = json.loads(Path(path).read_text())
    for group in data.get('groups', []):
        for case in group.get('cases', []):
            label = case.get('label')
            result = case.get('result') or {}
            if label and result:
                rows[label] = dict(score=result.get('score'), success=result.get('success'),
                                   steps=result.get('steps'), source=result.get('cookies_in_source'),
                                   phase=result.get('phase'), task=case.get('task'),
                                   profile=case.get('profile'), n=case.get('n'),
                                   source_column=case.get('source_column'), seed=case.get('seed'))
    return rows


def count_triggers(case_dir):
    trace_dir = case_dir / 'policy_trace'
    counts = {state: 0 for state in TRIGGER_STATES}
    trace_found = False
    if trace_dir.exists():
        for path in sorted(trace_dir.glob('seed_*.jsonl')):
            trace_found = True
            with path.open() as handle:
                for line in handle:
                    try:
                        row = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    columns = (((row.get('perception') or {}).get('target_visibility')) or {}).get('columns') or {}
                    for diag in columns.values():
                        if isinstance(diag, dict):
                            state = diag.get('state')
                            if state in counts:
                                counts[state] += 1
    counts['trace_found'] = trace_found
    counts['triggered'] = sum(counts[s] for s in TRIGGER_STATES)
    return counts


def main():
    root = Path(sys.argv[1])
    parent = load_parent(sys.argv[2])
    out_dir = Path(sys.argv[3])
    out_dir.mkdir(parents=True, exist_ok=True)
    protocol = json.loads((root / 'protocol.json').read_text())
    cases = []
    for job in protocol.get('jobs', []):
        label = job['label']
        result_path = root / label / 'result.json'
        if result_path.exists():
            result = json.loads(result_path.read_text())
            current = dict(score=result.get('score'), success=result.get('success'),
                           steps=result.get('steps'), source=result.get('cookies_in_source'),
                           phase=result.get('phase'))
        else:
            current = dict(score=None, success=None, steps=None, source=None, phase='MISSING')
        row = dict(label=label, task=job.get('task'), profile=job.get('profile'), n=job.get('n'),
                   source_column=job.get('source_column'), seed=job.get('seed'),
                   max_steps=job.get('max_steps'))
        row.update({f'candidate_{k}': v for k, v in current.items()})
        p = parent.get(label)
        if p:
            row.update({f'parent_{k}': v for k, v in p.items()})
            row['score_delta'] = None if current['score'] is None else current['score'] - p['score']
            row['success_change'] = None if current['success'] is None else int(bool(current['success'])) - int(bool(p['success']))
        else:
            row['parent_score'] = None
            row['parent_success'] = None
            row['parent_steps'] = None
            row['score_delta'] = None
            row['success_change'] = None
        row['triggers'] = count_triggers(root / label)
        cases.append(row)

    gained = [c['label'] for c in cases if c.get('success_change') == 1]
    lost = [c['label'] for c in cases if c.get('success_change') == -1]
    regressions = [c['label'] for c in cases if (c.get('score_delta') or 0) < 0]
    missing = [c['label'] for c in cases if c.get('candidate_score') is None]
    score_sum_delta = sum(c.get('score_delta') or 0 for c in cases)
    triggered = [c['label'] for c in cases if c['triggers'].get('triggered')]
    creation_gate = [c['label'] for c in cases if c['triggers'].get('creation_requires_conflict_free_support')]
    refuted = [c['label'] for c in cases if c['triggers'].get('prior_refuted_by_independent_roi_free')]
    parent_total = sum(c.get('parent_score') or 0 for c in cases)
    candidate_total = sum(c.get('candidate_score') or 0 for c in cases)
    parent_success = sum(int(bool(c.get('parent_success'))) for c in cases if c.get('parent_success') is not None)
    candidate_success = sum(int(bool(c.get('candidate_success'))) for c in cases if c.get('candidate_success') is not None)

    lines = ['# W1b 127例扩展对比（候选 vs 冻结V10 NoYCommon 父版同CPU）', '',
             f'- 回放根：{root}', f'- 父版原件：{sys.argv[2]}',
             f'- 例数：{len(cases)}（缺失 {len(missing)}）',
             f'- 数量：父 {parent_total} → 候选 {candidate_total}（Δ {score_sum_delta:+d}）',
             f'- 官方成功：父 {parent_success} → 候选 {candidate_success}（新增 {len(gained)}，丢失 {len(lost)}）',
             f'- 数量回退：{len(regressions)} 例',
             f'- 写协议实际触发：{len(triggered)} 例（创建门 {len(creation_gate)}，ROI反驳 {len(refuted)}）', '',
             '| label | profile | n | parent | candidate | Δscore | success | steps p→c | creation | refuted | conflict |',
             '|---|---|---:|---:|---:|---:|---|---:|---:|---:|---:|']
    for c in sorted(cases, key=lambda x: (x.get('score_delta') or 0, str(x['label']))):
        t = c['triggers']
        lines.append(f"| {c['label']} | {c.get('profile')} | {c.get('n')} | {c.get('parent_score')} | {c.get('candidate_score')} | {c.get('score_delta')} | {c.get('parent_success')}→{c.get('candidate_success')} | {c.get('parent_steps')}→{c.get('candidate_steps')} | {t.get('creation_requires_conflict_free_support')} | {t.get('prior_refuted_by_independent_roi_free')} | {t.get('conflicting_views')} |")
    report = dict(summary=dict(total=len(cases), missing=missing, gained_successes=gained, lost_successes=lost,
                               quantity_regressions=regressions, score_sum_delta=score_sum_delta,
                               parent_quantity=parent_total, candidate_quantity=candidate_total,
                               parent_success=parent_success, candidate_success=candidate_success,
                               triggered_cases=triggered, creation_gate_cases=creation_gate,
                               roi_refuted_cases=refuted), cases=cases)
    (out_dir / 'w1b_expand127_report.json').write_text(json.dumps(report, indent=2, ensure_ascii=False))
    (out_dir / 'w1b_expand127_report.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps(report['summary'], indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
