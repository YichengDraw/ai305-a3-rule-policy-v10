#!/usr/bin/env python3
"""Classify failure mechanisms at the end of A3 replay traces (read-only).

For each case directory the last N trace rows are inspected: frozen (zero)
actions, held state, final phase/stage, stored target-occupancy entries with
their measurement age, and the target column of the pending batch. This is a
triage aid; it does not score anything and does not touch official results.

Usage: python classify_failures.py REPLAY_ROOT [LABEL ...]
"""
import json
import subprocess
import sys
from collections import deque
from pathlib import Path

TAIL_ROWS = 400


def tail_rows(path, count=TAIL_ROWS):
    with open(path, 'rb') as handle:
        handle.seek(0, 2)
        size = handle.tell()
        block = max(4 * 1024 * 1024, size // 4)
        pos = size
        data = b''
        while pos > 0 and data.count(b'\n') <= count + 2:
            step = min(block, pos)
            pos -= step
            handle.seek(pos)
            data = handle.read(step) + data
        lines = data.split(b'\n')
        out = []
        for line in lines[-(count + 1):]:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                pass
        return out


def case_dirs(root):
    for entry in sorted(Path(root).iterdir()):
        if not entry.is_dir():
            continue
        trace = entry / 'policy_trace'
        if trace.is_dir():
            yield entry


def summarize(case):
    result_path = case / 'result.json'
    result = json.loads(result_path.read_text()) if result_path.exists() else {}
    trace_files = sorted((case / 'policy_trace').glob('seed_*.jsonl'))
    if not trace_files:
        return None
    rows = tail_rows(trace_files[0])
    if not rows:
        return None
    last = rows[-1]
    perception = last.get('perception') or {}
    request = last.get('request') or {}
    occupancy = perception.get('target_occupancy') or {}
    occ = {}
    pending_column = request.get('target_column')
    for key, entry in occupancy.items():
        if not isinstance(entry, dict):
            continue
        bounds = entry.get('bounds') or None
        occ[key] = dict(count=entry.get('count'), y=None if not bounds else [round(float(bounds[1][0]), 4), round(float(bounds[1][1]), 4)], measured=entry.get('measurement_step'), camera=entry.get('camera'))
    zeros = 0
    frozen_start = None
    for row in reversed(rows):
        action = row.get('action')
        zero = isinstance(action, list) and all(abs(float(a)) < 1e-6 for a in action[:6])
        if zero:
            zeros += 1
            frozen_start = row.get('step')
        else:
            break
    phases = []
    for row in rows[-80:]:
        phase = (row.get('phase'), (row.get('request') or {}).get('stage'))
        if not phases or phases[-1] != phase:
            phases.append(phase)
    entry = occ.get(str(pending_column)) if pending_column is not None else None
    stale = bool(entry) and entry.get('measured') is not None and (last.get('step') or 0) - entry['measured'] > 300
    return dict(label=case.name, score=result.get('score'), success=result.get('success'), steps=result.get('steps'),
                source=result.get('cookies_in_source'), phase=result.get('phase') or last.get('phase'),
                last_step=last.get('step'), last_phase=last.get('phase'), last_stage=request.get('stage'),
                batch=request.get('batch_index'), count=request.get('count'), pending_column=pending_column,
                held=(perception.get('held') or {}).get('currently_held'), slip=perception.get('slip_m'),
                frozen_rows=zeros, frozen_start_step=frozen_start, occupancy=occ,
                pending_column_entry=entry, pending_column_stale=stale,
                phase_tail=['/'.join(str(x) for x in p) for p in phases[-6:]])


def main():
    root = Path(sys.argv[1])
    wanted = set(sys.argv[2:])
    out = []
    for case in case_dirs(root):
        if wanted and case.name not in wanted:
            continue
        row = summarize(case)
        if row:
            out.append(row)
    out.sort(key=lambda r: (r['score'] if r['score'] is not None else -1))
    for row in out:
        print(json.dumps(row, ensure_ascii=False))
    frozen = [r['label'] for r in out if r['frozen_rows'] >= 100]
    print(json.dumps(dict(total=len(out), frozen=frozen, held_frozen=[r['label'] for r in out if r['frozen_rows'] >= 100 and r['held']])), file=sys.stderr)


if __name__ == '__main__':
    main()
