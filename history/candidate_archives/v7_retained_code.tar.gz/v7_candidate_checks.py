"""Data-only verification for the isolated full and alignment-only candidates."""
import json
import mujoco
import numpy as np
import controller_contract_checks as helper
import v7_controller_checks
from controller_r3 import RuleController as Full
from controller_align_only import RuleController as Align


def run():
    helper.RuleController=Full
    full=v7_controller_checks.run()
    c,obs,scene=helper.setup('b')
    first,second=helper.public_held_samples()
    scene['held']={**first,'age_steps':0,'pose_state':'measured','measurement_current':True}
    obs['observation.force'][12:14]=1.3
    c._advance('TRANSPORT');c.act(obs,scene)
    frozen=tuple(x.copy() for x in c._transport_goal)
    scene['held']={**second,'age_steps':0,'pose_state':'measured','measurement_current':True}
    obs['observation.eef_pose'][0]+=.005
    c.act(obs,scene)
    assert c.stage=='TRANSPORT'
    assert all(np.allclose(x,y) for x,y in zip(frozen,c._transport_goal))
    full['checks'].append('new view-dependent held refits do not move the frozen transfer position or rotation')
    full['passed']+=1
    # Check the low-confidence target gate from an actually reached high pose.
    c,obs,scene=helper.setup('b');scene['held']={**first,'age_steps':0,'pose_state':'measured','measurement_current':True}
    obs['observation.force'][12:14]=1.3
    scene['target_box'].update(confidence=.5,visible=False,occluded=True)
    c._target_box_reference=dict(scene['target_box'])
    c._advance('TRANSPORT');c.act(obs,scene)
    position,rotation=c._transport_goal
    obs['observation.eef_pose'][:3]=position
    q=np.empty(4);mujoco.mju_mat2Quat(q,rotation.ravel());obs['observation.eef_pose'][3:7]=q
    c.act(obs,scene)
    assert c.stage=='PREPLACE_OBSERVE'
    obs['observation.eef_pose'][:3]=c._preplace_view[0]
    mujoco.mju_mat2Quat(q,c._preplace_view[1].ravel());obs['observation.eef_pose'][3:7]=q
    scene['target_box'].update(confidence=.8,visible=True,occluded=False,anchor_confirmed=True)
    c.act(obs,scene);c.act(obs,scene)
    assert c.stage=='TRANSPORT' and c._preplace_checked
    full['checks'].append('reached high pose with an uncertain target gets a bounded new observation before descent')
    full['passed']+=1
    helper.RuleController=Align
    c,obs,scene=helper.setup('b')
    obs['observation.eef_pose'][:3]=c._preinsert
    pad=obs['observation.eef_pose'][:3]+c._pick_rotation@np.array([0.,-.014676,0.])
    scene['local_align']={'state':'correct','confidence':.8,'desired_pad_mid_world':pad+[.006,.001,0.],
        'observable_axis_world':[0.,1.,0.],'broad_axis_world':[1.,0.,0.],'measurement_id':'xy'}
    c._advance('LOCAL_ALIGN');c._local_align(obs,scene)
    assert c.stage=='XY_COARSE' and c._xy_coarse_target[0]>obs['observation.eef_pose'][0]+.002
    c,obs,scene=helper.setup('b');c._request_alignment_observation(obs,scene)
    count=c._alignment_observations;c._select(scene)
    assert c._alignment_observations==count
    # All unrelated methods remain exactly the V6 implementation, verified by AST.
    import ast,pathlib
    baseline=pathlib.Path('/nvme-ssd2/zhaoyicheng/a3_rule_policy_v6_20261102/frozen_policy_v6/rule_controller.py')
    def methods(text):
        cls=next(x for x in ast.parse(text).body if isinstance(x,ast.ClassDef))
        return {x.name:ast.dump(x,include_attributes=False) for x in cls.body if isinstance(x,ast.FunctionDef)}
    old=methods(baseline.read_text());new=methods(pathlib.Path(__file__).with_name('controller_align_only.py').read_text())
    unchanged=['_held_update','_place_pose','_start_source_recovery','_release_state','_commit','_start_target_observation','_start_target_repair','_confirm_observed_grasp']
    assert all(old[name]==new[name] for name in unchanged)
    return {'full_r3':full,'alignment_only':{'passed':3,'checks':['real XY correction','per-batch view memory','held, placement and recovery methods exactly V6']}}

if __name__=='__main__':print(json.dumps(run(),ensure_ascii=False,indent=2))
