"""Create the target-geometry ablation from the unchanged V6 runtime."""
import argparse
import ast
from pathlib import Path
import shutil

p=argparse.ArgumentParser()
p.add_argument('--baseline',type=Path,required=True)
p.add_argument('--perception-source',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args();a.output.mkdir(exist_ok=False)
for n in ('policy.py','perception.py','rule_controller.py','placement_audit.py'):
    shutil.copy2(a.baseline/n,a.output/n)
source=a.perception_source.read_text();old=(a.baseline/'perception.py').read_text()
lines=source.splitlines(keepends=True);oldlines=old.splitlines(keepends=True)
methods={n.name:n for c in ast.parse(source).body if isinstance(c,ast.ClassDef)
         for n in c.body if isinstance(n,ast.FunctionDef)}
target=next(n for c in ast.parse(old).body if isinstance(c,ast.ClassDef)
            for n in c.body if isinstance(n,ast.FunctionDef) and n.name=='_fit_boxes')
blocks=[]
for name in ('_v7_poly_distance','_v7_target_instance','_fit_boxes'):
    n=methods[name];start=min([n.lineno]+[d.lineno for d in n.decorator_list])
    blocks.append(''.join(lines[start-1:n.end_lineno])+'\n')
new=''.join(oldlines[:target.lineno-1])+'\n'.join(blocks)+''.join(oldlines[target.end_lineno:])
new=new.replace('self.step=0;self.last_key=None;',
    'self.v7_target_diagnostics={};self.v7_target_confirmed=False\n        self.step=0;self.last_key=None;',1)
ast.parse(new);(a.output/'perception.py').write_text(new)
f=a.output/'policy.py';f.write_text(f.read_text().replace('visual_force_rules_v6','visual_force_rules_v7_target_only'))
print(a.output)
