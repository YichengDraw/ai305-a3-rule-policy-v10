"""Collect original paired shard records into a portable audit file."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


def read_json(path):
    return json.loads(path.read_text())


def read_rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def collect(root):
    launch = read_json(root / "launch_protocol.json")
    runtime = Path(launch["policy_code_directory"])
    return dict(source_directory=str(root), launch=launch,
                launch_status=read_json(root / "launch_status.json"),
                complete=read_json(root / "complete.json"),
                runtime_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                for p in [runtime / n for n in (
                                    "policy.py", "perception.py", "rule_controller.py", "placement_audit.py")]
                                if p.exists()},
                cases=[dict(name=p.parent.name, group=p.parent.parent.name,
                            protocol=read_json(p.parent / "protocol.json"),
                            summary_status=read_json(p.parent / "summary.json")["status"],
                            episodes=read_rows(p))
                       for group in ("default", "extra_2x10_500")
                       for p in sorted((root / group).glob("*/episodes.jsonl"))],
                merged_episodes=read_rows(root / "final_default/episodes.jsonl"),
                merged_summary=read_json(root / "final_default/summary.json"),
                official500_episodes=read_rows(root / "final_official500/episodes.jsonl"),
                official500_summary=read_json(root / "final_official500/summary.json"),
                extra500_episodes=read_rows(root / "final_extra_2x10_500/episodes.jsonl"),
                extra500_summary=read_json(root / "final_extra_2x10_500/summary.json"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    pair = read_json(root / "paired_protocol.json")
    payload = dict(source_directory=str(root), collected_at_utc=datetime.now(timezone.utc).isoformat(),
                   paired_protocol=pair, paired_status=read_json(root / "paired_status.json"),
                   complete=read_json(root / "complete.json"),
                   policies={job["name"]: collect(root / job["name"]) for job in pair["jobs"]})
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"output": str(args.output.resolve()), "policies": {
        k: len(v["cases"]) for k, v in payload["policies"].items()}}))


if __name__ == "__main__":
    main()
