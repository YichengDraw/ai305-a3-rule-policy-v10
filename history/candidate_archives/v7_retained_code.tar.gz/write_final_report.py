"""Write the two-protocol readout after independent verification."""
from __future__ import annotations
import argparse
import json
from pathlib import Path


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--verification',type=Path,required=True)
    p.add_argument('--formal-root',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--changes-file',type=Path)
    p.add_argument('--development',type=Path)
    a=p.parse_args()
    root=a.output.resolve()
    audit=json.loads(a.verification.read_text())
    assert audit['validation']['raw_shards']==360
    assert audit['validation']['raw_and_merged_identical'] and audit['validation']['two_tables_reuse_identical_2x5']
    tables=audit['tables']
    for table,folder in (('official500','comparison_official500'),('extended','comparison')):
        auto=json.loads((a.formal_root/folder/'paired_results.json').read_text())
        verified=tables[table]
        assert auto['protocol']['steps']==verified['protocol']['steps']
        for label,name in (('old','v6'),('new','v7')):
            m=verified['results'][name]['overall']
            for key in ('completion_rate','success_rate'):
                assert abs(auto[label][key]-m[key])<1e-12
            assert auto[label]['successes']==m['successes']
    manifest=json.loads((root/'frozen_policy_v7/code_manifest.json').read_text())
    payload=dict(selected_policy=manifest.get('chosen_factory','policy:make_policy_b'),
                 tables=tables,validation=audit['validation'],code_manifest=manifest,
                 raw_evidence=audit['raw_evidence'])
    if a.development:
        payload['development']=json.loads(a.development.read_text())
    (root/'final_results.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    pct=lambda value:f'{value:.2%}'
    off=tables['official500'];ext=tables['extended']
    new=off['results']['v7']['overall'];old=off['results']['v6']['overall']
    lines=['# 策略优化与最终评测','',
           f"**教师统一500步：本轮策略完成率{pct(new['completion_rate'])}，成功率{pct(new['success_rate'])}（{new['successes']}/120）。** 同场景V6为{pct(old['completion_rate'])}、{pct(old['success_rate'])}，变化分别为{off['completion_delta_pp']:+.2f}、{off['success_delta_pp']:+.2f}个百分点。",'']
    lines += ['本轮在两种预算下都提高了终态入盒完成率，官方完整任务成功率下降。入盒数量的增加来自2×5；2×10在两种预算下均下降。本轮同场景对照中，V6完成整局的次数更多。','']
    em=ext['results']['v7']['overall']
    lines += [f"方案扩展预算（2×5为500步，2×10为3200步）下，完成率{pct(em['completion_rate'])}，成功率{pct(em['success_rate'])}（{em['successes']}/120）。",'',
              '新旧策略使用相同的新种子16000–16019，basic、medium、advanced各20回合，来源列1。保持官方非严格计分和连续满足条件5步。实际运行两版各180回合，共360回合；两张表复用同一组2×5各60回合，2×10的两种预算独立运行。','',
              '每回合2×5要求转移10块，2×10要求转移20块。完成率为120回合终态入盒比例的平均，成功率直接统计官方success。每格的成功分母均为20；所有失败、超时与恢复耗时计入。表中百分比保留两位，变化量按原始值计算。','']
    for table in ('official500','extended'):
        t=tables[table]
        lines += [f"## {t['protocol']['label']}",'',
                  '| 任务 / 难度 | V6完成率 | V7完成率 | V6成功 | V7成功 |',
                  '|---|---:|---:|---:|---:|']
        for x,y in zip(t['results']['v6']['cells'],t['results']['v7']['cells']):
            lines.append(f"| {x['task']} / {x['profile']} | {pct(x['completion_rate'])} | {pct(y['completion_rate'])} | {x['successes']}/20 | {y['successes']}/20 |")
        x,y=(t['results'][label]['overall'] for label in ('v6','v7'))
        pair=t['paired']
        lines += ['',f"整体完成率：{pct(x['completion_rate'])} → {pct(y['completion_rate'])}；官方成功：{x['successes']}/120 → {y['successes']}/120。",
                  f"数量加权完成率：{pct(x['cookie_weighted_completion_rate'])} → {pct(y['cookie_weighted_completion_rate'])}，新版最终入盒{y['final_cookies']}/{y['capacity']}。",
                  f"同场景得分升/平/降：{pair['score_improved']}/{pair['score_equal']}/{pair['score_worsened']}；成功新增/丢失：{pair['success_gained']}/{pair['success_lost']}。",'']
    lines += ['## 按任务汇总','',
              '| 任务与预算 | V6完成率 | V7完成率 | V6成功 | V7成功 |',
              '|---|---:|---:|---:|---:|']
    for table,task,title in (('official500','2x5','2×5，500步'),('official500','2x10','2×10，500步'),('extended','2x10','2×10，3200步')):
        values=[]
        for label in ('v6','v7'):
            cells=[c for c in tables[table]['results'][label]['cells'] if c['task']==task]
            values.append((sum(c['completion_rate'] for c in cells)/3,sum(c['successes'] for c in cells)))
        lines.append(f'| {title} | {pct(values[0][0])} | {pct(values[1][0])} | {values[0][1]}/60 | {values[1][1]}/60 |')
    lines += ['']
    if a.changes_file:
        lines += ['## 采用的修改','',a.changes_file.read_text().strip(),'']
    lines += ['## 结果范围与证据','',
              '独立审计逐一核对360份原始分片：冻结代码、唯一场景、每局预算、初始随机化、官方终态字段和两套合并结果一致。两表的2×5逐行相同，2×10在相同初始场景下分别执行相应预算。','',
              '教师原始数量流程为两任务均500步；500/3200是沿用上一轮方案的扩展预算。两张表分别与同预算V6配对。上一轮15000系列已用于诊断，本轮转为开发样本，正式16000系列在选版冻结后运行。','',
              '2×5的非严格判定可能在释放前结束。抓放物理诊断独立保存，采用阶段切换和每5步采样；官方成功按对应任务继续检查源区剩余、槽位或分列及保持；释放、落座等物理条件由离线审计另计。','']
    for table in ('official500','extended'):
        t=tables[table];v=t['results']['v7']
        full=len(v['full_count_but_official_failure'])
        lines.append(f"{t['protocol']['label']}下，V7有{120-v['overall']['successes']}回合未达到官方成功，其中{full}回合终态入盒数量已满。终止原因和批次诊断见独立验收。")
    lines += ['',
              f"- [最终数据]({root/'final_results.json'}) · [独立验收]({a.verification.resolve()})",
              f"- [使用说明]({root/'README.md'}) · [冻结策略]({root/'frozen_policy_v7/policy.py'})",
              f"- [教师500步逐回合记录]({a.formal_root.resolve()/'v7/final_official500/episodes.jsonl'}) · [扩展预算逐回合记录]({a.formal_root.resolve()/'v7/final_default/episodes.jsonl'})",
              f"- [评测口径]({root/'evaluation_protocol.md'}) · [最新方案]({root/'source_plan.md'}) · [开发记录]({root/'status.md'})",'',
              f"[策略代码、原始记录与复现工具包]({root/'rule_policy_v7_release_20261102.zip'})"]
    (root/'最终评测结果.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({table:{k:tables[table]['results']['v7']['overall'][k] for k in ('completion_rate','success_rate','successes')} for table in tables},indent=2))


if __name__=='__main__':
    main()
