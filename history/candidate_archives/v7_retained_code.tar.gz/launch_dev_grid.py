"""Snapshot a candidate and run development-only smoke or coverage episodes."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--stage', choices=('smoke', 'grid'), default='smoke')
    parser.add_argument('--workers', type=int, default=12)
    parser.add_argument('--variant', choices=('a', 'b', 'c'), default='c')
    parser.add_argument('--policy-code', type=Path)
    parser.add_argument('--policy', help='Override variant factory, e.g. policy:make_policy for the v5 reference')
    parser.add_argument('--egl-devices', type=int, nargs='+', default=[4, 5])
    parser.add_argument('--tasks', nargs='+', choices=('2x5','2x10'), default=['2x5','2x10'])
    parser.add_argument('--n-values', nargs='+', type=int, choices=range(10), default=list(range(10)))
    parser.add_argument('--max-steps-2x10', type=int, default=3200)
    args = parser.parse_args()
    if args.max_steps_2x10 < 1 or args.workers < 1:
        parser.error('Budget and workers must be positive')
    if len(set(args.n_values)) != len(args.n_values) or len(set(args.tasks)) != len(args.tasks):
        parser.error('Tasks and first-grasp values must not contain duplicates')
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=False)
    code = root / 'code'
    code.mkdir()
    source = Path(__file__).resolve().parent
    runtime_source = args.policy_code.resolve() if args.policy_code else source
    for name in ('policy.py', 'rule_controller.py', 'perception.py'):
        shutil.copy2(runtime_source / name, code / name)
    for name in ('run_dev.py', 'evaluate_policy.py', 'diagnostic_support.py', 'batch_metrics.py'):
        shutil.copy2(source / name, code / name)
    if (runtime_source / 'placement_audit.py').exists():
        shutil.copy2(runtime_source / 'placement_audit.py', code / 'placement_audit.py')
    policy = args.policy or f'policy:make_policy_{args.variant}'
    if args.stage == 'smoke':
        cases = [('2x5', p, 12001, 5) for p in ('basic', 'medium', 'advanced')]
        cases += [('2x10', 'basic', 12010+n, n) for n in (0, 1, 9)]
    else:
        cases = [('2x5', p, 14000+i, 5) for p in ('basic', 'medium', 'advanced') for i in range(5)]
        cases += [('2x10', p, 14000+n, n) for p in ('basic', 'medium', 'advanced') for n in range(10)]
    cases = [c for c in cases if c[0] in args.tasks and (c[0]=='2x5' or c[3] in args.n_values)]
    if not cases:
        parser.error('No cases selected')
    jobs = [dict(task=t, profile=p, seed=s, n=n, gpu=args.egl_devices[i % len(args.egl_devices)])
            for i, (t, p, s, n) in enumerate(cases)]
    (root/'protocol.json').write_text(json.dumps(dict(stage=args.stage, variant=args.variant, policy=policy, jobs=jobs,
        development_only=True, runtime_truth_access=False, code_directory=str(code),
        max_steps_by_task={'2x5':500,'2x10':args.max_steps_2x10},
        tasks=args.tasks,n_values=args.n_values), indent=2)+'\n')
    start = time.monotonic()

    def run(job):
        name = f"{job['task']}_{job['profile']}_{job['seed']}_n{job['n']}"
        output = root/name
        budget = 500 if job['task']=='2x5' else args.max_steps_2x10
        env = dict(os.environ, MUJOCO_GL='egl', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
            OPENBLAS_NUM_THREADS='1', MUJOCO_EGL_DEVICE_ID=str(job['gpu']),
            CUDA_VISIBLE_DEVICES=str(job['gpu']), A3_POLICY_MAX_STEPS=str(budget))
        if args.stage=='smoke':
            command=[sys.executable,str(code/'run_dev.py'),'--task',job['task'],'--profile',job['profile'],
                '--seed',str(job['seed']),'--first-grasp',str(job['n']),'--max-steps',str(budget),'--output',str(output),
                '--policy',policy]
        else:
            env['A3_POLICY_TRACE_DIR']=str(output/'policy_trace')
            command=[sys.executable,str(code/'evaluate_policy.py'),'--policy',policy,
                '--tasks',job['task'],'--profiles',job['profile'],'--episodes','1','--seed-start',str(job['seed']),
                '--first-grasp-2x10',str(job['n']),'--max-steps','500','--max-steps-2x10',str(args.max_steps_2x10),
                '--render-cameras','--audit-ground-truth','--output',str(output)]
        print('START',name,flush=True)
        with (root/(name+'.log')).open('w') as log:
            proc=subprocess.run(command,cwd=code,env=env,stdout=log,stderr=subprocess.STDOUT)
        print('FINISH',name,'rc',proc.returncode,flush=True)
        return dict(job, output=str(output),returncode=proc.returncode)

    done=[]
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        for future in as_completed([pool.submit(run,j) for j in jobs]):
            done.append(future.result())
            (root/'progress.json').write_text(json.dumps(dict(finished=len(done),total=len(jobs),jobs=done),indent=2)+'\n')
    (root/'complete.json').write_text(json.dumps(dict(status='completed',jobs=done,
        wall_seconds=time.monotonic()-start),indent=2)+'\n')
    if any(j['returncode'] for j in done):
        raise SystemExit('Development subprocess errors; inspect logs')


if __name__=='__main__':
    main()
