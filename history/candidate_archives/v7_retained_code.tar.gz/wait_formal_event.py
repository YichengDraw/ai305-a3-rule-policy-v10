"""Wait for paired completion or a real shard error using Linux inotify."""
from __future__ import annotations
import argparse
import ctypes
import json
import os
from pathlib import Path
import struct


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True)
    a=parser.parse_args()
    root=a.root.resolve()

    def check():
        complete=root/'complete.json'
        if complete.exists():
            try:
                value=json.loads(complete.read_text())
            except (OSError,ValueError):
                value=None
            if value is not None:
                print(json.dumps(dict(event='paired_completed',root=str(root),**value)),flush=True)
                return True
        pair=root/'paired_status.json'
        if pair.exists():
            try:
                value=json.loads(pair.read_text())
            except (OSError,ValueError):
                value={'results':[]}
            failures=[j for j in value['results'] if j['returncode']]
            if failures:
                print(json.dumps(dict(event='paired_process_error',root=str(root),failures=failures)),flush=True)
                return True
        for label in ('v6','v7'):
            status=root/label/'launch_status.json'
            if not status.exists():
                continue
            try:
                value=json.loads(status.read_text())
            except (OSError,ValueError):
                continue
            failures=[j for j in value['completed'] if j['returncode']]
            if failures:
                print(json.dumps(dict(event='shard_process_error',policy=label,root=str(root),failures=failures)),flush=True)
                return True
        return False

    if check():
        return
    lib=ctypes.CDLL('libc.so.6',use_errno=True)
    fd=lib.inotify_init1(0)
    if fd<0:
        raise OSError(ctypes.get_errno(),'inotify_init1')
    watched={}

    def add(path):
        wd=lib.inotify_add_watch(fd,os.fsencode(path),0x00000008|0x00000080|0x00000100)
        if wd<0:
            raise OSError(ctypes.get_errno(),f'inotify_add_watch:{path}')
        watched[wd]=path

    try:
        add(root)
        for label in ('v6','v7'):
            path=root/label
            if path.exists():
                add(path)
        if check():
            return
        while True:
            data=os.read(fd,65536)
            offset=0
            relevant=False
            while offset<len(data):
                wd,mask,cookie,n=struct.unpack_from('iIII',data,offset)
                name=os.fsdecode(data[offset+16:offset+16+n].split(b'\0',1)[0])
                offset+=16+n
                if mask & 0x40000000 and watched[wd]==root and name in ('v6','v7'):
                    add(root/name)
                if name in ('complete.json','paired_status.json','launch_status.json'):
                    relevant=True
            if relevant and check():
                return
    finally:
        os.close(fd)


if __name__=='__main__':
    main()
