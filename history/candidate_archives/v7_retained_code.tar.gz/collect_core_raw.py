"""Archive all finished core results and protocols without copying media."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


def file_source(path):
    if not path.exists():
        return None
    stat=path.stat()
    return dict(path=str(path),bytes=stat.st_size,
                modified_utc=datetime.fromtimestamp(stat.st_mtime,timezone.utc).isoformat())


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bases',type=Path,nargs='+',required=True)
    parser.add_argument('--output',type=Path,required=True)
    a=parser.parse_args()
    roots=sorted({p.resolve() for base in a.bases for p in base.glob('core_*')
                  if p.is_dir() and (p/'protocol.json').exists()})
    branches=[]
    for root in roots:
        complete_path=root/'complete.json'
        if not complete_path.exists():
            raise RuntimeError(f'Core group still running: {root}')
        launch=json.loads((root/'protocol.json').read_text())
        complete=json.loads(complete_path.read_text())
        actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'code').glob('*.py')}
        assert all(actual[name]==digest for name,digest in launch['code_sha256'].items())
        outcomes={(j['task'],j['profile'],j['seed'],j['n']):j for j in complete['jobs']}
        assert len(outcomes)==len(launch['jobs'])==len(complete['jobs'])
        cases=[]
        for job in launch['jobs']:
            key=job['task'],job['profile'],job['seed'],job['n']
            end=outcomes[key]
            case=root/f"{job['task']}_{job['profile']}_{job['seed']}_n{job['n']}"
            protocol_path=case/'development_protocol.json'
            result_path=case/'result.json'
            result=json.loads(result_path.read_text()) if result_path.exists() else None
            if not end['returncode']:
                assert result is not None and result['development_scope'] is True and not result['oracle_source_target']
            cases.append(dict(name=case.name,label=job['label'],returncode=end['returncode'],
                source_directory=str(case),
                protocol=json.loads(protocol_path.read_text()) if protocol_path.exists() else None,
                result=result,media_requested=job['video'],
                media_sources={name:file_source(case/'diagnostic'/name) for name in
                    ('front.mp4','left_wrist.mp4','right_wrist.mp4','trace.jsonl','success_diagnostics.json')},
                public_trace_source=file_source(case/'policy_trace'/f"seed_{job['seed']}.jsonl"),
                log_source=file_source(root/(case.name+'.log'))))
        branches.append(dict(name=root.name,source_directory=str(root),launch=launch,complete=complete,
                             code_sha256=actual,snapshot_matches_launch=True,cases=cases))
    payload=dict(scope='development_core_episodes_only',collected_utc=datetime.now(timezone.utc).isoformat(),
        branches=branches,total_branches=len(branches),total_cases=sum(len(b['cases']) for b in branches),
        all_finished=True,all_returncodes_zero=all(not c['returncode'] for b in branches for c in b['cases']),
        media_policy='Original videos and per-step public/privileged traces stay on server; source paths, sizes, and modification times are recorded. Only original result/protocol documents are embedded.')
    a.output.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:payload[k] for k in ('total_branches','total_cases','all_finished','all_returncodes_zero')}))


if __name__=='__main__':
    main()
