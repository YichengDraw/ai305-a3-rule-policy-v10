"""Public-observation regression for unreliable source lean, no simulator."""
import json
from pathlib import Path
import numpy as np
import controller_contract_checks as helper
from controller_align_only import RuleController as Previous
from controller_align_r5 import RuleController as Candidate
from rule_controller import CANONICAL,_rotation


def run():
    record=json.loads(Path(__file__).with_name('controller_r5_public_case.json').read_text())
    group=record['group']
    helper.RuleController=Previous
    old,_,_=helper.setup('b');old._apply_group_geometry(group)
    helper.RuleController=Candidate
    new,_,_=helper.setup('b');new._apply_group_geometry(group)
    assert group['tilt_verified'] is False and .58<float(group['confidence'])<.60
    old_lean=float(np.degrees(np.arccos(np.clip((np.trace(CANONICAL.T@old._pick_rotation)-1)/2,-1,1))))
    new_lean=float(np.degrees(np.arccos(np.clip((np.trace(CANONICAL.T@new._pick_rotation)-1)/2,-1,1))))
    assert old_lean>30 and new_lean<1e-5
    assert np.allclose(new._selected_rotation[:,2],[0,0,1])
    verified={**group,'confidence':.8,'tilt_verified':True,'rotation':_rotation('x',-.35),'tilt_deg':20.05}
    new._apply_group_geometry(verified)
    assert new._selected_tilt_verified and not np.allclose(new._pick_rotation,CANONICAL)
    weak={**verified,'confidence':.59}
    new._apply_group_geometry(weak)
    assert not new._selected_tilt_verified and np.allclose(new._pick_rotation,CANONICAL)
    return {'passed':3,'public_case':record['source'],'public_case_step':record['step'],
            'previous_unverified_pick_tilt_deg':old_lean,'candidate_unverified_pick_tilt_deg':new_lean,
            'checks':['actual .587-confidence unverified 37-degree hypothesis keeps upright pick',
                      'independently verified high-confidence lean still changes pick posture',
                      'a weak confidence cannot authorize tilt through a stale verified flag']}
if __name__=='__main__':print(json.dumps(run(),indent=2))
