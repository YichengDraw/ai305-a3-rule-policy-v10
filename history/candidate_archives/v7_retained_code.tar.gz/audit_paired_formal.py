"""Independent terminal audit of 360 raw one-episode formal shards; no simulation."""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path

from summarize_dev_reference import metrics
from summarize_dev_comparison import initial_randomization


PROFILES = ("basic", "medium", "advanced")
EXPECTED = {(t, p, s) for t in ("2x5", "2x10") for p in PROFILES for s in range(16000, 16020)}


def load_manifest(path):
    value = json.loads(path.read_text())
    return value.get("sha256", value)


def audit_policy(data, policy, runtime_hashes, evaluator_hashes, table):
    assert data["runtime_sha256"] == runtime_hashes
    assert data["complete"]["status"] == "completed" and data["complete"]["episodes"] == 180
    launch = data["launch"]
    assert launch["policy"] == policy and launch["seed_start"] == 16000 and launch["episodes_per_cell"] == 20
    assert launch["max_steps_by_task"] == {"2x5": 500, "2x10": 3200}
    assert len(launch["jobs"]) == 180 and all(j["episodes"] == 1 for j in launch["jobs"])
    expected_jobs = {(g, t, p, s) for g, tasks in (("default", ("2x5", "2x10")), ("extra_2x10_500", ("2x10",))) for t in tasks for p in PROFILES for s in range(16000,16020)}
    assert {(j["group"], j["task"], j["profile"], j["seed"]) for j in launch["jobs"]} == expected_jobs
    assert len(data["cases"]) == 180
    assert {(c["group"], c["episodes"][0]["task"], c["episodes"][0]["profile"], c["episodes"][0]["seed"]) for c in data["cases"]} == expected_jobs
    selected_cases = [c for c in data["cases"] if c["group"] == "default"] if table == "extended" else [c for c in data["cases"] if (c["group"] == "default" and c["episodes"][0]["task"] == "2x5") or c["group"] == "extra_2x10_500"]
    budgets = {"2x5":500,"2x10":3200 if table == "extended" else 500}
    status = data["launch_status"]
    assert status["finished_shards"] == status["planned_shards"] == 180
    assert len(status["completed"]) == 180 and all(j["returncode"] == 0 for j in status["completed"])
    assert {(j["group"], j["task"], j["profile"], j["seed"]) for j in status["completed"]} == expected_jobs
    rows, protocols = {}, {}
    for case in selected_cases:
        protocol, episodes = case["protocol"], case["episodes"]
        assert case["summary_status"] == "completed" and len(episodes) == 1
        row = episodes[0]
        key = row["task"], row["profile"], row["seed"]
        assert key in EXPECTED and key not in rows
        task, profile, seed = key
        assert protocol["policy"] == policy and protocol["episodes_per_cell"] == 1
        assert protocol["tasks"] == [task] and protocol["profiles"] == [profile] and protocol["seed_start"] == seed
        assert protocol["max_steps_by_task"][task] == budgets[task]
        assert row["max_steps"] == budgets[task]
        assert 0 < row["steps"] <= row["max_steps"]
        assert row["score"] == row["cookies_in_target"] and row["max_score"] == (10 if task == "2x5" else 20)
        assert 0 <= row["score"] <= row["max_score"] and isinstance(row["success"], bool)
        assert row["source_column"] == 1 and protocol["source_column"] == "1"
        assert row["strict_policy_completion"] is False and protocol["strict_policy_completion"] is False
        assert row["success_hold_steps"] == protocol["success_hold_steps"] == 5
        assert protocol["render_cameras"] is True and protocol["offline_ground_truth_audit"] is True
        assert not row.get("oracle_source_target") and not row.get("development_scope")
        for name, digest in runtime_hashes.items():
            assert protocol["code_sha256"]["policy_module" if name == "policy.py" else name] == digest
        for name, digest in evaluator_hashes.items():
            assert protocol["code_sha256"]["evaluation_script" if name == "evaluate_policy.py" else name] == digest
        audit = row["offline_batch_audit"]
        assert sum(batch["planned_count"] for batch in audit) == row["max_score"]
        assert len({b["batch_index"] for b in audit}) == len(audit)
        for batch in audit:
            for field in ("first_valid_grasp_step", "first_valid_placement_step", "first_attempt_step"):
                assert batch.get(field) is None or 0 <= batch[field] <= row["steps"]
        rows[key], protocols[key] = row, protocol
    assert set(rows) == EXPECTED and len(rows) == len(selected_cases) == 120
    merged_rows = data["merged_episodes"] if table == "extended" else data["official500_episodes"]
    merged = {(r["task"], r["profile"], r["seed"]): r for r in merged_rows}
    assert len(merged) == len(merged_rows) == 120 and merged == rows
    extra_raw = [c["episodes"][0] for c in data["cases"] if c["group"] == "extra_2x10_500"]
    extra_merged = data["extra500_episodes"]
    key = lambda r:(r["task"],r["profile"],r["seed"])
    assert len(extra_merged) == 60 and sorted(extra_raw,key=key) == sorted(extra_merged,key=key)
    assert len({json.dumps(p["code_sha256"], sort_keys=True) for p in protocols.values()}) == 1
    assert len({p["source_commit"] for p in protocols.values()}) == 1
    values = list(rows.values())
    overall = metrics(values)
    cells = [{"task": task, "profile": profile,
              **metrics([r for r in values if r["task"] == task and r["profile"] == profile])}
             for task in ("2x5", "2x10") for profile in PROFILES]
    summary = data["merged_summary"] if table == "extended" else data["official500_summary"]
    assert summary["status"] == "completed" and len(summary["sources"]) == 120
    assert summary["code_sha256"] == next(iter(protocols.values()))["code_sha256"]
    assert summary["source_commit"] == next(iter(protocols.values()))["source_commit"]
    prior = summary["overall"]
    assert prior["completed"] == 120 and prior["total_score"] == overall["final_cookies"]
    assert prior["successes"] == overall["successes"]
    assert abs(prior["mean_episode_completion_rate"] - overall["completion_rate"]) < 1e-12
    assert abs(prior["micro_completion_rate"] - overall["cookie_weighted_completion_rate"]) < 1e-12
    assert abs(sum(c["completion_rate"] for c in cells) / 6 - overall["completion_rate"]) < 1e-12
    auto_diagnostics = summary["batch_diagnostics"]
    diagnostic_fields = {"valid_grasp": "offline_truth_grasp", "valid_placement": "offline_truth_placement",
                         "final_retention": "offline_truth_final_retention",
                         "subsequent_given_prior_valid": "subsequent_batch_placement_given_previous_valid"}
    for own, saved in diagnostic_fields.items():
        assert overall["diagnostics"][own] == auto_diagnostics[saved]
    recovery = overall["diagnostics"]["local_recovery"]
    assert recovery["passed"] == auto_diagnostics["explicitly_labeled_recovery_successes"]
    assert recovery["observed"] == auto_diagnostics["explicitly_labeled_recovery_observations"]
    assert recovery["recorded_events"] == auto_diagnostics["recovery_events"]
    events = [e for row in values for e in row.get("policy_recovery_events", [])]
    assert all(e["success"] == e["recovered"] for e in events
               if e.get("success") is not None and e.get("recovered") is not None)
    reasons = Counter(r.get("policy_failure_reason") or r.get("failure_reason") or "no recorded reason" for r in values if not r["success"])
    return rows, protocols, {"factory": policy, "source_directory": data["source_directory"],
                             "overall": overall, "cells": cells, "failure_reason_counts": dict(reasons),
                             "full_count_but_official_failure": [
                                 {key: r.get(key) for key in ("task", "profile", "seed", "score", "failure_reason")}
                                 for r in values if r["score"] == r["max_score"] and not r["success"]],
                             "official_success_phase_counts": dict(Counter(r["phase"] for r in values if r["success"])),
                             "recovery_event_type_counts": dict(Counter(e.get("type", "legacy_without_type") for e in events))}


def paired_table(data, args, manifests, table):
    evaluator = {n: manifests["v7"][n] for n in ("evaluate_policy.py", "batch_metrics.py", "diagnostic_support.py")}
    names = ("policy.py", "perception.py", "rule_controller.py", "placement_audit.py")
    indexed, protocols, results = {}, {}, {}
    for label, policy in (("v6", args.old_policy), ("v7", args.new_policy)):
        indexed[label], protocols[label], results[label] = audit_policy(
            data["policies"][label], policy, {n: manifests[label][n] for n in names}, evaluator, table)
    for key in EXPECTED:
        a, b = indexed["v6"][key], indexed["v7"][key]
        assert initial_randomization(a) == initial_randomization(b), (table, key, "initial randomized scene differs")
        assert a["task_instruction"] == b["task_instruction"]
        for field in ("source_commit", "prompt_styles", "first_grasp_2x10", "randomization_settings"):
            assert protocols["v6"][key][field] == protocols["v7"][key][field]
    a, b = indexed["v6"], indexed["v7"]
    paired = dict(score_improved=sum(b[k]["score"] > a[k]["score"] for k in EXPECTED),
                  score_equal=sum(b[k]["score"] == a[k]["score"] for k in EXPECTED),
                  score_worsened=sum(b[k]["score"] < a[k]["score"] for k in EXPECTED),
                  success_gained=sum(b[k]["success"] and not a[k]["success"] for k in EXPECTED),
                  success_lost=sum(a[k]["success"] and not b[k]["success"] for k in EXPECTED))
    return indexed, dict(protocol=dict(label="教师统一500步" if table == "official500" else "方案扩展500/3200",
                                       episodes_per_policy=120, seeds=[16000,16019],
                                       steps={"2x5":500,"2x10":500 if table == "official500" else 3200},
                                       source_column=1, success_hold_steps=5, strict_policy_completion=False),
                         results=results, paired=paired,
                         completion_delta_pp=100*(results["v7"]["overall"]["completion_rate"]-results["v6"]["overall"]["completion_rate"]),
                         success_delta_pp=100*(results["v7"]["overall"]["success_rate"]-results["v6"]["overall"]["success_rate"]))


def write_markdown(payload, path):
    pct = lambda value: "未知" if value is None else f"{value:.2%}"
    lines = ["# 正式配对评测：独立验收", "",
             "真实运行360回合，两版各180回合；每张结果表每版120回合，两表复用相同的2×5各60回合。新种子16000–16019，每格20，来源列1，官方非严格判定，连续保持5步。", ""]
    for table in ("official500", "extended"):
        result = payload["tables"][table]
        lines += [f"## {result['protocol']['label']}", "",
                  "| 策略 | 完成率（回合等权） | 官方成功率 | 饼干加权完成率 |", "|---|---:|---:|---:|"]
        for name, policy in result["results"].items():
            m = policy["overall"]
            lines.append(f"| {name.upper()} | {pct(m['completion_rate'])} | {m['successes']}/120（{pct(m['success_rate'])}） | {m['final_cookies']}/{m['capacity']}（{pct(m['cookie_weighted_completion_rate'])}） |")
        lines += ["", "| 任务 / 难度 | V6 完成 / 成功 | V7 完成 / 成功 |", "|---|---:|---:|"]
        for i, cell in enumerate(result["results"]["v6"]["cells"]):
            values = [result["results"][name]["cells"][i] for name in ("v6", "v7")]
            lines.append(f"| {cell['task']} / {cell['profile']} | " + " | ".join(f"{pct(c['completion_rate'])} / {c['successes']}/20" for c in values) + " |")
        pair = result["paired"]
        lines += ["", f"完成率变化{result['completion_delta_pp']:+.2f}个百分点；成功率变化{result['success_delta_pp']:+.2f}个百分点。",
                  f"同场景得分升/平/降：{pair['score_improved']}/{pair['score_equal']}/{pair['score_worsened']}；成功新增/丢失：{pair['success_gained']}/{pair['success_lost']}。", "",
                  "| 离线真实诊断 | V6 | V7 |", "|---|---:|---:|"]
        for title, key in (("有效整批抓取", "valid_grasp"), ("有效整批放置", "valid_placement"),
                           ("前批有效条件下的后批放置", "subsequent_given_prior_valid"), ("程序明确结算恢复", "local_recovery")):
            values = [result["results"][name]["overall"]["diagnostics"][key] for name in ("v6", "v7")]
            lines.append(f"| {title} | " + " | ".join(f"{m['passed']}/{m['observed']}，{pct(m['rate'])}；未知{m['unknown']}" for m in values) + " |")
        lines += ["", "| V7失败的终止原因 | 次数 |", "|---|---:|"]
        lines += [f"| {reason} | {count} |" for reason, count in sorted(result["results"]["v7"]["failure_reason_counts"].items(), key=lambda x:(-x[1],x[0]))]
        lines += [""]
    lines += ["已逐一核对360份原始分片协议、冻结代码、唯一条件、预算、随机初始场景、官方原始字段和两套合并结果。两表的2×5逐行相同；2×10两种预算保留各自独立运行。",
              "抓放诊断按实际尝试批次统计，包含未到试提的尝试；恢复按程序明确标签统计，未知另列。"]
    path.write_text("\n".join(lines)+"\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input",type=Path,required=True)
    parser.add_argument("--old-manifest",type=Path,required=True)
    parser.add_argument("--new-manifest",type=Path,required=True)
    parser.add_argument("--old-policy",default="policy:make_policy_b")
    parser.add_argument("--new-policy",default="policy:make_policy_b")
    parser.add_argument("--output-stem",type=Path,required=True)
    args=parser.parse_args()
    data=json.loads(args.input.read_text())
    assert data["complete"]["status"] == "completed" and data["complete"]["episodes"] == 360
    pair=data["paired_protocol"]
    assert pair["scope"] == "frozen_paired_formal_test" and pair["seed_start"] == 16000
    assert pair["episodes_per_cell"] == 20 and pair["planned_episodes_per_policy"] == 180 and pair["shard_size"] == 1
    assert pair["steps"] == {"2x5":500,"2x10":3200} and pair["source_column"] == 1
    assert pair["success_hold_steps"] == 5 and pair["strict_policy_completion"] is False
    assert pair["tables"]["official500"]["steps"] == {"2x5":500,"2x10":500}
    assert pair["tables"]["extended"]["steps"] == {"2x5":500,"2x10":3200}
    assert pair["tables"]["official500"]["episodes_per_policy"] == pair["tables"]["extended"]["episodes_per_policy"] == 120
    assert pair["tables"]["official500"]["reused_2x5_from_extended"] == 60
    assert pair["tables"]["official500"]["additional_2x10"] == 60
    assert len(data["paired_status"]["results"]) == 2 and all(r["returncode"] == 0 for r in data["paired_status"]["results"])
    assert {r["name"] for r in data["paired_status"]["results"]} == {"v6","v7"}
    assert set(data["policies"]) == {"v6","v7"}
    manifests={"v6":load_manifest(args.old_manifest),"v7":load_manifest(args.new_manifest)}
    indexed,tables={},{}
    for table in ("official500","extended"):
        indexed[table],tables[table]=paired_table(data,args,manifests,table)
    for label in ("v6","v7"):
        a,b=indexed["official500"][label],indexed["extended"][label]
        for key in EXPECTED:
            if key[0] == "2x5":
                assert a[key] == b[key], (label,key,"2x5 rows were not reused exactly")
            else:
                assert initial_randomization(a[key]) == initial_randomization(b[key]), (label,key,"cross-budget initial scene differs")
                assert a[key]["task_instruction"] == b[key]["task_instruction"]
    payload=dict(validation=dict(raw_shards=360,simulated_episodes_per_policy=180,
                    table_episodes_per_policy=120,reused_2x5_rows_per_policy=60,cells_per_table=6,
                    seeds=[16000,16019],missing=0,duplicates=0,all_returncodes_zero=True,
                    frozen_code_matches=True,raw_and_merged_identical=True,
                    paired_initial_scenes_identical=True,cross_budget_initial_scenes_identical=True,
                    two_tables_reuse_identical_2x5=True,diagnostics_match_saved_summary=True,
                    recovery_labels_consistent=True),
                 raw_evidence=str(args.input.resolve()),tables=tables,
                 scope="360 independent original single-episode shards. Two 120-row tables per policy reuse 60 identical 2x5 rows. Official terminal fields retained. Ground truth stays in evaluator-only diagnostics.")
    args.output_stem.with_suffix(".json").write_text(json.dumps(payload,ensure_ascii=False,indent=2)+"\n")
    write_markdown(payload,args.output_stem.with_suffix(".md"))
    print(json.dumps({table:{label:{k:value['overall'][k] for k in ('completion_rate','successes','success_rate','final_cookies')} for label,value in results['results'].items()} for table,results in tables.items()},indent=2))


if __name__ == "__main__":
    main()

