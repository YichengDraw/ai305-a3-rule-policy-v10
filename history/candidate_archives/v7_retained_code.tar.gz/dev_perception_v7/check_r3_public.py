from pathlib import Path
import sys,json,cv2,numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'dev_perception_v7'));from perception_r3 import VisionEstimator
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
old=Path('/nvme-ssd2/zhaoyicheng/a3_rule_policy_v6_20261102/dev_perception');rows=[]
for case in ['c4_2x5_basic_12001_n5','c4_2x5_advanced_12001_n5']:
 folder=old/case
 if not (folder/'samples.json').exists():continue
 samples=json.loads((folder/'samples.json').read_text());truth=json.loads((folder/'offline_before.json').read_text());v=VisionEstimator(load_config(resource_root()/'configs/cookie_batch.yaml'))
 frames=[0,5,10]+[i for i in sorted(map(int,samples)) if i>200]
 for idx in frames:
  row=samples[str(idx)];obs=dict(row['observation']);request=dict(row['policy']['request'])
  for camera in ['front','left_wrist','right_wrist']:obs['observation.images.'+camera]=cv2.imread(str(folder/(str(idx)+'_'+camera+'.png')))[:,:,::-1]
  group=row['policy']['perception'].get('group');key=(request.get('batch_index'),request.get('source_column',1),request.get('source_start_index',0),request.get('count',5))
  if idx>200 and v.selected_group_key!=key and group is not None:
   copied={k:np.asarray(value) if k in ('center','rotation') else value for k,value in group.items()};copied['centers']=np.tile(copied['center'],(request['count'],1))
   v.selected_group_key=key;v.selected_group=copied;v.v6_held_previous=None;v.v6_held_reference=None;v.v6_held_method=None;v.v6_held_generation=0;v.v6_use_bevel_held=False;v.v6_held_cache=None
  v.step=0 if idx==0 else idx-1;p=v.estimate(obs,request);boxgt=np.asarray(truth[str(idx)]['target_position']);record={'case':case,'frame':idx,'target_error_mm':float(np.linalg.norm(p['target_box']['center']-boxgt)*1000),'target':p['target_box'],'diagnostics':p.get('target_pose_diagnostics'),'local_state':p['local_align'].get('state'),'held_state':p['held'].get('pose_state')};rows.append(record)
  print(case,idx,round(record['target_error_mm'],3),p['target_box']['confidence'],flush=True)
# A world observation must be re-evaluated at current EEF, not replayed.
v=object.__new__(VisionEstimator);v.selected_group_key=(0,1,0,1);v.step=10;v.v7_local_geometry=None
geometry=dict(confidence=.8,state='correct',valid=False,desired_pad_mid_world=np.array([0.,0.,.02]),observable_axis_world=np.array([1.,0.,0.]),broad_axis_world=np.array([0.,1.,0.]),measurement_step=10,measurement_id='frame10',gap_inner_width_m=.012,gap_width_m=.006,uncertainty_m=.0003)
v._v7_measure_local_alignment=lambda *args:dict(geometry)
obs={'observation.eef_pose':np.array([-.002,.014676,.03,1.,0.,0.,0.]),'observation.state':np.zeros(16)};cameras={'left_wrist':{'pos':np.zeros(3),'rotation':np.eye(3)}}
a=v._v6_local_alignment(obs,cameras,{}, {'stage':'ALIGN_OBSERVE'})
v._v7_measure_local_alignment=lambda *args:dict(state='unknown',confidence=0.)
v.step=12;obs['observation.eef_pose'][0]=.001
b=v._v6_local_alignment(obs,cameras,{}, {'stage':'ALIGN_RETURN'})
assert abs(b['relative_signed_error_m']+.001)<1e-12
assert b['measurement_id']=='frame10' and b['age_steps']==2
print('world_geometry_current_EEF_contract passed',flush=True)
def encode(x):
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,np.generic):return x.item()
 return str(x)
(root/'dev_perception_v7/r3_public_replay.json').write_text(json.dumps({'rows':rows,'world_geometry_contract':True},default=encode,indent=2))
