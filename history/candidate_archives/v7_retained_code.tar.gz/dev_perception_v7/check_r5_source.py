from pathlib import Path
import sys,json,cv2,numpy as np
from scipy.spatial.transform import Rotation
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'dev_perception_v7'));from perception_r4 import VisionEstimator as V4;from perception_r5 import VisionEstimator as V5
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
folder=Path('/nvme-ssd2/zhaoyicheng/a3_rule_policy_v6_20261102/dev_perception/advanced_12001');samples=json.loads((folder/'samples.json').read_text());truth=json.loads((folder/'offline_before.json').read_text());result=[]
for cls,version in [(V4,'r4'),(V5,'r5')]:
 v=cls(load_config(resource_root()/'configs/cookie_batch.yaml'))
 for idx in [0,5,10,15,125,146]:
  item=samples[str(idx)];obs=dict(item['observation'])
  for camera in ['front','left_wrist','right_wrist']:obs['observation.images.'+camera]=cv2.imread(str(folder/(str(idx)+'_'+camera+'.png')))[:,:,::-1]
  request=dict(item.get('policy',{}).get('request',{}));request.update(stage='LOCAL_ALIGN' if idx in [10,15,146] else 'APPROACH',force_refit=True);request.setdefault('count',5);request.setdefault('source_column',1);request.setdefault('source_start_index',0)
  v.step=0 if idx==0 else idx-1;p=v.estimate(obs,request);g=p['group'];start=request['source_start_index'];n=request['count'];gt=np.asarray(truth[str(idx)]['cookie_positions'])[start:start+n].mean(0)
  row={'version':version,'frame':idx,'start':start,'group_center':np.asarray(g['center']).tolist(),'group_error_mm':float(np.linalg.norm(np.asarray(g['center'])-gt)*1000),'tilt_deg':g['tilt_deg'],'confidence':g['confidence'],'tilt_verified':g['tilt_verified'],'candidate_tilt_deg':g.get('tilt_candidate_deg'),'candidate_confidence':g.get('tilt_candidate_confidence')};result.append(row);print(version,idx,round(row['tilt_deg'],2),round(row['confidence'],3),row['tilt_verified'],round(row['group_error_mm'],3),flush=True)
  assert g['tilt_verified'] or abs(float(g['tilt_deg']))<1e-9 if version=='r5' else True
(root/'dev_perception_v7/r5_source_public_replay.json').write_text(json.dumps(result,indent=2));print('saved RGB source geometry compatibility replay passed')
