from pathlib import Path
import sys,json,numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root));from perception import VisionEstimator
v=object.__new__(VisionEstimator);v.step=100;v.selected_group_key=(0,1,0,1);v.v7_target_baselines={0:{"count":0}}
obs={"observation.force":np.zeros(18)};request={"count":1,"batch_index":0,"target_column":0}
occupancy={"0":{"count":1,"confidence":.68,"bounds":[[-.05,-.01],[-.04,-.034],[.006,.04]],"measurement_step":100}}
source={"state":"absent","confidence":.68,"measurement_step":100}
a=v._v7_localize_object(obs,request,{"currently_held":False},source,occupancy)
assert a["state"]=="target"
b=v._v7_localize_object(obs,request,{"currently_held":False},{**source,"state":"present"},occupancy)
assert b["state"]=="source"
c=v._v7_localize_object(obs,request,{"currently_held":True,"pose_confidence":.8},source,occupancy)
assert c["state"]=="held"
d=v._v7_localize_object(obs,request,{"currently_held":False},source,{"0":{**occupancy["0"],"count":0}})
assert d["state"]=="unknown"
e=v._v7_localize_object(obs,request,{"currently_held":False},{**source,"measurement_step":90},occupancy)
assert e["state"]=="unknown"
(root/"dev_perception_v7/location_contracts.json").write_text(json.dumps({"target_new_occupancy_with_source_absent":True,"current_source_presence":True,"current_held":True,"no_target_gain_stays_unknown":True,"stale_source_stays_unknown":True},indent=2))
print("5 object-location contracts passed")
