from pathlib import Path
import sys,json,cv2,numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'dev_perception_v7'));from perception_r4 import VisionEstimator
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
rows=[]
for tag in ['core_target_only','core_target_r3']:
 folder=root/tag/'2x10_advanced_15019_n5';policy=[json.loads(line) for line in next((folder/'policy_trace').glob('*.jsonl')).open()];trace={x['step']:x for x in map(json.loads,(folder/'diagnostic/trace.jsonl').open())}
 caps={name:cv2.VideoCapture(str(folder/'diagnostic'/(name+'.mp4'))) for name in ['front','left_wrist','right_wrist']}
 v=VisionEstimator(load_config(resource_root()/'configs/cookie_2x10.yaml'));bootstrap=[];original=v._fit_boxes
 def fitted(obs,cameras):
  no_anchor=v.v6_target_anchor is None;gen=v.calibration_generation;box=original(obs,cameras)
  if v.step==1:bootstrap.append({'generation':gen,'anchor_was_none':no_anchor,'pose_camera':box['target_box'].get('pose_camera'),'center':box['target_box']['center'].tolist(),'confidence':box['target_box']['confidence']})
  return box
 v._fit_boxes=fitted
 for step in [0,5,75,85,89,90,95,215]:
  obs=dict(trace[step]['observation_before']);record=min(policy,key=lambda x:abs(x['step']-step));request=dict(record['request']);request['force_refit']=True
  for name,cap in caps.items():
   cap.set(cv2.CAP_PROP_POS_FRAMES,step);ok,im=cap.read();assert ok;obs['observation.images.'+name]=im[:,:,::-1]
  if step>0:
   public=record['perception'];calibration=public.get('wrist_calibration') or {}
   if calibration.get('mount_parameters') is not None:
    v.wrist_mount=np.asarray(calibration['mount_parameters'],float);v.wrist_calibration=dict(calibration);v.wrist_last_opening=float(np.asarray(obs['observation.state'])[7])
   front=(public.get('camera_calibration') or {}).get('front') or {}
   if front.get('adjustment') is not None:v.camera_adjustments['front']=np.asarray(front['adjustment'],float)
  # For sparse replay restore only the original public group's state; RGB and
  # public robot observations still supply every new metric fit.
  if step>=75:
   group=record['perception']['group'];key=(request.get('batch_index'),request.get('source_column',1),request.get('source_start_index',0),request.get('count',5))
   copied={k:np.asarray(val) if k in ('center','rotation') else val for k,val in group.items()};copied['centers']=np.tile(copied['center'],(request['count'],1));v.selected_group_key=key;v.selected_group=copied
  v.step=0 if step==0 else step;p=v.estimate(obs,request)
  truth=np.asarray(trace[step]['after']['target_position']);row={'recording':tag,'frame':step,'target_error_mm':float(np.linalg.norm(np.asarray(p['target_box']['center'])-truth)*1000),'box':p['target_box'],'diagnostics':p['target_pose_diagnostics'],'bootstrap_calls':bootstrap if step==0 else None,'public_rgb_calibration_restored':step>0};rows.append(row)
  print(tag,step,round(row['target_error_mm'],3),p['target_box'].get('pose_camera'),p['target_pose_diagnostics'].get('accepted'),p['target_box'].get('anchor_confirmed'),flush=True)
 for cap in caps.values():cap.release()
def encode(x):
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,np.generic):return x.item()
 return str(x)
(root/'dev_perception_v7/r4_bootstrap_replay.json').write_text(json.dumps(rows,default=encode,indent=2))
assert all(r['target_error_mm']<15 for r in rows if r['frame']<10),'bootstrap still has centimeter drift'
assert all(len(r['bootstrap_calls'])==2 and all(c['anchor_was_none'] for c in r['bootstrap_calls']) for r in rows if r['frame']==0)
print('bootstrap generation reset and saved-frame replay passed')
