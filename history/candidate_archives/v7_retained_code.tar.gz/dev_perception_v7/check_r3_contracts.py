from pathlib import Path
import sys,json,numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'dev_perception_v7'));from perception_r3 import VisionEstimator
v=object.__new__(VisionEstimator);v.step=100;v.selected_group_key=(0,1,0,1);v.v7_target_baselines={0:{'count':0}}
obs={'observation.force':np.zeros(18)};request={'count':1,'batch_index':0,'target_column':0}
occupancy={'0':{'count':1,'confidence':.68,'bounds':[[-.05,-.01],[-.04,-.034],[.006,.04]],'measurement_step':100,'measurement_id':'occ:100'}}
source={'state':'absent','confidence':.68,'measurement_step':100,'measurement_id':'src:100'}
a=v._v7_localize_object(obs,request,{'currently_held':False},source,occupancy)
assert a['state']=='target'
v.step=101;b=v._v7_localize_object(obs,request,{'currently_held':False},source,occupancy)
assert a['measurement_id']==b['measurement_id'] and b['age_steps']==1
s={**source,'state':'present'};c=v._v7_localize_object(obs,request,{'currently_held':False},s,occupancy)
v.step=102;d=v._v7_localize_object(obs,request,{'currently_held':False},s,occupancy)
assert c['state']=='source' and c['measurement_id']==d['measurement_id']
h={'currently_held':True,'pose_confidence':.8,'measurement_current':True,'pose_state':'measured','age_steps':0,'measurement_step':102,'measurement_id':'held:102'}
e=v._v7_localize_object(obs,request,h,source,occupancy);assert e['state']=='held' and e['measurement_id']=='location:held:held:102'
f=v._v7_localize_object(obs,request,{**h,'measurement_current':False,'pose_state':'predicted','age_steps':1},{'state':'unknown'},{});assert f['state']=='unknown'
g=v._v7_localize_object(obs,request,{**h,'measurement_id':'held:103','measurement_step':103},source,occupancy);assert g['measurement_id']!=e['measurement_id']
results={'target_with_independent_source_absence_and_gain':True,'retained_target_evidence_keeps_id':True,'retained_source_evidence_keeps_id':True,'fresh_held_inherits_frame_id':True,'predicted_held_stays_unknown':True,'distinct_held_frame_changes_id':True}
(root/'dev_perception_v7/r3_location_contracts.json').write_text(json.dumps(results,indent=2));print('6 r3 evidence freshness and ID checks passed')
