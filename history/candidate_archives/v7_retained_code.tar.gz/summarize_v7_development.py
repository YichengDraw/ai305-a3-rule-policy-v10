"""Validate V7 versus the already recorded V6 45-case development grid."""
from __future__ import annotations
import argparse
import json
from pathlib import Path

from summarize_dev_comparison import validate, summarize, paired
from summarize_dev_reference import metrics


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference',type=Path,required=True)
    parser.add_argument('--candidate',type=Path,required=True)
    parser.add_argument('--new-policy',default='policy:make_policy_b')
    parser.add_argument('--tasks',nargs='+',choices=('2x5','2x10'),default=['2x5','2x10'])
    parser.add_argument('--n-values',nargs='+',type=int,choices=range(10),default=list(range(10)))
    parser.add_argument('--max-steps-2x10',type=int,default=3200)
    parser.add_argument('--output-stem',type=Path,required=True)
    a=parser.parse_args()
    old,new=(json.loads(p.read_text()) for p in (a.reference,a.candidate))
    profiles=('basic','medium','advanced')
    expected=({('2x5',p,s,5) for p in profiles for s in range(14000,14005)} if '2x5' in a.tasks else set())
    if '2x10' in a.tasks:
        expected|={('2x10',p,14000+n,n) for p in profiles for n in a.n_values}
    budgets={'2x5':500,'2x10':a.max_steps_2x10}
    before,before_protocols=validate(old,'policy:make_policy_b',old['policy_code_sha256'],expected=expected,budgets=budgets)
    after,after_protocols=validate(new,a.new_policy,new['policy_code_sha256'],before,expected=expected,budgets=budgets)
    for key in before:
        for field in ('source_commit','prompt_styles','source_column','strict_policy_completion','success_hold_steps'):
            assert before_protocols[key][field]==after_protocols[key][field]
    results={'v6':summarize(before),'v7':summarize(after)}
    pair=paired(before,after)
    endpoints={name:metrics([r for key,r in rows.items() if key[0]=='2x10' and key[3] in (0,1,9)])
               for name,rows in (('v6',before),('v7',after))}
    payload=dict(scope='development_only',reference=str(a.reference.resolve()),
        candidate=str(a.candidate.resolve()),
        protocol=dict(tasks=a.tasks,first_grasp_values=a.n_values,max_steps_by_task=budgets),
        validation=dict(cases_per_policy=len(expected),all_returncodes_zero=True,paired_initial_scenes_identical=True,
                        snapshot_matches_recorded_runtime=True,official_fields_preserved=True),
        results=results,paired=pair,endpoint_2x10_n0_n1_n9=endpoints,
        completion_delta_pp=100*(results['v7']['overall']['completion_rate']-results['v6']['overall']['completion_rate']),
        success_delta_pp=100*(results['v7']['overall']['success_rate']-results['v6']['overall']['success_rate']))
    a.output_stem.with_suffix('.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    pct=lambda v:f'{v:.2%}'
    lines=[f'# V7开发评测（每版{len(expected)}回合）','',
        f"任务{', '.join(a.tasks)}，三档扰动，2×10首夹数量{a.n_values}；预算2×5为500步、2×10为{a.max_steps_2x10}步。两版初始场景已逐一核对。",'',
        '| 策略 | 完成率（回合等权） | 官方成功 | 数量加权完成率 |','|---|---:|---:|---:|']
    for label in ('v6','v7'):
        m=results[label]['overall'];lines.append(f"| {label.upper()} | {pct(m['completion_rate'])} | {m['successes']}/{len(expected)} | {pct(m['cookie_weighted_completion_rate'])} |")
    lines += ['', '| 任务 / 难度 | V6完成 / 成功 | V7完成 / 成功 |','|---|---:|---:|']
    for x,y in zip(results['v6']['cells'],results['v7']['cells']):
        lines.append(f"| {x['task']} / {x['profile']} | {pct(x['completion_rate'])} / {x['successes']}/{x['episodes']} | {pct(y['completion_rate'])} / {y['successes']}/{y['episodes']} |")
    lines += ['',f"同场景得分升/平/降：{pair['score_improved']}/{pair['score_equal']}/{pair['score_worsened']}；成功新增/丢失：{pair['success_gained']}/{pair['success_lost']}。",'',
              f"2×10端点子集n∈{{0,1,9}}，本组共{endpoints['v6']['episodes']}回合："]
    for label in ('v6','v7'):
        m=endpoints[label];rate='未知' if m['completion_rate'] is None else pct(m['completion_rate'])
        lines.append(f"- {label.upper()}：完成率{rate}，成功{m['successes']}/{m['episodes']}。")
    lines += ['', '这组回合用于开发选版；正式测试使用未参与调参的16000系列。']
    a.output_stem.with_suffix('.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({label:{k:v['overall'][k] for k in ('completion_rate','success_rate','successes')} for label,v in results.items()},indent=2))


if __name__=='__main__':
    main()
