"""Independent AST composition check; does not import or execute policies."""
from pathlib import Path
import ast,copy,json
from datetime import datetime,timezone
root=Path(__file__).resolve().parent;base=root.parent/'rule_policy_v6_20261102/frozen_policy_v6'
def tree(path):return ast.parse(path.read_text())
def dump(node):return ast.dump(node,include_attributes=False)
def methods(path):
 t=tree(path);return {f'{c.name}.{n.name}':n for c in t.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
def find(path,cls,name):return methods(path)[cls+'.'+name]
def same_method(a,b,cls,name):return dump(find(a,cls,name))==dump(find(b,cls,name))
def diff_methods(a,b):
 x,y=methods(a),methods(b)
 return dict(added=sorted(y.keys()-x.keys()),removed=sorted(x.keys()-y.keys()),changed=sorted(k for k in x.keys()&y.keys() if dump(x[k])!=dump(y[k])),unchanged=sum(dump(x[k])==dump(y[k]) for k in x.keys()&y.keys()))
def remove_methods(t,names):
 for c in t.body:
  if isinstance(c,ast.ClassDef):c.body=[n for n in c.body if not isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) or c.name+'.'+n.name not in names]
 return t
def reset_baseline(t):
 for c in t.body:
  if isinstance(c,ast.ClassDef) and c.name=='VisionEstimator':
   for n in c.body:
    if isinstance(n,ast.FunctionDef) and n.name=='reset':
     n.body=[s for s in n.body if not isinstance(s,ast.Assign) or not any(isinstance(target,ast.Attribute) and target.attr in ('v7_target_diagnostics','v7_target_confirmed') for target in s.targets)]
 return t
def normalize_policy_name(t):
 for c in t.body:
  if isinstance(c,ast.ClassDef) and c.name=='VisualForcePolicy':
   for n in c.body:
    if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='name' for x in n.targets):n.value=ast.Constant(value='policy_name')
 return t
def top_stage_blocks(path):
 n=find(path,'RuleController','act')
 return {ast.unparse(x.test):dump(x) for x in n.body if isinstance(x,ast.If)}
minimal=root/'candidate_minimal_r5';align=root/'candidate_align_r5';target=root/'candidate_target_only';r5=root/'dev_perception_v7/perception_r5.py'
target_methods=['_v7_poly_distance','_v7_target_instance','_fit_boxes']
allowed_perception={'VisionEstimator.'+x for x in target_methods+['_fit_selected_group']}
checks={}
checks['minimal_policy_only_name_changed']=dump(normalize_policy_name(tree(base/'policy.py')))==dump(normalize_policy_name(tree(minimal/'policy.py')))
checks['minimal_perception_remaining_AST_equals_V6']=dump(remove_methods(reset_baseline(tree(minimal/'perception.py')),allowed_perception))==dump(remove_methods(tree(base/'perception.py'),allowed_perception))
checks['minimal_controller_remaining_AST_equals_V6']=dump(remove_methods(tree(minimal/'rule_controller.py'),{'RuleController._apply_group_geometry'}))==dump(remove_methods(tree(base/'rule_controller.py'),{'RuleController._apply_group_geometry'}))
checks['minimal_placement_byte_equal_V6']=(minimal/'placement_audit.py').read_bytes()==(base/'placement_audit.py').read_bytes()
for label,directory in [('minimal',minimal),('align',align)]:
 for name in target_methods:checks[f'{label}_target_{name}_equals_R2']=same_method(directory/'perception.py',target/'perception.py','VisionEstimator',name)
 checks[f'{label}_source_fit_equals_R5']=same_method(directory/'perception.py',r5,'VisionEstimator','_fit_selected_group')
 checks[f'{label}_pick_geometry_equals_controller_R5']=same_method(directory/'rule_controller.py',root/'controller_align_r5.py','RuleController','_apply_group_geometry')
checks['align_controller_exact_reference']=(align/'rule_controller.py').read_bytes()==(root/'controller_align_r5.py').read_bytes()
checks['align_placement_exact_R2']=(align/'placement_audit.py').read_bytes()==(root/'placement_audit.py').read_bytes()
checks['align_vision_except_target_equals_full_R5']=dump(remove_methods(tree(align/'perception.py'),{'VisionEstimator.'+x for x in target_methods}))==dump(remove_methods(tree(r5),{'VisionEstimator.'+x for x in target_methods}))
old_blocks,new_blocks=top_stage_blocks(base/'rule_controller.py'),top_stage_blocks(align/'rule_controller.py')
changed_blocks=sorted(k for k in old_blocks.keys()&new_blocks.keys() if old_blocks[k]!=new_blocks[k]);added_blocks=sorted(new_blocks.keys()-old_blocks.keys());removed_blocks=sorted(old_blocks.keys()-new_blocks.keys())
checks['align_other_act_dispatch_blocks_equal_V6']=changed_blocks==["self.stage == 'ALIGN_OBSERVE'"] and added_blocks==["self.stage == 'XY_COARSE'"] and not removed_blocks
# Policy wrapper's additional fields are trace-only. The explicit make_policy_b
# factory used by evaluation retains the same b variant in both candidates.
checks['minimal_explicit_factory_B_equals_V6']=dump(next(n for n in tree(minimal/'policy.py').body if isinstance(n,ast.FunctionDef) and n.name=='make_policy_b'))==dump(next(n for n in tree(base/'policy.py').body if isinstance(n,ast.FunctionDef) and n.name=='make_policy_b'))
checks['align_explicit_factory_B_equals_V6']=dump(next(n for n in tree(align/'policy.py').body if isinstance(n,ast.FunctionDef) and n.name=='make_policy_b'))==dump(next(n for n in tree(base/'policy.py').body if isinstance(n,ast.FunctionDef) and n.name=='make_policy_b'))
review=[]
for label,directory in [('minimal',minimal),('align',align)]:
 modules={name:tree(directory/name) for name in ['policy.py','perception.py','rule_controller.py','placement_audit.py']}
 attrs=sorted({n.attr for t in modules.values() for n in ast.walk(t) if isinstance(n,ast.Attribute)})
 forbidden=sorted(set(attrs)&{'env','_env','privileged_cookie_in_target','mj_contactForce','cookie_positions','cookie_quaternions','cookie_rotations'})
 # geometry config carries cookie_source_positions_m; that static public CAD
 # prior is separate from an actual episode's randomized object state.
 keys=sorted({n.value for t in modules.values() for n in ast.walk(t) if isinstance(n,ast.Constant) and isinstance(n.value,str) and n.value.startswith('observation.') and len(n.value)<70})
 review.append({'candidate':label,'forbidden_episode_truth_attribute_hits':forbidden,'public_observation_literals':keys,
  'nominal_model_geometry_reads':'robot_data cam_xpos/cam_xmat and gripper geom_xpos/geom_xmat only, after public joint FK',
  'seed_use':'policy trace filename only; no seed-to-geometry reconstruction',
  'object_hypothesis_basis':'public fixed CAD/layout plus RGB fitting and public robot/force data',
  'outer_evaluator_truth':'separate diagnostic_support.py, absent from runtime module imports'})
 checks[label+'_no_actual_episode_truth_attribute_reads']=not forbidden
result={'time_utc':datetime.now(timezone.utc).isoformat(),'scope':'Static AST composition and runtime input provenance; no simulation executed',
 'all_checks_pass':all(checks.values()),'checks':checks,'minimal':{name:diff_methods(base/name,minimal/name) for name in ['policy.py','perception.py','rule_controller.py','placement_audit.py']},
 'align':{name:diff_methods(base/name,align/name) for name in ['policy.py','perception.py','rule_controller.py','placement_audit.py']},
 'align_act_dispatch':{'changed':changed_blocks,'added':added_blocks,'removed':removed_blocks},'data_source_review':review,
 'factory_note':'Formal/core uses explicit policy:make_policy_b. minimal make_policy default remains original V6 c; align default alias is b.',
 'paths':{'baseline':str(base),'minimal':str(minimal),'align':str(align),'target_R2':str(target),'source_R5':str(r5)}}
(root/'composition_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'all_checks_pass':result['all_checks_pass'],'failed':[k for k,v in checks.items() if not v],'align_act_dispatch':result['align_act_dispatch'],'review':review},ensure_ascii=False,indent=2))
