"""Compare the eight development cases against their recorded V6 results."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

from launch_core_cases import CASES, RUNTIME, HELPERS
from summarize_dev_comparison import initial_randomization
from summarize_dev_reference import metrics


def phase_steps(row):
    transitions = row.get("policy_transitions", [])
    result = Counter()
    if transitions:
        result[transitions[0].get("from", "SELECT")] += transitions[0].get("step", 0)
    for i, transition in enumerate(transitions):
        start = transition.get("step", transition.get("total_steps", 0))
        end = (transitions[i + 1].get("step", transitions[i + 1].get("total_steps", 0))
               if i + 1 < len(transitions) else row["steps"])
        result[transition.get("to", transition.get("phase", "unknown"))] += max(0, end - start)
    return dict(result)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--reference", type=Path, required=True,
                        help="Recorded V6 formal episodes.jsonl for seeds15000–15019")
    parser.add_argument("--output-stem", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    launch = json.loads((root / "protocol.json").read_text())
    complete = json.loads((root / "complete.json").read_text())
    assert launch["development_only"] and launch["scope"] == "v7_core_development"
    assert complete["status"] == "completed" and all(j["returncode"] == 0 for j in complete["jobs"])
    jobs = {j["label"]: j for j in launch["jobs"]}
    expected = {c[0]: c[1:] for c in CASES if c[0] in jobs}
    assert len(jobs) == len(expected) == len(complete["jobs"])
    for filename in RUNTIME + HELPERS:
        assert hashlib.sha256((root / "code" / filename).read_bytes()).hexdigest() == launch["code_sha256"][filename]
    prior_rows = [json.loads(line) for line in args.reference.read_text().splitlines() if line.strip()]
    prior = {(r["task"], r["profile"], r["seed"]): r for r in prior_rows}
    rows, pairs, old_rows = [], [], []
    for label, (task, profile, seed, n) in expected.items():
        job = jobs[label]
        assert (job["task"], job["profile"], job["seed"], job["n"]) == (task, profile, seed, n)
        case = root / f"{task}_{profile}_{seed}_n{n}"
        row = json.loads((case / "result.json").read_text())
        protocol = json.loads((case / "development_protocol.json").read_text())
        assert row["development_scope"] is True and not row["oracle_source_target"]
        assert protocol["offline_ground_truth_audit"] is True and not protocol["oracle_source_target"]
        assert row["max_steps"] == (500 if task == "2x5" else 3200)
        assert row["source_column"] == 1 and row["success_hold_steps"] == 5 and row["strict_policy_completion"] is False
        assert protocol["policy"] == launch["policy"] and protocol["first_grasp"] == str(n)
        old = prior[(task, profile, seed)]
        old_scene, new_scene = initial_randomization(old), initial_randomization(row)
        if task == "2x10":
            # Formal baseline chose n from the official seeded random mode;
            # the core launcher passes that same realized n explicitly.
            assert old_scene["first_grasp_count"] == new_scene["first_grasp_count"] == n
            old_scene.pop("first_grasp_mode", None)
            new_scene.pop("first_grasp_mode", None)
        assert old_scene == new_scene, (label, "initial randomized scene differs")
        assert row["task_instruction"] == old["task_instruction"], (label, "instruction differs")
        assert row["score"] == row["cookies_in_target"] and row["max_score"] == old["max_score"]
        rows.append(row)
        old_rows.append(old)
        pairs.append(dict(label=label, task=task, profile=profile, seed=seed, n=n,
                          old_score=old["score"], new_score=row["score"], max_score=row["max_score"],
                          old_success=old["success"], new_success=row["success"],
                          old_steps=old["steps"], new_steps=row["steps"],
                          old_failure=old.get("policy_failure_reason") or old.get("failure_reason"),
                          new_failure=row.get("policy_failure_reason") or row.get("failure_reason"),
                          old_phase_steps=phase_steps(old), new_phase_steps=phase_steps(row)))
    before, after = metrics(old_rows), metrics(rows)
    payload = dict(scope="development_only", reference=str(args.reference.resolve()),
                   candidate=str(root), snapshot_hashes=launch["code_sha256"],
                   validation=dict(all_returncodes_zero=True, initial_scenes_identical=True,
                                   explicit_first_grasp_matches_seeded_reference=True,
                                   frozen_snapshot_matches=True, official_protocol_matches=True),
                   old=before, new=after, pairs=pairs,
                   completion_delta_pp=100 * (after["completion_rate"] - before["completion_rate"]),
                   success_delta_pp=100 * (after["success_rate"] - before["success_rate"]))
    args.output_stem.with_suffix(".json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n")
    pct = lambda value: f"{value:.2%}"
    lines = [f"# 核心开发案例（{len(pairs)}回合）", "",
             "这批15000系列案例已用于提出修改，作为开发样本。V6成绩直接复用原正式记录，候选为独立运行。", "",
             "| 案例 | V6入盒 | 候选入盒 | V6成功 | 候选成功 | V6步数 | 候选步数 |",
             "|---|---:|---:|---:|---:|---:|---:|"]
    lines += [f"| {c['label']}：{c['task']}/{c['profile']}/{c['seed']}, n={c['n']} | {c['old_score']}/{c['max_score']} | {c['new_score']}/{c['max_score']} | {int(c['old_success'])} | {int(c['new_success'])} | {c['old_steps']} | {c['new_steps']} |" for c in pairs]
    lines += ["", f"回合等权完成率：{pct(before['completion_rate'])} → {pct(after['completion_rate'])}；官方成功：{before['successes']}/{len(pairs)} → {after['successes']}/{len(pairs)}。", "",
              "已核对运行快照、预算、初始随机场景和指令。开发结果服务于选择版本，独立正式测试使用16000系列。"]
    args.output_stem.with_suffix(".md").write_text("\n".join(lines) + "\n")
    print(json.dumps({k: payload[k] for k in ("old", "new", "completion_delta_pp", "success_delta_pp")}, indent=2))


if __name__ == "__main__":
    main()
