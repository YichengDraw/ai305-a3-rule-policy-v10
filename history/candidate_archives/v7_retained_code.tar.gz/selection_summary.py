"""Select from development evidence with exact six-cell bounds; never read test seeds."""
from __future__ import annotations
import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path

from summarize_dev_comparison import initial_randomization, validate

PROFILES=('basic','medium','advanced')
FILES=('policy.py','perception.py','rule_controller.py','placement_audit.py')
GRID={('2x5',p,s,5) for p in PROFILES for s in range(14000,14005)} | {('2x10',p,14000+n,n) for p in PROFILES for n in range(10)}
BUDGET={('2x10',p,14000+n,n) for p in PROFILES for n in (0,1,4,9)}
METRICS=('teacher500_completion','extended_completion','teacher500_success','extended_success')


def case_key(row):
    return row['task'],row['profile'],row['seed'],5 if row['task']=='2x5' else row['randomization']['first_grasp_count']


def load_source(path, expected, budget):
    if path.is_file():
        data=json.loads(path.read_text())
        done=data['complete']['jobs']
        original_status=data['complete']['status']
    else:
        launch=json.loads((path/'protocol.json').read_text())
        marker=path/'complete.json'
        marker=marker if marker.exists() else path/'progress.json'
        state=json.loads(marker.read_text()) if marker.exists() else {'jobs':[]}
        done=state.get('jobs',[])
        original_status=state.get('status','running')
        code=path/'code'
        cases=[]
        for job in done:
            if job['returncode']:
                continue
            case=Path(job['output'])
            assert json.loads((case/'summary.json').read_text())['status']=='completed'
            cases.append(dict(name=case.name,protocol=json.loads((case/'protocol.json').read_text()),
                              episodes=[json.loads(line) for line in (case/'episodes.jsonl').read_text().splitlines() if line.strip()]))
        data=dict(launch=launch,complete=state,cases=cases,
                  policy_code_sha256={n:hashlib.sha256((code/n).read_bytes()).hexdigest() for n in FILES})
    errors=[j for j in done if j['returncode']]
    good=[j for j in done if not j['returncode']]
    finished={(j['task'],j['profile'],j['seed'],j['n']) for j in good}
    assert len(finished)==len(good) and finished<=expected
    selected_cases=[c for c in data['cases'] if case_key(c['episodes'][0]) in finished]
    # This validation view contains only actual, successfully finished shards.
    # Pending and failed shards remain outside the view and retain [0,1] bounds.
    view=dict(data,cases=selected_cases,complete=dict(status='completed',jobs=good))
    if finished:
        rows,protocols=validate(view,'policy:make_policy_b',data['policy_code_sha256'],expected=finished,
                                budgets={'2x5':500,'2x10':budget})
    else:
        rows,protocols={},{}
    return rows,protocols,dict(source=str(path.resolve()),completed=len(rows),planned=len(expected),
        status=original_status,errors=errors,runtime_sha256=data['policy_code_sha256'])


def bound_json(lo,hi):
    return dict(lower=float(lo),upper=float(hi),lower_fraction=str(lo),upper_fraction=str(hi),exact=lo==hi)


def summarize_bounds(rows, expected):
    cells=[]
    completion_lo=completion_hi=success_lo=success_hi=Fraction()
    for task in ('2x5','2x10'):
        for profile in PROFILES:
            keys={k for k in expected if k[:2]==(task,profile)}
            assert keys
            present=[rows[k] for k in keys if k in rows]
            n=len(keys);missing=n-len(present)
            count=sum((Fraction(r['cookies_in_target'],r['max_score']) for r in present),Fraction())
            successes=sum(r['success'] for r in present)
            cl,ch=count/n,(count+missing)/n
            sl,sh=Fraction(successes,n),Fraction(successes+missing,n)
            completion_lo+=cl/6;completion_hi+=ch/6
            success_lo+=sl/6;success_hi+=sh/6
            cells.append(dict(task=task,profile=profile,completed=len(present),planned=n,
                              successes=successes,completion=bound_json(cl,ch),success=bound_json(sl,sh)))
    return dict(completed=len(rows),planned=len(expected),cells=cells,
                completion=bound_json(completion_lo,completion_hi),success=bound_json(success_lo,success_hi)),(completion_lo,completion_hi,success_lo,success_hi)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--protocol',type=Path,required=True)
    parser.add_argument('--candidate',action='append',nargs=3,metavar=('NAME','GRID','BUDGET500'),required=True)
    parser.add_argument('--output-stem',type=Path,required=True)
    a=parser.parse_args()
    protocol=json.loads(a.protocol.read_text())
    supplied={name:(Path(grid),Path(budget)) for name,grid,budget in a.candidate}
    assert len(supplied)==len(a.candidate) and set(supplied)==set(protocol['candidates'])
    assert protocol['formal_test_seeds_unrun']==[16000,16019]
    records={};reports={};vectors={};all_protocols=[]
    reference_scenes={}
    for name in protocol['candidates']:
        grid,grid_proto,grid_meta=load_source(supplied[name][0],GRID,3200)
        budget,budget_proto,budget_meta=load_source(supplied[name][1],BUDGET,500)
        assert grid_meta['runtime_sha256']==budget_meta['runtime_sha256'],(name,'runtime changed between budgets')
        for rows in (grid,budget):
            for key,row in rows.items():
                scene=initial_randomization(row)
                if key in reference_scenes:
                    assert reference_scenes[key]==(scene,row['task_instruction']),(name,key,'initial scene/instruction differs')
                else:
                    reference_scenes[key]=(scene,row['task_instruction'])
        all_protocols.extend(list(grid_proto.values())+list(budget_proto.values()))
        teacher={k:v for k,v in grid.items() if k[0]=='2x5'} | budget
        teacher_expected={k for k in GRID if k[0]=='2x5'} | BUDGET
        t,tv=summarize_bounds(teacher,teacher_expected)
        e,ev=summarize_bounds(grid,GRID)
        lo=(tv[0],ev[0],tv[2],ev[2]);hi=(tv[1],ev[1],tv[3],ev[3])
        vectors[name]=(lo,hi)
        reports[name]=dict(grid=grid_meta,budget500=budget_meta,teacher500=t,extended=e,
            vector_lower=[str(x) for x in lo],vector_upper=[str(x) for x in hi],
            primary_complete=t['completed']==27,
            eligible=not grid_meta['errors'] and not budget_meta['errors'])
        records[name]=dict(grid=grid,budget500=budget)
    assert len({p['source_commit'] for p in all_protocols})==1
    winners=[name for name in protocol['candidates'] if reports[name]['eligible'] and
             all(vectors[name][0]>vectors[other][1] for other in protocol['candidates'] if other!=name)]
    assert len(winners)<=1
    winner=winners[0] if winners else None
    proof=[]
    if winner:
        for other in protocol['candidates']:
            if other==winner:continue
            lo,hi=vectors[winner][0],vectors[other][1]
            decisive=next(i for i,(x,y) in enumerate(zip(lo,hi)) if x!=y)
            assert lo[decisive]>hi[decisive]
            proof.append(dict(competitor=other,decisive_metric=METRICS[decisive],
                              winner_lower=str(lo[decisive]),competitor_upper=str(hi[decisive])))
    exact=all(lo==hi for lo,hi in vectors.values())
    payload=dict(scope='development_selection_only',protocol=protocol,metrics_order=METRICS,
        validation=dict(initial_scenes_and_instructions_match=True,runtime_matches_between_budgets=True,
                        only_14000_series_development_cases=True,completed_subprocesses_validated=True),
        candidates=reports,selected_candidate=winner,selection_mathematically_determined=bool(winner),
        proof=proof,final_ranking=sorted(vectors,key=lambda n:vectors[n][0],reverse=True) if exact else None,
        lower_bound_order=sorted(vectors,key=lambda n:vectors[n][0],reverse=True),
        teacher_complete_for_all=all(r['primary_complete'] for r in reports.values()),
        source_commit=all_protocols[0]['source_commit'])
    a.output_stem.with_suffix('.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    show=lambda b:f"{b['lower']:.2%}" if b['exact'] else f"[{b['lower']:.2%}, {b['upper']:.2%}]"
    lines=['# 开发集选择结果','',
           '排序依次为教师500步六格等权完成率、扩展预算六格等权完成率、教师500步六格等权成功率、扩展六格等权成功率。2×5每格5例，教师2×10每格4例，扩展2×10每格10例。','',
           '| 候选 | 教师已完/27 | 教师完成率 | 扩展已完/45 | 扩展完成率 | 教师成功率 | 扩展成功率 |','|---|---:|---:|---:|---:|---:|---:|']
    for name in payload['lower_bound_order']:
        r=reports[name];t,e=r['teacher500'],r['extended']
        lines.append(f"| {name} | {t['completed']}/27 | {show(t['completion'])} | {e['completed']}/45 | {show(e['completion'])} | {show(t['success'])} | {show(e['success'])} |")
    lines+=['',f"数学上已确定选择：{winner}" if winner else '目前区间仍重叠，尚未确定选择。','',
            '区间对未完成回合按0到满分计算，采用有理数进行精确比较。只读取已正常退出的开发分片。'+('全部开发回合均已完成。' if exact else '未完成的健康计算继续运行。')+'各候选初始随机场景、指令、实际预算和冻结运行代码已核对。']
    if proof:
        lines+=['','| 竞争候选 | 决定排序的指标 | 胜者下界 | 对手上界 |','|---|---|---:|---:|']
        lines += [f"| {p['competitor']} | {p['decisive_metric']} | {p['winner_lower']} | {p['competitor_upper']} |" for p in proof]
    a.output_stem.with_suffix('.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(dict(selected_candidate=winner,selection_mathematically_determined=bool(winner),
                         teacher_complete_for_all=payload['teacher_complete_for_all'],proof=proof),ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
