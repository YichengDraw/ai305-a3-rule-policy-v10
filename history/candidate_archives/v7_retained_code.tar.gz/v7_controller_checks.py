"""V7 public-data regression checks, without environment stepping or rendering."""
from __future__ import annotations
import json
import numpy as np
from controller_contract_checks import setup, public_held_samples
from rule_controller import PAD_OFFSET, _rotation


def run():
    passed=[]
    c,obs,scene=setup('b')
    obs['observation.eef_pose'][:3]=c._preinsert
    pad=obs['observation.eef_pose'][:3]+c._pick_rotation@PAD_OFFSET
    scene['local_align']={'state':'correct','confidence':.8,'valid':False,
        'desired_pad_mid_world':pad+[.006,.001,0.], 'observable_axis_world':[0.,1.,0.],
        'broad_axis_world':[1.,0.,0.], 'gap_width_m':.004,'uncertainty_m':.0004,
        'measurement_id':'broad0','measurement_step':1}
    c._advance('LOCAL_ALIGN');c._local_align(obs,scene)
    assert c.stage=='XY_COARSE' and c._xy_coarse_target[0]>obs['observation.eef_pose'][0]+.002
    assert c._xy_coarse_target[2]>=c._preinsert[2]
    target=c._xy_coarse_target.copy()
    c._alignment_now(obs,scene)
    assert np.allclose(c._xy_coarse_target,target)
    passed.append('6 mm broad residual produces an actual XY action at safe height')

    c,obs,scene=setup('b')
    obs['observation.eef_pose'][:3]=c._preinsert
    c._request_alignment_observation(obs,scene)
    obs['observation.eef_pose'][:3]=c._alignment_view[0]
    import mujoco
    q=np.empty(4);mujoco.mju_mat2Quat(q,c._alignment_view[1].ravel())
    obs['observation.eef_pose'][3:7]=q
    desired=obs['observation.eef_pose'][:3]+c._alignment_view[1]@PAD_OFFSET+[0.,.001,0.]
    scene['local_align']={'state':'correct','confidence':.8,'desired_pad_mid_world':desired,
                         'observable_axis_world':[0.,1.,0.],'broad_axis_world':[1.,0.,0.],
                         'measurement_id':'arrival','measurement_step':10,'gap_width_m':.004,'uncertainty_m':.0004}
    c.act(obs,scene)
    assert c.stage=='ALIGN_OBSERVE' and c._alignment_geometry is None
    scene['local_align'].update(measurement_id='post-arrival',measurement_step=11)
    c.act(obs,scene)
    assert c.stage=='ALIGN_RETURN' and c._alignment_geometry is not None
    assert c._source_memory[0]['observations'][-1]['frame_id']=='post-arrival'
    obs['observation.eef_pose'][:3]+=[-.003,.002,0.]
    scene['local_align']={'state':'unknown','confidence':0.}
    recomputed=c._alignment_now(obs,scene)
    pos,rot=c._snapshot_pose(obs)
    expected=desired-pos-rot@PAD_OFFSET;expected[2]=0.
    assert np.allclose(recomputed['correction_world'],expected)
    passed.append('observation waits for a fresh post-arrival frame and recomputes world geometry after return')
    observations=c._alignment_observations
    c._select(scene)
    assert c._alignment_observations==observations and c._alignment_attempt_views==0
    passed.append('source observation history survives another SELECT attempt')

    c,obs,scene=setup('b')
    sample=public_held_samples()[0]
    scene['held']={**sample,'age_steps':0,'estimate_state':'measured','currently_held':True}
    c._held_update(scene);original=c._held_center_local.copy()
    c.total_steps+=20
    scene['held']={**sample,'center_tool':[.09,.09,.09],'age_steps':20,'estimate_state':'predicted'}
    c._held_update(scene)
    assert np.allclose(c._held_center_local,original) and c._request_held_refresh
    assert c._held_pose_confidence<sample['pose_confidence']
    passed.append('predicted stale held pose does not overwrite measured geometry and requests a current image')

    c,obs,scene=setup('b')
    held={'center_tool':[0.,0.,0.],'rotation_tool':np.eye(3),'pose_confidence':.8,
          'geometry_generation':0,'measurement_id':1,'age_steps':0,'uncertainty_m':.0005,'width_m':.0633333333}
    c._held_width=.0633333333
    assert not c._slip_evidence(held)[2]
    held.update(rotation_tool=_rotation('z',.20),measurement_id=2)
    confident,endpoint,confirmed=c._slip_evidence(held)
    assert confident and endpoint>.004 and not confirmed
    assert not c._slip_evidence(held)[2]
    held.update(measurement_id=3)
    assert c._slip_evidence(held)[2]
    passed.append('rotation is evaluated by endpoint displacement and requires two distinct current measurements')

    c,obs,scene=setup('b')
    first,second=public_held_samples()
    scene['held']=first;c._held_update(scene)
    c._place_box_frozen=True;c._placement_goal=c._place_pose(scene)
    frozen=tuple(x.copy() for x in c._placement_goal)
    c._advance('PLACE');scene['held']=second;c._held_update(scene)
    assert all(np.allclose(a,b) for a,b in zip(frozen,c._placement_goal))
    passed.append('contact-time held refit does not move the frozen descent goal')
    for state in ('target','source','held'):
        c,obs,scene=setup('b')
        c.ledger['grasp_verified']=True
        c.ledger['held_indices']=list(c.ledger['planned_indices'])
        c._start_object_localization('public trace recovery probe')
        scene['object_location']={'state':state,'confidence':.8,'age_steps':0,'measurement_id':1}
        if state=='held':
            scene['held']={**public_held_samples()[0],'currently_held':True,'pose_state':'measured','measurement_current':True}
            obs['observation.force'][12:14]=1.3
        c.act(obs,scene)
        assert c.stage=='OBJECT_LOCALIZE'
        scene['object_location']['measurement_id']=2
        c.act(obs,scene)
        assert c.stage=={'target':'OPEN','source':'SELECT','held':'TRANSPORT'}[state]
        assert c.ledger['grasp_verified'] is True
        assert c.ledger['currently_held'] is (state=='held')
    passed.append('two current physical-location samples branch to target/source/hand while preserving historical grasp')

    c,obs,scene=setup('b')
    c.is_2x10=True;c.batch_sizes=[1,9,1,9];c.batch_index=1
    c.geometry={'target_bin_half_size_m':[.063,.0508333333],'bin_wall_thickness_m':.006}
    c._held_width=.057
    c._column_occupancy={0:{'bounds':[[-.053,-.003],[-.035667,-.029333],[.003,.028]],
                               'confidence':.68,'uncertainty_m':.002,'scope':'column','measurement_id':'occ1'}}
    y=c._space_center(scene,0,.007166667)
    space=c.current_report['placement_space']
    assert c._placement_feasible and abs(y-.007166667)<1e-8
    chosen=space['intervals'][-1]
    assert chosen['y_min']<=y<=chosen['y_max']
    c._column_occupancy[0]['bounds'][1][1]=-.022
    y=c._space_center(scene,0,.007166667)
    assert c._placement_feasible and c._release_extra_gap==.003
    assert c.current_report['placement_space']['template']=='narrow_release'
    c._column_occupancy[0]['bounds'][1][1]=.025
    c._space_center(scene,0,.007166667)
    assert not c._placement_feasible and c.current_report['placement_space']['chosen_y'] is None
    passed.append('second-group center simultaneously satisfies occupied-front and rear-wall bounds; narrow opening has its own envelope')

    c.batch_index=3
    scene['placement']={'state':'valid','confidence':.8,'count':10,'count_confidence':.8,'count_scope':'column'}
    assert c._placement_state(scene)[0]=='valid'
    passed.append('column-scoped count uses the current column total instead of the whole task total')
    return {'passed':len(passed),'checks':passed}

if __name__=='__main__':
    print(json.dumps(run(),ensure_ascii=False,indent=2))
