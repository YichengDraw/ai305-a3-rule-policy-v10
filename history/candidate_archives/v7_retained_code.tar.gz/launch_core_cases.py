"""Freeze a candidate and run the plan's eight development cases.

The 15000-series cases were used to design the changes and are development
data here. Final selection must precede the separate 16000-series test.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time


CASES = (
    ("align", "2x10", "advanced", 15017, 4),
    ("recover_single", "2x10", "basic", 15001, 1),
    ("remaining_single", "2x10", "basic", 15010, 9),
    ("wide_source", "2x10", "basic", 15000, 0),
    ("target_pose", "2x10", "advanced", 15019, 5),
    ("target_slots", "2x5", "advanced", 15009, 5),
    ("advanced_success", "2x10", "advanced", 15002, 1),
    ("basic_success", "2x5", "basic", 15000, 5),
)
RUNTIME = ("policy.py", "rule_controller.py", "perception.py", "placement_audit.py")
HELPERS = ("run_dev.py", "evaluate_policy.py", "diagnostic_support.py", "batch_metrics.py")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--policy-code", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--policy", default="policy:make_policy_b")
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--egl-devices", type=int, nargs="+", default=[4])
    parser.add_argument("--cases", nargs="+", choices=[c[0] for c in CASES])
    parser.add_argument("--video-cases", nargs="*", choices=[c[0] for c in CASES],
                        default=["align", "target_pose"],
                        help="Full independent three-camera diagnostic video for these cases")
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("workers must be positive")
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=False)
    code = root / "code"
    code.mkdir()
    source = Path(__file__).resolve().parent
    runtime = args.policy_code.resolve()
    for name in RUNTIME:
        shutil.copy2(runtime / name, code / name)
    for name in HELPERS:
        shutil.copy2(source / name, code / name)
    hashes = {name: hashlib.sha256((code / name).read_bytes()).hexdigest()
              for name in RUNTIME + HELPERS}
    cases = [c for c in CASES if not args.cases or c[0] in args.cases]
    jobs = [dict(label=label, task=task, profile=profile, seed=seed, n=n,
                 gpu=args.egl_devices[i % len(args.egl_devices)], video=label in args.video_cases)
            for i, (label, task, profile, seed, n) in enumerate(cases)]
    protocol = dict(scope="v7_core_development", development_only=True,
                    started_utc=datetime.now(timezone.utc).isoformat(),
                    policy=args.policy, runtime_truth_access=False,
                    offline_ground_truth_audit=True, source_column=1,
                    max_steps_by_task={"2x5": 500, "2x10": 3200},
                    success_hold_steps=5, strict_policy_completion=False,
                    policy_code_directory=str(code), code_sha256=hashes, jobs=jobs)
    (root / "protocol.json").write_text(json.dumps(protocol, indent=2) + "\n")
    start = time.monotonic()

    def run(job):
        name = f"{job['task']}_{job['profile']}_{job['seed']}_n{job['n']}"
        output = root / name
        budget = 500 if job["task"] == "2x5" else 3200
        env = dict(os.environ, MUJOCO_GL="egl", MUJOCO_EGL_DEVICE_ID=str(job["gpu"]),
                   CUDA_VISIBLE_DEVICES=str(job["gpu"]), OMP_NUM_THREADS="1",
                   MKL_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", A3_POLICY_MAX_STEPS=str(budget))
        command = [sys.executable, str(code / "run_dev.py"), "--task", job["task"],
                   "--profile", job["profile"], "--seed", str(job["seed"]),
                   "--first-grasp", str(job["n"]), "--max-steps", str(budget),
                   "--output", str(output), "--policy", args.policy, "--code-dir", str(code)]
        if not job["video"]:
            command.append("--no-video")
        print("START", name, job["label"], flush=True)
        with (root / (name + ".log")).open("w") as log:
            process = subprocess.run(command, cwd=code, env=env, stdout=log, stderr=subprocess.STDOUT)
        print("FINISH", name, "rc", process.returncode, flush=True)
        return dict(job, output=str(output), returncode=process.returncode, command=command)

    done = []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        for future in as_completed([pool.submit(run, job) for job in jobs]):
            done.append(future.result())
            (root / "progress.json").write_text(json.dumps(dict(
                finished=len(done), total=len(jobs), jobs=done), indent=2) + "\n")
    complete = dict(status="completed" if all(j["returncode"] == 0 for j in done) else "failed",
                    jobs=done, wall_seconds=time.monotonic() - start,
                    finished_utc=datetime.now(timezone.utc).isoformat())
    (root / "complete.json").write_text(json.dumps(complete, indent=2) + "\n")
    if complete["status"] != "completed":
        raise SystemExit("Core development subprocess errors; inspect logs")


if __name__ == "__main__":
    main()
