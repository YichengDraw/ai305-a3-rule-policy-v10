"""Freeze the selected runtime and the exact formal evaluation helpers."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

p=argparse.ArgumentParser()
p.add_argument('--candidate',type=Path,required=True)
p.add_argument('--selection',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
decision=json.loads(a.selection.read_text())
source=Path(__file__).resolve().parent
a.output.mkdir(exist_ok=False)
runtime=('policy.py','perception.py','rule_controller.py','placement_audit.py')
helpers=('evaluate_policy.py','diagnostic_support.py','batch_metrics.py',
         'launch_evaluation.py','launch_paired_formal.py','merge_results.py',
         'paired_comparison.py','run_dev.py')
for n in runtime:shutil.copy2(a.candidate/n,a.output/n)
for n in helpers:shutil.copy2(source/n,a.output/n)
manifest=dict(status='frozen_for_formal',frozen_utc=datetime.now(timezone.utc).isoformat(),
    chosen_factory='policy:make_policy_b',candidate_directory=str(a.candidate.resolve()),
    selection_evidence=str(a.selection.resolve()),selection=decision,
    formal_seeds=[16000,16019],source_column=1,success_hold_steps=5,
    strict_policy_completion=False,teacher_budgets={'2x5':500,'2x10':500},
    extended_budgets={'2x5':500,'2x10':3200},
    sha256={n:hashlib.sha256((a.output/n).read_bytes()).hexdigest() for n in runtime+helpers})
(a.output/'code_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'output':str(a.output.resolve()),'factory':manifest['chosen_factory'],'files':len(runtime+helpers)}))
