"""Package the frozen policy, original scores and independent replay tools."""
from pathlib import Path
import hashlib
import json
import zipfile

root=Path(__file__).resolve().parent
audit=json.loads((root/'verification.json').read_text())
assert audit['validation']['raw_shards']==360 and audit['validation']['all_returncodes_zero']
assert audit['validation']['raw_and_merged_identical']
manifest=json.loads((root/'frozen_policy_v7/code_manifest.json').read_text())
required=('README.md','最终评测结果.md','final_results.json','verification.json','verification.md',
          'formal_audit_raw.json','source_plan.md','teacher_protocol_excerpt.md','evaluation_protocol.md',
          'adopted_changes.md','run_environment.json','status.md','selection_protocol.json',
          'selection_early.json','selection_early.md','composition_verification.json','composition_verification.md')
tools=('policy.py','perception.py','rule_controller.py','placement_audit.py',
       'audit_paired_formal.py','collect_formal_raw.py','batch_metrics.py','diagnostic_support.py',
       'summarize_dev_reference.py','summarize_dev_comparison.py','summarize_v7_development.py',
       'launch_dev_grid.py','launch_core_cases.py','run_dev.py','evaluate_policy.py',
       'launch_evaluation.py','launch_paired_formal.py','merge_results.py',
       'paired_comparison.py','collect_dev_raw.py','summarize_core_cases.py','selection_summary.py',
       'freeze_candidate.py','write_final_report.py','package_release.py')
files={root/n for n in required+tools}
for folder in ('frozen_policy_v7','baseline_v6'):
    files.update(p for p in (root/folder).iterdir() if p.suffix in ('.py','.json'))
for pattern in ('selection_final.*','dev_core_*.json','dev_core_*.md',
                'grid_*_raw.json','grid_*_comparison.json','grid_*_comparison.md',
                'budget500_*_raw.json','budget500_*_comparison.json','budget500_*_comparison.md',
                'core_*_comparison.json','core_*_comparison.md','controller_changes.md','perception_changes.md',
                'candidate_r5_composition.json'):
    files.update(root.glob(pattern))
formal=root/'formal_pair_v7'
files.update(formal.glob('*.json'))
files.update(formal.glob('comparison*/*'))
for label in ('v6','v7'):
    files.update((formal/label).glob('*.json'))
    for group in ('final_default','final_official500','final_extra_2x10_500'):
        files.update((formal/label/group).glob('*'))
files={p for p in files if p.is_file()}
assert all((root/n).is_file() for n in required+tools)
archive=root/'rule_policy_v7_release_20261102.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as out:
    for p in sorted(files):out.write(p,root.name+'/'+str(p.relative_to(root)))
with zipfile.ZipFile(archive) as out:
    assert out.testzip() is None
    for name,digest in manifest['sha256'].items():
        assert hashlib.sha256(out.read(root.name+'/frozen_policy_v7/'+name)).hexdigest()==digest
    for label in ('v6','v7'):
        for group in ('final_default','final_official500'):
            rows=out.read(root.name+f'/formal_pair_v7/{label}/{group}/episodes.jsonl').decode().splitlines()
            assert len(rows)==120
receipt=dict(archive=str(archive),files=len(files),bytes=archive.stat().st_size,
             zip_crc_checked=True,frozen_files_match_manifest=True,
             actual_formal_episodes=360,tables_per_policy=2,rows_per_table=120)
(root/'release_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False))
