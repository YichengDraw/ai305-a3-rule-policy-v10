#!/usr/bin/env python3
"""Paired analysis of the O1 (outer IK dispatch) replay against its parent.

Reads two replay roots produced by launch_replays.py with the same case group,
the same CPU/OSMesa backend and the same official protocol, and reports per-case
native outcomes (score / cookies_in_source / official success / steps / end
phase), trace stage occupancy, and - for the candidate - the recorded
`finite_pitch_search.plan_state` distribution from the diagnostic frames.

No official field is recomputed: score and success are read verbatim.

Usage: analyze_o1_pair.py PARENT_ROOT CANDIDATE_ROOT OUT_DIR
"""
import json
import sys
from collections import Counter
from pathlib import Path


def load_result(case_dir):
    path = case_dir / 'result.json'
    if not path.exists():
        return dict(score=None, success=None, steps=None, source=None, phase='MISSING')
    result = json.loads(path.read_text())
    return dict(score=result.get('score'), success=result.get('success'), steps=result.get('steps'),
                source=result.get('cookies_in_source'), phase=result.get('phase'),
                failure_reason=result.get('failure_reason'), target=result.get('cookies_in_target'),
                profile=result.get('profile'), n=(result.get('randomization') or {}).get('first_grasp_count'))


def trace_stage_counts(case_dir):
    counts = Counter()
    trace = case_dir / 'policy_trace'
    if not trace.is_dir():
        return counts
    for path in sorted(trace.glob('seed_*.jsonl')):
        with path.open() as handle:
            for line in handle:
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue
                counts[(row.get('phase'), (row.get('request') or {}).get('stage'))] += 1
    return counts


def pitch_states(case_dir):
    """count plan_state / selected pitch / variant from recorded public evidence"""
    frames = case_dir / 'diagnostic' / 'frames.jsonl'
    states = Counter()
    pitches = Counter()
    variants = Counter()
    lattices = Counter()
    seen = 0
    if not frames.exists():
        return dict(plan_state=states, selected_pitch=pitches, lattice=lattices, variant=variants, rows=0)
    with frames.open() as handle:
        for line in handle:
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            evidence = (row.get('policy_public_evidence_after_act') or {})
            controller = evidence.get('controller') or {}
            search = ((controller.get('public_evidence') or {}).get('finite_pitch_search') or {})
            if not search:
                search = (((evidence.get('policy') or {}).get('public_evidence') or {}).get('finite_pitch_search') or {})
            if not search:
                continue
            seen += 1
            states[str(search.get('plan_state'))] += 1
            if search.get('selected_pitch') is not None:
                pitches[search.get('selected_pitch')] += 1
                lattices[str(search.get('selected_lattice'))] += 1
                variants[str(search.get('selected_variant'))] += 1
    return dict(plan_state=states, selected_pitch=pitches, lattice=lattices, variant=variants, rows=seen)


def jobs_of(root):
    protocol = json.loads((root / 'protocol.json').read_text())
    return [job['label'] for job in protocol.get('jobs', [])]


def main():
    parent = Path(sys.argv[1])
    candidate = Path(sys.argv[2])
    out = Path(sys.argv[3])
    out.mkdir(parents=True, exist_ok=True)
    lines = ['# O1 配对结果（外列 IK 分流）', '', f'- 父版：{parent}', f'- 候选：{candidate}', '']
    rows = []
    for label in jobs_of(candidate):
        p = load_result(parent / label)
        c = load_result(candidate / label)
        row = dict(label=label, profile=c.get('profile'), n=c.get('n'), parent=p, candidate=c,
                   delta_score=None if c['score'] is None or p['score'] is None else c['score'] - p['score'],
                   success_change=None if c['success'] is None or p['success'] is None else int(bool(c['success'])) - int(bool(p['success'])),
                   parent_stages=dict(trace_stage_counts(parent / label)),
                   candidate_stages=dict(trace_stage_counts(candidate / label)),
                   candidate_pitch=pitch_states(candidate / label))
        rows.append(row)

    lines.append('| case | profile | n | 父 分数/源/成功/步 | 候选 分数/源/成功/步 | Δ分 | 成功变化 | 父末阶段 | 候选末阶段 |')
    lines.append('|---|---|---:|---|---|---:|---|---|---|')
    for r in rows:
        p, c = r['parent'], r['candidate']
        lines.append(f"| {r['label']} | {r['profile']} | {r['n']} | {p['score']}/{p['source']}/{p['success']}/{p['steps']} | {c['score']}/{c['source']}/{c['success']}/{c['steps']} | {r['delta_score']} | {r['success_change']} | {p['phase']} | {c['phase']} |")

    lines += ['', '## 机制触发（候选端记录的 finite_pitch_search）', '']
    for r in rows:
        info = r['candidate_pitch']
        lines.append(f"- {r['label']}: plan_state {dict(info['plan_state'])}；选中 pitch {dict(info['selected_pitch'])}；lattice {dict(info['lattice'])}；variant {dict(info['variant'])}（记录行 {info['rows']}）")

    lines += ['', '## 阶段占用（SOURCE_OBSERVE 等）', '']
    for r in rows:
        parent_so = sum(v for k, v in r['parent_stages'].items() if k[0] == 'SOURCE_OBSERVE' or k[1] == 'SOURCE_OBSERVE')
        cand_so = sum(v for k, v in r['candidate_stages'].items() if k[0] == 'SOURCE_OBSERVE' or k[1] == 'SOURCE_OBSERVE')
        lines.append(f"- {r['label']}: SOURCE_OBSERVE 行 父 {parent_so} → 候选 {cand_so}")

    gained = [r['label'] for r in rows if r['success_change'] == 1]
    lost = [r['label'] for r in rows if r['success_change'] == -1]
    regressions = [r['label'] for r in rows if (r['delta_score'] or 0) < 0]
    summary = dict(cases=len(rows), gained_successes=gained, lost_successes=lost, quantity_regressions=regressions,
                   parent_score_sum=sum((r['parent']['score'] or 0) for r in rows),
                   candidate_score_sum=sum((r['candidate']['score'] or 0) for r in rows),
                   parent_success=sum(int(bool(r['parent']['success'])) for r in rows),
                   candidate_success=sum(int(bool(r['candidate']['success'])) for r in rows))
    lines += ['', '## 汇总', '', f"- 例数 {summary['cases']}；数量 {summary['parent_score_sum']} → {summary['candidate_score_sum']}；官方成功 {summary['parent_success']} → {summary['candidate_success']}",
              f"- 新增成功 {gained}；丢失成功 {lost}；数量回退 {regressions}"]
    (out / 'o1_pairs.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    (out / 'o1_pairs.json').write_text(json.dumps(dict(summary=summary, cases=rows), ensure_ascii=False, indent=1, default=str))
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == '__main__':
    main()
