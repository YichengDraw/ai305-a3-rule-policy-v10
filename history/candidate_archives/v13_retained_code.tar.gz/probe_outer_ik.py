#!/usr/bin/env python3
"""Offline probe: fixed-kinematics IK residuals for an outer-column stuck frame.

Reads a completed outer replay case (policy_trace + diagnostic frames), rebuilds
the real production objects (config, MuJoCo model, outer RuleController,
FixedRobotPitchSearch, PathFeasibility) and re-runs the IK search on the
recorded public inputs. No simulation is started and no official result is
touched. Purpose: test whether the recorded "all pitches unreachable" is a
sampling-lattice artefact (12 mm / 0.08 rad) before changing production code.

Usage: probe_outer_ik.py CASE_DIR [TRACE_ROW|-1]
"""
import json
import sys
from pathlib import Path

import numpy as np

CASE = Path(sys.argv[1])
ROW = int(sys.argv[2]) if len(sys.argv) > 2 else -1
PY_NAMES = ('LEFT_JOINTS', 'RIGHT_JOINTS')


def load_rows(path):
    rows = []
    with path.open() as handle:
        for line in handle:
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return rows


def public_state(case, step):
    frames = case / 'diagnostic' / 'frames.jsonl'
    with frames.open() as handle:
        for line in handle:
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            if row.get('step') == step:
                return row.get('public_before') or {}
    return {}


def main():
    import mujoco
    from scipy.spatial.transform import Rotation, Slerp
    from a3_dual_arm_sim.config import load_config
    from a3_dual_arm_sim.paths import resource_root
    from a3_dual_arm_sim.sim.model import build_model
    from v10_leaves_17e0363838a9.two10_outer.rule_controller import RuleController
    from v10_leaves_17e0363838a9.two10_outer.f_source_controller import FixedRobotPitchSearch
    from v10_leaves_17e0363838a9.two10_outer.path_feasibility import PathFeasibility

    trace = sorted((CASE / 'policy_trace').glob('seed_*.jsonl'))[0]
    rows = load_rows(trace)
    row = rows[ROW]
    step = int(row['step'])
    request = row.get('request') or {}
    perception = row.get('perception') or {}
    group = perception.get('group')
    target = perception.get('target_box')
    source = perception.get('source_box')
    print(json.dumps(dict(step=step, phase=row.get('phase'), stage=request.get('stage'),
                          batch=request.get('batch_index'), count=request.get('count'),
                          source_column=request.get('source_column'),
                          group_center=None if not group else group.get('center'),
                          group_conf=None if not group else group.get('confidence'),
                          fixed_pitch=request.get('finite_pitch_search')), ensure_ascii=False, default=str)[:600])

    public = public_state(CASE, step)
    observation = dict(public)
    if 'observation.eef_pose' not in observation and row.get('eef') is not None:
        observation['observation.eef_pose'] = row['eef']
    observation.setdefault('time', float(row.get('time', 0.0)))
    observation.setdefault('observation.force', row.get('force'))
    missing = [k for k in ('observation.state', 'observation.eef_pose') if k not in observation]
    if missing:
        print('MISSING_PUBLIC_FIELDS', missing)
        return 2

    config = load_config(resource_root() / 'configs' / 'cookie_2x10.yaml')
    model = build_model(config, scene='cookie_transfer').model
    controller = RuleController(config)
    controller.reset({'task': request.get('task') or 'Transfer 20 cookies from source column 4 into the 2x10 target box. Grasp 0 cookies first, then 10 to fill target column 1 with 10. Repeat: grasp 0, then 10 to fill target column 2 with 10. Release all 20 cookies upright in the target box and leave 60 in the source box.'})
    controller.batch_index = int(request.get('batch_index') or 0)
    controller.stage = 'SELECT'
    planner = FixedRobotPitchSearch(model, config, PathFeasibility(config))
    controller._f_planner = planner

    scene = {'source_box': source, 'target_box': target, 'source_geometry': None}

    def ik_with(observation, waypoints, sample_m, sample_rad):
        work, q = planner.public_kinematics(observation)
        max_position = max_angle = 0.0
        samples = 0
        public_pose = np.asarray(observation['observation.eef_pose'], float)[:7]
        rotation = np.empty(9)
        mujoco.mju_quat2Mat(rotation, public_pose[3:7])
        nodes = [dict(name='public_current', position=public_pose[:3], rotation=rotation.reshape(3, 3))]
        nodes.extend({**p, 'position': np.asarray(p['position'], float), 'rotation': np.asarray(p['rotation'], float).reshape(3, 3)} for p in waypoints)
        for start, end in zip(nodes[:-1], nodes[1:]):
            length = float(np.linalg.norm(end['position'] - start['position']))
            angle = float(np.linalg.norm(Rotation.from_matrix(start['rotation'].T @ end['rotation']).as_rotvec()))
            steps = max(1, int(np.ceil(length / sample_m)), int(np.ceil(angle / sample_rad)))
            slerp = Slerp([0.0, 1.0], Rotation.from_matrix(np.array([start['rotation'], end['rotation']])))
            for t in np.linspace(0.0, 1.0, steps + 1)[1:]:
                position = (1 - t) * start['position'] + t * end['position']
                rot = slerp(t).as_matrix()
                quat = np.empty(4)
                mujoco.mju_mat2Quat(quat, rot.ravel())
                q = planner.adapter.solve(position, quat, q)
                work.qpos[list(planner.adapter._qpos_ids[0])] = q
                mujoco.mj_kinematics(planner.model, work)
                actual = np.empty(4)
                error = np.empty(3)
                mujoco.mju_mat2Quat(actual, work.site_xmat[planner.site])
                mujoco.mju_subQuat(error, quat, actual)
                pe = float(np.linalg.norm(work.site_xpos[planner.site] - position))
                ae = float(np.linalg.norm(error))
                samples += 1
                max_position = max(max_position, pe)
                max_angle = max(max_angle, ae)
                if (not np.all(np.isfinite(q))) or pe > 0.0008 or ae > 0.015:
                    return dict(state='unreachable', segment=[start['name'], end['name']], position_error_m=pe, rotation_error_rad=ae, samples=samples)
        return dict(state='reachable', max_position_error_m=max_position, max_rotation_error_rad=max_angle, samples=samples)

    if not group or not target:
        print('NO_GROUP_OR_TARGET')
        return 2
    print('\n== production search (unchanged) ==')
    result = planner.search(controller, observation, scene, group)
    for c in result['candidates']:
        print(json.dumps(dict(pitch=c['pitch_deg'], ik=c['ik_state'], seg=c['ik'].get('segment'),
                              pos_mm=None if c['ik'].get('position_error_m') is None else round(c['ik']['position_error_m'] * 1000, 3),
                              rot_mrad=None if c['ik'].get('rotation_error_rad') is None else round(c['ik']['rotation_error_rad'] * 1000, 2),
                              path=c['path_state']), ensure_ascii=False))

    print('\n== sampling lattice sweep (same waypoints, same thresholds 0.8mm/0.015rad) ==')
    for pitch in planner.pitches:
        geometry = planner.geometry(controller, observation, group, pitch)
        points = planner.waypoints(controller, observation, scene, group, geometry)
        out = []
        for sample_m, sample_rad in ((0.012, 0.08), (0.006, 0.04), (0.003, 0.02)):
            ik = ik_with(observation, points, sample_m, sample_rad)
            out.append(dict(grid=f'{sample_m * 1000:.0f}mm/{sample_rad:.2f}rad', state=ik['state'],
                            seg=ik.get('segment'), pos_mm=None if ik.get('position_error_m') is None else round(ik['position_error_m'] * 1000, 3),
                            samples=ik['samples']))
        print(json.dumps(dict(pitch=pitch, tries=out), ensure_ascii=False))

    print('\n== transit variants when the failing segment is the lateral high transit ==')
    for pitch in planner.pitches:
        geometry = planner.geometry(controller, observation, group, pitch)
        points = planner.waypoints(controller, observation, scene, group, geometry)
        names = [p['name'] for p in points]
        if 'lift_high' not in names or 'target_high' not in names:
            continue
        i = names.index('lift_high')
        j = names.index('target_high')
        lift = np.asarray(points[i]['position'], float)
        tgt = np.asarray(points[j]['position'], float)
        mid = (lift + tgt) / 2.0
        mid_point = dict(points[j], name='transit_mid', position=mid)
        lateral = np.array([tgt[0], tgt[1], max(lift[2], tgt[2])])
        lateral_point = dict(points[j], name='transit_lateral', position=lateral)
        for label, extra in (('midpoint', [mid_point]), ('lateral_then_descend', [lateral_point])):
            variant = points[:j] + extra + points[j:]
            fine = ik_with(observation, variant, 0.003, 0.02)
            base = ik_with(observation, variant, 0.012, 0.08)
            print(json.dumps(dict(pitch=pitch, variant=label,
                                  base=dict(state=base['state'], seg=base.get('segment'), pos_mm=None if base.get('position_error_m') is None else round(base['position_error_m'] * 1000, 3)),
                                  fine=dict(state=fine['state'], seg=fine.get('segment'), pos_mm=None if fine.get('position_error_m') is None else round(fine['position_error_m'] * 1000, 3))), ensure_ascii=False))

    print('\n== extra pitches at base lattice ==')
    for pitch in (-30.0, -60.0, -65.0):
        geometry = planner.geometry(controller, observation, group, pitch)
        points = planner.waypoints(controller, observation, scene, group, geometry)
        ik = ik_with(observation, points, 0.012, 0.08)
        fine = ik_with(observation, points, 0.003, 0.02)
        print(json.dumps(dict(pitch=pitch, base=dict(state=ik['state'], seg=ik.get('segment'), pos_mm=None if ik.get('position_error_m') is None else round(ik['position_error_m'] * 1000, 3)),
                              fine=dict(state=fine['state'], seg=fine.get('segment'), pos_mm=None if fine.get('position_error_m') is None else round(fine['position_error_m'] * 1000, 3))), ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
