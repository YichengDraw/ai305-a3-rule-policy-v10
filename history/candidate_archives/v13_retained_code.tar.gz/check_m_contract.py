#!/usr/bin/env python3
"""M2 contract: the admitted route is the executed route (real code path, synthetic plan).

Part A (shadow): `check_o1_contract.py` output for this candidate must equal the parent's
stage/pitch/candidate states (proved separately, see `out_contract_m.json`).

Part B (plan consumption): drive the real outer controller's `act()` at a recorded
TRANSPORT frame with a synthetic execution plan whose single `transit_mid` node sits at
the current EEF pose. The production branch must (1) consume that node before the final
target and (2) drop it when the target geometry epoch changes.

`synthetic=true`: the plan nodes are injected; the observation/scene come from a real
recorded episode frame. This proves interface behaviour only, not physical benefit.

Usage: check_m_contract.py CODE_ROOT FRAME_CASE_DIR OUT_JSON
"""
import json
import sys
from pathlib import Path

import numpy as np


def load_transport_row(case_dir):
    trace = sorted((Path(case_dir) / 'policy_trace').glob('seed_*.jsonl'))[0]
    rows = []
    with trace.open() as handle:
        for line in handle:
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            if row.get('phase') == 'TRANSPORT':
                rows.append(row)
    return rows[len(rows) // 2]


def public_state(case_dir, step):
    frames = Path(case_dir) / 'diagnostic' / 'frames.jsonl'
    with frames.open() as handle:
        for line in handle:
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            if row.get('step') == step:
                return row.get('public_before') or {}
    return {}


def main():
    root, case_dir, out_path = sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3])
    sys.path.insert(0, root)
    from a3_dual_arm_sim.config import load_config
    from a3_dual_arm_sim.paths import resource_root
    from v10_leaves_17e0363838a9.two10_outer.rule_controller import RuleController

    row = load_transport_row(case_dir)
    request = row.get('request') or {}
    perception = row.get('perception') or {}

    def setup(changed_epoch=False):
        observation = dict(public_state(case_dir, row['step']))
        observation.setdefault('observation.eef_pose', row.get('eef'))
        observation.setdefault('observation.force', row.get('force'))
        observation.setdefault('time', float(row.get('time', 0.0)))
        scene = {k: perception.get(k) for k in ('source_box', 'target_box', 'group', 'source_frontier', 'source_geometry', 'held', 'target_occupancy')}
        if changed_epoch and isinstance(scene.get('target_box'), dict):
            scene['target_box'] = dict(scene['target_box'], geometry_version=str(scene['target_box'].get('geometry_version')) + ':changed')
        controller = RuleController(load_config(resource_root() / 'configs' / 'cookie_2x10.yaml'))
        controller.reset({'task': request.get('task') or 'Transfer 20 cookies from source column 4 into the 2x10 target box.'})
        controller.batch_index = int(request.get('batch_index') or 0)
        controller.stage = 'TRANSPORT'
        controller.total_steps = int(row.get('step') or 0)
        controller._obs = observation
        controller._scene = scene
        group = scene.get('group') or {}
        controller._f_selected_pitch = -35.0
        controller._f_pinch_height = 0.01
        if group.get('center') is not None:
            controller._apply_group_geometry(group)
        controller._target_box_reference = scene.get('target_box')
        controller._place_box_frozen = False
        controller._placement_goal = None
        controller._carry_path = [(np.asarray(observation['observation.eef_pose'], float)[:3].copy(), np.eye(3))]
        controller._carry_source_high_pose = controller._carry_path[0]
        pose = np.asarray(observation['observation.eef_pose'], float)
        quat = pose[3:7]
        w, x, y, z = quat
        rotation = np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                             [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                             [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])
        node = dict(name='transit_mid', position=pose[:3].copy(), rotation=rotation.copy(), opening=float(pose[6]) if pose.size > 6 else 0.0, carrying=True, box_key='target_box')
        controller._execution_plan = dict(plan_id='synthetic:transit_mid', batch_index=controller.batch_index, pitch=-35.0, variant='transit_midpoint', nodes=[node], target_epoch=(perception.get('target_box') or {}).get('geometry_version'), source_epoch=None, created_step=controller.total_steps, consumed_nodes=[], rule='synthetic contract plan')
        controller._plan_pending_nodes = [node]
        controller._plan_invalidations = []
        return controller, observation, scene

    report = []
    controller, observation, scene = setup()
    try:
        action = controller.act(observation, scene)
        report.append(dict(step='consume_1', stage_after=str(controller.stage), pending_after=len(controller._plan_pending_nodes), consumed=list((controller._execution_plan or {}).get('consumed_nodes') or []), action=np.asarray(action, float)[:7].tolist(), error=None))
    except Exception as error:
        report.append(dict(step='consume_1', error=f'{type(error).__name__}: {error}'))

    controller, observation, scene = setup(changed_epoch=True)
    try:
        action = controller.act(observation, scene)
        report.append(dict(step='epoch_change', stage_after=str(controller.stage), pending_after=len(controller._plan_pending_nodes), invalidations=list(getattr(controller, '_plan_invalidations', []) or []), action=np.asarray(action, float)[:7].tolist(), error=None))
    except Exception as error:
        report.append(dict(step='epoch_change', error=f'{type(error).__name__}: {error}'))

    out = dict(code_root=root, frame_step=row['step'], synthetic=True, synthetic_fields=['execution_plan', 'transit_mid node'],
               source_inputs='recorded public observation/perception of a real TRANSPORT frame', rows=report,
               consumed_before_final_target=bool(report and report[0].get('consumed')),
               invalidated_on_epoch_change=bool(len(report) > 1 and report[1].get('invalidations')))
    print(json.dumps(out, ensure_ascii=False, indent=1))
    out_path.write_text(json.dumps(out, ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()
