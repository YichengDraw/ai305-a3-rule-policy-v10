#!/usr/bin/env python3
"""F1 evidence: does an explicit target view really produce a new occupancy measurement?

For a candidate run and (optionally) its parent run, scan the policy traces and count,
per case, the target-occupancy measurement activity recorded in `perception.target_visibility`:
  * rows where a measurement object exists,
  * distinct `measurement_step` values (a new step == a new measurement instance),
  * the recorded `dispatch_reason` values and `request_stage` values,
  * per-column fusion states (measured / conflicting_views / creation_requires_conflict_free_support ...).

Read-only; the official score is read verbatim from result.json.
Usage: analyze_f1.py CAND_ROOT [PARENT_ROOT] OUT_DIR
"""
import json
import sys
from collections import Counter
from pathlib import Path


def scan(case_dir):
    trace = case_dir / 'policy_trace'
    rows = 0
    with_measurement = 0
    steps = set()
    reasons = Counter()
    stages = Counter()
    states = Counter()
    preplace_steps = set()
    result_path = case_dir / 'result.json'
    result = json.loads(result_path.read_text()) if result_path.exists() else {}
    if trace.is_dir():
        newest = max(trace.glob('seed_*.jsonl'), key=lambda p: p.stat().st_size, default=None)
        if newest is not None:
            with newest.open() as handle:
                for line in handle:
                    try:
                        row = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    rows += 1
                    stage = str((row.get('request') or {}).get('stage', ''))
                    perception = row.get('perception') or {}
                    visibility = perception.get('target_visibility')
                    if not isinstance(visibility, dict):
                        continue
                    with_measurement += 1
                    step = visibility.get('measurement_step')
                    if step is not None:
                        steps.add(int(step))
                        if stage == 'PREPLACE_OBSERVE':
                            preplace_steps.add(int(step))
                    if visibility.get('dispatch_reason'):
                        reasons[str(visibility.get('dispatch_reason'))[:80]] += 1
                    if visibility.get('request_stage'):
                        stages[str(visibility.get('request_stage'))] += 1
                    for key, diag in (visibility.get('columns') or {}).items():
                        if isinstance(diag, dict):
                            states[f"{key}:{diag.get('state')}"] += 1
    return dict(label=case_dir.name, score=result.get('score'), source=result.get('cookies_in_source'),
                success=result.get('success'), steps=result.get('steps'), trace_rows=rows,
                rows_with_measurement=with_measurement, distinct_measurement_steps=len(steps),
                preplace_measurement_steps=len(preplace_steps), dispatch_reasons=dict(reasons),
                request_stages=dict(stages), column_states=dict(states.most_common(8)))


def main():
    cand = Path(sys.argv[1])
    parent = Path(sys.argv[2]) if len(sys.argv) > 3 else None
    out = Path(sys.argv[3])
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    for case in sorted(p for p in cand.iterdir() if p.is_dir() and (p / 'policy_trace').is_dir()):
        entry = dict(candidate=scan(case))
        if parent is not None and (parent / case.name).is_dir():
            entry['parent'] = scan(parent / case.name)
        rows.append(entry)
    lines = ['# F1：显式目标观察是否产生新测量', '', f'- 候选：{cand}', f'- 父版：{parent}', '']
    lines.append('| case | 候选 分数/成功/步 | 父 分数/成功/步 | 候选 测量实例 | 父 测量实例 | PREPLACE 期间的测量 | dispatch_reason |')
    lines.append('|---|---|---|---:|---:|---:|---|')
    for entry in rows:
        c = entry['candidate']
        p = entry.get('parent') or {}
        lines.append(f"| {c['label']} | {c.get('score')}/{c.get('success')}/{c.get('steps')} | {p.get('score')}/{p.get('success')}/{p.get('steps')} | {c.get('distinct_measurement_steps')} | {p.get('distinct_measurement_steps')} | {c.get('preplace_measurement_steps')} | {list((c.get('dispatch_reasons') or {}).keys())} |")
    (out / 'f1_evidence.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    (out / 'f1_evidence.json').write_text(json.dumps(rows, ensure_ascii=False, indent=1, default=str))
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
