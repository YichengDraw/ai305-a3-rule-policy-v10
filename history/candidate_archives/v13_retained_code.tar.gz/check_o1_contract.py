#!/usr/bin/env python3
"""O1 contract check on recorded public inputs (no simulation, no rendering).

Rebuilds the real outer-leaf objects from a code root (config, MuJoCo model,
RuleController, FixedRobotPitchSearch, PathFeasibility) and calls the actual
production chain `_select -> FixedRobotPitchSearch.search -> check_ik_path`
on public inputs recorded in a completed replay trace.

Every result row is marked `synthetic=false` for the public inputs (they are the
recorded observation/perception of a real episode) but the check itself cannot
prove physical benefit: it only proves the dispatch type and the candidate set.

Usage: check_o1_contract.py CODE_ROOT FIXTURE_JSON [OUT_JSON]
"""
import json
import sys
from pathlib import Path

import numpy as np


def load_jsonl(path):
    rows = []
    with open(path) as handle:
        for line in handle:
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return rows


def public_state(case_dir, step):
    frames = Path(case_dir) / 'diagnostic' / 'frames.jsonl'
    with frames.open() as handle:
        for line in handle:
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            if row.get('step') == step:
                return row.get('public_before') or {}
    return {}


def build(code_root):
    if code_root not in sys.path:
        sys.path.insert(0, code_root)
    from a3_dual_arm_sim.config import load_config
    from a3_dual_arm_sim.paths import resource_root
    from a3_dual_arm_sim.sim.model import build_model
    from v10_leaves_17e0363838a9.two10_outer.rule_controller import RuleController
    from v10_leaves_17e0363838a9.two10_outer.f_source_controller import FixedRobotPitchSearch
    from v10_leaves_17e0363838a9.two10_outer.path_feasibility import PathFeasibility
    config = load_config(resource_root() / 'configs' / 'cookie_2x10.yaml')
    model = build_model(config, scene='cookie_transfer').model
    return config, model, RuleController, FixedRobotPitchSearch, PathFeasibility


def run_fixture(code_root, fixture):
    config, model, RuleController, FixedRobotPitchSearch, PathFeasibility = build(code_root)
    case_dir = fixture['case_dir']
    trace = sorted((Path(case_dir) / 'policy_trace').glob('seed_*.jsonl'))[0]
    rows = load_jsonl(trace)
    row = rows[fixture['row']]
    request = row.get('request') or {}
    perception = row.get('perception') or {}
    public = public_state(case_dir, row['step'])
    observation = dict(public)
    observation.setdefault('observation.eef_pose', row.get('eef'))
    observation.setdefault('observation.force', row.get('force'))
    observation.setdefault('time', float(row.get('time', 0.0)))
    scene = {key: perception.get(key) for key in ('source_box', 'target_box', 'group', 'source_frontier', 'source_geometry', 'held', 'target_occupancy', 'cookies')}
    synthetic_fields = []
    if fixture.get('synthetic_source_geometry') is not None:
        scene['source_geometry'] = fixture['synthetic_source_geometry']
        synthetic_fields.append('source_geometry')

    controller = RuleController(config)
    controller.reset({'task': request.get('task') or fixture['task']})
    controller.batch_index = int(request.get('batch_index') or 0)
    controller.stage = 'SELECT'
    controller.total_steps = int(row.get('step') or 0)
    controller._obs = observation
    controller._scene = scene
    controller.prepare_fixed_robot_search(model, PathFeasibility(config))
    controller._f_search_key = None

    group = scene.get('group')
    selected = None
    plan_state = None
    if group and scene.get('target_box'):
        search = controller._f_planner.search(controller, observation, scene, group)
        selected = search['selected']
        plan_state = search.get('plan_state')
    dispatch = controller._select(scene)
    return dict(
        fixture=fixture['name'],
        step=row.get('step'),
        batch=request.get('batch_index'),
        count=request.get('count'),
        selected_pitch=None if selected is None else selected['pitch_deg'],
        selected_lattice=None if selected is None else selected.get('lattice'),
        selected_variant=None if selected is None else selected.get('variant'),
        plan_state=plan_state,
        refined=None if selected is None else search.get('refined'),
        extra_evaluations=None if selected is None else search.get('extra_evaluations'),
        dispatch_returns=bool(dispatch),
        stage_after=controller.stage,
        search_record=(controller._f_pitch_results or {}).get('plan_state'),
        candidate_states=[(c.get('pitch_deg'), c.get('ik_state'), c.get('path_state'), c.get('next_action')) for c in (controller._f_pitch_results or {}).get('candidates', [])],
        synthetic=bool(synthetic_fields),
        synthetic_fields=synthetic_fields,
    )


def main():
    code_root = sys.argv[1]
    fixtures = json.loads(Path(sys.argv[2]).read_text())
    out_path = Path(sys.argv[3]) if len(sys.argv) > 3 else None
    report = []
    for fixture in fixtures:
        try:
            report.append(run_fixture(code_root, fixture))
        except Exception as error:  # keep the failing fixture visible instead of aborting the sweep
            report.append(dict(fixture=fixture['name'], error=f'{type(error).__name__}: {error}', synthetic=False))
    print(json.dumps(report, ensure_ascii=False, indent=1))
    if out_path is not None:
        out_path.write_text(json.dumps(dict(code_root=code_root, fixtures=report), ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()
