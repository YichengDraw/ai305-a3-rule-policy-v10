#!/usr/bin/env python3
"""T1 contract: load-state separation and the source-return gate (no simulation).

Calls the real production `RuleController._b2_return_allowed` with synthetic
public scenes built from the recorded end state of `adv/n1/21004`
(count 1 @0.7, pose confidence 0.58, bilateral 0.58 N) and its variants.

Every row is marked synthetic=true: these are interface inputs, not a physical
result. Usage: check_t1_contract.py CODE_ROOT [OUT_JSON]
"""
import json
import sys
from pathlib import Path

import numpy as np


def main():
    root = sys.argv[1]
    out_path = Path(sys.argv[2]) if len(sys.argv) > 2 else None
    sys.path.insert(0, root)
    from a3_dual_arm_sim.config import load_config
    from a3_dual_arm_sim.paths import resource_root
    from v10_leaves_17e0363838a9.two10_source1.rule_controller import RuleController

    config = load_config(resource_root() / 'configs' / 'cookie_2x10.yaml')
    controller = RuleController(config)
    controller.reset({'task': 'Transfer 20 cookies from source column 1 into the 2x10 target box. Grasp 1 cookies first, then 9 to fill target column 1 with 10. Repeat: grasp 1, then 9 to fill target column 2 with 10. Release all 20 cookies upright in the target box and leave 60 in the source box.'})

    def scene(count=1, count_conf=0.7, pose_conf=0.58, touch=0.58, released=False, vacancy=('absent', 0.7), load_state=None, width=0.083):
        held = dict(count=count, count_confidence=count_conf, center_tool=[0.0, 0.0, 0.01], rotation_tool=np.eye(3).tolist(),
                    pose_confidence=pose_conf, width_m=width, released=released, currently_held=None if pose_conf < 0.6 else True)
        if load_state is not None:
            held.update(load_state=load_state, load_contact=bool(touch and touch >= 0.1), load_count_known=bool(count is not None and count_conf >= 0.6))
        observation = {'observation.force': np.r_[np.zeros(12), [touch, touch], np.zeros(4)].tolist()}
        return dict(held=held, source_presence=dict(state=vacancy[0], confidence=vacancy[1])), observation

    controller._carry_path = [(np.zeros(3), np.eye(3)), (np.array([0.1, 0.2, 0.9]), np.eye(3))]
    controller._carry_source_high_pose = (np.array([0.1, 0.2, 0.9]), np.eye(3))
    controller._b2_departure_width = 0.083
    controller._held_width = 0.083

    rows = [
        ('pose_unreadable_count1_contact', dict(load_state='HELD_POSE_UNKNOWN'), True),
        ('pose_known_control', dict(pose_conf=0.86, load_state='HELD'), True),
        ('pose_unreadable_count_missing', dict(count=None, count_conf=0.0, load_state='UNKNOWN'), False),
        ('pose_unreadable_no_contact', dict(touch=0.0, load_state='HELD'), False),
        ('empty_count0', dict(count=0, load_state='EMPTY'), False),
        ('no_source_vacancy', dict(vacancy=('present', 0.7), load_state='HELD_POSE_UNKNOWN'), False),
        ('pose_unreadable_width_unknown_uses_lift_width', dict(width=None, load_state='HELD_POSE_UNKNOWN'), True),
    ]
    report = []
    for name, kwargs, expected in rows:
        scene_value, observation = scene(**kwargs)
        controller._scene = scene_value
        controller._obs = observation
        try:
            value = bool(controller._b2_return_allowed())
            error = None
        except Exception as exc:  # keep failures visible
            value, error = None, f'{type(exc).__name__}: {exc}'
        report.append(dict(case=name, expectation=expected, value=value, error=error, synthetic=True,
                           held=(scene_value['held'].get('load_state'), scene_value['held'].get('currently_held'), scene_value['held'].get('count')),
                           note='interface contract only; no physical claim'))
    print(json.dumps(report, ensure_ascii=False, indent=1))
    if out_path is not None:
        out_path.write_text(json.dumps(dict(code_root=root, rows=report), ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()
