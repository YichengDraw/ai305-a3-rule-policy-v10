#!/usr/bin/env python3
"""Generic paired replay analysis (parent vs candidate), native fields only.

Works for any case group: reads each case directory's result.json verbatim and
the recorded stage occupancy from policy_trace. Optionally reports the outer
leaf's recorded `finite_pitch_search.plan_state` distribution when present.

Usage: analyze_pair.py PARENT_ROOT CANDIDATE_ROOT OUT_DIR
"""
import json
import sys
from collections import Counter
from pathlib import Path


def result_of(case_dir):
    path = case_dir / 'result.json'
    if not path.exists():
        return dict(score=None, success=None, steps=None, source=None, target=None, phase='MISSING', failure_reason=None)
    r = json.loads(path.read_text())
    return dict(score=r.get('score'), success=r.get('success'), steps=r.get('steps'),
                source=r.get('cookies_in_source'), target=r.get('cookies_in_target'),
                phase=r.get('phase'), failure_reason=r.get('failure_reason'),
                profile=r.get('profile'), n=(r.get('randomization') or {}).get('first_grasp_count'),
                task=r.get('task'))


def stage_counts(case_dir):
    counts = Counter()
    trace = case_dir / 'policy_trace'
    if not trace.is_dir():
        return counts
    newest = max(trace.glob('seed_*.jsonl'), key=lambda p: p.stat().st_size, default=None)
    if newest is None:
        return counts
    with newest.open() as handle:
        for line in handle:
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            counts[str(row.get('phase'))] += 1
    return counts


def main():
    parent = Path(sys.argv[1])
    candidate = Path(sys.argv[2])
    out = Path(sys.argv[3])
    out.mkdir(parents=True, exist_ok=True)
    labels = [p.name for p in sorted(candidate.iterdir()) if p.is_dir() and (p / 'policy_trace').is_dir()]
    rows = []
    for label in labels:
        p = result_of(parent / label)
        c = result_of(candidate / label)
        rows.append(dict(label=label, task=c.get('task'), profile=c.get('profile'), n=c.get('n'),
                         parent=p, candidate=c,
                         delta_score=None if c['score'] is None or p['score'] is None else c['score'] - p['score'],
                         success_change=None if c['success'] is None or p['success'] is None else int(bool(c['success'])) - int(bool(p['success'])),
                         parent_stages=dict(stage_counts(parent / label)),
                         candidate_stages=dict(stage_counts(candidate / label))))
    lines = ['# 配对结果（native 字段直读，不重算）', '', f'- 父版：{parent}', f'- 候选：{candidate}', '',
             '| case | task | profile | n | 父 分数/源/成功/步 | 候选 分数/源/成功/步 | Δ分 | 成功变化 | 父末阶段 | 候选末阶段 |',
             '|---|---|---|---:|---|---|---:|---|---|---|']
    for r in rows:
        p, c = r['parent'], r['candidate']
        lines.append(f"| {r['label']} | {r['task']} | {r['profile']} | {r['n']} | {p['score']}/{p['source']}/{p['success']}/{p['steps']} | {c['score']}/{c['source']}/{c['success']}/{c['steps']} | {r['delta_score']} | {r['success_change']} | {p['phase']} | {c['phase']} |")
    gained = [r['label'] for r in rows if r['success_change'] == 1]
    lost = [r['label'] for r in rows if r['success_change'] == -1]
    regressions = [r['label'] for r in rows if (r['delta_score'] or 0) < 0]
    so = {r['label']: (r['parent_stages'].get('SOURCE_OBSERVE', 0), r['candidate_stages'].get('SOURCE_OBSERVE', 0)) for r in rows}
    summary = dict(cases=len(rows), gained_successes=gained, lost_successes=lost, quantity_regressions=regressions,
                   parent_score_sum=sum((r['parent']['score'] or 0) for r in rows),
                   candidate_score_sum=sum((r['candidate']['score'] or 0) for r in rows),
                   parent_success=sum(int(bool(r['parent']['success'])) for r in rows),
                   candidate_success=sum(int(bool(r['candidate']['success'])) for r in rows),
                   source_observe_rows=so)
    lines += ['', '## 汇总', '',
              f"- 例数 {summary['cases']}；数量 {summary['parent_score_sum']} → {summary['candidate_score_sum']}；官方成功 {summary['parent_success']} → {summary['candidate_success']}",
              f"- 新增成功 {gained}；丢失成功 {lost}；数量回退 {regressions}",
              f"- SOURCE_OBSERVE 行（父→候选）：{so}"]
    (out / 'pairs.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    (out / 'pairs.json').write_text(json.dumps(dict(summary=summary, cases=rows), ensure_ascii=False, indent=1, default=str))
    print(json.dumps({k: v for k, v in summary.items() if k != 'source_observe_rows'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
