#!/usr/bin/env python3
"""Read the F0 shadow records: which predicate actually binds at real decisions.

Scans the diagnostic frames of an F0 run (public evidence -> F0_return / F0_blocked)
and summarises, per case:
  * how many times the production return gate was evaluated,
  * the distribution of `binding_false` combinations (which predicate blocked),
  * the blocked-transport decisions with their target/escape predicates.

Read-only: native result fields are not recomputed.
Usage: analyze_f0.py RUN_ROOT OUT_DIR
"""
import json
import sys
from collections import Counter
from pathlib import Path


def scan(case_dir):
    frames = case_dir / 'diagnostic' / 'frames.jsonl'
    returns = 0
    binding = Counter()
    blocked = Counter()
    escape = Counter()
    result_path = case_dir / 'result.json'
    result = json.loads(result_path.read_text()) if result_path.exists() else {}
    if not frames.exists():
        return dict(label=case_dir.name, missing=True, score=result.get('score'), success=result.get('success'))
    with frames.open() as handle:
        for line in handle:
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            evidence = (row.get('policy_public_evidence_after_act') or {})
            controller = evidence.get('controller') or {}
            public = controller.get('public_evidence') or {}
            ret = public.get('F0_return')
            if isinstance(ret, dict):
                returns += 1
                binding[tuple(ret.get('binding_false') or ['ALL_TRUE'])] += 1
            blocked_record = public.get('F0_blocked')
            if isinstance(blocked_record, dict):
                blocked[(blocked_record.get('decision'), tuple(blocked_record.get('binding_false') or []))] += 1
                escape[str((blocked_record.get('escape_path_feasible') or {}).get('value'))] += 1
    return dict(label=case_dir.name, score=result.get('score'), source=result.get('cookies_in_source'),
                success=result.get('success'), steps=result.get('steps'), phase=result.get('phase'),
                return_calls=returns, binding_top=binding.most_common(5),
                blocked_top=blocked.most_common(5), escape_values=dict(escape))


def main():
    root = Path(sys.argv[1])
    out = Path(sys.argv[2])
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    for case in sorted(p for p in root.iterdir() if p.is_dir() and (p / 'policy_trace').is_dir()):
        rows.append(scan(case))
    lines = ['# F0 绑定谓词读数', '', f'- 运行：{root}', '',
             '| case | 分数/源/成功/步 | 回源门调用 | 绑定的假谓词（top） | blocked 决策（top） | escape 值 |',
             '|---|---|---:|---|---|---|']
    for r in rows:
        lines.append(f"| {r['label']} | {r.get('score')}/{r.get('source')}/{r.get('success')}/{r.get('steps')} | {r.get('return_calls')} | {r.get('binding_top')} | {r.get('blocked_top')} | {r.get('escape_values')} |")
    (out / 'f0_predicates.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    (out / 'f0_predicates.json').write_text(json.dumps(rows, ensure_ascii=False, indent=1, default=str))
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
