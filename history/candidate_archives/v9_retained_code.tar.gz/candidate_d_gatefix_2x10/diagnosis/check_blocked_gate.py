from pathlib import Path
from types import SimpleNamespace,MethodType
import sys,json,numpy as np
root=Path('/nvme-ssd1/zhaoyicheng/a3_rule_policy_v9_20261103');sys.path.insert(0,str(root/'candidate_d_gatefix_2x10'))
from rule_controller import RuleController
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
out=[]
for name,config_name,frame,batch,expect in [('replay_e_d3/2x5_medium_n5_s1_native_scene20001','cookie_batch.yaml',157,0,'blocked'),('replay_abcd/guard_basic_2x10','cookie_2x10.yaml',160,1,'feasible')]:
 case=root/name;result=json.loads((case/'result.json').read_text());frames={r['frame_id']:r for r in map(json.loads,(case/'diagnostic/frames.jsonl').read_text().splitlines())};trace=list(map(json.loads,next((case/'policy_trace').glob('*.jsonl')).read_text().splitlines()));obs=frames[frame]['public_before'];scene=next(r for r in reversed(trace) if r['step']<=frame)['perception'];h=scene['held']
 report=result['policy_current_report'] if expect=='blocked' else None
 center=np.asarray(report['held_center_tool'] if report else h['center_tool']);rot=np.asarray(report['held_rotation_tool'] if report else h['rotation_tool']);width=report['release_actual_width_m'] if report else h['width_m']
 c=RuleController(load_config(resource_root()/'configs'/config_name));c.reset(SimpleNamespace(task=result['task_instruction']));c.batch_index=batch;c.stage='TRANSPORT';c.current_report={};c._clearance=.04;c._obs=obs;c._scene=scene;c._held_center_local=center;c._held_cookie_local=rot;c._held_width=width;c._held_pose_confidence=.8;c.actual_opening=float(obs['observation.state'][7]);c.opening=.29;c._d_observed.add(batch)
 c._held_update=MethodType(lambda self,*args:True,c);c._servo=MethodType(lambda self,*args,**kwargs:(self._hold(),True),c);c._b2_return_allowed=MethodType(lambda self:False,c)
 stages=[]
 for _ in range(2 if expect=='blocked' else 1):
  action=c.act(obs,scene);stages.append(c.stage)
  if expect=='blocked':assert c.stage=='TRANSPORT' and c._placement_goal is None and not c._place_box_frozen and np.all(action[:6]==0),(c.stage,c._d_report)
  else:assert c.stage=='PLACE' and c._placement_goal is not None,(c.stage,c._d_report)
 assert c._d_report['state']==expect,(name,c._d_report)
 out.append(dict(recording=name,actual_public_frame=frame,contract='reached-high transition with unchanged real scene geometry; servo arrival abstracted',D_state=c._d_report['state'],consecutive_stages=stages,first_conflict=c._d_report.get('conflicts',[])[:1]))
print(json.dumps(dict(checks=out,physics_steps=0,ground_truth_read=False),indent=2))
