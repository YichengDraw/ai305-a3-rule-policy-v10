from pathlib import Path
import sys,json,inspect
import numpy as np
root=Path('/nvme-ssd1/zhaoyicheng/a3_rule_policy_v9_20261103');sys.path[:0]=[str(root/'candidate_e_d2'),str(root/'candidate_c/diagnosis')]
import perception
from perception import VisionEstimator
from public_frame_loader import PublicFrameLoader
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
import textwrap
for case,k in [('replay_e_d/guard_basic_2x5',94),('replay_e_b2_views/2x5_medium_n5_s1_native_scene20001',112)]:
 v=VisionEstimator(load_config(resource_root()/'configs/cookie_batch.yaml'));loader=PublicFrameLoader(root/case,v);obs,cameras,old=loader.load(k)
 # Prefer already stored lossless image.
 import cv2
 for name in cameras:
  f=root/case/'diagnostic/lossless'/name/f'{k:06d}.png'
  if f.exists():obs['observation.images.'+name]=cv2.cvtColor(cv2.imread(str(f)),cv2.COLOR_BGR2RGB)
 v.boxes={'source_box':old['source_box'],'target_box':old['target_box']};v.v9_target_geometry=old['target_geometry'];v.d_force_target_observation=True
 p=v._v9_preplacement_observation(obs,cameras,old['held']);assert p['valid'] and p['actual_fk_complete'] and p['path_state']=='feasible' and p['ik']['state']=='reachable',p;print(json.dumps({'case':case,'frame':k,'p':p},default=lambda x:x.tolist() if hasattr(x,'tolist') else str(x)),flush=True);loader.close()
