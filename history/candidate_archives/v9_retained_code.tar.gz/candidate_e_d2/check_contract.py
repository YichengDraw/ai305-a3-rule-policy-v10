"""Offline public-pose contracts; no simulation/ground-truth stream."""
from pathlib import Path
from types import SimpleNamespace,MethodType
import sys,json,copy,importlib.util
import numpy as np
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
root=Path('/nvme-ssd1/zhaoyicheng/a3_rule_policy_v9_20261103')
sys.path.insert(0,str(root/'candidate_e_d2'))
from rule_controller import RuleController
case=root/'replay_e_c2/guard_basic_2x5';result=json.loads((case/'result.json').read_text())
frames={r['frame_id']:r for r in map(json.loads,(case/'diagnostic/frames.jsonl').read_text().splitlines())}
trace=list(map(json.loads,next((case/'policy_trace').glob('*.jsonl')).read_text().splitlines()))
k=min(k for k,r in frames.items() if r['phase_before']=='PLACE');obs=frames[k]['public_before'];scene=copy.deepcopy(next(r for r in reversed(trace) if r['step']<=k)['perception'])
config=load_config(resource_root()/'configs/cookie_batch.yaml')
def controller():
 c=RuleController(config);c.reset(SimpleNamespace(task=result['task_instruction']));c.stage='TRANSPORT';c.current_report={};c._clearance=.04;c._obs=obs;c._scene=scene
 h=scene['held'];c._held_center_local=np.asarray(h['center_tool']);c._held_cookie_local=np.asarray(h['rotation_tool']);c._held_width=h['width_m'];c._held_pose_confidence=h['pose_confidence'];c.actual_opening=float(obs['observation.state'][7]);c.opening=.25
 return c
c=controller();p,r=c._place_pose(scene,0.);assert np.isfinite(p).all() and np.isfinite(r).all()
assert c._d_report['state'] in ('feasible','unknown'),c._d_report
# Force the reached high-pose branch: an unconfirmed 21mm-shifted target must
# obtain an independent view and cannot freeze a descent, even after a view try.
bad=copy.deepcopy(scene);bad['target_box'].update(anchor_confirmed=False,center=(np.asarray(scene['target_box']['center'])+[.021,0,0]).tolist())
bad['target_geometry']={'measurement_id':'unconfirmed_fixture','preplacement_observation':{'needed':False,'valid':False}}
c=controller();c._d_observed.add(c.batch_index);c._held_update=MethodType(lambda self,*args:True,c);c._servo=MethodType(lambda self,*args,**kwargs:(self._hold(),True),c)
a=c.act(obs,bad)
assert c.stage!='PLACE' and c._d_view_pending and c.opening==.25,(c.stage,c._d_report)
# The pure geometry module can explicitly check empty-hand observation paths.
from path_feasibility import PathFeasibility
checker=PathFeasibility(config);p0=np.asarray(obs['observation.eef_pose'])[:3];R=np.eye(3)
wp=[dict(name='observe_up',position=p0+[0,0,.05],rotation=R,opening=1.,carrying=False),dict(name='observe_side',position=p0+[.01,0,.05],rotation=R,opening=1.,carrying=False)]
view=checker.check_path(obs,wp,None,{**scene,'path_scope':'empty_hand_observation'},protected_objects=[])
assert view['full_path_status']=='observation_path_checked'
print(json.dumps(dict(factory_and_geometry_path=True,unconfirmed_target_never_freezes_descent=True,commanded_clamp_preserved=True,
 empty_hand_view_scope_supported=True,source_and_B2_AST_preserved='composition.json',simulation_started=False,ground_truth_read=False),indent=2))
