"""Check completed E public paths; this script never opens the truth stream."""
from pathlib import Path
import sys,json,time
import numpy as np
from scipy.spatial.transform import Rotation
sys.path.insert(0,str(Path(__file__).parents[1]))
from path_feasibility import PathFeasibility
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
case=Path(sys.argv[1]);assert (case/'result.json').exists()
frames={r['frame_id']:r for r in map(json.loads,(case/'diagnostic/frames.jsonl').read_text().splitlines())}
trace=list(map(json.loads,next((case/'policy_trace').glob('*.jsonl')).read_text().splitlines()))
start=min(k for k,r in frames.items() if r['phase_before']=='PLACE')
first_open=min(k for k,r in frames.items() if k>start and r['phase_before']=='OPEN')
first_retract=min(k for k,r in frames.items() if k>first_open and r['phase_before']=='RETRACT')
stop=min(k for k,r in frames.items() if k>first_retract and r['phase_before']=='SELECT')-1
old=next(r for r in reversed(trace) if r['step']<=start)['perception']
held=old['held'];envelope={k:held.get(k) for k in ('center_tool','rotation_tool','width_m','bounds_tool','measurement_id')}
obs=frames[start]['public_before'];check=PathFeasibility(load_config(resource_root()/'configs/cookie_batch.yaml'))
waypoints=[]
for k,name,carrying in ((start,'target_high',True),(first_open-1,'descend_place',True),(first_retract,'release_open',False),(stop,'withdraw_high',False)):
 ob=frames[k]['public_before'];p=np.asarray(ob['observation.eef_pose'])[:7];r=Rotation.from_quat(np.r_[p[4:],p[3]]).as_matrix()
 waypoints.append(dict(name=name,position=p[:3],rotation=r,opening=float(ob['observation.state'][7]),carrying=carrying,box_key='target_box',reference=name=='descend_place'))
unit=dict(unit_id='original_source1_batch0',object_scope='batch',source_column=1,batch_index=0,count_interval=[5,5],object_ids=list(range(5)))
t0=time.perf_counter();report=check.check_path(obs,waypoints,envelope,{'target_box':old['target_box']},repair_unit=unit,protected_objects=[])
report['seconds']=time.perf_counter()-t0;report['public_frame_landmarks']=[start,first_open-1,first_retract,stop]
report['scope']='recorded public actual aperture/eef and vision box/held only; no ground truth'
out=Path(__file__).parent/(case.name+'_first_path.json');out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'case':case.name,'state':report['state'],'seconds':report['seconds'],'conflict_count':len(report['conflicts']),'first_conflicts':report['conflicts'][:8],'y':report['feasible_y_intervals'],'gripper_pieces':list(check.closed),'out':str(out)},indent=2))
