"""Endpoint-clear wall sweep, palm height, scope and missing-coverage contracts."""
from pathlib import Path
import sys,json,copy
import numpy as np
from scipy.spatial.transform import Rotation
sys.path.insert(0,str(Path(__file__).parents[1]))
from path_feasibility import PathFeasibility,_poly,_separation
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
case=Path('/nvme-ssd1/zhaoyicheng/a3_rule_policy_v9_20261103/replay_e_c2/guard_basic_2x5')
frames={r['frame_id']:r for r in map(json.loads,(case/'diagnostic/frames.jsonl').read_text().splitlines())}
trace=list(map(json.loads,next((case/'policy_trace').glob('*.jsonl')).read_text().splitlines()))
start=min(k for k,r in frames.items() if r['phase_before']=='PLACE');op=min(k for k,r in frames.items() if k>start and r['phase_before']=='OPEN');rt=min(k for k,r in frames.items() if k>op and r['phase_before']=='RETRACT');end=min(k for k,r in frames.items() if k>rt and r['phase_before']=='SELECT')-1
old=next(r for r in reversed(trace) if r['step']<=start)['perception'];obs=frames[start]['public_before'];held=old['held'];scene={'target_box':old['target_box']}
check=PathFeasibility(load_config(resource_root()/'configs/cookie_batch.yaml'))
def node(k,name,carry):
 ob=frames[k]['public_before'];p=np.asarray(ob['observation.eef_pose'])[:7]
 return dict(name=name,position=p[:3],rotation=Rotation.from_quat(np.r_[p[4:],p[3]]).as_matrix(),opening=float(ob['observation.state'][7]),carrying=carry,reference=name=='place')
path=[node(start,'high',True),node(op-1,'place',True),node(rt,'open',False),node(end,'withdraw',False)]
unit=dict(unit_id='original_batch0',object_scope='batch',source_column=1,batch_index=0,count_interval=[5,5],object_ids=list(range(5)))
normal=check.check_path(obs,path,held,scene,repair_unit=unit,protected_objects=[])
assert normal['state']=='feasible',normal['conflicts']
# Fully-open endpoint fingers are outside the short walls; opening sweeps across them.
bad=copy.deepcopy(path);bad[2]['position']=bad[1]['position'].copy();bad[2]['rotation']=bad[1]['rotation'].copy();bad[2]['opening']=1.;bad[3]['opening']=1.
box=check._box(scene,'target_box');endpoint=[]
for name,vertices in check.gripper_vertices_tool(obs,1.).items():
 poly=_poly((vertices@bad[2]['rotation'].T+bad[2]['position']-box['center'])@box['rotation'])
 endpoint.extend((name,wall) for wall,obstacle in box['obstacles'] if _separation(poly,obstacle)<-check.collision_epsilon_m)
assert not endpoint,endpoint
sweep=check.check_path(obs,bad,held,scene,repair_unit=unit,protected_objects=[])
assert sweep['state']=='blocked' and any('wall:1:' in x['obstacle'] and x['name']=='open' for x in sweep['conflicts'])
assert sweep['feasible_y_intervals']==[],sweep['feasible_y_intervals']
ambiguous={**unit,'object_scope':'column','count_interval':[10,10],'object_ids':list(range(10))}
assert check.check_path(obs,path,held,scene,repair_unit=ambiguous,protected_objects=[])['state']=='unknown'
assert check.check_path(obs,path,held,scene,repair_unit=unit)['state']=='unknown'
assert check.check_path(obs,path[:2],held,scene,repair_unit=unit,protected_objects=[])['full_path_status']=='incomplete'
# A repair approach must also avoid its own fixed unit before attachment.
repair=copy.deepcopy(path);repair[0]['carrying']=False;repair[0]['opening']=.8
descend={**copy.deepcopy(repair[1]),'name':'repair_descend','carrying':False,'opening':.1,'reference':False}
close={**copy.deepcopy(path[1]),'name':'close','carrying':True,'reference':False}
lift={**copy.deepcopy(path[0]),'name':'lift','carrying':True}
repair_path=[repair[0],descend,close,lift,*copy.deepcopy(path[1:])]
narrow=check.check_path(obs,repair_path,held,scene,repair_unit=unit,protected_objects=[])
assert narrow['state']=='blocked' and any(x['obstacle']=='repair_unit_before_grasp' and x['name']=='repair_descend' for x in narrow['conflicts'])
# Height-aware palm handling: its broad footprint exceeds the inner x width,
# yet the successful descent has no palm/wall intersection above the rim.
palm=check.gripper_vertices_tool(obs,path[1]['opening'])['L_2f85_base_collision']
world=(palm@path[1]['rotation'].T+path[1]['position']-box['center'])@box['rotation']
assert world[:,0].min() < -box['inner'][0] or world[:,0].max()>box['inner'][0]
assert world[:,2].min()>box['z1']
result=dict(public_recorded_place_feasible=True,physical_gripper_piece_count=len(check.closed),palm_above_rim_not_falsely_blocked=True,
 endpoint_clear_but_opening_sweep_blocked=True,empty_y_interval_explicit=True,column10_repair_scope_unknown=True,
 narrow_regrasp_descend_through_unit_blocked=True,
 missing_protected_geometry_unknown=True,incomplete_path_not_full_clearance=True,ground_truth_read=False,
 nominal_opening_conflicts=sweep['conflicts'][:4])
out=Path(__file__).with_name('path_contract_result.json');out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
