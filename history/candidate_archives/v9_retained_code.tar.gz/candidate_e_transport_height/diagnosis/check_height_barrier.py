from pathlib import Path
from types import SimpleNamespace
import sys,json,copy,numpy as np
root=Path('/nvme-ssd1/zhaoyicheng/a3_rule_policy_v9_20261103');sys.path.insert(0,str(root/'candidate_e_transport_height'))
from rule_controller import RuleController
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
config=load_config(resource_root()/'configs/cookie_batch.yaml');case=root/'coverage_e_final_source1_9/2x5_advanced_n5_s1_native_scene20002';result=json.loads((case/'result.json').read_text());frames={r['frame_id']:r for r in map(json.loads,(case/'diagnostic/frames.jsonl').read_text().splitlines())};trace=list(map(json.loads,next((case/'policy_trace').glob('*.jsonl')).read_text().splitlines()));obs=frames[320]['public_before'];scene=next(r for r in reversed(trace) if r['step']<=320)['perception'];h=scene['held']
def make():
 c=RuleController(config);c.reset(SimpleNamespace(task=result['task_instruction']));c.set_variant('b');c.batch_index=1;c.stage='TRANSPORT';c.current_report={};c._clearance=.04;c._obs=obs;c._scene=scene;c._held_center_local=np.asarray(h['center_tool']);c._held_cookie_local=np.asarray(h['rotation_tool']);c._held_width=h['width_m'];c._held_pose_confidence=h['pose_confidence'];c.opening=.29;c.actual_opening=float(obs['observation.state'][7]);return c
c=make();a=c.act(obs,scene);assert np.allclose(a[:2],0.) and a[2]>0 and np.linalg.norm(a[3:6])<1e-6,a
corr=c._d_report['transport_height_correction'];assert corr['active'] and corr['full_macro_state']=='feasible' and not corr['current_lift_conflicts'],corr
assert abs((a[6]+1)/2-.29)<1e-12 and c.stage=='TRANSPORT'
# A constructed at-height pose takes the untouched underlying servo action.
raised=copy.deepcopy(obs);raised['observation.eef_pose'][2]=c._d_transport_high[0][2]
normal=make();base=make();normal._obs=raised;base._obs=raised
actual=normal.act(raised,scene);base_act=next(cls.__dict__['act'] for cls in type(base).__mro__ if cls.__name__=='RuleController' and 'act' in cls.__dict__)
expected=base_act(base,raised,scene);assert np.allclose(actual,expected,rtol=0,atol=1e-12),(actual,expected)
# advanced20001's actual transport records have no known target occupancy;
# its later false PUSH source issue is therefore outside this correction.
other=root/'coverage_e_final_source1_9/2x5_advanced_n5_s1_native_scene20001';other_trace=list(map(json.loads,next((other/'policy_trace').glob('*.jsonl')).read_text().splitlines()));eligible=[]
for r in other_trace:
 if r['request']['stage']!='TRANSPORT':continue
 protected,_=c._d_objects(r['perception'])
 if protected and r['perception']['target_box'].get('anchor_confirmed'):eligible.append(r['step'])
assert not eligible,eligible
print(json.dumps(dict(actual_public_frame=320,correction=corr,action=a.tolist(),at_height_original_action_equal=True,
 advanced20001_eligible_actual_records=eligible,source_and_opening_commands_unchanged=True,physics_steps=0,ground_truth_read=False),indent=2))
