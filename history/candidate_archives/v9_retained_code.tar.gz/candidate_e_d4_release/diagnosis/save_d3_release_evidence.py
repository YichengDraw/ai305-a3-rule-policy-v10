from pathlib import Path
import json
root=Path('/nvme-ssd1/zhaoyicheng/a3_rule_policy_v9_20261103');case=root/'replay_e_d3/2x5_medium_n5_s1_native_scene20001';r=json.loads((case/'result.json').read_text());frames={x['frame_id']:x for x in map(json.loads,(case/'diagnostic/frames.jsonl').read_text().splitlines())}
rows=[]
for k in [175,176,180,200,202,203,205,208,210,211,213,215,218,225,235,237,245,248,250,499]:
 f=frames[k];e=f['policy_public_evidence_after_act']['controller']['public_evidence'];d=e.get('D_path',{});rows.append(dict(frame=k,phase_before=f['phase_before'],phase_after=f['phase_after_policy'],eef_position=f['public_before']['observation.eef_pose'][:3],actual_opening=f['public_before']['observation.state'][7],command_opening=(f['processed_action'][6]+1)/2,touch=f['force18'][12:14],official_count=f['official_after']['cookies_in_target'],D_state=d.get('state'),D_first_conflict=d.get('conflicts',[])[:1]))
out=dict(recording=str(case),scope='completed synchronized public before-policy data; no GT read',official_final=dict(count=r['cookies_in_target'],success=r['success'],steps=r['steps']),active_batch=r['policy_current_report']['batch_index'],first_open_step=177,second_batch_started=False,conclusion='release-lift progress resets in the next OPEN because put pose stayed at its original height; fingers remain blocked against the left wall; not a hold5 or free-transit budget bottleneck',keyframes=rows)
(root/'candidate_e_d4_release/diagnosis/release_loop_evidence.json').write_text(json.dumps(out,indent=2))
