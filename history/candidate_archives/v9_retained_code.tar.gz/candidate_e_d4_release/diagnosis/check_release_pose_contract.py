from pathlib import Path
from types import SimpleNamespace
import sys,json,numpy as np
root=Path('/nvme-ssd1/zhaoyicheng/a3_rule_policy_v9_20261103');sys.path.insert(0,str(root/'candidate_e_d4_release'))
from rule_controller import RuleController
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
case=root/'replay_e_d3/2x5_medium_n5_s1_native_scene20001';result=json.loads((case/'result.json').read_text());frames={r['frame_id']:r for r in map(json.loads,(case/'diagnostic/frames.jsonl').read_text().splitlines())};trace=list(map(json.loads,next((case/'policy_trace').glob('*.jsonl')).read_text().splitlines()));obs=frames[210]['public_before'];scene=next(r for r in reversed(trace) if r['step']<=210)['perception'];c=RuleController(load_config(resource_root()/'configs/cookie_batch.yaml'));c.reset(SimpleNamespace(task=result['task_instruction']));p,R=c._snapshot_pose(obs)
c.stage='RELEASE_LIFT';c._release_lift=p.copy();c._put_position=p-[0,0,.004];c._put_rotation=R.copy();c.current_report={};c.actual_opening=float(obs['observation.state'][7]);c.opening=c.actual_opening
c.act(obs,scene)
assert c.stage=='OPEN' and np.array_equal(c._put_position,p) and np.array_equal(c._put_rotation,R),(c.stage,c._put_position)
action=c.act(obs,scene)
assert np.linalg.norm(action[:3])<1e-8,action
print(json.dumps(dict(actual_public_frame=210,lift_reached_reopens_at_actual_pose=True,next_open_action_has_no_return_translation=True,physical_opening_and_force_rules_unchanged=True,physics_steps=0,ground_truth_read=False),indent=2))
