"""Full perception + original near-source controller on completed RGB, no GT."""
from pathlib import Path
from types import SimpleNamespace
import json,cv2,numpy as np
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from perception import VisionEstimator
from rule_controller import RuleController
r=Path(__file__).parent;root=r.parent;case=root/'replay_e_g3_broad_only/2x5_medium_n5_s1_native_scene20001'
frames={x['frame_id']:x for x in map(json.loads,(case/'diagnostic/frames.jsonl').open())};trace=[json.loads(l) for l in next((case/'policy_trace').glob('*.jsonl')).open()]
config=load_config(resource_root()/'configs/cookie_batch.yaml');v=VisionEstimator(config);ctl=RuleController(config);ctl.reset(SimpleNamespace(task='Transfer 10 cookies from source column 1 into the target box in two batches of five.'));ctl.set_variant('b');results=[];scenes=[];observations=[]
for step in (0,5,10,15,25):
 obs=dict(frames[step]['public_before'])
 for camera in ('front','left_wrist','right_wrist'):
  lossless=(frames[step].get('lossless_png_paths') or {}).get(camera)
  assert lossless is not None,(step,camera,'exact original RGB required for the full calibration replay')
  bgr=cv2.imread(str(case/'diagnostic'/lossless));assert bgr is not None
  obs['observation.images.'+camera]=cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)
 request=dict(trace[0]['request']);request['stage']=frames[step]['phase_before'];v.step=step
 if step>0:
  actual=min(trace,key=lambda x:abs(x['step']-step))['perception']['wrist_calibration']['mount_parameters'];v.wrist_mount=np.asarray(actual,float)
 scene=v.estimate(obs,request);scenes.append(scene);observations.append(obs)
 results.append(dict(frame=step,group_center=np.asarray(scene['group']['center']).tolist(),confidence=scene['group']['confidence'],broad=scene['group']['broad_measurement'],seed=scene['group']['broad_seed_m'].tolist(),reference_id=scene['group']['broad_reference_measurement_id']))
assert any(abs(x['seed'][0])>.015 for x in results),results
assert .082<results[1]['group_center'][0]<.093,results
assert all(.082<x['group_center'][0]<.094 and abs(x['seed'][0])>.015 for x in results),results
ctl._obs=observations[0];ctl._select(scenes[0]);before=ctl._preinsert.copy()
# Use a recorded high source observation: applying the corrected group is the
# parent's unchanged _near_group_update, with its original 25mm acceptance.
updated=False
for scene,obs in zip(scenes[1:],observations[1:]):
 if ctl._near_group_update(obs,scene):updated=True;break
assert ctl._preinsert[0]<.094 or before[0]<.094,(before,ctl._preinsert,results)
receipt=dict(status='passed',physics_steps=0,ground_truth_read=False,G3_world_X_reference_preserved_across_actual_wrist_signatures=True,original_near_source_controller_consumes_correction=True,
 before_preinsert=before.tolist(),after_preinsert=ctl._preinsert.tolist(),frames=results)
(r/'g3_real_public_checks.json').write_text(json.dumps(receipt,indent=2,default=lambda x:x.tolist() if hasattr(x,'tolist') else x)+'\n')
print(json.dumps(dict(status='passed',before=before.tolist(),after=ctl._preinsert.tolist(),frames=[{k:x[k] for k in ['frame','group_center','seed','reference_id']} for x in results]),indent=2))
