"""Independent source sweep/finite motion supervisor, public inputs only."""
from __future__ import annotations
import copy,types
import numpy as np
from scipy.spatial.transform import Rotation
from .f_source_primitives import FixedRobotPitchSearch
from .path_feasibility import PathFeasibility
from .source_geometry import SourceGeometry,calibrated_source_cameras,source_planning_scene,source_path_coverage


class SourceMotionGuard:
    def __init__(self,config,vision):
        self.vision=vision;self.model=vision.robot_model;self.checker=PathFeasibility(config)
        self.planner=FixedRobotPitchSearch(self.model,config,self.checker);self.geometry=SourceGeometry(config)
        self.selected=None;self.tried=set();self.cached_objects={};self.evidence={};self.last_signature=None
        self.last_result={};self.probe=None;self.probe_requested=False;self._applying=False;self._applied_pinch=.010;self.column_anchor_active=None

    @property
    def public_evidence(self):return copy.deepcopy(self.last_result)

    def attach(self,controller):
        controller._source_guard=self
        if not hasattr(controller,'_source_guard_base_apply'):controller._source_guard_base_apply=controller._apply_group_geometry
        guard=self
        def apply(ctl,group):
            ctl._source_guard_base_apply(group)
            guard._applied_pinch=.010
            if guard.selected is not None and guard.selected['batch_index']==ctl.batch_index:
                guard._apply_candidate(ctl,group,guard.selected['pitch_deg'])
            if guard.column_anchor_active is not None and guard.column_anchor_active['batch_index']==ctl.batch_index:
                guard._anchor_column_goal(ctl,guard.column_anchor_active['axis'],guard.column_anchor_active['value'])
        controller._apply_group_geometry=types.MethodType(apply,controller)

    def _measure(self,ctl,obs,scene):
        evidence=self.geometry.estimate(obs,scene,calibrated_source_cameras(self.vision,obs),measurement_step=self.vision.step,color_mask=self.vision._v6_color_mask)
        # Occlusion preserves older static obstacle hypotheses with their old
        # IDs/time; a new frame does not turn them into current measurements.
        for obj in evidence.get('protected_objects',[]):self.cached_objects[obj['object_id']]=copy.deepcopy(obj)
        current={o['object_id'] for o in evidence.get('protected_objects',[])}
        obstacles=[]
        for key,obj in self.cached_objects.items():
            # Grasping/pushing changes the requested column. Its old cached
            # occupancy cannot become a new hard obstacle after a batch.
            if obj['source_column']==ctl.source_column and key not in current:continue
            item=copy.deepcopy(obj)
            if key not in current:item.update(state='predicted_static_from_last_RGB',currently_verified=False)
            else:item['currently_verified']=True
            obstacles.append(item)
        evidence['protected_objects']=obstacles;self.evidence=evidence
        return source_planning_scene(scene,evidence)

    def _anchor_column_goal(self,ctl,axis,value):
        from rule_controller import PAD_OFFSET
        axis=np.asarray(axis,float)
        midpoint=np.asarray(ctl._pick)+np.asarray(ctl._pick_rotation)@PAD_OFFSET-[0,0,self._applied_pinch]
        shift=axis*(float(value)-float(midpoint@axis))
        for name in ('_pick','_preinsert','_trial','_high'):
            if hasattr(ctl,name):setattr(ctl,name,np.asarray(getattr(ctl,name))+shift)
        # Object pose stays in the parent observation frame. Only the planned
        # gripper contact/reference point moves to the retained column anchor.
        if np.linalg.norm(shift)>.0001:ctl._alignment_geometry=None
        return shift

    def _preserve_initial_column(self,ctl,scene):
        frame=scene.get('source_row_frame') or (scene.get('object_inventory') or {}).get('source_row_frame') or {}
        if ctl.source_column!=1 or frame.get('current_contact_epoch')!=0 or not self.evidence.get('source_box',{}).get('broad_axis_verified'):return
        axis=np.asarray(frame.get('broad_axis_world',[1,0,0]),float);box=self.evidence['source_box']
        value=float(np.asarray(box['center'])@axis)+float(self.geometry.columns[ctl.source_column-1]-self.geometry.scene.source_bin_center_m[0])
        from rule_controller import PAD_OFFSET
        midpoint=np.asarray(ctl._pick)+np.asarray(ctl._pick_rotation)@PAD_OFFSET-[0,0,self._applied_pinch]
        bias=float(midpoint@axis)-value
        gap=float(np.min(np.diff(self.geometry.columns))-2*ctl.half_size[0])
        side=ctl.source_column+(1 if bias>0 else -1)
        supported=any(o['source_column']==side and o.get('verified') for o in self.evidence.get('objects',[]))
        if bias>gap>0 and supported:
            self.column_anchor_active=dict(batch_index=ctl.batch_index,axis=axis.tolist(),value=value,
                measurement_id=box['measurement_id'],geometry_version=box['geometry_version'],displaced_goal_bias_m=bias,nominal_intercolumn_edge_gap_m=gap)
            shift=self._anchor_column_goal(ctl,axis,value)
            self.last_result.update(initial_column_anchor_preserved=True,broad_goal_shift_m=shift.tolist(),
                displaced_goal_bias_m=bias,nominal_intercolumn_edge_gap_m=gap,
                reason='partly occluded source update moved the grasp midpoint beyond the adjacent-column CAD gap; preserve the complete initial body/outer-edge frame')
            ctl._rule_reason=self.last_result['reason']

    def _source_points(self,ctl,obs,scene,group,pitch):
        # The commanded pinch midpoint can differ from the observed cookie
        # centre after local alignment. Keep those two frames separate.
        target_group=copy.deepcopy(group)
        if hasattr(ctl,'_pick'):
            from rule_controller import PAD_OFFSET
            target_group['center']=np.asarray(ctl._pick)+np.asarray(ctl._pick_rotation)@PAD_OFFSET-[0,0,self._applied_pinch]
        candidate=self.planner.geometry(ctl,obs,target_group,pitch)
        points=self.planner.waypoints(ctl,obs,scene,group,candidate)[:7]
        actual_center=np.asarray(group['center'],float).copy();box=scene.get('source_box') or {}
        if box.get('broad_axis_verified'):
            axis=np.asarray((scene.get('source_row_frame') or (scene.get('object_inventory') or {}).get('source_row_frame') or {}).get('broad_axis_world',[1,0,0]),float)
            nominal_x=self.geometry.columns[ctl.source_column-1]-self.geometry.scene.source_bin_center_m[0]
            actual_center+=axis*(float(np.asarray(box['center'])@axis)+nominal_x-float(actual_center@axis))
        candidate['center_tool']=candidate['rotation'].T@(actual_center-candidate['pick'])
        envelope=dict(frame='tool',center_tool=candidate['center_tool'],rotation_tool=candidate['rotation_tool'],
            half_size=[ctl.half_size[0],ctl.count*ctl.half_size[1],ctl.half_size[2]],count_interval=[ctl.count,ctl.count],basis='observed source column origin; physical packed planned unit')
        # Reuse the measured current orientation/XY tracking error once the
        # source endpoint has been reached. Do not assume perfect future EEF.
        pose,rotation=ctl._snapshot_pose(obs)
        reference=ctl._preinsert if ctl.stage in ('ALIGN_APPROACH','LOCAL_ALIGN','XY_COARSE','ALIGN_OBSERVE','ALIGN_RETURN') else ctl._pick
        delta=pose-np.asarray(reference)
        angle=float(Rotation.from_matrix(np.asarray(ctl._pick_rotation).T@rotation).magnitude())
        if np.linalg.norm(delta)<.004 and angle<.04:
            error_rotation=rotation@np.asarray(ctl._pick_rotation).T
            for point in points[1:]:
                point['position']=np.asarray(point['position'])+[delta[0],delta[1],0.]
                point['rotation']=error_rotation@point['rotation']
        return candidate,points,envelope

    def _check(self,ctl,obs,scene,pitch):
        group=scene.get('group') or {};geometry,points,envelope=self._source_points(ctl,obs,scene,group,pitch)
        unit=copy.deepcopy(group.get('source_unit') or {})
        if unit:unit.update(object_scope='individual_objects',source_column=ctl.source_column,batch_index=ctl.batch_index)
        result=self.checker.check_path(obs,points,envelope,scene,repair_unit=unit or None,protected_objects=self.evidence.get('protected_objects'))
        coverage=source_path_coverage(self.checker,obs,points,self.evidence)
        incomplete='supplied path omits a descend, release-opening or post-release withdrawal segment'
        state='blocked' if result.get('conflicts') else 'unknown' if result.get('reason') not in (incomplete,'complete supplied gripper/held sweep clears supplied geometry') else 'clear'
        # This supervisor checks source motion only; the target supervisor owns
        # the remaining path. Preserve D's incomplete full-path result verbatim.
        if state=='clear' and coverage['state']!='covered':state='unknown'
        return dict(state=state,pitch_deg=float(pitch),geometry=geometry,waypoints=points,envelope=envelope,D=result,source_coverage=coverage)

    def _apply_candidate(self,ctl,group,pitch):
        if self._applying:return
        self._applying=True
        try:
            center=np.asarray(ctl._selected_center,float).copy()
            if hasattr(ctl,'_pick'):
                from rule_controller import PAD_OFFSET
                center=np.asarray(ctl._pick)+np.asarray(ctl._pick_rotation)@PAD_OFFSET-[0,0,self._applied_pinch]
            geometry=self.planner.geometry(ctl,ctl._obs,{**group,'center':center},pitch)
            for name,key in (('_pick','pick'),('_preinsert','preinsert'),('_trial','trial'),('_high','high'),('_pick_rotation','rotation')):setattr(ctl,name,np.asarray(geometry[key]).copy())
            ctl._held_cookie_local=np.asarray(geometry['rotation_tool']).copy();ctl._group_offset=np.asarray(geometry['center_tool']).copy()
            self._applied_pinch=float(geometry['pinch_height_m'])
            ctl._alignment_geometry=None
        finally:self._applying=False

    def try_alternative(self,controller,obs,scene,*,reason='source_path_or_repeated_geometry',force_change=True):
        ctl=controller
        if ctl.current_report is None:
            return dict(state='observe_required',handled=False,reason='initialize a normal source grasp report with the parent select before applying a finite primitive')
        if scene.get('group') is None or not hasattr(ctl,'_pick'):
            return dict(state='observe_required',handled=False,reason='measured source group unavailable')
        planning=self._measure(ctl,obs,scene)
        if self.evidence.get('state')=='unknown':return dict(state='observe_required',handled=False,reason=self.evidence.get('reason'))
        base=(0.,-15.,-35.,-35.)[ctl.source_column-1]
        pitches=[base,base-3.,base-5.,base-10.,base-15.]
        choices=[]
        for pitch in pitches:
            key=(ctl.batch_index,round(pitch,4))
            if force_change and (key in self.tried or abs(pitch-(self.selected['pitch_deg'] if self.selected is not None and self.selected['batch_index']==ctl.batch_index else base))<.1):continue
            result=self._check(ctl,obs,planning,pitch);choices.append(result)
            if result['state']=='blocked':continue
            ik=self.planner.check_ik_path(obs,result['waypoints']);result['ik']=ik
            if ik['state']!='reachable':continue
            # Unknown coverage can use a bounded contact probe after a changed
            # physical pose; it never becomes a declared collision or success.
            self.selected=dict(batch_index=ctl.batch_index,pitch_deg=pitch)
            self.tried.add(key);self._apply_candidate(ctl,scene['group'],pitch)
            self.probe_requested=result['state']=='unknown'
            self.last_result=dict(state='probe' if self.probe_requested else 'planned',handled=True,reason=reason,
                primitive_id=f'source_pose:{ctl.batch_index}:{pitch}',measurement_id=self.evidence.get('measurement_id'),
                geometry_version=self.evidence.get('geometry_version'),pitch_deg=pitch,source_state=result['state'],
                nominal_conflicts=result['D'].get('conflicts'),source_coverage=result['source_coverage'],ik=ik,
                complete_path_state=result['D'].get('full_path_status'),scope='source approach, insertion, closure and trial/lift; target path separately checked')
            ctl._rule_reason=reason;ctl._advance('APPROACH');return copy.deepcopy(self.last_result)
        self.last_result=dict(state='blocked' if choices and all(c['state']=='blocked' for c in choices) else 'unknown',handled=False,reason=reason,
            candidates=[dict(pitch_deg=c['pitch_deg'],state=c['state'],conflicts=c['D'].get('conflicts'),source_coverage=c['source_coverage']) for c in choices])
        return copy.deepcopy(self.last_result)

    def before_act(self,ctl,obs,scene):
        ctl._obs=obs;ctl._scene=scene;ctl.actual_opening=float(np.asarray(obs['observation.state'])[7])
        if ctl.stage=='SOURCE_GUARD_PROBE':
            pose,_=ctl._snapshot_pose(obs);touch=ctl._touch(obs)
            if pose[2]<self.probe['last_z']-.0003:self.probe['progress_step']=ctl.total_steps
            self.probe['last_z']=float(pose[2])
            stalled=ctl.total_steps-self.probe['progress_step']>3
            contact=bool(max(touch)>20. or max(touch)>8. and stalled)
            ctl.opening=ctl.actual_opening
            action,reached=ctl._servo(obs,self.probe['target'],ctl._pick_rotation,.0012,.0008)
            if contact:
                self.last_result.update(probe_result='contact_before_probe_endpoint',touch_n=touch.tolist(),measured_depth_m=float(self.probe['origin'][2]-pose[2]))
                ctl._start_source_recovery('bounded source probe contacted an unresolved obstacle',carrying=False)
                self.probe=None
                return ctl._hold()
            if reached:
                self.last_result.update(probe_result='new_reached_source_view_at_lower_depth',measured_depth_m=float(self.probe['origin'][2]-pose[2]))
                self.probe=None;self.probe_requested=False;ctl._advance('LOCAL_ALIGN')
            return action
        if self.probe_requested and ctl.stage=='LOCAL_ALIGN' and not (scene.get('local_align') or {}).get('valid'):
            origin=np.asarray(ctl._preinsert,float).copy();target=origin+[0,0,-.003]
            self.probe=dict(origin=origin,target=target,last_z=float(np.asarray(obs['observation.eef_pose'])[2]),progress_step=ctl.total_steps)
            self.probe_requested=False;ctl._advance('SOURCE_GUARD_PROBE')
            return ctl._hold()
        if ctl.stage=='SELECT':
            self._measure(ctl,obs,scene);return None
        if ctl.stage not in ('APPROACH','ALIGN_APPROACH','LOCAL_ALIGN','XY_COARSE','DESCEND','CLOSE'):return None
        if not hasattr(ctl,'_pick'):return None
        pose,rotation=ctl._snapshot_pose(obs)
        signature=(ctl.batch_index,ctl.stage,tuple(np.round(np.asarray(ctl._pick)/.0005)),tuple(np.round(rotation.ravel()/.002)),round(float(np.asarray(obs['observation.state'])[7])/.005))
        if signature==self.last_signature:return None
        self.last_signature=signature;planning=self._measure(ctl,obs,scene)
        self._preserve_initial_column(ctl,scene)
        pitch=self.selected['pitch_deg'] if self.selected is not None and self.selected['batch_index']==ctl.batch_index else (0.,-15.,-35.,-35.)[ctl.source_column-1]
        result=self._check(ctl,obs,planning,pitch)
        self.last_result=dict(state=result['state'],pitch_deg=pitch,measurement_id=self.evidence.get('measurement_id'),geometry_version=self.evidence.get('geometry_version'),
            nominal_conflicts=result['D'].get('conflicts'),source_coverage=result['source_coverage'],full_path_status=result['D'].get('full_path_status'),
            actual_eef_position=pose.tolist(),actual_eef_rotation=rotation.tolist(),actual_opening=float(np.asarray(obs['observation.state'])[7]),initial_column_anchor=copy.deepcopy(self.column_anchor_active))
        if result['state']=='blocked':
            if ctl.stage=='CLOSE' and min(ctl._touch(obs))>=ctl._stable_force:
                self.last_result['reason']='loaded closing command preserved; subsequent held supervisor owns recovery'
                return None
            if ctl.stage in ('DESCEND','CLOSE') and pose[2]<ctl._preinsert[2]-.003:
                ctl._start_source_recovery('source gripper/packed envelope intersects a verified neighbouring source object',carrying=False)
                return ctl._hold()
            alternative=self.try_alternative(ctl,obs,scene,reason='verified source-neighbour sweep conflict',force_change=True)
            if alternative.get('handled'):return ctl._hold()
        return None
