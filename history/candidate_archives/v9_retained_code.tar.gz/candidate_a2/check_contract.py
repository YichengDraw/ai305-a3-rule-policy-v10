"""Public-state/synthetic RGB contracts; no environment instance or simulation."""
from pathlib import Path
from types import SimpleNamespace
import json
import numpy as np
import cv2
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from rule_controller import RuleController, CANONICAL, opening_from_gap
from perception import VisionEstimator, _project

config=load_config(resource_root()/'configs/cookie_2x10.yaml')
controller=RuleController(config)
controller.reset(SimpleNamespace(task='transfer 20 cookies into target box; source column 1; grasp 7 cookies first'))
controller.set_variant('b')
controller._apply_group_geometry(dict(center=[.1,.2,.78],rotation=np.eye(3),confidence=.7,tilt_verified=False))
controller.current_report={}
controller.stage='TRANSPORT'
controller.opening=opening_from_gap(.020)
state=np.zeros(16);state[7]=controller.opening
obs={'observation.state':state,'observation.eef_pose':np.r_[.1,.2,.84,1.,0.,0.,0.,np.zeros(7)],
     'observation.force':np.r_[np.zeros(12),[1.,1.],np.zeros(4)],'observation.velocity':np.zeros(16),'time':1.}
def held_frame(i,count=3):
 return dict(count=count,count_confidence=.8,count_measurement_step=i,count_measurement_id=f'count:{i}',
  measurement_step=i,measurement_id=f'pose:{i}',pose_confidence=.8,center_tool=[0.,-.01,0.],
  rotation_tool=np.eye(3),width_m=.020,currently_held=True,measurement_current=True,pose_state='measured',age_steps=0)
scene={'held':held_frame(1),'object_inventory':{'partial':True}}
action=controller.act(obs,scene)
assert controller.stage=='HELD_COUNT_RECONCILE' and np.allclose(action[:6],0)
for i in (2,3):controller.act({**obs,'time':float(i)},{'held':held_frame(i),'object_inventory':{'partial':True}})
assert controller.stage=='TRANSPORT' and controller.execution_count==3 and controller.count==7
assert controller.ledger['partial'] and controller._repair_unit['count_interval']==[3,3]
assert not any(e.get('kind')=='return_source' for e in controller.recovery_events)
assert controller.public_evidence['actual_held_count']==3

# One cached placement frame cannot produce multiple independent confirmations.
controller._placement_state=lambda scene:('valid',scene['placement'])
controller._release_state=lambda obs,scene:('valid',True,True)
controller._motion_valid_samples=controller._motion_verify_samples=0
placement={'measurement_id':'frame:one','state':'valid','confidence':.8,'stationary':True}
for _ in range(5):controller._motion_retreat_sample(obs,{'placement':placement})
assert controller._motion_valid_samples==1
controller._motion_retreat_sample(obs,{'placement':{**placement,'measurement_id':'frame:two'}})
assert controller._motion_valid_samples==2 and controller._motion_current_admissible

# Auditor already proves stationary support using its own real-time history.
commits=[];controller._commit=lambda placement,verified:commits.append(verified)
controller.stage='VERIFY';controller.phase_steps=0;controller._metric=None
controller.act(obs,{'placement':{**placement,'stationary':True}})
assert commits==[True]

# A connected column contour cannot become a one-piece repair command.
reasons=[];controller._start_target_observation=reasons.append
controller._start_target_repair({'count_scope':'column','count':10,'repairable':True})
assert reasons and 'RepairUnit' in reasons[-1]

vision=object.__new__(VisionEstimator)
vision.cookie_half=np.array([.025,.019/6,.0125]);vision.step=9;vision.selected_group_key=(0,19,1)
vision.selected_group={'geometry_version':{'batch':0,'measurement':9}}
vision.v7_target_baselines={0:{'count':3}}
vision._v6_color_mask=lambda image:((np.asarray(image)[:,:,0]>150)&(np.asarray(image)[:,:,1]<150)).astype(np.uint8)*255
camera={'pos':np.array([0.,0.,1.]),'rotation':np.eye(3),'fovy':45.}
cameras={'left_wrist':camera,'front':camera}
group={'center':np.array([0.,0.,.5]),'rotation':np.eye(3),'geometry_version':{'batch':0}}
image=np.full((512,512,3),100,np.uint8)
front=image.copy()
points=np.array([[x,0.,.5125] for x in (-.016,.016)])
uv,_=_project(points,camera,image.shape)
cv2.rectangle(front,(int(uv[0,0])-2,251),(int(uv[1,0])+2,260),(210,90,40),-1)
observation={'observation.images.left_wrist':image,'observation.images.front':front}
request={'count':1,'source_start_index':0,'requested_indices':[0]}
presence=vision._v7_measure_source_presence(observation,cameras,group,request)
assert presence['state']=='present' and presence['camera']=='front' and len(presence['per_camera'])==2,presence
# Last source piece has a visible empty-floor exit without a rear neighbour.
empty=vision._v7_measure_source_presence({key:image for key in observation},cameras,group,{**request,'source_start_index':19})
assert empty['state']=='absent' and empty['terminal_empty_band'] and empty['rear_neighbour_support'] is None,empty
# Counts at different locations retain independent scope and partial identity.
held=held_frame(9,7)
inventory=vision._v9_inventory({'count':9,'batch_index':0,'target_column':0,'requested_indices':list(range(9))},held,
 {'state':'present','confidence':.7,'count_interval':[2,2],'measurement_step':9,'measurement_id':'source:9'},
 {'0':{'count':10,'confidence':.7,'measurement_step':9,'measurement_id':'column:9'}})
assert inventory['partial'] and inventory['locations']['held']['count_interval']==[7,7]
assert inventory['locations']['source']['count_interval']==[2,2]
assert inventory['locations']['target0']['object_scope']=='target_column_0'
assert inventory['association_hypotheses'][0]['count_interval']==[0,7]
receipt=dict(status='passed',checks=['TRANSPORT false count consumed before movement','fresh repeated actual count retains 3/7 partial RepairUnit',
 'no automatic source return on count mismatch','public evidence snapshot','cached placement measurement deduplicated','auditor stationary valid advances without five extra images',
 'column contour cannot define batch repair','unknown first camera continues to informative front',
 'terminal empty floor supports final-group absence','partial location counts and column identity scope'],simulation_instances=0)
Path(__file__).with_name('contract_checks.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
