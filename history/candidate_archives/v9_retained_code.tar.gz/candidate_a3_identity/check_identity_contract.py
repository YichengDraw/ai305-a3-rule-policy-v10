from pathlib import Path
from types import SimpleNamespace
import json,numpy as np
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from rule_controller import RuleController,opening_from_gap
from perception import VisionEstimator
c=RuleController(load_config(resource_root()/'configs/cookie_2x10.yaml'))
c.reset(SimpleNamespace(task='transfer 20 cookies into target box; source column 1; grasp 1 cookies first'))
c.current_report={};c.actual_opening=opening_from_gap(2*c.half_size[1]);c._stable_force=.35
c._grasp_reference_eef=np.r_[.1,.2,.76,1,0,0,0]
obs={'observation.eef_pose':np.r_[.1,.2,.79,1,0,0,0],'observation.force':np.r_[np.zeros(12),.58,.58,np.zeros(4)]}
c._obs=obs;c._scene={}
assert c._confirm_observed_grasp(True,obs)
assert c.ledger['grasp_verified'] is True and c.ledger['identity_verified'] is None
assert c.ledger['planned_indices']==[0] and c.ledger['held_indices']==[] and c.ledger['taken_indices']==[]
assert c.ledger['actual_held_count_interval']==[1,1] and c.ledger['held_batch_association_interval']==[0,1]
assert c.public_evidence['object_id'] is None and c.public_evidence['planned_object_hypotheses']==[0]
c._commit({'measurement_id':'target:1'},True)
assert c.batch_ledger[0]['placed_indices']==[] and c.completed_indices==[]
# A reliable explicitly observed source-gap association can confirm actual IDs,
# including the counterexample that the held cookie is label1, not planned0.
c.reset(SimpleNamespace(task='transfer 20 cookies into target box; source column 1; grasp 1 cookies first'))
c.current_report={};c.actual_opening=opening_from_gap(2*c.half_size[1]);c._stable_force=.35;c._grasp_reference_eef=np.r_[.1,.2,.76,1,0,0,0]
c._scene={'object_association':{'object_ids':[1],'confidence':.8,'measurement_id':'sourcegap:1','source_gap_verified':True}}
assert c._confirm_observed_grasp(True,obs)
assert c.ledger['observed_object_ids']==[1] and c.ledger['held_batch_association_interval']==[0,1]
v=object.__new__(VisionEstimator);v.selected_group_key=(0,1,0,1);v.selected_group={};v.v7_target_baselines={};v.step=10
inventory=v._v9_inventory({'count':1,'requested_indices':[0]},dict(count=1,count_confidence=.7,count_measurement_step=10,count_measurement_id='held:1'),
 dict(state='present',confidence=.7,count_interval=[1,1],measurement_step=10,measurement_id='source:1'),{})
assert inventory['locations']['held']['count_interval']==[1,1] and inventory['locations']['source']['count_interval']==[1,1]
assert inventory['locations']['unknown']['count_interval']==[0,1]
assert all(a['count_interval']==[0,1] for a in inventory['association_hypotheses'])
r=dict(status='passed',checks=['quantity one does not confirm planned identity zero','placement quantity does not fabricate source labels',
 'actual cookie1 association retained separately from planned cookie0','source1 plus held1 totals remain separate identity hypotheses'],simulation_instances=0)
Path(__file__).with_name('identity_contract_checks.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
