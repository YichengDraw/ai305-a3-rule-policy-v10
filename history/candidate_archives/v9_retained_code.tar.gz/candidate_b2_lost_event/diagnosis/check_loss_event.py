from pathlib import Path
from types import SimpleNamespace
import sys,json,copy,numpy as np
root=Path('/nvme-ssd1/zhaoyicheng/a3_rule_policy_v9_20261103');sys.path.insert(0,str(root/'candidate_b2_lost_event'))
from lost_payload import ContactLossEvidence,localization_region
from rule_controller import RuleController
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
case=root/'replay_e_d4_release/2x5_medium_n5_s1_native_scene20001';result=json.loads((case/'result.json').read_text());frames={r['frame_id']:r for r in map(json.loads,(case/'diagnostic/frames.jsonl').read_text().splitlines())};trace=list(map(json.loads,next((case/'policy_trace').glob('*.jsonl')).read_text().splitlines()));report=result['policy_current_report'];gap=float(report['measured_inner_gap_m']);selected=list(range(390,401));kwargs=dict(stage='TRANSPORT',grasp_token=(1,1),reference_gap_m=gap,planned_count=5,grasp_established=bool(report['width_consistent'] and report['force_consistent']))
tracker=ContactLossEvidence();event=None
for k in selected:
 obs=frames[k]['public_before'];e=tracker.update(obs,**{**kwargs,'stage':frames[k]['phase_before']})
 if e is not None:event=(k,e);break
assert event is not None and 395<=event[0]<=400,event
for variation in ['contact_only','width_only','duplicate_time','intentional_open','unverified_grasp']:
 tracker=ContactLossEvidence();found=[]
 for k in selected:
  obs=copy.deepcopy(frames[k]['public_before']);kw=dict(kwargs)
  if variation=='contact_only':obs['observation.state'][7]=(gap-.0053616)/.085
  if variation=='width_only':obs['observation.force'][12:14]=[1.,1.]
  if variation=='duplicate_time':obs['time']=frames[399]['public_before']['time']
  if variation=='intentional_open':kw['stage']='OPEN'
  if variation=='unverified_grasp':kw['grasp_established']=False
  if tracker.update(obs,**kw):found.append(k)
 assert not found,(variation,found)
k,event_data=event;obs=frames[k]['public_before'];scene=copy.deepcopy(next(r for r in reversed(trace) if r['step']<=k)['perception']);c=RuleController(load_config(resource_root()/'configs/cookie_batch.yaml'));c.reset(SimpleNamespace(task=result['task_instruction']));c.batch_index=1;c.stage='TRANSPORT';c.current_report=copy.deepcopy(report);c.ledger['grasp_verified']=None;c.opening=.29;c._obs=obs;c._scene=scene;c.total_steps=k+1
source=frames[321]['public_before'];c._safe_source_high=c._snapshot_pose(source);c._d_view_pending=True;c._d_view_active=True;c._d_envelope={'stale':True};c._actual_held_count=5;old_indices=list(c.ledger['planned_indices']);c._lp_begin(obs,scene,event_data)
assert c.stage=='PAYLOAD_LOCALIZE' and c._lp_packet['region']=='source'
assert c.perception_request()['stage']=='SOURCE_OBSERVE' and c.perception_request()['localization_stage']=='OBJECT_LOCALIZE' and c.perception_request()['force_target_observation'] is False
assert not c._d_view_pending and c._d_envelope is None and c.ledger['actual_held_count_interval']==[0,5]
assert c.ledger['grasp_verified'] is None and c.ledger['planned_indices']==old_indices and c.batch_index==1
assert np.allclose(c._lp_nodes[-1][:2],c._safe_source_high[0][:2])
assert c.opening==.29 and c._actual_held_count is None
assert localization_region(np.asarray(scene['target_box']['center']),c._safe_source_high,scene['target_box'])=='target'
print(json.dumps(dict(actual_recording=str(case),trigger_frame=k,event=event_data,source_view_position=c._lp_nodes[-1].tolist(),stage=c.stage,
 localize_request=c.perception_request()['stage'],unknown_interval_retained=True,historical_grasp_and_plan_preserved=True,closing_command_preserved=True,
 missing_envelope_loaded_target_loop_cleared=True,negative_variations_passed=['contact_only','width_only','duplicate_time','intentional_open','unverified_grasp'],
 physics_steps=0,ground_truth_read=False),indent=2))
