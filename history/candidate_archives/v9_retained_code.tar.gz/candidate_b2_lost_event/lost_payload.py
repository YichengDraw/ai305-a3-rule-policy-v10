"""Public contact/aperture loss event and a current-region observation handoff.

Counts and batch identity remain intervals until RGB associates a physical unit.
No target count, source count, official result or historical grasp flag is changed.
"""
from __future__ import annotations
import copy
import numpy as np


class ContactLossEvidence:
    def __init__(self):
        self.token=None;self.last_time=None;self.clear=[];self.fired=False

    def update(self,obs,*,stage,grasp_token,reference_gap_m,planned_count,grasp_established):
        if grasp_token!=self.token:
            self.token=grasp_token;self.last_time=None;self.clear=[];self.fired=False
        if stage!='TRANSPORT' or not grasp_established or self.fired or reference_gap_m is None:
            self.clear=[];return None
        now=float(obs.get('time',0.))
        if self.last_time is not None and now<=self.last_time+1e-7:return None
        self.last_time=now
        force=np.asarray(obs.get('observation.force',np.zeros(18)),float)
        opening=float(np.asarray(obs['observation.state'])[7]);gap=.0053616+.085*opening
        collapse=float(reference_gap_m)-gap
        if max(force[12:14])<.12 and collapse>=.001:
            self.clear.append(dict(time=now,gap_m=gap,collapse_m=collapse,touch=force[12:14].tolist()))
        else:self.clear=[]
        if len(self.clear)<2 or now-self.clear[0]['time']<.049:return None
        self.fired=True
        return dict(state='payload_location_pending',measurement_id=f'contact_gap_loss:{grasp_token}:{now:.6f}',
            measurement_time=now,object_scope='current_planned_batch_hypotheses',planned_count=int(planned_count),
            held_count_interval=[0,int(planned_count)],nearby_count_interval=[0,int(planned_count)],
            reference_gap_m=float(reference_gap_m),current_gap_m=gap,collapse_m=collapse,
            distinct_public_samples=len(self.clear),clear_duration_s=now-self.clear[0]['time'],
            rule='transporting after measured closed-gap/bilateral-contact grasp; both public finger contacts absent and physical aperture contracted',samples=copy.deepcopy(self.clear))


def localization_region(position,source_high,target_box):
    p=np.asarray(position,float)
    source=None if source_high is None else np.asarray(source_high[0],float)
    target=None if not target_box or target_box.get('center') is None else np.asarray(target_box['center'],float)
    ds=float(np.linalg.norm(p[:2]-source[:2])) if source is not None else float('inf')
    dt=float(np.linalg.norm(p[:2]-target[:2])) if target is not None else float('inf')
    return 'source' if ds<dt else 'target' if np.isfinite(dt) else 'current'


class LostPayloadSupervisor:
    def reset(self,context=None):
        super().reset(context)
        self._lp_detector=ContactLossEvidence();self._lp_packet={};self._lp_nodes=[]
        self._lp_active=False;self._lp_arrival_id=None;self._lp_inventory_ids=set();self._lp_views=0

    @property
    def public_evidence(self):
        return {**super().public_evidence,'payload_localization':copy.deepcopy(self._lp_packet)}

    def perception_request(self):
        request=super().perception_request()
        if self._lp_active:
            source_view=self._lp_packet.get('region')=='source' and self._obs is not None and max(self._touch(self._obs))<.12
            request.update(stage='SOURCE_OBSERVE' if source_view else 'OBJECT_LOCALIZE',localization_stage='OBJECT_LOCALIZE',force_refit=True,held_reobserve=True,
                payload_localization=copy.deepcopy(self._lp_packet),force_target_observation=False)
        return request

    def _lp_begin(self,obs,scene,event):
        p,R=self._snapshot_pose(obs);source_high=getattr(self,'_safe_source_high',None)
        region=localization_region(p,source_high,scene.get('target_box'))
        self._lp_packet={**event,'measurement_step':self.total_steps,'geometry_version':(scene.get('group') or {}).get('geometry_version'),'region':region,'location':'unknown','inventory':copy.deepcopy(scene.get('object_inventory') or {}),
            'planned_indices':list(self.ledger['planned_indices']),'source_column':self.source_column,
            'view_basis':'current public high pose and previously reached source high; fresh RGB required'}
        self.ledger['actual_held_count_interval']=[0,self.count]
        self.ledger['state']='payload_location_pending'
        if self._repair_unit is not None:self._repair_unit.update(location='unknown',count_interval=[0,self.count])
        self._lp_closing_command=float(self.opening)
        self._held_center_local=None;self._held_pose_confidence=0.;self._held_width=None;self._actual_held_count=None
        self._placement_goal=None;self._place_box_frozen=False
        for name in ('_d_view_pending','_d_view_active'):setattr(self,name,False)
        self._d_envelope=None
        self._request_held_refresh=True
        self._rule_reason='contact and aperture show transport loss; locate current objects before selecting a loaded path'
        self._event('transport_payload_unlocated',self._rule_reason)
        if self.current_report is not None:self.current_report['payload_loss_evidence']=copy.deepcopy(self._lp_packet)
        if region=='target':
            self._lp_active=False;self._start_target_observation(self._rule_reason);return self._hold()
        # First rise, then return only to the actually reached source high XY.
        # The command stays closed; an interval does not authorize a replacement grasp.
        height=max(float(p[2]),float(source_high[0][2]) if source_high is not None else float(p[2]))+.015
        rise=p.copy();rise[2]=height
        destination=rise.copy()
        if source_high is not None:destination[:2]=np.asarray(source_high[0])[:2]
        self._lp_rotation=R.copy();self._lp_nodes=[rise,destination];self._lp_view_anchor=destination.copy()
        self._lp_active=True;self._lp_arrival_id=None;self._lp_inventory_ids=set();self._lp_views=0
        self._advance('PAYLOAD_LOCALIZE');return self._hold()

    def _lp_localize_step(self,obs,scene):
        self.total_steps+=1;self.phase_steps+=1;self._obs,self._scene=obs,scene
        self.actual_opening=float(np.asarray(obs['observation.state'])[7]);self.opening=self._lp_closing_command
        self._inventory=copy.deepcopy(scene.get('object_inventory') or {});self._request_held_refresh=True
        source=scene.get('source_presence') or {};identifier=source.get('measurement_id')
        if self._lp_nodes:
            action,reached=self._servo(obs,self._lp_nodes[0],self._lp_rotation,.003)
            if reached:
                self._lp_nodes.pop(0)
                if not self._lp_nodes:self._lp_arrival_id=identifier
            return action
        if identifier is not None and identifier!=self._lp_arrival_id:
            self._lp_inventory_ids.add(identifier)
            self._lp_packet.update(inventory=copy.deepcopy(self._inventory),measurement_inventory_ids=sorted(self._lp_inventory_ids),
                state='observed_location_interval',next_action='associate an observed source/nearby RepairUnit before retrying this batch')
        held=scene.get('held') or {};touch=self._touch(obs)
        if held.get('measurement_current') and held.get('count') is not None and float(held.get('count_confidence',0.) or 0.)>=.6 and float(held.get('pose_confidence',0.) or 0.)>=.6 and min(touch)>=.1:
            self._lp_active=False;self._advance('TRANSPORT');self._b2_begin('fresh current-region RGB and restored bilateral contact require normal B2 confirmation');return self._hold()
        location=scene.get('object_location') or {}
        if location.get('state')=='target' and float(location.get('confidence',0.) or 0.)>=.6:
            self._lp_packet['location']='target_region_candidate';self._lp_active=False
            self._start_target_observation('localized target-region candidate; original placement audit must verify it');return self._hold()
        # Preserve the unknown interval. Three distinct high views are an
        # observation handoff, not permission to take unrelated source objects.
        if len(self._lp_inventory_ids)>self._lp_views and self._lp_views<2:
            self._lp_views+=1;delta=.008 if self._lp_views==1 else -.008
            self._lp_nodes=[self._lp_view_anchor+np.array([delta,0.,0.])]
        return self._hold()

    def act(self,obs,scene):
        if self._lp_active:return self._lp_localize_step(obs,scene)
        report=self.current_report or {};reference=report.get('measured_inner_gap_m')
        token=(self.batch_index,int(self.ledger.get('attempts',0)))
        event=self._lp_detector.update(obs,stage=self.stage,grasp_token=token,reference_gap_m=reference,
            planned_count=self.count,grasp_established=bool(self.ledger.get('grasp_verified') or report.get('width_consistent') and report.get('force_consistent') and min(report.get('grip_touch_n',[0.,0.]))>=.1))
        if event is not None:
            self.total_steps+=1;self.phase_steps+=1;self._obs,self._scene=obs,scene
            return self._lp_begin(obs,scene,event)
        return super().act(obs,scene)
