"""Actual completed public soft-limit values + exact fixed-CAD FK, no env."""
from pathlib import Path
import ast,json,numpy as np,mujoco
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from path_feasibility import PathFeasibility,_corners
r=Path(__file__).parent;root=r.parent
checker=PathFeasibility(load_config(resource_root()/'configs/cookie_2x10.yaml'));examples=[]
for name in ('f4_basic_n0','f4_medium_n5','f4_advanced_n9'):
 rows=[json.loads(l) for l in (root/'replay_f4'/name/'diagnostic/frames.jsonl').open()]
 frame=max(rows,key=lambda x:x['public_before']['observation.state'][7]);obs=frame['public_before'];o=float(obs['observation.state'][7]);assert o>1
 predicted=checker.gripper_vertices_tool(obs,o)
 # Direct FK at the public actual prismatic coordinate, without clipping.
 state=np.asarray(obs['observation.state']);checker.data.qpos[checker.arm_addresses]=np.r_[state[:7],state[8:15]]
 checker.data.qpos[checker.finger_addresses[0]]=(1-o)*.0425;checker.data.qpos[checker.finger_addresses[1]]=(1-state[15])*.0425
 mujoco.mj_kinematics(checker.model,checker.data)
 p=checker.data.site_xpos[checker.site];rotation=checker.data.site_xmat[checker.site].reshape(3,3);errors=[]
 for gid in checker.geoms:
  if int(checker.model.geom_type[gid])!=int(mujoco.mjtGeom.mjGEOM_BOX):continue
  name_geom=mujoco.mj_id2name(checker.model,mujoco.mjtObj.mjOBJ_GEOM,gid)
  vertices=_corners(checker.model.geom_size[gid]);actual=(vertices@checker.data.geom_xmat[gid].reshape(3,3).T+checker.data.geom_xpos[gid]-p)@rotation
  errors.append(float(np.max(abs(predicted[name_geom]-actual))))
 assert max(errors)<1e-12,errors
 examples.append(dict(case=name,public_frame_id=frame['frame_id'],stage=frame['phase_before'],raw_actual_opening=o,direct_FK_max_error_m=max(errors),
  exception_frame_recorded=False,note='recorded public soft-limit example; failing act frame was not serialized'))
for value in (-.0002,1.0002):
 shapes=checker.gripper_vertices_tool(obs,value);assert all(np.all(np.isfinite(x)) for x in shapes.values())
files=['policy.py','perception.py','rule_controller.py','placement_audit.py','source_geometry.py']
assert all((r/name).read_bytes()==(root/'candidate_f_frontier3'/name).read_bytes() for name in files)
a=ast.parse((root/'candidate_f_frontier3/path_feasibility.py').read_text());b=ast.parse((r/'path_feasibility.py').read_text())
funcs=lambda x:{n.name:ast.dump(n,include_attributes=False) for n in ast.walk(x) if isinstance(n,ast.FunctionDef)}
x,y=funcs(a),funcs(b);assert [n for n in x if x[n]!=y[n]]==['gripper_vertices_tool']
receipt=dict(status='passed',simulation_instances=0,physics_steps=0,only_runtime_change='PathFeasibility.gripper_vertices_tool accepts finite actual prismatic coordinates',
 command_generation_unchanged=True,actual_values_not_clipped=True,examples=examples)
(r/'actual_opening_checks.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
