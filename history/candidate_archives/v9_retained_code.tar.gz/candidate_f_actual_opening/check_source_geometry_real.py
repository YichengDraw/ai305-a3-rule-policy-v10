"""Current neighbour RGB support on completed source frames; no GT input."""
from pathlib import Path
import json,cv2,numpy as np
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from perception import VisionEstimator
from source_geometry import SourceGeometry
root=Path(__file__).parent.parent;case=root/'replay_b1_frontier2/last_single_medium_n9'
frames={r['frame_id']:r for r in map(json.loads,(case/'diagnostic/frames.jsonl').open())}
trace=[json.loads(line) for line in next((case/'policy_trace').glob('*.jsonl')).open()]
config=load_config(resource_root()/'configs/cookie_2x10.yaml');v=VisionEstimator(config);helper=SourceGeometry(config);results=[];initial_frame=None
for step in (0,150):
 row=min(trace,key=lambda r:abs(r['step']-step));p=row['perception'];obs=dict(frames[step]['public_before'])
 for camera in ('front','left_wrist','right_wrist'):
  cap=cv2.VideoCapture(str(case/'diagnostic'/(camera+'.mp4')));cap.set(cv2.CAP_PROP_POS_FRAMES,frames[step]['rgb_video_frame']);ok,bgr=cap.read();cap.release();assert ok
  obs['observation.images.'+camera]=cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)
 v.step=step+1;v.wrist_mount=np.array(p['wrist_calibration']['mount_parameters']);v.calibration_generation=1
 cameras=v._robot_cameras(obs);cameras['left_wrist']=v._v6_wrist_camera(cameras['left_wrist'],obs)
 cameras['front']=v._adjust_camera(cameras['front'],np.array(p['camera_calibration']['front']['adjustment']))
 v.boxes={'source_box':p['source_box']};v._v6_learn_cookie_colors(obs,cameras)
 if initial_frame is None:
  v.v9_source_frontier=v._v9_scan_source_column(obs,cameras,p['source_box'],row['request']);initial_frame=v._v9_public_source_row_frame(1)
 scene={**p,'source_row_frame':initial_frame};e=helper.estimate(obs,scene,cameras,measurement_step=step+1,color_mask=v._v6_color_mask)
 results.append(dict(frame_id=step,state=e['state'],source_box=e['source_box'],coverage=e['coverage'],objects=e['objects'],per_camera=e['per_camera']))
assert results[0]['source_box']['row_axis_verified']
assert -.016<results[0]['source_box']['row_axis_correction_m']<-.007
assert results[0]['source_box']['broad_axis_verified'],results[0]['source_box']
neighbor=next(x for x in results[0]['objects'] if x['source_column']==2 and x['row_hypothesis']==4)
assert neighbor['verified'],neighbor
# The initial identity frame is not claimed as newly measured occupancy.
assert results[0]['source_box']['measurement_id']==results[1]['source_box']['measurement_id']
assert all(o['measurement_step']==151 for o in results[1]['objects'])
r=dict(status='passed',physics_steps=0,ground_truth_read=False,neighbour_column2_row4_current_rgb_supported=True,results=results)
Path(__file__).with_name('source_geometry_real_checks.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(dict(status=r['status'],frames=[dict(frame=x['frame_id'],verified=x['coverage']['verified_count'],protected=x['coverage']['protected_count'],source_center=x['source_box']['center']) for x in results],initial_neighbor=neighbor),indent=2))
