"""Pure source-edge RGB + fixed robot FK/IK contracts. No physics step."""
from pathlib import Path
from types import SimpleNamespace
import ast,json,importlib.util
import cv2,numpy as np
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from perception import VisionEstimator,_project
from rule_controller import RuleController,FixedRobotPitchSearch,CANONICAL
r=Path(__file__).parent;parent=r.parent/'candidate_b1_frontier3'
def function(path,name):
 node=next(n for n in ast.walk(ast.parse(path.read_text())) if isinstance(n,ast.FunctionDef) and n.name==name)
 node.name='same';return ast.dump(node,include_attributes=False)
assert function(r/'perception.py','_v8_broad_edge_column1')==function(parent/'perception.py','_v8_broad_edge')
v=object.__new__(VisionEstimator);v.cookie_half=np.array([.025,.019/6,.0125]);v.step=1;v.calibration_generation=1;v.wrist_calibration={'uncertainty_m':.0015}
v._eef_rotation=lambda obs:(np.array([.25,.3,.84]),CANONICAL)
v._v6_color_mask=lambda im:((np.asarray(im)[:,:,0]>150)&(np.asarray(im)[:,:,1]<150)).astype(np.uint8)*255
camera={'pos':np.array([.25,.3,1.]),'rotation':np.eye(3),'fovy':45.};image=np.full((512,512,3),100,np.uint8)
for y in np.arange(3)*.008833333333-.008833333333:
 corners=np.array([[x,yy,.781] for x in (.25+.004-.025,.25+.004+.025) for yy in (.3+y-.00067,.3+y+.00067)])
 uv,_=_project(corners,camera,image.shape);cv2.fillConvexPoly(image,np.rint(cv2.convexHull(uv.astype(np.float32))).astype(np.int32),(210,90,40))
group={'center':np.array([.25,.3,.7685]),'rotation':np.eye(3)};obs={'observation.images.left_wrist':image}
edge=v._v8_broad_edge(obs,{'left_wrist':camera},group,{'count':3,'source_column':4,'stage':'SELECT','batch_index':0})
assert edge['observable'] and abs(edge['shift_from_prior_m']-.004)<.0006,edge
for column in (2,3):
 inner=v._v8_broad_edge(obs,{'left_wrist':camera},group,{'count':3,'source_column':column,'stage':'SELECT'})
 assert not inner['observable'] and inner['confidence']==0.
# Source1 execution geometry stays exactly the parent even after adding F state.
spec=importlib.util.spec_from_file_location('FParentController',parent/'rule_controller.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
config=load_config(resource_root()/'configs/cookie_2x10.yaml');a=RuleController(config);b=module.RuleController(config)
g={'center':[.1,.25,.7685],'rotation':np.eye(3),'confidence':.7,'tilt_verified':False}
a._apply_group_geometry(g);b._apply_group_geometry(g)
for name in ('_pick','_preinsert','_high','_trial','_pick_rotation','_group_offset'):assert np.array_equal(getattr(a,name),getattr(b,name)),name
# Only known fixed model kinematics and a completed public frame are loaded.
case=r.parent/'replay_b1/guard_basic_2x10';frame=json.loads(next((case/'diagnostic/frames.jsonl').open()));public=frame['public_before']
vision=VisionEstimator(config);search=FixedRobotPitchSearch(vision.robot_model,config)
p,R=a._snapshot_pose(public);path=[dict(name='current',position=p,rotation=R),dict(name='small_free_offset',position=p+[.001,0,0],rotation=R)]
reachable=search.check_ik_path(public,path);assert reachable['state']=='reachable',reachable
unreachable=search.check_ik_path(public,[path[0],dict(name='impossible_far',position=np.array([10.,10.,10.]),rotation=R)])
assert unreachable['state']=='unreachable'
receipt=dict(status='passed',simulation_instances=0,physics_steps=0,checks=['source1 G3 original body AST exact',
 'column4 positive-x outer-edge mirror','inner columns never claim an outside edge','source1 grasp geometry exact parent',
 'fixed-model IK accepts small reachable path and rejects impossible pose'],mirror_shift_m=edge['shift_from_prior_m'],ik=reachable,
 candidate_state='prepared; four-source actual evaluation not run; D protected-geometry coverage required')
(r/'f_contract_checks.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
