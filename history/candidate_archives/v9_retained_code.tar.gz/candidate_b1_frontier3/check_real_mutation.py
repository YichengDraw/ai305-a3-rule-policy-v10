"""Replay completed public RGB/state at a real source-push boundary; no GT."""
from pathlib import Path
import json,cv2,numpy as np
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from perception import VisionEstimator
root=Path(__file__).parent.parent;case=root/'replay_b1_frontier2/last_single_medium_n9'
frames={r['frame_id']:r for r in map(json.loads,(case/'diagnostic/frames.jsonl').open())}
trace=[json.loads(line) for line in next((case/'policy_trace').glob('*.jsonl')).open()]
v=VisionEstimator(load_config(resource_root()/'configs/cookie_2x10.yaml'));results=[]
def observe(step):
 row=min(trace,key=lambda r:abs(r['step']-step));p=row['perception'];obs=dict(frames[step]['public_before'])
 for camera in ('front','left_wrist','right_wrist'):
  cap=cv2.VideoCapture(str(case/'diagnostic'/(camera+'.mp4')));cap.set(cv2.CAP_PROP_POS_FRAMES,frames[step]['rgb_video_frame']);ok,bgr=cap.read();cap.release();assert ok
  obs['observation.images.'+camera]=cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)
 v.step=step+1;v.wrist_mount=np.array(p['wrist_calibration']['mount_parameters']);v.calibration_generation=1
 cameras=v._robot_cameras(obs);cameras['left_wrist']=v._v6_wrist_camera(cameras['left_wrist'],obs)
 cameras['front']=v._adjust_camera(cameras['front'],np.array(p['camera_calibration']['front']['adjustment']))
 v.boxes={'source_box':p['source_box']};v._v6_learn_cookie_colors(obs,cameras)
 result=v._v9_scan_source_column(obs,cameras,p['source_box'],row['request']);v.v9_source_frontier=result
 results.append(dict(frame_id=step,state=result['state'],measurement_id=result['measurement_id'],contact_epoch=result.get('contact_epoch'),
  selected_center=result.get('selected_center'),measurement_source=result.get('measurement_source'),geometry_valid=result.get('geometry_valid'),
  topology_basis=result.get('topology_basis'),requires_wrist_view=result.get('requires_wrist_view'),per_camera=result.get('per_camera')))
 return result
first=observe(0);anchor=v._v9_public_source_row_frame(1)
v._v9_note_source_mutation('DESCEND',np.array([1.,1.]));v._v9_note_source_mutation('SOURCE_OBSERVE',np.zeros(2))
before=observe(207)
for stage in ('PUSH_DESCEND','PUSH_SWEEP','PUSH_RETRACT'):
 v._v9_note_source_mutation(stage,np.zeros(2))
assert v.v9_source_frontier['geometry_valid'] is False
assert v._v9_public_source_row_frame(1)['measurement_id']==anchor['measurement_id']
after=observe(280)
observe(300)
assert before['state']=='measured' and .297<float(before['frontier_center'][1])<.303,results
assert after['state']=='measured' and .312<float(after['frontier_center'][1])<.321,results
assert after['measurement_id']!=before['measurement_id'] and after['contact_epoch']>before['contact_epoch'],results
assert after['selected_count']==1 and after['requested_count']==1
assert v._v9_public_source_row_frame(1)['measurement_id']==anchor['measurement_id']
receipt=dict(status='passed',simulation_instances=0,ground_truth_read=False,
 actual_public_source_push_remeasured=True,stable_initial_identity_retained=True,results=results,
 row_frame_contract=v._v9_public_source_row_frame(1))
Path(__file__).with_name('real_mutation_checks.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('results','row_frame_contract')}));print(json.dumps([{k:v for k,v in r.items() if k!='per_camera'} for r in results],indent=2))
