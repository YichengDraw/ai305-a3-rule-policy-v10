from pathlib import Path
import sys,json,numpy as np
root=Path('/nvme-ssd1/zhaoyicheng/a3_rule_policy_v9_20261103');sys.path.insert(0,str(root/'candidate_e_d3'))
from perception import VisionEstimator
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
v=object.__new__(VisionEstimator);v.scene=load_config(resource_root()/'configs/cookie_batch.yaml').cookie_transfer
v.v6_target_anchor=dict(center=np.array([.1,.1,.74975]),yaw=0.,confidence=.8,anchor_confirmed=False)
v.calibration_generation=1;v.wrist_mount=np.zeros(7);v.camera_adjustments={};v.v9_target_epoch=0;v.step=3
left=dict(camera='left_wrist',valid=True,complete=False,metric_observable=True,visible_top_corners=2,complete_metric_outline=False,
 center=np.array([.1,.109,.74975]),yaw=0.,confidence=.95,visible_rim_fraction=.9,uncertainty_m=.0025,forward_median_px=.2,reverse_median_px=.3)
v._v9_target_view=lambda name,*args:dict(left) if name=='left_wrist' else dict(camera=name,valid=False)
obs={'observation.images.'+name:np.zeros((5,5,3),np.uint8) for name in ['front','left_wrist','right_wrist']};obs['time']=.1
b=v._v9_fit_target(obs,{name:{} for name in ['front','left_wrist','right_wrist']})
assert not b['anchor_confirmed'] and not v.v9_target_geometry['accepted']
assert np.allclose(b['center'],[.1,.1,.74975])
print(json.dumps(dict(scope='constructed partial two-corner data fixture; 9mm wrong candidate',partial_two_corner_anchor_rejected=True,old_provisional_pose_retained=True,physics_steps=0,ground_truth_read=False),indent=2))
