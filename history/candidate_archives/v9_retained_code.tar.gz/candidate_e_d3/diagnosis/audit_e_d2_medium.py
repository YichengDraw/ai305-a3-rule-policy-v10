from pathlib import Path
import json,numpy as np
from scipy.spatial.transform import Rotation
root=Path('/nvme-ssd1/zhaoyicheng/a3_rule_policy_v9_20261103');case=root/'replay_e_d2/2x5_medium_n5_s1_native_scene20001';d=case/'diagnostic'
truth={r['frame_id']:r for r in map(json.loads,(d/'ground_truth_before.jsonl').read_text().splitlines())};frames={r['frame_id']:r for r in map(json.loads,(d/'frames.jsonl').read_text().splitlines())};trace=list(map(json.loads,next((case/'policy_trace').glob('*.jsonl')).read_text().splitlines()))
def public_pose(k):
 q=np.asarray(frames[k]['public_before']['observation.eef_pose'])[:7];return q[:3],Rotation.from_quat(np.r_[q[4:],q[3]]).as_matrix()
def perception(k):return next(r for r in reversed(trace) if r['step']<=k)['perception']
p,R=public_pose(80);est=p+R@np.asarray(perception(80)['held']['center_tool']);ids=np.argsort(np.linalg.norm(np.asarray(truth[80]['cookie_positions'])-est,axis=1))[:5];base=(np.asarray(truth[80]['cookie_positions'])[ids]-p)@R
rows=[]
for k in [80,110,140,180,225,230,235,240,245,260,300,345]:
 p,R=public_pose(k);g=truth[k];s=perception(k);h=s['held'];l=s['target_pose_diagnostics']['per_camera'].get('left_wrist',{});body=(np.asarray(g['cookie_positions'])[ids]-p)@R;center=body.mean(0)
 qs=np.asarray(g['cookie_quaternions'])[ids];gr=Rotation.from_quat(np.c_[qs[:,1:],qs[:,0]]).mean().as_matrix();true_object_tool=R.T@gr
 fitang=None if h.get('rotation_tool') is None else float(np.rad2deg(np.linalg.norm(Rotation.from_matrix(true_object_tool.T@np.asarray(h['rotation_tool'])).as_rotvec())))
 rows.append(dict(frame=k,phase=frames[k]['phase_before'],target_ref_error_mm=float(np.linalg.norm(np.asarray(s['target_box']['center'])[:2]-np.asarray(g['target_position'])[:2])*1000),left_fit_error_mm=None if l.get('center') is None else float(np.linalg.norm(np.asarray(l['center'])[:2]-np.asarray(g['target_position'])[:2])*1000),left={q:l.get(q) for q in ['valid','complete','metric_observable','visible_top_corners','visible_rim_fraction','forward_median_px','reverse_median_px']},actual_center_tool_mm=(center*1000).tolist(),held_fit_error_mm=None if h.get('center_tool') is None else float(np.linalg.norm(center-np.asarray(h['center_tool']))*1000),held_fit_rotation_error_deg=fitang,max_cookie_to_tool_change_from80_mm=float(np.max(np.linalg.norm(body-base,axis=1))*1000),touch=frames[k]['force18'][12:14]))
out=dict(scope='completed development replay; synchronized public before-policy frames with outer GT solely for offline errors',offline_cookie_association='five bodies nearest the observed held envelope at frame80, then immutable identities',offline_cookie_ids=ids.tolist(),official=json.loads((case/'result.json').read_text())['cookies_in_target'],conclusion='first complete view140 recovered a .097mm target candidate, rejected solely by grey-rim support; repeat views never updated the 21.12mm anchor; large true sliding began on the third return235-240, with all five still moving with the gripper at the terminal frame',rows=rows)
(root/'candidate_e_d3/diagnosis/e_d2_medium_view_audit.json').write_text(json.dumps(out,indent=2))
