from pathlib import Path
import sys,json,copy
import numpy as np
root=Path('/nvme-ssd1/zhaoyicheng/a3_rule_policy_v9_20261103');sys.path[:0]=[str(root/'candidate_e_d3'),str(root/'candidate_c/diagnosis')]
from perception import VisionEstimator
from public_frame_loader import PublicFrameLoader
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from PIL import Image
results=[]
for label,case,k in [('complete','replay_e_d2/2x5_medium_n5_s1_native_scene20001',140),('partial_protection','replay_e_c/guard_basic_2x5',2)]:
 v=VisionEstimator(load_config(resource_root()/'configs/cookie_batch.yaml'));loader=PublicFrameLoader(root/case,v);obs,cameras,old=loader.load(k)
 for name in cameras:
  p=root/case/'diagnostic/lossless'/name/f'{k:06d}.png'
  if p.exists():obs['observation.images.'+name]=np.asarray(Image.open(p).convert('RGB'))
 v.boxes={'source_box':old['source_box'],'target_box':old['target_box']};v.v6_target_anchor=copy.deepcopy(old['target_box']);v.v6_target_anchor['anchor_confirmed']=False
 target=v._v9_fit_target(obs,cameras);left=v.v9_target_geometry['per_camera']['left_wrist']
 if label=='complete':
  assert left['complete'] and left['valid'] and left['complete_metric_outline'] and target['anchor_confirmed'] and v.v9_target_geometry['accepted'],(target,left)
  assert np.linalg.norm(np.asarray(target['center'])[:2]-np.asarray(old['target_box']['center'])[:2])>.015
 else:assert not left['complete'] and not left['complete_metric_outline'] and not target['anchor_confirmed'],(target,left)
 results.append(dict(label=label,frame=k,target_center=target['center'],anchor_confirmed=target['anchor_confirmed'],
  complete=left['complete'],visible_top_corners=left['visible_top_corners'],complete_metric_outline=left['complete_metric_outline'],
  rim=left['visible_rim_fraction'],forward=left['forward_median_px'],reverse=left['reverse_median_px']))
 loader.close()
print(json.dumps(dict(checks=results,ground_truth_read=False,physics_steps=0),default=lambda x:x.tolist() if hasattr(x,'tolist') else str(x),indent=2))
