from pathlib import Path
from types import SimpleNamespace
import sys,json,copy,time
import numpy as np
root=Path('/nvme-ssd1/zhaoyicheng/a3_rule_policy_v9_20261103');sys.path.insert(0,str(root/'candidate_d2_reserve'))
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from rule_controller import RuleController
config=load_config(resource_root()/'configs/cookie_2x10.yaml')
results=[]
for name in ['guard_basic_2x10','moving_target_advanced','target_medium_n2','placed_basic_n2']:
 case=root/'replay_abcd'/name;result=json.loads((case/'result.json').read_text());trace=list(map(json.loads,next((case/'policy_trace').glob('*.jsonl')).read_text().splitlines()));row=next(x for x in trace if x['phase']=='PLACE');k=row['step'];frames={x['frame_id']:x for x in map(json.loads,(case/'diagnostic/frames.jsonl').read_text().splitlines())};obs=frames[k]['public_before'];scene=row['perception'];c=RuleController(config);c.reset(SimpleNamespace(task=result['task_instruction']));c.batch_index=row['request']['batch_index'];c.stage='TRANSPORT';c.current_report={};c._clearance=.04;c._obs=obs;c._scene=scene;c._held_center_local=np.asarray(scene['held']['center_tool']);c._held_cookie_local=np.asarray(scene['held']['rotation_tool']);c._held_width=scene['held']['width_m'];c.actual_opening=float(obs['observation.state'][7]);c.opening=.25
 t=time.monotonic();p,R=c._place_pose(scene,0.);dt=time.monotonic()-t
 reservation=c._d_joint_reservations.get(str(c.batch_index//2));assert c._d_report['state'] in ('feasible','unknown'),c._d_report
 if c.batch_index%2==0 and c.batch_sizes[c.batch_index+1]>0:assert reservation['state']=='reserved_geometry',reservation
 results.append(dict(case=name,frame=k,batch=c.batch_index,planned_count=c.count,reservation=reservation,D=c._d_report,seconds=dt))
print(json.dumps(results,default=lambda x:x.tolist() if hasattr(x,'tolist') else str(x),indent=2))
