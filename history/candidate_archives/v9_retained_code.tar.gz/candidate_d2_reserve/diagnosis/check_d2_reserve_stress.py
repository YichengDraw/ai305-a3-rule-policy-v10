exec(open('/nvme-ssd1/zhaoyicheng/a3_rule_policy_v9_20261103/candidate_d2_reserve/check_d2_reserve.py').read().split('results=[]')[0])
case=root/'replay_abcd/target_medium_n2';result=json.loads((case/'result.json').read_text());trace=list(map(json.loads,next((case/'policy_trace').glob('*.jsonl')).read_text().splitlines()));row=next(x for x in trace if x['phase']=='PLACE');k=row['step'];frames={x['frame_id']:x for x in map(json.loads,(case/'diagnostic/frames.jsonl').read_text().splitlines())}
out=[]
for width in [.030,.070]:
 obs=copy.deepcopy(frames[k]['public_before']);scene=copy.deepcopy(row['perception']);scene['held']['width_m']=width;obs['observation.state'][7]=(width-.0053616)/.085
 c=RuleController(config);c.reset(SimpleNamespace(task=result['task_instruction']));c.batch_index=0;c.stage='TRANSPORT';c.current_report={};c._clearance=.04;c._obs=obs;c._scene=scene;c._held_center_local=np.asarray(scene['held']['center_tool']);c._held_cookie_local=np.asarray(scene['held']['rotation_tool']);c._held_width=width;c.actual_opening=float(obs['observation.state'][7]);p,R=c._place_pose(scene,0.)
 rr=c._d_joint_reservations.get('0');out.append(dict(width=width,report=c._d_report,reservation=rr))
 if width==.070:assert c._d_report['state']=='blocked',c._d_report
 if width==.030:assert rr['state']=='reserved_geometry',rr
print(json.dumps(dict(scope='constructed CAD envelope-width stress on recorded public pose; not actual episode observations',checks=out,physics_steps=0,ground_truth_read=False),default=lambda x:x.tolist() if hasattr(x,'tolist') else str(x),indent=2))
