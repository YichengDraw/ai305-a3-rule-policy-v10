"""Replay completed public snapshots only. No GT input or environment."""
from pathlib import Path
import json,cv2,numpy as np
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from perception import VisionEstimator
root=Path(__file__).parent.parent;case=root/'replay_b1_frontier/source_loop_medium'
frames={r['frame_id']:r for r in map(json.loads,(case/'diagnostic/frames.jsonl').open())}
trace=[json.loads(line) for line in next((case/'policy_trace').glob('*.jsonl')).open()]
v=VisionEstimator(load_config(resource_root()/'configs/cookie_2x10.yaml'));results=[]
for step in (0,4,15,150):
 row=min(trace,key=lambda r:abs(r['step']-step));p=row['perception'];obs=dict(frames[step]['public_before'])
 for camera in ('front','left_wrist','right_wrist'):
  cap=cv2.VideoCapture(str(case/'diagnostic'/(camera+'.mp4')));cap.set(cv2.CAP_PROP_POS_FRAMES,frames[step]['rgb_video_frame']);ok,bgr=cap.read();cap.release();assert ok
  obs['observation.images.'+camera]=cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)
 v.step=step+1;v.wrist_mount=np.array(p['wrist_calibration']['mount_parameters']);v.calibration_generation=1
 cameras=v._robot_cameras(obs);cameras['left_wrist']=v._v6_wrist_camera(cameras['left_wrist'],obs)
 cameras['front']=v._adjust_camera(cameras['front'],np.array(p['camera_calibration']['front']['adjustment']))
 v.boxes={'source_box':p['source_box']};v._v6_learn_cookie_colors(obs,cameras)
 request={**row['request'],'batch_index':0 if step<100 else 1,'count':3 if step<100 else 7}
 result=v._v9_scan_source_column(obs,cameras,p['source_box'],request)
 results.append(dict(frame_id=step,state=result['state'],measurement_id=result['measurement_id'],measurement_step=result['measurement_step'],
  selected_center=result.get('selected_center'),selected_count=result.get('selected_count'),topology_basis=result.get('topology_basis'),
  measurement_source=result.get('measurement_source'),coarse_state=(result.get('coarse_current_observation') or {}).get('state'),
  component_counts=[len(c) for c in result.get('components',[])],repair_unit=result.get('repair_unit'),requires_wrist_view=result.get('requires_wrist_view')))
for result in results[:3]:
 assert result['selected_count']==3 and .226<result['selected_center'][1]<.233,result
assert results[1]['measurement_id']==results[0]['measurement_id']==results[2]['measurement_id'],results
assert results[1]['state']=='retained' and results[2]['state']=='retained'
assert results[3]['state']=='noncontiguous' and results[3]['selected_count']==1 and results[3]['requires_wrist_view']
assert results[3]['repair_unit']['count_interval']==[1,1] and results[3]['repair_unit']['planned_batch_count']==7
assert results[3]['repair_unit']['plan_count_changed'] is False
receipt=dict(status='passed',simulation_instances=0,ground_truth_read=False,results=results,
 source_world_geometry_survives_coarse_frames4_15=True,retained_measurement_id_unchanged=True,
 isolated_object_and_following_six_not_closed_as_seven=True)
Path(__file__).with_name('real_retention_checks.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
