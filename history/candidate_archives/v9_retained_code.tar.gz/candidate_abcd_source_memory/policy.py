"""ABCD/R3/B2 unchanged normal runtime plus persistent source retry memory."""
from legacy.policy import VisualForcePolicy as ParentPolicy
from source_retry_memory import RuleController
from source_guard.source_motion_guard import SourceMotionGuard

class MemoryPolicy(ParentPolicy):
    name='v9_abcd_r3_persistent_source_retry_memory'
    def reset(self,context):
        super().reset(context)
        state={k:v for k,v in self.controller.__dict__.items() if k not in ('_source_guard','_source_guard_base_apply','_apply_group_geometry')}
        controller=RuleController(self.vision.config);controller.__dict__.update(state);controller._init_source_retry_memory()
        self.controller=controller;self.source_guard=SourceMotionGuard(self.vision.config,self.vision);self.source_guard.attach(controller)

def make_policy_b():return MemoryPolicy('b')
def make_policy():return MemoryPolicy('b')
