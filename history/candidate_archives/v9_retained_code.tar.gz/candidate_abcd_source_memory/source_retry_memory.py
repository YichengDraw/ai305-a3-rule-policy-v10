"""Persistent source failure memory; current frontier observations only."""
from __future__ import annotations
import copy
import numpy as np
from legacy.rule_controller import RuleController as ParentController,_rotation,gap_from_opening

class SourceRetryMemory:
    def reset(self,context=None):
        super().reset(context);self._init_source_retry_memory()
    def _init_source_retry_memory(self):
        self._b1_source_failures={};self._b1_view_count=0;self._b1_arrival_step=None;self._b1_arrival_time=None
        self._b1_effective_views={};self._b1_seen_view_poses={};self._b1_guard_results=[];self._b1_suppressed=False
        self._memory_guard_active=False;self._b1_ready=True
    @property
    def public_evidence(self):
        result=copy.deepcopy(super().public_evidence)
        result.update(source_failure_memory=copy.deepcopy(self._b1_source_failures.get(self.batch_index,[])),
            source_effective_views=copy.deepcopy(self._b1_effective_views.get(self.batch_index,[])),
            source_alternative_results=copy.deepcopy(self._b1_guard_results),
            source_motion_guard=copy.deepcopy(getattr(getattr(self,'_source_guard',None),'public_evidence',None)))
        return result
    def perception_request(self):
        request=super().perception_request()
        if self.stage in ('B1_SOURCE_VIEW','SOURCE_GUARD_PROBE'):
            request['stage']='SOURCE_OBSERVE';request['force_refit']=True
            request['dynamic_source_refit']=False
        return request
    def _b1_geometry(self,scene):
        local=scene.get('local_align') or {};group=scene.get('group') or {}
        return dict(center=np.asarray(self._pick).copy(),rotation=np.asarray(self._pick_rotation).copy(),
            opening=float(self._initial_opening),row_confidence=float(local.get('row_confidence',local.get('confidence',0.)) or 0.),
            broad_confidence=float(local.get('broad_confidence',0.) or 0.),uncertainty_m=float(local.get('uncertainty_m',.004) or .004),
            gap_width_m=local.get('gap_width_m'),geometry_version=copy.deepcopy(group.get('geometry_version')),
            measurement_id=local.get('measurement_id'),observed_group_center=copy.deepcopy(group.get('center')))
    @staticmethod
    def _b1_same_geometry(a,b):
        angle=float(np.arccos(np.clip((np.trace(np.asarray(a['rotation']).T@np.asarray(b['rotation']))-1.)/2.,-1.,1.)))
        return bool(np.linalg.norm(np.asarray(a['center'])-np.asarray(b['center']))<.001
            and angle<.025 and abs(float(a['opening'])-float(b['opening']))*.085<.0007)
    @staticmethod
    def _b1_new_information(current,previous):
        new_axis=any(previous[k]<.6<=current[k] for k in ('row_confidence','broad_confidence'))
        precision=current['row_confidence']>=.6 and current['uncertainty_m']<.8*previous['uncertainty_m']
        return bool(new_axis or precision)
    def _b1_repeated_candidate(self,scene):
        if not hasattr(self,'_pick'):return False
        current=self._b1_geometry(scene);matching=[f for f in self._b1_source_failures.get(self.batch_index,[]) if self._b1_same_geometry(current,f['geometry'])]
        if len(matching)<2:return False
        last=matching[-1];same=[f for f in matching if f['failure_class']==last['failure_class'] and abs(float(f['depth_m'])-float(last['depth_m']))<.002]
        return len(same)>=2 and not self._b1_new_information(current,last['geometry'])
    def _b1_record_failure(self,reason):
        if self.stage not in ('DESCEND','CLOSE','LOCAL_ALIGN','XY_COARSE','ALIGN_APPROACH'):return
        pose,_=self._snapshot_pose(self._obs);kind='insertion_contact' if 'insertion' in reason else 'grasp_width_contact' if self.stage=='CLOSE' else 'pose_alignment'
        record=dict(step=self.total_steps,stage=self.stage,failure_class=kind,reason=reason,depth_m=float(pose[2]-self._pick[2]),
            geometry=self._b1_geometry(self._scene),contact_epoch=((self._scene.get('source_row_frame') or {}).get('contact_epoch')),touch=self._touch(self._obs).tolist())
        self._b1_source_failures.setdefault(self.batch_index,[]).append(record)
        self._source_memory.setdefault(self.batch_index,{}).setdefault('failures',[]).append(copy.deepcopy(record))
    def _start_source_recovery(self,reason,carrying=False):
        if not carrying:self._b1_record_failure(reason)
        return super()._start_source_recovery(reason,carrying=carrying)
    def _select(self,scene):
        selected=super()._select(scene)
        if selected and self.stage=='APPROACH' and self._b1_repeated_candidate(scene):self._b1_start_view(scene)
        return selected
    def _advance(self,stage):
        if stage=='DESCEND' and getattr(self,'_b1_ready',False) and self._scene is not None and self._b1_repeated_candidate(self._scene):
            self._b1_start_view(self._scene);return
        return super()._advance(stage)
    def _b1_start_view(self,scene):
        if not self._b1_suppressed:
            self.ledger['attempts']=max(0,self.ledger['attempts']-1);self._b1_suppressed=True
            if self.current_report is not None:self.current_report.update(attempt=self.ledger['attempts'],candidate_suppressed_before_insertion=True)
        view=self._source_observation_target(scene)
        if view is None:view=(self._high.copy(),self._pick_rotation.copy())
        offsets=((0.,-.008,.004,-.08),(0.,.008,.004,.08),(-.008,0.,.006,-.10),(.008,0.,.006,.10))
        dx,dy,dz,yaw=offsets[self._b1_view_count%4];self._b1_view_count+=1
        self._b1_view=(np.asarray(view[0])+[dx,dy,dz],np.asarray(view[1])@_rotation('z',yaw));self._b1_arrival_step=None;self._b1_arrival_time=None
        self._rule_reason='two same-geometry/depth failures: obtain a new actual source view before another insertion'
        self._event('source_reobserve',self._rule_reason).update(view_index=self._b1_view_count,failure_memory_persists_across_contact=True,view_basis=copy.deepcopy(getattr(self,'_source_observe_basis',None)))
        self._advance('B1_SOURCE_VIEW')
    def _b1_resume(self,stage,reason):
        if self._b1_suppressed:self.ledger['attempts']+=1;self._b1_suppressed=False
        self._rule_reason=reason;self._alignment_geometry=None;self._advance(stage)
    def _b1_source_view(self,obs,scene):
        action,reached=self._servo(obs,*self._b1_view,.003)
        if not reached:return action
        if self._b1_arrival_step is None:
            self._b1_arrival_step=self.total_steps;self._b1_arrival_time=float(obs.get('time',0.));return action
        if float(obs.get('time',0.))-self._b1_arrival_time<.049:return action
        local=scene.get('local_align') or {};group=scene.get('group') or {};before=self._b1_geometry(scene)
        failures=self._b1_source_failures.get(self.batch_index,[]);previous=failures[-1]['geometry'] if failures else before
        # Use the current frontier's original group/local fit. No old dynamic
        # source model, contact-epoch refresh or manufactured tilt is introduced.
        fresh=int(group.get('geometry_measurement_step',-999))>=self._b1_arrival_step
        if fresh and group.get('center') is not None and float(group.get('confidence',0.) or 0.)>=.6:
            saved={name:copy.deepcopy(getattr(self,name)) for name in ('_pick','_preinsert','_trial','_high','_pick_rotation','_selected_center','_selected_rotation','_group_offset','_held_cookie_local','_selected_tilt_verified','_clearance')}
            self._apply_group_geometry(group)
            if not self._b1_same_geometry(before,self._b1_geometry(scene)):
                self.group=copy.deepcopy(group);self._b1_resume('APPROACH','fresh current-frontier group geometry changes the failed physical candidate');return action
            for name,value in saved.items():setattr(self,name,value)
        information=self._b1_new_information(self._b1_geometry(scene),previous)
        if information and int(local.get('measurement_step',-999))>=self._b1_arrival_step and self._capture_alignment(obs,local):
            self._b1_resume('ALIGN_RETURN','new observable axis or improved precision constrains the failed geometry');return action
        if self.total_steps-self._b1_arrival_step<4:return action
        pose,R=self._snapshot_pose(obs);pose_key=tuple(np.r_[np.round(pose/.002),np.round(R.ravel()/.03)].astype(int))
        seen=self._b1_seen_view_poses.setdefault(self.batch_index,set())
        if pose_key not in seen:
            seen.add(pose_key);self._b1_effective_views.setdefault(self.batch_index,[]).append(dict(step=self.total_steps,position=pose.tolist(),rotation=R.tolist(),
                observation_time=float(obs.get('time',0.)),measurement_id=local.get('measurement_id'),geometry_version=copy.deepcopy(group.get('geometry_version'))))
        if len(self._b1_effective_views.get(self.batch_index,[]))>=4:
            guard=getattr(self,'_source_guard',None)
            ready=True
            if self.current_report is None:
                selected=ParentController._select(self,scene)
                ready=bool(selected and self.stage=='APPROACH' and self.current_report is not None)
                if self.stage not in ('B1_SOURCE_VIEW','APPROACH'):return self._hold()
            if not ready:result=dict(state='observe_required',handled=False,reason='source selection not ready for a new insertion')
            elif guard is None:result=dict(state='unknown',handled=False,reason='fallback_unavailable')
            else:result=guard.try_alternative(self,obs,scene,reason='four_source_views_still_unknown',force_change=True)
            self._b1_guard_results.append(copy.deepcopy(result))
            if result.get('handled'):
                self._memory_guard_active=True
                if self._b1_suppressed:self.ledger['attempts']+=1;self._b1_suppressed=False
                return self._hold()
            self._rule_reason=result.get('reason','fallback_unavailable; continue current source observation')
        self._b1_start_view(scene);return action
    def act(self,obs,scene):
        previous=self.stage;override=None
        empty_source=self.stage in ('APPROACH','ALIGN_APPROACH','LOCAL_ALIGN','XY_COARSE','DESCEND','CLOSE','SOURCE_GUARD_PROBE')
        if self._memory_guard_active and empty_source and getattr(self,'_source_guard',None) is not None:override=self._source_guard.before_act(self,obs,scene)
        action=super().act(obs,scene)  # exactly one original act/counter update
        if override is not None:return override
        if previous=='B1_SOURCE_VIEW' and self.stage=='B1_SOURCE_VIEW' and not self.finished:return self._b1_source_view(obs,scene)
        return action

class RuleController(SourceRetryMemory,ParentController):pass
