from pathlib import Path
from types import SimpleNamespace,MethodType
import sys,json,copy,numpy as np
root=Path('/nvme-ssd1/zhaoyicheng/a3_rule_policy_v9_20261103');sys.path.insert(0,str(root/'candidate_d2_gatefix'))
from rule_controller import RuleController
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
case=root/'replay_abcd/target_medium_n2';res=json.loads((case/'result.json').read_text());trace=list(map(json.loads,next((case/'policy_trace').glob('*.jsonl')).read_text().splitlines()));row=next(r for r in trace if r['phase']=='PLACE');k=row['step'];frame=next(r for r in map(json.loads,(case/'diagnostic/frames.jsonl').read_text().splitlines()) if r['frame_id']==k);results=[]
for stress in [False,True]:
 obs=copy.deepcopy(frame['public_before']);scene=copy.deepcopy(row['perception'])
 if stress:scene['held']['width_m']=.070;obs['observation.state'][7]=(.070-.0053616)/.085
 c=RuleController(load_config(resource_root()/'configs/cookie_2x10.yaml'));c.reset(SimpleNamespace(task=res['task_instruction']));c.stage='TRANSPORT';c._clearance=.04;c.current_report={};c._held_center_local=np.asarray(scene['held']['center_tool']);c._held_cookie_local=np.asarray(scene['held']['rotation_tool']);c._held_width=scene['held']['width_m'];c.actual_opening=float(obs['observation.state'][7]);c.opening=.29;c._d_observed.add(0)
 c._held_update=MethodType(lambda self,*args:True,c);c._servo=MethodType(lambda self,*args,**kwargs:(self._hold(),True),c);c._b2_return_allowed=MethodType(lambda self:False,c)
 stages=[]
 for _ in range(2 if stress else 1):
  action=c.act(obs,scene);stages.append(c.stage)
  if stress:assert c.stage=='TRANSPORT' and c._placement_goal is None and not c._place_box_frozen and np.all(action[:6]==0),(c.stage,c._d_report)
  else:assert c.stage=='PLACE' and c._placement_goal is not None,(c.stage,c._d_report)
 r=c._d_joint_reservations['0'];assert r['state']==('infeasible_joint_geometry' if stress else 'reserved_geometry')
 results.append(dict(scope='constructed 70mm current-envelope stress on public pose' if stress else 'unchanged actual public frame',recorded_frame=k,joint_state=r['state'],D_state=c._d_report['state'],consecutive_stages=stages))
print(json.dumps(dict(checks=results,physics_steps=0,ground_truth_read=False),indent=2))
