"""Public-data control contract: preserve grasp command while taking a target view."""
from pathlib import Path
import sys,json,types
import numpy as np
sys.path.insert(0,str(Path(__file__).parents[1]))
from rule_controller import RuleController
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
c=RuleController(load_config(resource_root()/'configs/cookie_batch.yaml'))
c.reset(types.SimpleNamespace(task='Transfer 10 cookies from source column 1 into the 2x5 box.'))
c.stage='TRANSPORT';c.opening=.25;c.current_report={};c._clearance=.04
q=[1.,0.,0.,0.];obs={'observation.eef_pose':np.r_[[.09,.10,.82],q,[0,0,0],q],
 'observation.state':np.r_[np.zeros(7),.65,np.zeros(7),1.], 'observation.force':np.zeros(18),'time':0.}
box={'center':[.095,.1,.74975],'yaw':0.,'confidence':.7,'visible':True,'anchor_confirmed':False,'visible_rim_fraction':.8}
view={'needed':True,'valid':True,'eef_position':[.09,.07,.86],'eef_rotation':np.eye(3).tolist(),
 'waypoints':[[.09,.10,.86],[.09,.07,.86]],'reason':'contradictory visible target rim'}
scene={'target_box':box,'target_geometry':{'measurement_id':'initial','preplacement_observation':view},'held':{}}
c._servo=lambda *args,**kwargs:(np.zeros(14),True)
c.act(obs,scene)
assert c.stage=='PREPLACE_OBSERVE' and c.opening==.25
assert c.perception_request()['force_refit'] and c.perception_request()['held_reobserve']
c.act(obs,scene);assert c.stage=='PREPLACE_OBSERVE'
scene['target_geometry']['measurement_id']='new_view';scene['target_geometry']['preplacement_observation']={'needed':False,'valid':False}
scene['target_box']={**box,'center':[.095,.092,.74975],'anchor_confirmed':True}
c.act(obs,scene);assert c.stage=='TRANSPORT' and c.opening==.25
assert np.isclose(c._target_box_reference['center'][1],.092)
c.act(obs,scene);assert c.stage=='PLACE' and c._placement_goal is not None
assert c.opening==.25
print(json.dumps({'control':'public-data-only','commanded_grip_preserved':True,'new_measurement_required':True,'new_target_used_before_freezing_goal':True,'once_per_batch':True,'no_simulation':True},indent=2))
