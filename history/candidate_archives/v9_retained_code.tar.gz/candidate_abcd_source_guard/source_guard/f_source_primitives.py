"""Fixed model/public-state source primitives extracted without parent act."""
import mujoco
import numpy as np
from rule_controller import _get,_rotation,_mat,opening_from_gap,PAD_OFFSET,CANONICAL

class FixedRobotPitchSearch:
    """Fixed robot FK/IK plus public state; never binds an episode environment."""
    pitches=(-35.,-40.,-45.,-50.,-55.)

    def __init__(self,model,config,path_checker=None):
        from a3_dual_arm_sim.sim.actions import CartesianDeltaAdapter
        from a3_dual_arm_sim.contracts import LEFT_JOINTS,RIGHT_JOINTS
        self.model=model;self.config=config;self.path_checker=path_checker
        self.adapter=CartesianDeltaAdapter(model,config)
        self.qids=[int(model.jnt_qposadr[mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_JOINT,n)]) for n in (*LEFT_JOINTS,*RIGHT_JOINTS)]
        self.fingers=[[int(model.jnt_qposadr[mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_JOINT,f'{side}_finger_{finger}_joint')]) for finger in ('inner','outer')] for side in ('L','R')]
        self.site=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_SITE,'L_eef')
        self.base=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_GEOM,'L_2f85_base_collision')

    def public_kinematics(self,observation):
        state=np.asarray(observation['observation.state'],float)
        work=self.adapter._work
        work.qpos[self.qids]=np.r_[state[:7],state[8:15]]
        for i,opening in enumerate((state[7],state[15])):work.qpos[self.fingers[i]]=(1-np.clip(opening,0,1))*.0425
        mujoco.mj_kinematics(self.model,work)
        return work,state[:7].copy()

    def geometry(self,controller,observation,group,pitch):
        work,_=self.public_kinematics(observation)
        site_R=work.site_xmat[self.site].reshape(3,3)
        base_offset=site_R.T@(work.geom_xpos[self.base]-work.site_xpos[self.site])
        base_rotation=site_R.T@work.geom_xmat[self.base].reshape(3,3)
        trusted=bool(group.get('tilt_verified')) and float(group.get('confidence',0.) or 0.)>=.6
        obj_R=np.asarray(group.get('rotation',np.eye(3)),float)
        if not trusted:obj_R=_rotation('z',float(np.arctan2(obj_R[1,0],obj_R[0,0])))
        up=obj_R[:,2];fall=np.arctan2(up[1],max(up[2],.1)) if trusted else 0.
        rotation=_rotation('y',np.deg2rad(pitch))@_rotation('x',-np.clip(fall,-.6,.6))@CANONICAL
        center=np.asarray(group['center'],float)
        base_axis=(rotation@base_rotation)[:,2];size=self.model.geom_size[self.base]
        base_half_height=size[0]*np.sqrt(max(0.,1-base_axis[2]**2))+size[1]*abs(base_axis[2])
        offset=rotation@(base_offset-PAD_OFFSET)
        wall=float(_get(controller.geometry,'source_wall_base_z_m',.753))+float(_get(controller.geometry,'source_bin_wall_height_m',.026))
        # The 3mm flange-to-wall term is copied from official expert geometry.
        pinch=max(.010,float(wall+.003-center[2]-offset[2]+base_half_height))
        pick=center+[0,0,pinch]-rotation@PAD_OFFSET
        clearance=max(.040,float(_get(controller.geometry,'source_bin_wall_height_m',.026))+.014)
        center_tool=rotation.T@(center-pick);obj_tool=rotation.T@obj_R
        return dict(pitch_deg=float(pitch),pinch_height_m=pinch,pick=pick,preinsert=pick+[0,0,.024],
            trial=pick+[0,0,.012],high=pick+[0,0,clearance],rotation=rotation,
            center_tool=center_tool,rotation_tool=obj_tool,clearance=clearance)

    def observation_target(self,controller,observation,center,min_height=None):
        current,R=controller._snapshot_pose(observation)
        offset=controller._source_recovery_count%len(self.pitches)
        for pitch in self.pitches[offset:]+self.pitches[:offset]:
            geometry=self.geometry(controller,observation,dict(center=center,rotation=np.eye(3)),pitch)
            position=geometry['high'].copy();position[0]+=.004 if controller._source_recovery_count%2==0 else -.004
            if min_height is not None:position[2]=max(position[2],float(min_height))
            waypoints=[dict(name='public_current',position=current,rotation=R),
                dict(name='source_observe_high',position=position,rotation=geometry['rotation'])]
            if self.check_ik_path(observation,waypoints)['state']=='reachable':return position,geometry['rotation'],pitch
        return None

    def waypoints(self,controller,observation,scene,group,candidate):
        target=scene.get('target_box') or {};box_R=_rotation('z',float(target.get('yaw',0.)))
        target_column=controller.batch_index//2 if controller.is_2x10 else controller.batch_index
        x=np.unique(controller.slots[:,0])[target_column];ys=controller.slots[np.isclose(controller.slots[:,0],x),1]
        if controller.is_2x10:
            n=controller.batch_sizes[0];rows=np.arange(n) if controller.batch_index%2==0 else np.arange(n,10)
            y=float(np.mean(ys[rows]))+((-.004 if controller.batch_index%2==0 else .004) if n else 0.)
            if controller.batch_index%2:
                previous=controller.batch_ledger[controller.batch_index-1].get('target_local_bounds')
                if previous is not None and np.asarray(previous).shape==(3,2):
                    low=float(np.asarray(previous)[1,1])+.008+controller.count*controller.half_size[1]
                    inner=float(_get(controller.geometry,'target_bin_half_size_m',[.063,.0508333])[1])-float(_get(controller.geometry,'bin_wall_thickness_m',.006))
                    high=inner-controller.count*controller.half_size[1]-.001
                    candidate['target_y_interval']=[low,high]
                    candidate['target_interval_empty']=low>high
                    y=min(max(y,low),high)
        else:y=float(np.mean(ys))
        floor=float(_get(controller.geometry,'target_floor_z_m',.003))+.003
        target_center=np.asarray(target['center'])+box_R@np.array([x,y,floor+controller.half_size[2]+.002])
        target_rotation=box_R@candidate['rotation_tool'].T
        place=target_center-target_rotation@candidate['center_tool'];target_high=place+[0,0,candidate['clearance']]
        opening=opening_from_gap(float(group.get('width_m',controller.count*2*controller.half_size[1]))+.0015)
        # Geometry uses the physical packed width. The tighter actuator command
        # that creates pinch force is not an observed finger separation.
        closed=opening_from_gap(controller.count*2*controller.half_size[1])
        released=opening_from_gap(controller.count*2*controller.half_size[1]+.006)
        pose,rotation=controller._snapshot_pose(observation)
        def point(name,p,R,grip,carrying,box):return dict(name=name,position=np.asarray(p),rotation=np.asarray(R),opening=float(grip),carrying=carrying,box_key=box,reference=name=='place')
        return [point('public_current',pose,rotation,controller.actual_opening,False,'source_box'),
            point('source_high',candidate['high'],candidate['rotation'],opening,False,'source_box'),
            point('preinsert',candidate['preinsert'],candidate['rotation'],opening,False,'source_box'),
            point('pick_open',candidate['pick'],candidate['rotation'],opening,False,'source_box'),
            point('pick_closed',candidate['pick'],candidate['rotation'],closed,True,'source_box'),
            point('trial',candidate['trial'],candidate['rotation'],closed,True,'source_box'),
            point('lift_high',candidate['high'],candidate['rotation'],closed,True,'source_box'),
            point('target_high',target_high,target_rotation,closed,True,'target_box'),
            point('place',place,target_rotation,closed,True,'target_box'),
            point('opened',place,target_rotation,released,False,'target_box'),
            point('retracted',target_high,target_rotation,released,False,'target_box')]

    def check_ik_path(self,observation,waypoints):
        from scipy.spatial.transform import Rotation,Slerp
        work,q=self.public_kinematics(observation);max_position=max_angle=max_joint_delta=0.;samples=0
        if not waypoints:return dict(state='unknown',reason='no waypoints supplied')
        public=np.asarray(observation['observation.eef_pose'],float)[:7]
        nodes=[dict(name='public_current',position=public[:3],rotation=_mat(public[3:7]))]
        nodes.extend({**point,'name':point.get('name',f'waypoint_{i}'),
            'position':np.asarray(point['position'],float),'rotation':np.asarray(point['rotation'],float).reshape(3,3)} for i,point in enumerate(waypoints))
        for start,end in zip(nodes[:-1],nodes[1:]):
            length=float(np.linalg.norm(end['position']-start['position']))
            angle=float(np.linalg.norm(Rotation.from_matrix(start['rotation'].T@end['rotation']).as_rotvec()))
            steps=max(1,int(np.ceil(length/.012)),int(np.ceil(angle/.08)))
            slerp=Slerp([0.,1.],Rotation.from_matrix(np.array([start['rotation'],end['rotation']])))
            for t in np.linspace(0.,1.,steps+1)[1:]:
                position=(1-t)*start['position']+t*end['position'];rotation=slerp(t).as_matrix();quat=np.empty(4)
                mujoco.mju_mat2Quat(quat,rotation.ravel());previous=q.copy();q=self.adapter.solve(position,quat,q)
                work.qpos[list(self.adapter._qpos_ids[0])]=q;mujoco.mj_kinematics(self.model,work)
                actual=np.empty(4);error=np.empty(3);mujoco.mju_mat2Quat(actual,work.site_xmat[self.site]);mujoco.mju_subQuat(error,quat,actual)
                position_error=float(np.linalg.norm(work.site_xpos[self.site]-position));angle_error=float(np.linalg.norm(error));samples+=1
                max_position=max(max_position,position_error);max_angle=max(max_angle,angle_error);max_joint_delta=max(max_joint_delta,float(np.max(abs(q-previous))))
                if not np.all(np.isfinite(q)) or position_error>.0008 or angle_error>.015:
                    return dict(state='unreachable',segment=[start['name'],end['name']],position_error_m=position_error,
                        rotation_error_rad=angle_error,samples=samples,criterion='official expert .8mm/.015rad FK residual')
        return dict(state='reachable',max_position_error_m=max_position,max_rotation_error_rad=max_angle,
            max_sample_joint_delta_rad=max_joint_delta,samples=samples,criterion='sampled entire path; fixed kinematics only')

    def search(self,controller,observation,scene,group):
        candidates=[];selected=None
        for pitch in self.pitches:
            geometry=self.geometry(controller,observation,group,pitch)
            points=self.waypoints(controller,observation,scene,group,geometry)
            ik=self.check_ik_path(observation,points)
            envelope=dict(frame='tool',center_tool=geometry['center_tool'],rotation_tool=geometry['rotation_tool'],
                half_size=[controller.half_size[0],controller.count*controller.half_size[1],controller.half_size[2]],
                count_interval=[0,controller.count],basis='source RGB/CAD hypothesis; update after actual lift')
            path={'state':'unknown','reason':'D swept-gripper checker not attached'}
            if geometry.get('target_interval_empty'):
                path={'state':'blocked','reason':'existing placement interval is empty; observe/rearrange target','next_action':'observe_target'}
            elif ik['state']=='reachable' and self.path_checker is not None:
                unit=group.get('source_unit')
                if unit is not None:unit={**unit,'object_scope':'individual_objects',
                    'source_column':controller.source_column,'batch_index':controller.batch_index}
                from .source_geometry import source_path_coverage
                evidence=scene.get('source_geometry') or {}
                coverage=source_path_coverage(self.path_checker,observation,points,evidence)
                path=self.path_checker.check_path(observation,points,envelope,scene,repair_unit=unit,
                    protected_objects=evidence.get('protected_objects'))
                path['source_coverage']=coverage
                if path.get('state')=='feasible' and coverage['state']!='covered':
                    path.update(state='unknown',status='unknown',reason=coverage['reason'],next_action='observe_source_path_region')
            result=dict(pitch_deg=pitch,ik_state=ik['state'],ik=ik,path_state=path.get('state','unknown'),path=path,
                geometry=geometry,waypoints=points,actual_envelope=envelope)
            candidates.append(result)
            if selected is None and ik['state']=='reachable' and not geometry.get('target_interval_empty',False) and (self.path_checker is None or path.get('state')=='feasible'):selected=result
        return dict(selected=selected,candidates=candidates,uses_episode_environment=False,
            admission_scope='supplied full swept path; require feasible result' if self.path_checker is not None else 'prepared kinematics only; D swept path pending')


def make_public_ik_checker(config,model=None):
    """Cache this checker; pass public observation and named Cartesian nodes."""
    if model is None:
        from a3_dual_arm_sim.sim.model import build_model
        model=build_model(config,scene='cookie_transfer').model
    return FixedRobotPitchSearch(model,config)

