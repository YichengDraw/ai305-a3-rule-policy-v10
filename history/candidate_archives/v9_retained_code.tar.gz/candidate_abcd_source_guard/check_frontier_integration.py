"""Use finished real public snapshots; no environment or physics stepping."""
from pathlib import Path
from types import SimpleNamespace
import json,cv2,numpy as np
from policy import make_policy_b
from rule_controller import RuleController
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
root=Path(__file__).parent.parent
results=[]
for relative,seed in [('replay_parent_ab/last_single_medium_n9',18009),('replay_b1/guard_basic_2x10',17001)]:
    case=root/relative;data=json.loads((case/'result.json').read_text())
    frame=json.loads(next((case/'diagnostic/frames.jsonl').open()));obs=dict(frame['public_before'])
    for name in ('front','left_wrist','right_wrist'):
        cap=cv2.VideoCapture(str(case/'diagnostic'/(name+'.mp4')));ok,image=cap.read();cap.release();assert ok
        obs['observation.images.'+name]=cv2.cvtColor(image,cv2.COLOR_BGR2RGB)
    policy=make_policy_b();policy.reset(SimpleNamespace(task=data['task_instruction'],seed=seed))
    action=policy.act(obs)
    scene=policy.controller._scene;frontier=scene['source_frontier'];unit=scene['group'].get('source_unit')
    result={'case':relative,'phase':policy.phase_name,'frontier_state':frontier['state'],
        'frontier_center':frontier.get('frontier_center'),'selected_center':scene['group']['center'],
        'planned_count':policy.controller.count,'source_unit_count':None if unit is None else unit['count_interval'],
        'observed_count_interval':frontier['observed_count_interval']}
    if 'last_single' in relative:
        assert frontier['state']=='measured' and frontier['observed_count_interval']==[20,20],result
        assert .252<np.asarray(scene['group']['center'])[1]<.258,result
        assert unit['count_interval']==[9,9]
    assert policy.controller.count in (9,10) and action.shape==(14,)
    results.append(result);policy.close()
# A coarse overview at the actual front must drive observation, not a far-end pick.
c=RuleController(load_config(resource_root()/'configs/cookie_2x10.yaml'))
c.reset(SimpleNamespace(task='transfer 20 cookies into target box; source column 1; grasp 9 cookies first'))
c.batch_index=3
scene={'source_frontier':{'frontier_center':[.099,.227,.7685],'requires_wrist_view':True,
    'source_column':1,'confidence':.55,'measurement_id':'real_overview:2960'},'source_box':{'yaw':0.,'center':[.175,.315],'confidence':.8}}
assert c._select(scene) and c.stage=='SOURCE_OBSERVE'
assert c._source_observe_pose[0][1]<.25 and c._source_observe_basis['kind']=='measured_column_frontier'
receipt={'status':'passed','simulation_instances':0,'real_first_frame_results':results,
 'coarse_overview_moves_wrist_to_actual_front_y_m':float(c._source_observe_pose[0][1]),
 'column_contour_does_not_replace_planned_unit_count':True}
Path(__file__).with_name('frontier_integration_checks.json').write_text(json.dumps(receipt,indent=2,default=lambda x:x.tolist() if isinstance(x,np.ndarray) else str(x))+'\n')
print(json.dumps(receipt,indent=2,default=lambda x:x.tolist() if isinstance(x,np.ndarray) else str(x)))
