"""No simulation: failure memory + actual synthetic RGB CAD fitting."""
from pathlib import Path
from types import SimpleNamespace
import json
import numpy as np
import cv2
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from rule_controller import RuleController,CANONICAL
from perception import VisionEstimator,_project

c=RuleController(load_config(resource_root()/'configs/cookie_2x10.yaml'))
c.reset(SimpleNamespace(task='transfer 20 cookies into target box; source column 1; grasp 9 cookies first'))
c._apply_group_geometry(dict(center=[.1,.2,.78],rotation=np.eye(3),confidence=.7))
c._initial_opening=.4
scene={'local_align':{'confidence':.35,'row_confidence':.35,'broad_confidence':.0,'uncertainty_m':.004,'measurement_id':'first'}}
g=c._b1_geometry(scene)
c._b1_source_failures[0]=[dict(failure_class='insertion_contact',depth_m=.009,geometry=g,contact_epoch=0),
 dict(failure_class='insertion_contact',depth_m=.0095,geometry=g,contact_epoch=7)]
assert c._b1_repeated_candidate(scene)
# New raw frame / contact epoch does not excuse the same failed geometry.
assert c._b1_repeated_candidate({'local_align':{**scene['local_align'],'measurement_id':'newframe:999'}})
c._selected_center[0]+=.003
assert not c._b1_repeated_candidate(scene)
c._selected_center[0]-=.003
new_axis={'local_align':{**scene['local_align'],'row_confidence':.7,'confidence':.7}}
assert not c._b1_repeated_candidate(new_axis)
c._b1_source_failures[0][0]['depth_m']=.02
assert not c._b1_repeated_candidate(scene)

# Third insertion is replaced by a source viewpoint action before descent.
c2=RuleController(load_config(resource_root()/'configs/cookie_2x10.yaml'))
c2.reset(SimpleNamespace(task='transfer 20 cookies into target box; source column 1; grasp 9 cookies first'))
c2._obs={'observation.eef_pose':np.r_[.1,.2,.84,1.,0.,0.,0.,np.zeros(7)]}
scene2={'group':{'center':np.array([.1,.2,.78]),'rotation':np.eye(3),'confidence':.7},
 'target_box':{'center':np.array([.1,0.,.75]),'confidence':.7},
 'source_box':{'center':np.array([.15,.34]),'confidence':.7},'local_align':scene['local_align']}
assert c2._select(scene2) and c2.stage=='APPROACH'
g2=c2._b1_geometry(scene2)
c2._b1_source_failures[0]=[dict(failure_class='insertion_contact',depth_m=.009,geometry=g2),dict(failure_class='insertion_contact',depth_m=.009,geometry=g2)]
assert c2._select(scene2) and c2.stage=='B1_SOURCE_VIEW'
assert c2.current_report['candidate_suppressed_before_insertion']

# Real existing RGB/CAD fitter: a single object has no repeated stripe signal.
v=object.__new__(VisionEstimator);v.cookie_half=np.array([.025,.019/6,.0125]);v.scene=SimpleNamespace(cookie_edge_bevel_m=.0025,cookie_bottom_edge_bevel_m=.0025)
v.step=20;v.selected_group_key=(1,1,9,1);v.v9_contact_epoch=3
v._v6_color_mask=lambda image:((np.asarray(image)[:,:,0]>150)&(np.asarray(image)[:,:,1]<150)).astype(np.uint8)*255
center=np.array([0.,0.,.5]);hx,hy,hz=v.cookie_half;b=.0025
profile=np.array([[-hy,-hz+b],[-hy+b,-hz],[hy-b,-hz],[hy,-hz+b],[hy,hz-b],[hy-b,hz],[-hy+b,hz],[-hy,hz-b]])
corners=np.array([[x,y,z] for x in (-hx,hx) for y,z in profile])+center
cameras={};observations={}
for name,position in [('left_wrist',[0.,-.18,.70]),('front',[.18,-.08,.66])]:
 p=np.array(position);z=(p-center)/np.linalg.norm(p-center);x=np.cross([0.,0.,1.],z);x/=np.linalg.norm(x);y=np.cross(z,x)
 camera={'pos':p,'rotation':np.column_stack([x,y,z]),'fovy':60.};cameras[name]=camera
 image=np.full((512,512,3),100,np.uint8);uv,_=_project(corners,camera,image.shape)
 cv2.fillConvexPoly(image,np.rint(cv2.convexHull(uv.astype(np.float32))).astype(np.int32),(210,90,40))
 observations['observation.images.'+name]=image
result=v._v9_dynamic_source_model(observations,cameras,dict(center=center,rotation=np.eye(3)),{'count':1,'requested_indices':[9]}, {})
assert result['state']=='measured',result
assert np.linalg.norm(result['center']-center)<.0005 and len(result['cameras'])==2
# A single view is a candidate, not a fabricated second independent constraint.
one=v._v9_dynamic_source_model({'observation.images.left_wrist':observations['observation.images.left_wrist']},{'left_wrist':cameras['left_wrist']},dict(center=center,rotation=np.eye(3)),{'count':1}, {})
assert one['state']!='measured' and one['confidence']<.6
receipt={'status':'passed','checks':['two same-depth failures persist across contact epochs','fresh frame alone is not new information',
 'observed new axis or real geometric change permits a new candidate','different-depth failure is not conflated','third equivalent insertion replaced by source observation before motion',
 'single-cookie beveled CAD measured from two actual synthetic side images without stripe count',
 'single-view ambiguity stays candidate'],'simulation_instances':0,
 'synthetic_single_center_error_m':float(np.linalg.norm(result['center']-center))}
Path(__file__).with_name('b1_contract_checks.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
