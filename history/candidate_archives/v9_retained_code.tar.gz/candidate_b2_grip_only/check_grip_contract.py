from pathlib import Path
from types import SimpleNamespace
import json,ast
import numpy as np
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from rule_controller import RuleController
config=load_config(resource_root()/'configs/cookie_2x10.yaml')
def check(carrying):
 c=RuleController(config);c.reset(SimpleNamespace(task='transfer 20 cookies into target box; grasp 1 cookies first'))
 c._obs={'observation.eef_pose':np.r_[.1,.09,.81,1,0,0,0,np.zeros(7)]};c.current_report={};c.opening=0.;c.actual_opening=.0113541
 c._carry_path=[(np.array([.1,.23,.81]),np.eye(3)),(np.array([.1,.09,.81]),np.eye(3))]
 c._source_path=list(c._carry_path);c._carry_source_high_index=0
 c._start_source_recovery('measured object-to-tool translation changed by over 4 mm',carrying=carrying)
 assert c.stage=='RECOVER_PATH'
 assert abs(c.opening-(0. if carrying else .0113541))<1e-12
 return c
assert check(True)._hold()[6]==-1
check(False)
# Count/slip thresholds and all other methods stay exactly parent A2.
p=Path(__file__).parent;parent=p.parent/'candidate_a2'
def normalized(path):
 t=ast.parse(path.read_text())
 for node in ast.walk(t):
  if isinstance(node,ast.FunctionDef) and node.name=='_start_source_recovery':node.body=[]
 return ast.dump(t,include_attributes=False)
assert normalized(p/'rule_controller.py')==normalized(parent/'rule_controller.py')
for name in ('perception.py','placement_audit.py','policy.py'):assert (p/name).read_bytes()==(parent/name).read_bytes()
r=dict(status='passed',checks=['carrying retains pre-alarm pinch command','empty slit retreat holds actual opening',
 '4mm threshold and all remaining controller methods unchanged','other three runtime files identical A2'],simulation_instances=0)
Path(__file__).with_name('grip_contract_checks.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
