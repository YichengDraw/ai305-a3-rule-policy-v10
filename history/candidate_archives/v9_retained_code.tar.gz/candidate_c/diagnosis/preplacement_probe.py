"""Public-frame probe of when and where the bounded target observation triggers."""
from pathlib import Path
import argparse,json,sys
import numpy as np
p=argparse.ArgumentParser();p.add_argument('case',type=Path);p.add_argument('--step',type=int,required=True);a=p.parse_args()
sys.path.insert(0,str(Path(__file__).parents[1]))
from perception import VisionEstimator
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from public_frame_loader import PublicFrameLoader
config=load_config(resource_root()/('configs/cookie_2x10.yaml' if json.loads((a.case/'development_protocol.json').read_text())['task']=='2x10' else 'configs/cookie_batch.yaml'))
v=VisionEstimator(config);loader=PublicFrameLoader(a.case,v);obs,cameras,old=loader.load(a.step)
v.v6_target_anchor=old['target_box'];new=v._v9_fit_target(obs,cameras)
v.boxes={'target_box':new,'source_box':old['source_box']}
proposal=v._v9_preplacement_observation(obs,cameras,old.get('held') or {})
left=v.v9_target_geometry['per_camera']['left_wrist']
out={'case':a.case.name,'frame':a.step,'parent_anchor_confirmed':old['target_box'].get('anchor_confirmed'),
 'new_anchor_confirmed':new.get('anchor_confirmed'),'new_target_center':np.asarray(new['center']).tolist(),
 'left_prior_residual_px':left.get('prior_forward_visible_median_px'),'left_forward_residual_px':left.get('forward_median_px'),
 'left_reverse_residual_px':left.get('reverse_median_px'),'left_visible_top_corners':left.get('visible_top_corners'),
 'proposal':proposal}
print(json.dumps(out));loader.close()
