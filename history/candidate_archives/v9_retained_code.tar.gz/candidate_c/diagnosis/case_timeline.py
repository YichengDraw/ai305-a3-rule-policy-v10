from pathlib import Path
import sys,json
import numpy as np
case=Path(sys.argv[1]);assert (case/'result.json').exists()
frames={r['frame_id']:r for r in map(json.loads,(case/'diagnostic/frames.jsonl').read_text().splitlines())}
truth=list(map(json.loads,(case/'diagnostic/ground_truth_before.jsonl').read_text().splitlines()))
trace=list(map(json.loads,next((case/'policy_trace').glob('*.jsonl')).read_text().splitlines()))
base=np.asarray(truth[0]['target_position']);out=[];prev=None
for gt in truth:
 f=frames[gt['frame_id']];phase=f['phase_before'];k=gt['frame_id']
 if k>550:break
 if phase==prev:continue
 prev=phase
 if phase not in ('TRANSPORT','PLACE','OPEN','RETRACT','VERIFY','REPAIR_APPROACH','SOURCE_STRAIGHTEN'):continue
 old=next(r for r in reversed(trace) if r['step']<=k)['perception']['target_box']
 out.append({'frame':k,'phase':phase,'official_after':f['official_after']['cookies_in_target'],
 'target_movement_mm':float(np.linalg.norm(np.asarray(gt['target_position'])[:2]-base[:2])*1000),
 'parent_target_error_mm':float(np.linalg.norm(np.asarray(old['center'])[:2]-np.asarray(gt['target_position'])[:2])*1000),
 'target_anchor_confirmed':old.get('anchor_confirmed'),'target_pose_camera':old.get('pose_camera')})
print(json.dumps({'case':case.name,'timeline':out},indent=2))
