"""Offline camera reconstruction from recorded public data; never reads truth."""
from pathlib import Path
import json
import cv2
import numpy as np


class PublicFrameLoader:
    def __init__(self,case,vision):
        self.case=Path(case);self.vision=vision
        assert (self.case/'result.json').exists(), 'Only completed recordings'
        self.frames={r['frame_id']:r for r in map(json.loads,(self.case/'diagnostic/frames.jsonl').read_text().splitlines())}
        self.trace=sorted(map(json.loads,next((self.case/'policy_trace').glob('*.jsonl')).read_text().splitlines()),key=lambda r:r['step'])
        self.caps={n:cv2.VideoCapture(str(self.case/'diagnostic'/(n+'.mp4'))) for n in ('front','left_wrist','right_wrist')}

    def load(self,frame_id):
        row=self.frames[frame_id]
        observation={k:np.asarray(x) if k.startswith('observation.') else x for k,x in row['public_before'].items()}
        recorded=next(r for r in reversed(self.trace) if r['step']<=frame_id)['perception']
        v=self.vision;v.step=frame_id+1
        v.wrist_calibration=recorded.get('wrist_calibration',{}) or {}
        v.wrist_mount=np.asarray(v.wrist_calibration.get('mount_parameters',np.zeros(7)),float)
        front=(recorded.get('camera_calibration',{}) or {}).get('front',{}) or {}
        v.camera_adjustments={'front':np.asarray(front.get('adjustment',np.zeros(7)),float)}
        v.calibration_generation=int(recorded.get('target_box',{}).get('calibration_generation',1))
        v.v6_source_anchor=recorded.get('source_box')
        cameras=v._robot_cameras(observation)
        cameras['left_wrist']=v._v6_wrist_camera(cameras['left_wrist'],observation)
        cameras={n:v._adjust_camera(c,v.camera_adjustments.get(n,np.zeros(7))) for n,c in cameras.items()}
        for name,cap in self.caps.items():
            cap.set(cv2.CAP_PROP_POS_FRAMES,frame_id);ok,im=cap.read()
            if not ok:raise ValueError((str(self.case),name,frame_id))
            observation['observation.images.'+name]=cv2.cvtColor(im,cv2.COLOR_BGR2RGB)
        return observation,cameras,recorded

    def close(self):
        for cap in self.caps.values():cap.release()
