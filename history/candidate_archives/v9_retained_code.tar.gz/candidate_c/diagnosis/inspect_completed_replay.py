"""Offline RGB/public-only target re-fit; outer truth used only after the fit."""
from pathlib import Path
import argparse,json,sys,cv2,time
import numpy as np
from scipy.spatial.transform import Rotation
p=argparse.ArgumentParser();p.add_argument('case',type=Path);p.add_argument('--steps',nargs='+',type=int);p.add_argument('--label',default='c1');a=p.parse_args()
assert (a.case/'result.json').exists(), 'Read only completed cases'
sys.path.insert(0,str(Path(__file__).parents[1]))
from perception import VisionEstimator,_project,_rot_z
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root

def enc(x):
 if hasattr(x,'tolist'):return x.tolist()
 if hasattr(x,'item'):return x.item()
 raise TypeError(type(x).__name__)
case=a.case;diag=case/'diagnostic';frames={r['frame_id']:r for r in map(json.loads,(diag/'frames.jsonl').read_text().splitlines())}
truth={r['frame_id']:r for r in map(json.loads,(diag/'ground_truth_before.jsonl').read_text().splitlines())}
trace=list(map(json.loads,next((case/'policy_trace').glob('*.jsonl')).read_text().splitlines()))
trace.sort(key=lambda r:r['step']);base=np.asarray(truth[min(truth)]['target_position'])
events=[]
for threshold in (.002,.006,.010,.020):
 candidates=[k for k,r in truth.items() if np.linalg.norm(np.asarray(r['target_position'])[:2]-base[:2])>=threshold]
 if candidates:
  k=min(candidates);f=frames[k];events.append({'threshold_m':threshold,'frame':k,'phase':f['phase_before'],'eef':f['public_before']['observation.eef_pose'][:3],'touch':f['force18'][12:14]})
steps=a.steps or sorted(set([0,5,60,70,75,80,85,90,100,190,200,205,210,215,220,235,240,260,295,310,400,460]+[e['frame'] for e in events]))
steps=[k for k in steps if k in frames and k in truth]
task=json.loads((case/'development_protocol.json').read_text()).get('task','2x10')
v=VisionEstimator(load_config(resource_root()/('configs/cookie_2x10.yaml' if task=='2x10' else 'configs/cookie_batch.yaml')));v.calibration_generation=1
from public_frame_loader import PublicFrameLoader
loader=PublicFrameLoader(case,v);caps=loader.caps
records=[];sheets=[]
for k in steps:
 frame=frames[k];obs,cameras,old=loader.load(k)
 # The diagnostic tests target observations against the parent's actual prior.
 # New target candidates never receive truth positions or camera parameters.
 v.v6_target_anchor=old['target_box'] if k else None;v.v9_initial_target_prior=old['target_box'] if not k else None;started=time.perf_counter();new=v._v9_fit_target(obs,cameras);fit_seconds=time.perf_counter()-started;packet=v.v9_target_geometry
 gt=truth[k];tc=np.asarray(gt['target_position']);tr=Rotation.from_quat(np.r_[gt['target_quaternion'][1:],gt['target_quaternion'][0]]).as_matrix()
 rec={'frame':k,'fit_seconds':fit_seconds,'phase':frame['phase_before'],'official_after':frame['official_after'],'target_gt':tc,'target_movement_m':float(np.linalg.norm(tc[:2]-base[:2])),
  'parent_target':old['target_box'],'parent_diagnostics':old.get('target_pose_diagnostics'),
  'new_target':new,'new_geometry':packet,'parent_xy_error_m':float(np.linalg.norm(np.asarray(old['target_box']['center'])[:2]-tc[:2])),
  'new_xy_error_m':float(np.linalg.norm(np.asarray(new['center'])[:2]-tc[:2])),'eef':obs['observation.eef_pose'][:3],'force18':obs['observation.force']}
 records.append(rec)
 if k in (0,70,80,90,205,220,240,295,310,460) or k in [e['frame'] for e in events]:
  row=[];half=np.asarray(v.scene.target_bin_half_size_m)+v.scene.bin_wall_thickness_m
  corners=np.array([[x,y,z] for z in (0.,v.scene.target_bin_wall_height_m) for x in (-half[0],half[0]) for y in (-half[1],half[1])])
  for name in caps:
   im=cv2.cvtColor(obs['observation.images.'+name],cv2.COLOR_RGB2BGR)
   for world,cam,col in ((corners@_rot_z(old['target_box']['yaw']).T+np.asarray(old['target_box']['center']),cameras[name],(0,0,255)),(corners@_rot_z(new['yaw']).T+np.asarray(new['center']),cameras[name],(0,220,0))):
    uv,z=_project(world,cam,im.shape)
    if np.all(z>0):cv2.polylines(im,[np.rint(cv2.convexHull(uv.astype(np.float32))).astype(np.int32)],True,col,2)
   # Ground truth contour is a separate offline overlay using its true camera.
   ix=gt['camera_names'].index(name);gcam={'pos':np.asarray(gt['camera_positions'][ix]),'rotation':np.asarray(gt['camera_rotations'][ix]).reshape(3,3),'fovy':float(gt['camera_fovy'][ix])}
   uv,z=_project(corners@tr.T+tc,gcam,im.shape)
   if np.all(z>0):cv2.polylines(im,[np.rint(cv2.convexHull(uv.astype(np.float32))).astype(np.int32)],True,(255,170,0),1)
   im=cv2.resize(im,(400,300));cv2.putText(im,f'{k} {frame["phase_before"]} {name}',(7,17),cv2.FONT_HERSHEY_SIMPLEX,.43,(255,255,255),1)
   cv2.putText(im,f'GTmove {rec["target_movement_m"]*1000:.1f}mm old/new err {rec["parent_xy_error_m"]*1000:.1f}/{rec["new_xy_error_m"]*1000:.1f}',(7,34),cv2.FONT_HERSHEY_SIMPLEX,.40,(255,255,255),1)
   row.append(im)
  sheets.append(np.hstack(row))
for cap in caps.values():cap.release()
out=Path(__file__).parent/case.name;out.mkdir(exist_ok=True)
(out/(a.label+'_per_view_replay.json')).write_text(json.dumps({'source':str(case),'scope':'offline refit using public images/state/calibration; GT only error/overlay','movement_events':events,'frames':records},default=enc,indent=2)+'\n')
if sheets:cv2.imwrite(str(out/(a.label+'_synchronized_target_views.png')),np.vstack(sheets))
print(json.dumps({'case':case.name,'frames':len(records),'movement_events':events,'out':str(out)},default=enc))
