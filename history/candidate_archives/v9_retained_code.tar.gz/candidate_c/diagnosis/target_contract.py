"""Offline projected-contour and evidence freshness contracts; no simulator."""
from pathlib import Path
import ast,json,types
import numpy as np,cv2
from scipy.optimize import least_squares

src=Path(__file__).parents[1]/'perception.py'
tree=ast.parse(src.read_text());class_node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='VisionEstimator')
keep={'_v7_target_instance','_v7_poly_distance','_box_points','_v9_target_view','_v9_target_calibration_signature','_v9_fit_target'}
class_node.body=[n for n in class_node.body if isinstance(n,ast.FunctionDef) and n.name in keep]
mod=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('_rot_z','_project','_sample_map','_sample_rectangle')]+[class_node],type_ignores=[])
ns=dict(np=np,cv2=cv2,least_squares=least_squares);exec(compile(ast.fix_missing_locations(mod),str(src),'exec'),ns)
V=ns['VisionEstimator'];v=V.__new__(V)
v.scene=types.SimpleNamespace(target_bin_world_position_m=[.11,.12,.74975],target_bin_half_size_m=[.063,.0508333],bin_wall_thickness_m=.006,target_bin_wall_height_m=.04,source_wall_base_z_m=.75)
v.wrist_mount=np.zeros(7);v.camera_adjustments={};v.calibration_generation=1;v.step=1
cam={'pos':np.array([.11,.12,1.1]),'rotation':np.eye(3),'fovy':70.}
t=.006;half=np.array([.063,.0508333])+t
corners=np.array([[x,y,z] for z in (0.,.04) for x in (-half[0],half[0]) for y in (-half[1],half[1])])
center=np.array([.122,.112,.74975]);uv,_=ns['_project'](corners+center,cam,(480,640,3))
im=np.zeros((480,640,3),np.uint8);cv2.fillConvexPoly(im,np.rint(cv2.convexHull(uv.astype(np.float32))).astype(np.int32),(180,180,180))
view=v._v9_target_view('left_wrist',im,cam,np.array([.11,.12,0.]),.74975,corners)
assert view['valid'],view
error=float(np.linalg.norm(np.asarray(view['center'])[:2]-center[:2]));assert error<.001,error
out={'synthetic_translation_error_m':error,'bidirectional_residual_px':[view['forward_median_px'],view['reverse_median_px']]}

# State contract uses public per-view packets; same measurement cannot confirm a move twice.
original=V._v9_target_view
pose=np.array([.11,.12,.74975]);valid=True;complete=True

def packets(self,name,*args):
    if name!='left_wrist':return {'camera':name,'valid':False}
    return {'camera':name,'valid':valid,'center':pose.copy(),'yaw':0.,'confidence':.90,'complete':complete,'uncertainty_m':.0025,'visible_rim_fraction':.8,'forward_median_px':.4,'reverse_median_px':.4}
V._v9_target_view=packets
v.placement_auditor=None;v.v6_target_anchor=None;v.v9_target_epoch=0;v.v9_target_pending=None;v.v7_occupancy={'0':{'bounds':[1]}};v.v7_target_baselines={'batch':2};v.v6_placement_tracks={}
obs={'time':0.,'observation.images.left_wrist':im};cameras={'left_wrist':cam}
initial=v._v9_fit_target(obs,cameras);assert initial['anchor_confirmed']
pose+=np.array([.020,0,0]);v.step=2
v._v9_fit_target(obs,cameras);assert v.v9_target_geometry['pose_state']=='suspected_moved'
v._v9_fit_target(obs,cameras);assert v.v9_target_epoch==0
v.step=3;new=v._v9_fit_target(obs,cameras)
assert v.v9_target_epoch==1 and np.allclose(new['center'],pose)
assert not v.v7_occupancy and not v.v7_target_baselines
out.update(same_frame_not_double_counted=True,new_frame_relocalizes=True,occupancy_invalidated=True)
# Mount change is represented independently, and invalidates pending confirmations.
pose+=np.array([.012,0,0]);v.step=4;v._v9_fit_target(obs,cameras)
v.wrist_mount[0]=.001;v.step=5;v._v9_fit_target(obs,cameras)
assert v.v9_target_geometry['pose_state']=='suspected_moved' and v.v9_target_epoch==1
out['mount_change_does_not_confirm_pending_target_move']=True
print(json.dumps(out,indent=2))
