"""Read finished public RGB/state/estimated camera records; no GT input."""
from pathlib import Path
import json,cv2,numpy as np
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from perception import VisionEstimator,_project
root=Path(__file__).parent.parent
case=root/'replay_parent_ab/last_single_medium_n9'
frames={r['frame_id']:r for r in map(json.loads,(case/'diagnostic/frames.jsonl').open())}
trace=[json.loads(line) for line in next((case/'policy_trace').glob('*.jsonl')).open()]
vision=VisionEstimator(load_config(resource_root()/'configs/cookie_2x10.yaml'))
results=[];sheets=[]
for step in (0,10,900,2960,3150):
    row=min(trace,key=lambda r:abs(r['step']-step));p=row['perception'];obs=dict(frames[step]['public_before'])
    for camera in ('front','left_wrist','right_wrist'):
        cap=cv2.VideoCapture(str(case/'diagnostic'/(camera+'.mp4')));cap.set(cv2.CAP_PROP_POS_FRAMES,frames[step]['rgb_video_frame']);ok,bgr=cap.read();cap.release();assert ok
        obs['observation.images.'+camera]=cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)
    vision.step=step+1;vision.wrist_mount=np.array(p['wrist_calibration']['mount_parameters']);vision.calibration_generation=1
    cameras=vision._robot_cameras(obs);cameras['left_wrist']=vision._v6_wrist_camera(cameras['left_wrist'],obs)
    cameras['front']=vision._adjust_camera(cameras['front'],np.array(p['camera_calibration']['front']['adjustment']))
    vision.boxes={'source_box':p['source_box']};vision._v6_learn_cookie_colors(obs,cameras)
    request=row['request'];request={**request,'source_column':1,'count':9 if step<100 else 1}
    result=vision._v9_scan_source_column(obs,cameras,p['source_box'],request)
    results.append({'frame_id':step,'result':result,'previous_planned_group_center':p['group']['center']})
    images=[]
    for name in ('front','left_wrist'):
        image=cv2.cvtColor(obs['observation.images.'+name],cv2.COLOR_RGB2BGR)
        objects=result.get('objects',[])
        if objects:
            points=np.array([o['center'] for o in objects]);points[:,2]+=vision.cookie_half[2];uv,_=_project(points,cameras[name],image.shape)
            for xy in uv:cv2.circle(image,tuple(np.rint(xy).astype(int)),2,(0,255,0),1)
        cv2.putText(image,f'{name} {step} {result["state"]}',(4,15),cv2.FONT_HERSHEY_SIMPLEX,.42,(255,255,255),1)
        images.append(image)
    sheets.append(np.concatenate(images,1))
out=root/'frontier_diagnosis';out.mkdir(exist_ok=True)
(out/'real_public_frontier.json').write_text(json.dumps(results,indent=2,default=lambda x:x.tolist() if isinstance(x,np.ndarray) else str(x))+'\n')
cv2.imwrite(str(out/'real_public_frontier.png'),np.concatenate(sheets,0))
for r in results:
    s=r['result'];print(r['frame_id'],s['state'],s['confidence'],s.get('observed_count_interval'),s.get('frontier_center'),s.get('selected_center'),s['per_camera'])
