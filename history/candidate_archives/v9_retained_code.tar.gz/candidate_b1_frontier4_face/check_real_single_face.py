"""Fit actual completed single-source RGB, never read GT as input."""
from pathlib import Path
import json,cv2,numpy as np
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from perception import VisionEstimator
r=Path(__file__).parent;root=r.parent;case=root/'replay_b1_frontier3/last_single_medium_n9'
frames={r['frame_id']:r for r in map(json.loads,(case/'diagnostic/frames.jsonl').open())};trace=[json.loads(l) for l in next((case/'policy_trace').glob('*.jsonl')).open()]
v=VisionEstimator(load_config(resource_root()/'configs/cookie_2x10.yaml'));results=[]
for step in (205,207,278,320,343):
 row=min(trace,key=lambda r:abs(r['step']-step));p=row['perception'];obs=dict(frames[step]['public_before'])
 for camera in ('front','left_wrist','right_wrist'):
  cap=cv2.VideoCapture(str(case/'diagnostic'/(camera+'.mp4')));cap.set(cv2.CAP_PROP_POS_FRAMES,frames[step]['rgb_video_frame']);ok,bgr=cap.read();cap.release();assert ok
  obs['observation.images.'+camera]=cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)
 v.step=step+1;v.wrist_mount=np.array(p['wrist_calibration']['mount_parameters']);v.calibration_generation=1
 cameras=v._robot_cameras(obs);cameras['left_wrist']=v._v6_wrist_camera(cameras['left_wrist'],obs);cameras['front']=v._adjust_camera(cameras['front'],np.array(p['camera_calibration']['front']['adjustment']))
 centers=np.column_stack([v.layout,np.full(len(v.layout),v.scene.cookie_model_z_m)])
 centers[9]=p['source_frontier']['frontier_center'];centers[9,0]=p['group']['broad_measurement']['center_world'][0] if (p['group'].get('broad_measurement') or {}).get('center_world') is not None else p['group']['center'][0]
 fit=v._fit_selected_group(obs,cameras,centers,np.array([9]),p['source_box']['position_error_m'],allow_tilt=True)
 results.append(dict(frame=step,original_tilt=p['group']['tilt_deg'],original_verified=p['group']['tilt_verified'],original_center=p['group']['center'],new_fit=fit))
assert all(not x['new_fit']['tilt_verified'] and x['new_fit']['tilt_deg']==0. and x['new_fit']['confidence']>=.6 for x in results[:3]),results
receipt=dict(status='passed',physics_steps=0,ground_truth_read=False,results=results)
(r/'real_single_face_checks.json').write_text(json.dumps(receipt,indent=2,default=lambda x:x.tolist() if hasattr(x,'tolist') else x)+'\n');print(json.dumps([dict(frame=x['frame'],old=x['original_tilt'],new=x['new_fit']['tilt_deg'],verified=x['new_fit']['tilt_verified'],confidence=x['new_fit']['confidence'],center=x['new_fit']['center'].tolist()) for x in results],indent=2))
