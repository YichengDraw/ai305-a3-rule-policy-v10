"""Guard contract using recorded public per-view packets; no truth input."""
from pathlib import Path
import sys,json,copy,types
import numpy as np
sys.path.insert(0,str(Path(__file__).parents[1]))
from perception import VisionEstimator
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
root=Path('/nvme-ssd1/zhaoyicheng/a3_rule_policy_v9_20261103')
def first(run):return json.loads(next((root/run/'guard_basic_2x5/policy_trace').glob('*.jsonl')).read_text().splitlines()[0])['perception']
p=first('replay_parent_e');bad=first('replay_e_c')['target_geometry']['per_camera'];left=bad['left_wrist']
assert left['valid'] and not left['complete'] and left['metric_observable']
v=VisionEstimator(load_config(resource_root()/'configs/cookie_batch.yaml'))
v.v9_initial_target_prior=copy.deepcopy(p['target_box']);v.v6_target_anchor=None
v._v9_target_view=types.MethodType(lambda self,name,*args:copy.deepcopy(bad[name]),v)
obs={'time':0.,**{'observation.images.'+n:np.zeros((480,640,3),np.uint8) for n in bad}};cameras={n:{} for n in bad}
v.step=1;initial=v._v9_fit_target(obs,cameras)
assert np.allclose(initial['center'],p['target_box']['center']) and not initial['anchor_confirmed']
v.step=2;again=v._v9_fit_target(obs,cameras)
assert np.allclose(again['center'],initial['center']) and not again['anchor_confirmed']
complete=copy.deepcopy(bad);complete['left_wrist'].update(complete=True,center=(np.asarray(initial['center'])+[.002,0,0]).tolist(),confidence=.85,visible_rim_fraction=.8)
v._v9_target_view=types.MethodType(lambda self,name,*args:copy.deepcopy(complete[name]),v)
v.step=3;anchored=v._v9_fit_target(obs,cameras);assert anchored['anchor_confirmed']
v._v9_target_view=types.MethodType(lambda self,name,*args:copy.deepcopy(bad[name]),v)
for k in (4,5):
 v.step=k;retained=v._v9_fit_target(obs,cameras);assert np.allclose(retained['center'],anchored['center'])
print(json.dumps({'fixture':'public guard initial packet','partial_low_residual_does_not_certify_anchor':True,'initial_mixed_prior_retained':True,'complete_wrist_can_confirm':True,'repeated_partial_does_not_relocate':True,'ground_truth_read':False},indent=2))
