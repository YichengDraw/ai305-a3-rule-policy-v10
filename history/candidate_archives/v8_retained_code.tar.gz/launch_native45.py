"""Snapshot and run the shared14000 native45 development cohort."""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from launch_core_cases import runtime_files,HELPERS

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--policy-code',type=Path,required=True);p.add_argument('--policy',default='policy:make_policy_b')
    p.add_argument('--output',type=Path,required=True);p.add_argument('--workers',type=int,default=24)
    p.add_argument('--egl-devices',type=int,nargs='+',default=[5]);p.add_argument('--trace-policy',action='store_true')
    a=p.parse_args();root=a.output.resolve();root.mkdir(parents=True,exist_ok=False);code=root/'code';code.mkdir()
    scripts=Path(__file__).resolve().parent;source=a.policy_code.resolve();dependencies=runtime_files(source)
    for name in dependencies:
        (code/name).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/name,code/name)
    for name in HELPERS:shutil.copy2(scripts/name,code/name)
    cases=[('2x5',profile,14000+i,5) for profile in ('basic','medium','advanced') for i in range(5)]
    cases += [('2x10',profile,14000+n,n) for profile in ('basic','medium','advanced') for n in range(10)]
    jobs=[dict(task=t,profile=p,seed=s,n=n,gpu=a.egl_devices[i%len(a.egl_devices)]) for i,(t,p,s,n) in enumerate(cases)]
    (root/'protocol.json').write_text(json.dumps(dict(scope='v8_native45_development',development_only=True,
        policy=a.policy,code_directory=str(code),runtime_dependencies=dependencies,
        code_sha256={n:hashlib.sha256((code/n).read_bytes()).hexdigest() for n in dependencies+list(HELPERS)},
        jobs=jobs,max_steps_by_task={'2x5':500,'2x10':3200},source_column=1,success_hold_steps=5,
        strict_policy_completion=False,offline_ground_truth_audit=False,trace_policy=a.trace_policy,
        primary_metric='equal six-cell raw mean official final_count, cookies/episode',started_utc=datetime.now(timezone.utc).isoformat()),indent=2)+'\n')
    start=time.monotonic();done=[]
    def run(job):
        name=f"{job['task']}_{job['profile']}_{job['seed']}_n{job['n']}";output=root/name
        env=dict(os.environ,MUJOCO_GL='egl',MUJOCO_EGL_DEVICE_ID=str(job['gpu']),CUDA_VISIBLE_DEVICES=str(job['gpu']),
            OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
        if a.trace_policy:env['A3_POLICY_TRACE_DIR']=str(output/'policy_trace')
        else:env.pop('A3_POLICY_TRACE_DIR',None)
        command=[sys.executable,str(code/'evaluate_policy.py'),'--policy',a.policy,'--policy-code',str(code),
            '--tasks',job['task'],'--profiles',job['profile'],'--seed-start',str(job['seed']),'--episodes','1',
            '--first-grasp-2x10',str(job['n']),'--max-steps','500','--max-steps-2x10','3200',
            '--render-cameras','--output',str(output)]
        print('START',name,flush=True)
        with (root/(name+'.log')).open('w') as log:
            result=subprocess.run(command,cwd=code,env=env,stdout=log,stderr=subprocess.STDOUT)
        print('FINISH',name,'rc',result.returncode,flush=True)
        return dict(job,output=str(output),returncode=result.returncode,command=command)
    with ThreadPoolExecutor(max_workers=a.workers) as pool:
        for future in as_completed([pool.submit(run,j) for j in jobs]):
            done.append(future.result());(root/'progress.json').write_text(json.dumps(dict(jobs=done,finished=len(done),total=45),indent=2)+'\n')
    complete=dict(status='completed' if all(not j['returncode'] for j in done) else 'failed',jobs=done,
        wall_seconds=time.monotonic()-start,finished_utc=datetime.now(timezone.utc).isoformat())
    (root/'complete.json').write_text(json.dumps(complete,indent=2)+'\n')
    if complete['status']!='completed':raise SystemExit('Native45 subprocess error')

if __name__=='__main__':main()
