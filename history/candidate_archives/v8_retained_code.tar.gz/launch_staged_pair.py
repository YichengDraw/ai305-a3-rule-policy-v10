"""Frozen natural tests: first30 per policy, then the same code extends to120."""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
from launch_core_cases import runtime_files


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--phase',choices=('initial','extend'),required=True)
    p.add_argument('--c0-code',type=Path,required=True)
    p.add_argument('--candidate-code',type=Path,required=True)
    p.add_argument('--c0-policy',default='policy:make_policy')
    p.add_argument('--candidate-policy',default='policy:make_policy_b')
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--workers',type=int,default=24)
    p.add_argument('--egl-devices',type=int,nargs='+',default=[5])
    a=p.parse_args()
    if a.workers<2:p.error('At least two workers')
    root=a.output.resolve();scripts=Path(__file__).resolve().parent
    versions=[]
    for label,code,factory in (('c0',a.c0_code,a.c0_policy),('v8',a.candidate_code,a.candidate_policy)):
        code=code.resolve()
        versions.append(dict(name=label,code=str(code),policy=factory,
            runtime_sha256={name:hashlib.sha256((code/name).read_bytes()).hexdigest() for name in runtime_files(code)}))
    helpers={name:hashlib.sha256((scripts/name).read_bytes()).hexdigest() for name in (
        'evaluate_policy.py','batch_metrics.py','diagnostic_support.py','launch_evaluation.py','merge_results.py','paired_comparison.py')}
    registration=dict(scope='v8_frozen_natural_paired',seed_start=17000,seeds=[17000,17019],
        stages={'initial':{'seed_start':17000,'episodes_per_cell':5},'extend':{'seed_start':17005,'episodes_per_cell':15}},
        max_steps_by_task={'2x5':500,'2x10':3200},source_column=1,strict_policy_completion=False,
        success_hold_steps=5,primary_metric='mean official final_count, cookies/episode',
        versions=versions,evaluator_sha256=helpers)
    if a.phase=='initial':
        root.mkdir(parents=True,exist_ok=False)
        (root/'protocol.json').write_text(json.dumps(dict(registration,registered_utc=datetime.now(timezone.utc).isoformat()),indent=2)+'\n')
    else:
        saved=json.loads((root/'protocol.json').read_text());saved.pop('registered_utc')
        assert saved==registration,'Frozen runtime/evaluator/protocol changed; use new final seeds'
        assert json.loads((root/'initial/complete.json').read_text())['status']=='completed'
    stage=root/a.phase;stage.mkdir(exist_ok=False)
    spec=registration['stages'][a.phase];start=time.monotonic()
    def run(job):
        workers=a.workers//2 if job['name']=='c0' else a.workers-a.workers//2
        command=[sys.executable,str(scripts/'launch_evaluation.py'),'--output',str(stage/job['name']),
            '--policy-code',job['code'],'--policy',job['policy'],'--episodes',str(spec['episodes_per_cell']),
            '--seed-start',str(spec['seed_start']),'--shard-size','1','--workers',str(workers),
            '--no-audit-ground-truth','--egl-devices',*[str(g) for g in a.egl_devices]]
        with (stage/(job['name']+'.log')).open('w') as log:
            result=subprocess.run(command,cwd=scripts,stdout=log,stderr=subprocess.STDOUT)
        return dict(name=job['name'],returncode=result.returncode,command=command)
    with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,versions))
    (stage/'status.json').write_text(json.dumps(dict(results=results,wall_seconds=time.monotonic()-start),indent=2)+'\n')
    if any(x['returncode'] for x in results):raise SystemExit('Natural shard error; inspect status and original logs')
    final={}
    for job in versions:
        if a.phase=='initial':
            final[job['name']]=stage/job['name']/'final_default'
        else:
            inputs=[p.parent for phase in ('initial','extend') for p in sorted((root/phase/job['name']/'default').glob('*/episodes.jsonl'))]
            assert len(inputs)==120
            final[job['name']]=root/job['name']/'final_natural'
            subprocess.run([sys.executable,str(scripts/'merge_results.py'),'--inputs',*[str(x) for x in inputs],
                '--output',str(final[job['name']]),'--seed-start','17000','--episodes','20',
                '--max-steps','500','--max-steps-2x10','3200'],check=True,cwd=scripts)
    comparison=stage/'comparison' if a.phase=='initial' else root/'comparison'
    subprocess.run([sys.executable,str(scripts/'paired_comparison.py'),'--old',str(final['c0']),'--new',str(final['v8']),
        '--old-label','C0','--new-label','V8','--seed-start','17000','--episodes','5' if a.phase=='initial' else '20',
        '--protocol-label','官方500/3200自然抽样','--output',str(comparison)],check=True,cwd=scripts)
    complete=dict(status='completed',scope='natural_sampling_only',phase=a.phase,
        episodes=60 if a.phase=='initial' else 180,table_episodes_per_policy=30 if a.phase=='initial' else 120,
        wall_seconds=time.monotonic()-start,finished_utc=datetime.now(timezone.utc).isoformat())
    (stage/'complete.json').write_text(json.dumps(complete,indent=2)+'\n')
    if a.phase=='extend':
        (root/'complete.json').write_text(json.dumps(dict(complete,episodes=240,initial_rows_reused_per_policy=30),indent=2)+'\n')


if __name__=='__main__':main()
