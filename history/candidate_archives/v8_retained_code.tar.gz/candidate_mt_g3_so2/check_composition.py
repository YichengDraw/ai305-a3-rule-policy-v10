"""Exact AST composition and parent receipts for the unselected G3+SO2 candidate."""
from pathlib import Path
import ast,json,hashlib,datetime
here=Path(__file__).resolve().parent;root=here.parent
parents={'G3':root/'candidate_mtg3_v7','SO2':root/'candidate_source_observe_so2','MT':root/'candidate_mt_v7'}
files=['policy.py','perception.py','placement_audit.py','rule_controller.py']
def parts(path):
 tree=ast.parse(path.read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef));methods={n.name:ast.dump(n,include_attributes=False) for n in cls.body if isinstance(n,ast.FunctionDef)};act=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='act');blocks={ast.unparse(n.test):ast.dump(n,include_attributes=False) for n in act.body if isinstance(n,ast.If)};return methods,blocks
combined,blocks=parts(here/'rule_controller.py');g2,g2blocks=parts(parents['G3']/'rule_controller.py');so2,so2blocks=parts(parents['SO2']/'rule_controller.py')
changed=[name for name in g2 if g2[name]!=combined[name]];assert changed==['act']
added=[name for name in combined if name not in g2];assert added==['_source_observation_target']
assert combined['_source_observation_target']==so2['_source_observation_target']
assert combined['_apply_group_geometry']==g2['_apply_group_geometry']
assert combined['_capture_alignment']==g2['_capture_alignment']
changed_blocks=[key for key in g2blocks if g2blocks[key]!=blocks[key]]
assert changed_blocks==["self.stage == 'SELECT'", "self.stage == 'SOURCE_OBSERVE'"]
assert all(blocks[key]==so2blocks[key] for key in changed_blocks)
for name in files[:3]:assert (here/name).read_bytes()==(parents['G3']/name).read_bytes()
hashfiles=lambda folder:{name:hashlib.sha256((folder/name).read_bytes()).hexdigest() for name in files}
result={'status':'prepared_unselected_combination','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'base':'candidate_mtg3_v7','source_observation_donor':'candidate_source_observe_so2','changed_existing_methods_vs_g3':changed,
 'added_methods':added,'changed_dispatch_blocks':changed_blocks,'g3_apply_geometry_and_capture_alignment_retained':True,
 'other_m1_t1_blocks_retained':True,'non_control_modules_identical_to_g3':True,
 'parent_sha256':{name:hashfiles(folder) for name,folder in parents.items()},'candidate_sha256':hashfiles(here),
 'simulation_run':False,'selection_not_decided':True}
(here/'composition.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['status','changed_existing_methods_vs_g3','added_methods','changed_dispatch_blocks','non_control_modules_identical_to_g3']},indent=2))
