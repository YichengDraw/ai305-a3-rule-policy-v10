"""Public source-view transit plus G2 cache-version check; no simulation."""
from pathlib import Path
from types import SimpleNamespace
import json,copy
import numpy as np
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from rule_controller import RuleController,CANONICAL
root=Path(__file__).resolve().parents[1];record=json.loads((root/'source_observe_diagnosis/source_observe_public_state.json').read_text());config=load_config(resource_root()/'configs/cookie_2x10.yaml')
c=RuleController(config);c.reset(SimpleNamespace(task='Transfer 20 cookies from source column 1. Grasp 4 cookies first.'));c.set_variant('b');c.batch_index=1
scene=record['perception'];target,rot=c._source_observation_target(scene)
assert target[1]>.28 and c._source_observe_basis['planned_indices']==list(range(4,10))
c._source_observe_pose=(target,rot);c._advance('SOURCE_OBSERVE')
state=np.zeros(16);state[7]=state[15]=1.;pose=np.asarray(record['eef']);obs={'observation.eef_pose':np.r_[pose,pose],'observation.state':state,'observation.velocity':np.zeros(16),'observation.force':np.zeros(18),'time':0.}
action=c.act(obs,scene);assert np.linalg.norm(action[:3]*c.translation_scale)>.0149 and np.linalg.norm(action[:3]*c.translation_scale)<=.015+1e-12
# Preserve G3's requirement that incompatible geometry versions invalidate cache.
c._alignment_geometry={'geometry_version':{'g2_active':True,'group_key':'old','calibration_key':1}}
new={'geometry_version':{'g2_active':True,'group_key':'new','calibration_key':1},'state':'unknown','confidence':0.}
assert c._capture_alignment(obs,new) is False and c._alignment_geometry is None
# Preserve G3's required EEF orientation alongside its accepted source geometry.
group=copy.deepcopy(scene['group']);group['geometry_version']={'g2_active':True,'group_key':'new','calibration_key':1}
c._apply_group_geometry(group)
assert np.allclose(c._source_geometry_version['required_eef_rotation'],c._pick_rotation)
result={'passed':4,'public_case_step':record['step'],'source_view':target.tolist(),'source_requested_indices':list(range(4,10)),
 'so2_transit_limit_m':.015,'g3_version_cache_invalidation_retained':True,'g3_required_eef_rotation_retained':True,
 'simulation_steps':0,'ground_truth_used_in_control':False}
Path(__file__).with_name('public_contract.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
