"""Collect initial30 or completed120 natural test records, without resimulation."""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path

def read(path):return json.loads(path.read_text())
def rows(path):return [json.loads(x) for x in path.read_text().splitlines() if x.strip()]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,required=True)
    p.add_argument('--phase',choices=('initial','full'),required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();root=a.root.resolve();protocol=read(root/'protocol.json')
    phases=('initial',) if a.phase=='initial' else ('initial','extend')
    payload=dict(scope='natural_sampling_only',phase=a.phase,source_directory=str(root),
        collected_utc=datetime.now(timezone.utc).isoformat(),registration=protocol,
        stages={phase:dict(complete=read(root/phase/'complete.json'),status=read(root/phase/'status.json')) for phase in phases},policies={})
    if a.phase=='full':payload['complete']=read(root/'complete.json')
    for version in protocol['versions']:
        label=version['name'];code=Path(version['code'])
        records=[];launches={}
        for phase in phases:
            source=root/phase/label
            launches[phase]=dict(launch=read(source/'launch_protocol.json'),status=read(source/'launch_status.json'),complete=read(source/'complete.json'))
            for path in sorted((source/'default').glob('*/episodes.jsonl')):
                records.append(dict(phase=phase,source_directory=str(path.parent),protocol=read(path.parent/'protocol.json'),
                    summary_status=read(path.parent/'summary.json')['status'],episodes=rows(path)))
        final=root/'initial'/label/'final_default' if a.phase=='initial' else root/label/'final_natural'
        payload['policies'][label]=dict(runtime_sha256={n:hashlib.sha256((code/n).read_bytes()).hexdigest() for n in version['runtime_sha256']},
            launches=launches,cases=records,merged_episodes=rows(final/'episodes.jsonl'),merged_summary=read(final/'summary.json'))
    a.output.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(phase=a.phase,raw_shards=sum(len(p['cases']) for p in payload['policies'].values()))))

if __name__=='__main__':main()
