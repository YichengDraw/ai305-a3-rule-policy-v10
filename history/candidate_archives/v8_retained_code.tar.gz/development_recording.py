"""Sparse evaluator-only diagnostics with RGB and truth from the same pre-action frame."""
from __future__ import annotations
import json
from pathlib import Path
import cv2
import mujoco
import numpy as np


def encode(value):
    if hasattr(value,'tolist'):return value.tolist()
    if hasattr(value,'item'):return value.item()
    raise TypeError(type(value).__name__)


class DevelopmentRecorder:
    def __init__(self,root,*,video=False,quality=False,stride=10):
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=False)
        self.video=video;self.quality=quality;self.stride=stride
        self.stream=(self.root/'frames.jsonl').open('w');self.writers={}
        self.step=0;self.previous_phase=None;self.pending=None

    def before(self,observation,phase,env):
        if self.video:
            for key,frame in observation.items():
                if not key.startswith('observation.images.'):continue
                name=key.rsplit('.',1)[-1]
                if name not in self.writers:
                    writer=cv2.VideoWriter(str(self.root/(name+'.mp4')),cv2.VideoWriter_fourcc(*'mp4v'),20,(frame.shape[1],frame.shape[0]))
                    if not writer.isOpened():raise RuntimeError(f'Cannot record {name}')
                    self.writers[name]=writer
                self.writers[name].write(cv2.cvtColor(frame,cv2.COLOR_RGB2BGR))
        sample=self.step%self.stride==0 or phase!=self.previous_phase
        self.pending=None
        if sample:
            self.pending=dict(step=self.step,rgb_video_frame=self.step,time=float(observation['time']),
                phase_before=phase,public_before={k:v for k,v in observation.items() if 'images' not in k})
            if self.quality:
                ids=list(env._cookie_bodies);target=env._target_bin_body
                self.pending['quality_before']=dict(
                    cookie_positions=env.cookie_positions.copy(),cookie_quaternions=env.data.xquat[ids].copy(),
                    target_position=env.data.xpos[target].copy(),target_quaternion=env.data.xquat[target].copy(),
                    eef_positions=env.data.site_xpos[list(env._eef_sites)].copy(),
                    eef_rotations=env.data.site_xmat[list(env._eef_sites)].copy(),
                    camera_positions=env.data.cam_xpos.copy(),camera_rotations=env.data.cam_xmat.copy(),
                    camera_fovy=env.model.cam_fovy.copy(),camera_names=[mujoco.mj_id2name(env.model,mujoco.mjtObj.mjOBJ_CAMERA,i) for i in range(env.model.ncam)])
        self.previous_phase=phase

    def add_frame(self,observation,action,info,*,raw_action=None,phase='',env=None,policy_seconds=None):
        if self.pending is not None:
            self.pending.update(phase_after_policy=phase,raw_action=raw_action,processed_action=action,
                policy_seconds=policy_seconds,official_after={k:info.get(k) for k in (
                    'cookies_in_target','cookies_in_source','cookies_in_target_mask','cookies_in_source_mask',
                    'target_column_counts','target_slot_occupancy','success','success_hold_count',
                    'required_success_hold_steps','safety_reason')})
            self.stream.write(json.dumps(self.pending,default=encode)+'\n')
        self.pending=None;self.step+=1

    def close(self):
        self.stream.close()
        for writer in self.writers.values():writer.release()
        (self.root/'recording.json').write_text(json.dumps(dict(
            control_steps=self.step,video=self.video,quality_before=self.quality,stride=self.stride,
            synchronization='RGB and quality_before are from the same pre-action state; official_after is the state after that action.',
            official_scoring_changed=False,extra_completion_conditions=False),indent=2)+'\n')


class RecordedPolicy:
    """Only this evaluator wrapper holds the real env; the runtime receives public observations."""
    def __init__(self,policy,recorder):self.policy=policy;self.recorder=recorder;self.env=None
    def __getattr__(self,name):return getattr(self.policy,name)
    def bind_env(self,env):self.env=env
    def reset(self,context):return self.policy.reset(context)
    def act(self,observation,task=''):
        self.recorder.before(observation,getattr(self.policy,'phase_name','unknown'),self.env)
        return self.policy.act(observation,task)
    def close(self):
        if hasattr(self.policy,'close'):self.policy.close()
