"""Actual post-grasp public frames verify that zero correction stays cached."""
from pathlib import Path
from types import SimpleNamespace
import sys,json,importlib.util,cv2,numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'candidate_mt_v7'));from perception import VisionEstimator as MT
spec=importlib.util.spec_from_file_location('G3',root/'candidate_mtg3_v7/perception.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
case=root/'core_mt_m1t1_500/2x10_advanced_16004_n5';P={x['step']:x for x in map(json.loads,next((case/'policy_trace').glob('*.jsonl')).open())};D={x['step']:x for x in map(json.loads,(case/'diagnostic/frames.jsonl').open())};steps=[s for s in [0,5,20,50,111,120,125,137,140,243,260,275,372,400,405] if s in P and s in D];caps={cam:cv2.VideoCapture(str(case/'diagnostic'/(cam+'.mp4'))) for cam in ['front','left_wrist','right_wrist']};images={}
for step in steps:
 for cam,cap in caps.items():cap.set(cv2.CAP_PROP_POS_FRAMES,step);ok,im=cap.read();assert ok;images[(step,cam)]=im[:,:,::-1]
for cap in caps.values():cap.release()
records={}
for name,cls in [('MT',MT),('G3',m.VisionEstimator)]:
 cv2.setRNGSeed(0);v=cls(load_config(resource_root()/'configs/cookie_2x10.yaml'));v.reset(SimpleNamespace(task='transfer 20 cookies'));rows=[]
 for step in steps:
  p=P[step];obs=dict(D[step]['public_before']);obs.update({'observation.images.'+cam:images[(step,cam)] for cam in caps})
  if step>0:
   cal=p['perception']['wrist_calibration'];v.wrist_mount=np.asarray(cal['mount_parameters']);v.wrist_calibration=cal;v.wrist_last_opening=float(obs['observation.state'][7])
  request=dict(p['request']);request['force_refit']=True;v.step=0 if step==0 else step;scene=v.estimate(obs,request);g=scene['group'];record={'step':step,'batch':request['batch_index'],'stage':request['stage'],'group':g,'source_box':scene['source_box'],'target_box':scene['target_box'],'source_disturbed':v.source_disturbed};rows.append(record)
  if name=='G3':print(step,request['stage'],'contact_history',v.source_disturbed,'seed',g['broad_seed_m'],'ref',g['broad_measurement'].get('column_reference_measurement_id'),'apply',g['broad_measurement'].get('column_reference_applies'),flush=True)
 records[name]=rows
for old,new in zip(records['MT'],records['G3']):
 assert np.allclose(old['group']['center'],new['group']['center'],atol=1e-9)
 assert np.allclose(old['group']['rotation'],new['group']['rotation'],atol=1e-9)
 assert np.allclose(old['source_box']['center'],new['source_box']['center'],atol=1e-9)
 assert np.allclose(old['target_box']['center'],new['target_box']['center'],atol=1e-9)
 assert np.linalg.norm(new['group']['broad_seed_m'])==0
assert any(r['step']>=111 and r['source_disturbed'] for r in records['G3'])
assert any(r['step']>=111 and r['group']['broad_measurement'].get('column_reference_measurement_id') is not None for r in records['G3'])
def encode(x):
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,np.generic):return x.item()
 return str(x)
(root/'candidate_mtg3_v7/column_reference_public_validation.json').write_text(json.dumps({'rows':records,'MT_post_grasp_geometry_unchanged':True,'zero_correction_reference_retained_across_batches':True,'simulation_steps':0},default=encode,indent=2));print('post-grasp cache regression passed')
