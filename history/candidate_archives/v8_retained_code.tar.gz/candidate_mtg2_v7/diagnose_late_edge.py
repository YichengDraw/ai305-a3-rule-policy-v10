from pathlib import Path
import json,cv2,numpy as np
root=Path('/nvme-ssd1/zhaoyicheng/a3_rule_policy_v8_20261102');case=root/'core_mtg2_targeted_500/2x10_advanced_16004_n5';out=root/'candidate_mtg2_v7';P=list(map(json.loads,next((case/'policy_trace').glob('*.jsonl')).open()));D={x['step']:x for x in map(json.loads,(case/'diagnostic/frames.jsonl').open())};selected=[]
for step in [0,111,120,125,130,140]:
 p=next(x for x in P if x['step']==step);g=p['perception']['group'];b=g.get('broad_measurement',{});selected.append({'step':step,'phase':p['request']['stage'],'batch':p['request']['batch_index'],'group':g,'eef':p['eef'],'local':p['perception'].get('local_align')})
rows=[];caps={n:cv2.VideoCapture(str(case/'diagnostic'/(n+'.mp4'))) for n in ['front','left_wrist','right_wrist']}
for step in [0,111,120,121,125,140]:
 strip=[]
 for name,cap in caps.items():
  cap.set(cv2.CAP_PROP_POS_FRAMES,step);ok,im=cap.read();assert ok;im=cv2.resize(im,(384,384),interpolation=cv2.INTER_NEAREST);im=cv2.copyMakeBorder(im,24,0,0,0,cv2.BORDER_CONSTANT,value=(245,245,245));cv2.putText(im,f'{step} {name}',(4,16),cv2.FONT_HERSHEY_SIMPLEX,.45,(20,20,20),1);strip.append(im)
 rows.append(np.concatenate(strip,axis=1))
for cap in caps.values():cap.release()
cv2.imwrite(str(out/'late_edge_source_views.png'),np.concatenate(rows,axis=0));(out/'late_edge_source_packets.json').write_text(json.dumps(selected,indent=2));print('late edge evidence saved')
