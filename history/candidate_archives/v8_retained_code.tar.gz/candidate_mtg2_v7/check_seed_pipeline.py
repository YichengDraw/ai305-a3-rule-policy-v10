"""Same recorded public input through MT and MT+G2 perception; no rollout."""
from pathlib import Path
from types import SimpleNamespace
import sys,json,importlib.util,cv2,numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'candidate_mt_v7'));from perception import VisionEstimator as MT
spec=importlib.util.spec_from_file_location('G2',root/'candidate_mtg2_v7/perception.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
result=[]
for name,steps,legacy in [('replay_medium16006_v7',[0,5,10,15,20,24],True),('core_mt_m1t1_500/2x10_advanced_16004_n5',[0,5,10,15,20],False)]:
 folder=root/name;P=list(map(json.loads,next((folder/'policy_trace').glob('*.jsonl')).open()));D={x['step']:x for x in map(json.loads,(folder/'diagnostic'/('trace.jsonl' if legacy else 'frames.jsonl')).open())};caps={n:cv2.VideoCapture(str(folder/'diagnostic'/(n+'.mp4'))) for n in ['front','left_wrist','right_wrist']};images={}
 for step in steps:
  for cam,cap in caps.items():cap.set(cv2.CAP_PROP_POS_FRAMES,step);ok,im=cap.read();assert ok;images[(step,cam)]=im[:,:,::-1]
 for cap in caps.values():cap.release()
 perversion={}
 for label,cls in [('MT',MT),('G2',m.VisionEstimator)]:
  cv2.setRNGSeed(0);v=cls(load_config(resource_root()/'configs/cookie_2x10.yaml'));v.reset(SimpleNamespace(task='transfer 20 cookies'));rows=[]
  for step in steps:
   row=min(P,key=lambda r:abs(r['step']-step));obs=dict(D[step]['observation_before'] if legacy else D[step]['public_before']);obs.update({'observation.images.'+cam:images[(step,cam)] for cam in caps});request=dict(row['request']);request['force_refit']=True;v.step=0 if step==0 else step;estimate=v.estimate(obs,request);g=estimate['group'];start=request['source_start_index'];count=request['count'];before=D[max(0,step-1)]['after'] if legacy else D[step]['quality_before'];truth=np.asarray(before['cookie_positions'])[start:start+count].mean(0)
   record={'case':name,'version':label,'frame':step,'group':g,'source_box':estimate['source_box'],'target_box':estimate['target_box'],'error_mm':((np.asarray(g['center'])-truth)*1000).tolist(),'geometry_version':g.get('geometry_version'),'local_align':estimate['local_align']};rows.append(record);result.append(record)
   print(name,label,step,np.round(record['error_mm'],2).tolist(),'seed',g.get('broad_seed_m'),'tilt',g['tilt_deg'],flush=True)
  perversion[label]=rows
 for before,after in zip(perversion['MT'],perversion['G2']):
  assert np.allclose(before['source_box']['center'],after['source_box']['center'])
  assert np.allclose(before['target_box']['center'],after['target_box']['center'])
  if 'advanced' in name:
   assert np.allclose(before['group']['center'],after['group']['center'],atol=1e-9)
   assert np.allclose(before['group']['rotation'],after['group']['rotation'],atol=1e-9)
   assert not after['geometry_version']['g2_active']
def encode(x):
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,np.generic):return x.item()
 return str(x)
(root/'candidate_mtg2_v7/source_seed_pipeline_validation.json').write_text(json.dumps({'rows':result,'target_and_source_boxes_unchanged':True,'normal_advanced_geometry_unchanged':True,'simulation_steps':0},default=encode,indent=2));print('seed pipeline and MT preservation checks passed')
