"""Offline current RGB broad-edge evidence on old failures and MT successes."""
from pathlib import Path
import sys,json,cv2,importlib.util,numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'parents/v7'));spec=importlib.util.spec_from_file_location('G2',root/'candidate_mtg2_v7/perception.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
records=[]
cases=[('replay_medium16006_v7',[0,24],True),('replay_basic16003_v7',[5,20],True),('core_mt_m1t1_500/2x10_advanced_16004_n5',[0,20,137,140,275,405],False)]
for name,steps,legacy in cases:
 folder=root/name;P=list(map(json.loads,next((folder/'policy_trace').glob('*.jsonl')).open()));D={x['step']:x for x in map(json.loads,(folder/'diagnostic'/('trace.jsonl' if legacy else 'frames.jsonl')).open())};cap=cv2.VideoCapture(str(folder/'diagnostic/left_wrist.mp4'))
 v=m.VisionEstimator(load_config(resource_root()/'configs/cookie_2x10.yaml'))
 for step in steps:
  row=next(x for x in P if x['step']==step);state=D[step];obs=dict(state['observation_before'] if legacy else state['public_before']);cap.set(cv2.CAP_PROP_POS_FRAMES,step);ok,im=cap.read();assert ok;obs['observation.images.left_wrist']=im[:,:,::-1]
  request=row['request'];g=row['perception']['group'];cal=row['perception']['wrist_calibration'];v.wrist_mount=np.asarray(cal.get('mount_parameters',np.zeros(7)));v.wrist_calibration=dict(cal);v.step=step+1;v.selected_group_key=(request['batch_index'],request['source_column'],request['source_start_index'],request['count']);v.calibration_generation=int(row['perception']['target_box'].get('calibration_generation',1));cams=v._robot_cameras(obs);cams['left_wrist']=v._v6_wrist_camera(cams['left_wrist'],obs);b=v._v8_broad_edge(obs,cams,g,request)
  quality=(D[max(0,step-1)]['after'] if legacy else state['quality_before']);start=request['source_start_index'];count=request['count'];truth=np.asarray(quality['cookie_positions'])[start:start+count].mean(0);original=np.asarray(g['center']);new=np.asarray(b['center_world']) if b.get('significant_prior_disagreement') else original
  record={'case':name,'frame':step,'broad':b,'prior_error_mm':((original-truth)*1000).tolist(),'applied_error_mm':((new-truth)*1000).tolist()};records.append(record)
  print(name,step,'obs',b['observable'],'conf',round(b['confidence'],3),'shift',None if b['shift_from_prior_m'] is None else round(b['shift_from_prior_m']*1000,2),'sigma',None if b['uncertainty_m'] is None else round(b['uncertainty_m']*1000,2),'active',b.get('significant_prior_disagreement'),'xerr',round(record['prior_error_mm'][0],2),'->',round(record['applied_error_mm'][0],2),flush=True)
 cap.release()
def encode(x):
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,np.generic):return x.item()
 return str(x)
(root/'candidate_mtg2_v7/broad_edge_public_validation.json').write_text(json.dumps(records,default=encode,indent=2))
