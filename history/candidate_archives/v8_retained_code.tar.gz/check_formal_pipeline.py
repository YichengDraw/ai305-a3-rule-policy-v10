"""Exercise stage ordering/failure waits with inert functions, not real launchers."""
from pathlib import Path
import json,tempfile,threading
from formal_pipeline import Pipeline,parser


class FakePipeline(Pipeline):
    def __init__(self,args,scenario):
        super().__init__(args);self.scenario=scenario;self.history=[]
        self.supp_started=threading.Event();self.natural_failed=threading.Event()
        self.strat_started={k:threading.Event() for k in ['c0','v8']}
    def run_stage(self,name,on_spawn=None):
        self.history.append('start:'+name)
        self.record(name,status='running',command=self.plan[name],simulation=False)
        if on_spawn is not None:on_spawn()
        code=0
        if name=='natural_initial':
            if self.scenario=='protocol_missing':code=2
            else:
                natural=self.root/'natural';natural.mkdir();(natural/'protocol.json').write_text(json.dumps({'scope':'inert-test','mean_final_count':0.})+'\n')
                assert self.supp_started.wait(5),'Supplement did not start from protocol event'
                if self.scenario=='natural_failed':
                    code=2;self.natural_failed.set()
        elif name=='supplement_initial':
            assert (self.root/'natural/protocol.json').exists()
            self.supp_started.set()
            if self.scenario=='natural_failed':assert self.natural_failed.wait(5)
            if self.scenario=='supplement_failed':code=3
        elif name=='collect_natural_initial':
            (self.root/'audits/natural_initial_raw.json').write_text(json.dumps({'mean_final_count':0.})+'\n')
        elif name=='audit_natural_initial':
            (self.root/'audits/natural_initial_verification.json').write_text(json.dumps({'verified':True,'mean_final_count':0.})+'\n')
        elif name=='natural_extend':
            assert (self.root/'audits/natural_initial_verification.json').exists()
            for event in self.strat_started.values():assert event.wait(5)
        elif name.startswith('stratified_'):
            assert 'start:natural_extend' in self.history
            self.strat_started[name.split('_')[-1]].set()
        elif name=='supplement_extend':
            assert 'finish:supplement_initial' in self.history and 'start:natural_extend' in self.history
        result={'status':'failed' if code else 'completed','returncode':code}
        if code:result['error']='intentional inert-stage failure'
        self.record(name,**result);self.history.append('finish:'+name)
        return result


def main():
    results=[]
    with tempfile.TemporaryDirectory(prefix='a3_pipeline_inert_check_') as tmp:
        for scenario in ['success','natural_failed','supplement_failed','protocol_missing']:
            args=parser().parse_args(['--candidate-code',str(Path(tmp)/'unlaunched_candidate'),
                '--c0-code',str(Path(tmp)/'unlaunched_c0'),'--output',str(Path(tmp)/scenario)])
            run=FakePipeline(args,scenario);code=run.run();stages=run.manifest['stages']
            if scenario=='success':
                assert code==0 and stages['natural_extend']['status']=='completed'
                assert run.history.index('start:supplement_initial')<run.history.index('finish:natural_initial')
                assert run.history.index('finish:audit_natural_initial')<run.history.index('start:natural_extend')
                assert all(stages[n]['status']=='completed' for n in ['supplement_extend','stratified_c0','stratified_v8'])
                assert json.loads((run.root/'audits/natural_initial_verification.json').read_text())['mean_final_count']==0.
            elif scenario=='natural_failed':
                assert code==1 and stages['supplement_initial']['status']=='completed'
                assert run.history.index('finish:natural_initial')<run.history.index('finish:supplement_initial')
                assert stages['natural_extend']['status']==stages['stratified_c0']['status']=='skipped'
            elif scenario=='supplement_failed':
                assert code==1 and all(stages[n]['status']=='completed' for n in ['natural_extend','stratified_c0','stratified_v8'])
                assert stages['supplement_extend']['status']=='skipped'
            else:
                assert code==1 and stages['supplement_initial']['status']=='skipped'
            assert run.manifest['all_started_processes_waited'] and (run.root/'complete.json').exists()
            assert len(run.final_commands)==6
            assert run.plan['natural_initial'][-2:]==['--workers','48']
            assert run.plan['natural_extend'][-2:]==['--workers','40']
            results.append({'scenario':scenario,'pipeline_returncode':code,'result':run.manifest['status'],
                            'started_stages':[x[6:] for x in run.history if x.startswith('start:')]})
    result={'status':'passed','scope':'inert stage orchestration only; no subprocess, policy, environment, rendering or simulation launched',
        'scenarios':results,'initial_audit_precedes_same_code_extension':True,'valid_zero_initial_score_still_extends':True,
        'supplement_starts_only_after_valid_protocol_exists':True,'started_independent_jobs_waited_after_failure':True,
        'final_audits_left_as_six_explicit_commands':True,'real_launcher_invocations':0}
    path=Path(__file__).with_name('formal_pipeline_checks.json');path.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
