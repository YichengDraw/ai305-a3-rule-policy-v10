"""Optional500-step supplement; reuse natural2x5 rows, separately run2x10."""
from __future__ import annotations
import argparse
import ctypes
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from launch_core_cases import runtime_files


def wait_for_natural_2x5(root,phases):
    """Wait on actual completed-shard events, so supplement can run in parallel."""
    required={phase:(17000,5) if phase=='initial' else(17005,15) for phase in phases}
    def ready():
        for phase,(seed,n) in required.items():
            expected={(p,s) for p in ('basic','medium','advanced') for s in range(seed,seed+n)}
            for label in ('c0','v8'):
                path=root/phase/label/'launch_status.json'
                if not path.exists():return False
                try:value=json.loads(path.read_text())
                except ValueError:return False
                jobs=[j for j in value['completed'] if j['task']=='2x5']
                if any(j['returncode'] for j in jobs):raise RuntimeError('Natural2x5 shard error')
                if {(j['profile'],j['seed']) for j in jobs}!=expected:return False
        return True
    if ready():return
    lib=ctypes.CDLL('libc.so.6',use_errno=True);fd=lib.inotify_init1(0)
    if fd<0:raise OSError(ctypes.get_errno(),'inotify_init1')
    watched=set()
    try:
        while True:
            directories=[root]+[root/p for p in phases]+[root/p/label for p in phases for label in ('c0','v8')]
            for path in directories:
                if path.exists() and path not in watched:
                    wd=lib.inotify_add_watch(fd,os.fsencode(path),0x8|0x80|0x100)
                    if wd<0:raise OSError(ctypes.get_errno(),str(path))
                    watched.add(path)
            if ready():return
            os.read(fd,65536)
    finally:os.close(fd)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--natural-root',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--phase',choices=('initial','extend'),required=True)
    p.add_argument('--workers',type=int,default=12)
    p.add_argument('--egl-devices',type=int,nargs='+',default=[5])
    a=p.parse_args();natural=a.natural_root.resolve();root=a.output.resolve();scripts=Path(__file__).resolve().parent
    reg=json.loads((natural/'protocol.json').read_text());versions=reg['versions']
    helpers={name:hashlib.sha256((scripts/name).read_bytes()).hexdigest() for name in reg['evaluator_sha256']}
    assert helpers==reg['evaluator_sha256'],'Frozen natural evaluator changed'
    for job in versions:
        code=Path(job['code']);assert job['runtime_sha256']=={n:hashlib.sha256((code/n).read_bytes()).hexdigest() for n in runtime_files(code)}
    if a.phase=='initial':
        root.mkdir(parents=True,exist_ok=False)
        (root/'protocol.json').write_text(json.dumps(dict(scope='supplementary_500_not_official_default',
            natural_root=str(natural),versions=versions,evaluator_sha256=helpers,reused_2x5=True,steps={'2x5':500,'2x10':500}),indent=2)+'\n')
    else:
        saved=json.loads((root/'protocol.json').read_text());assert saved['versions']==versions and saved['natural_root']==str(natural)
        assert json.loads((root/'initial/complete.json').read_text())['status']=='completed'
    stage=root/a.phase;stage.mkdir(exist_ok=False);start=time.monotonic()
    seed,episodes=(17000,5) if a.phase=='initial' else(17005,15)
    def run(job):
        command=[sys.executable,str(scripts/'launch_evaluation.py'),'--output',str(stage/job['name']),
            '--policy-code',job['code'],'--policy',job['policy'],'--tasks','2x10','--episodes',str(episodes),
            '--seed-start',str(seed),'--shard-size','1','--max-steps-2x10','500','--no-audit-ground-truth',
            '--workers',str(max(1,a.workers//2)),'--egl-devices',*[str(g) for g in a.egl_devices]]
        with (stage/(job['name']+'.log')).open('w') as log:
            result=subprocess.run(command,cwd=scripts,stdout=log,stderr=subprocess.STDOUT)
        return dict(name=job['name'],returncode=result.returncode,command=command)
    with ThreadPoolExecutor(max_workers=2) as pool:done=list(pool.map(run,versions))
    (stage/'status.json').write_text(json.dumps(dict(results=done),indent=2)+'\n')
    if any(j['returncode'] for j in done):raise SystemExit('Supplementary shard error')
    phases=('initial',) if a.phase=='initial' else('initial','extend')
    count=5 if a.phase=='initial' else 20
    wait_for_natural_2x5(natural,phases)
    finals={}
    for job in versions:
        label=job['name']
        inputs=[p.parent for phase in phases for p in sorted((natural/phase/label/'default').glob('2x5_*/episodes.jsonl'))]
        inputs += [p.parent for phase in phases for p in sorted((root/phase/label/'default').glob('2x10_*/episodes.jsonl'))]
        assert len(inputs)==6*count
        final=stage/label/'supplementary_500' if a.phase=='initial' else root/label/'supplementary_500'
        finals[label]=final
        subprocess.run([sys.executable,str(scripts/'merge_results.py'),'--inputs',*[str(x) for x in inputs],
            '--output',str(final),'--seed-start','17000','--episodes',str(count),'--max-steps-2x10','500'],check=True,cwd=scripts)
    comparison=stage/'comparison' if a.phase=='initial' else root/'comparison'
    subprocess.run([sys.executable,str(scripts/'paired_comparison.py'),'--old',str(finals['c0']),'--new',str(finals['v8']),
        '--old-label','C0','--new-label','V8','--seed-start','17000','--episodes',str(count),
        '--max-steps-2x10','500','--protocol-label','500步运动预算补充（非默认主表）','--output',str(comparison)],check=True,cwd=scripts)
    complete=dict(status='completed',scope='supplementary_500_only',additional_episodes=30 if a.phase=='initial' else 90,
        table_episodes_per_policy=6*count,reused_natural_2x5_per_policy=3*count,wall_seconds=time.monotonic()-start)
    (stage/'complete.json').write_text(json.dumps(complete,indent=2)+'\n')
    if a.phase=='extend':(root/'complete.json').write_text(json.dumps(dict(complete,additional_episodes=120),indent=2)+'\n')

if __name__=='__main__':main()
