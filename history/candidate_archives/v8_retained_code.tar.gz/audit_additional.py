"""Independent count/success audit of separate 18000 diagnostics or 500 supplements."""
from __future__ import annotations
import argparse
from collections import defaultdict
import json
from pathlib import Path
from audit_natural import metrics, PROFILES, TERMINAL


def validate_case(case, version, reg, scope):
    assert case['summary_status'] == 'completed' and len(case['episodes']) == 1
    row = case['episodes'][0]; q = case['protocol']
    task, profile, seed = row['task'], row['profile'], row['seed']
    budget = 3200 if scope == 'stratified' else 500
    assert row['max_steps'] == budget and 0 < row['steps'] <= budget
    assert row['max_score'] == (10 if task == '2x5' else 20)
    assert row['score'] == row['cookies_in_target'] and row['score'] >= 0
    assert isinstance(row['success'], bool)
    assert q['policy'] == version['policy'] and q['seed_start'] == seed and q['episodes_per_cell'] == 1
    assert q['tasks'] == [task] and q['profiles'] == [profile]
    assert q['max_steps_by_task']['2x5'] == 500 and q['max_steps_by_task']['2x10'] == (3200 if scope == 'stratified' or task == '2x5' else 500)
    assert q['source_column'] == '1' and row['source_column'] == 1
    assert q['success_hold_steps'] == row['success_hold_steps'] == 5
    assert q['strict_policy_completion'] is row['strict_policy_completion'] is False
    assert q['render_cameras'] is True and q['offline_ground_truth_audit'] is False
    assert q['source_commit'] == '0729068ee1e75a562cfbc4f2c83ab9539cf75081'
    assert not row.get('oracle_source_target') and not row.get('development_scope')
    if version['name'] == 'c0':
        assert row['policy_task_parent'] == ('v7' if task == '2x5' else 'v6')
    if scope == 'stratified':
        assert task == '2x10' and q['first_grasp_2x10'] == str(seed - 18000)
        assert row['randomization']['first_grasp_count'] == seed - 18000
        assert case['origin'] == 'new_stratified_18000'
    elif task == '2x5':
        assert case['origin'] == 'reused_natural_2x5'
    else:
        assert q['first_grasp_2x10'] == 'random' and case['origin'] == 'new_supplement_2x10'
    fingerprints = q['code_sha256']; runtime = version['runtime_sha256']
    assert fingerprints['policy_module'] == runtime['policy.py']
    for name, digest in runtime.items():
        if '/' in name:
            assert fingerprints['runtime/' + name] == digest
        elif name != 'policy.py':
            assert fingerprints.get(name, fingerprints.get('runtime/' + name)) == digest
    for name, digest in fingerprints.items():
        if name.startswith('runtime/'):
            assert runtime[name[len('runtime/'):]] == digest
    for name in ('evaluate_policy.py', 'batch_metrics.py', 'diagnostic_support.py'):
        assert fingerprints['evaluation_script' if name == 'evaluate_policy.py' else name] == reg['evaluator_sha256'][name]
    return (task, profile, seed), row, q


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output-stem', type=Path, required=True)
    a = p.parse_args(); data = json.loads(a.input.read_text()); scope = data['scope']; reg = data['registration']
    assert scope in ('stratified', 'supplement') and reg['scope'] == 'v8_frozen_natural_paired'
    assert reg['seeds'] == [17000, 17019] and reg['max_steps_by_task'] == {'2x5': 500, '2x10': 3200}
    n = 10 if scope == 'stratified' else 20 if data['phase'] == 'full' else 5
    tasks = ('2x10',) if scope == 'stratified' else ('2x5', '2x10')
    first = 18000 if scope == 'stratified' else 17000
    expected = {(t, p, s) for t in tasks for p in PROFILES for s in range(first, first + n)}
    if scope == 'supplement':
        assert data['protocol']['scope'] == 'supplementary_500_not_official_default'
        assert data['protocol']['reused_2x5'] is True and data['protocol']['steps'] == {'2x5': 500, '2x10': 500}
        assert data['protocol']['versions'] == reg['versions']
        for phase, state in data['stages'].items():
            assert state['complete']['status'] == 'completed'
            assert len(state['status']['results']) == 2 and all(j['returncode'] == 0 for j in state['status']['results'])
        if data['phase'] == 'full':
            assert data['complete']['status'] == 'completed'
    indexed = {}; protocols = {}; results = {}
    for version in reg['versions']:
        label = version['name']; d = data['policies'][label]
        assert d['runtime_sha256'] == version['runtime_sha256'] and len(d['cases']) == len(expected)
        if scope == 'stratified':
            q = d['protocol']; done = d['complete']
            assert q['scope'] == 'stratified_n_diagnostic_not_natural' and q['merge_with_natural'] is False
            assert q['runtime_sha256'] == version['runtime_sha256'] and q['policy'] == version['policy']
            assert q['max_steps'] == 3200 and q['source_column'] == 1 and q['success_hold_steps'] == 5 and q['strict_policy_completion'] is False
            assert done['status'] == 'completed' and done['episodes'] == 30 and len(done['jobs']) == 30
            assert all(j['returncode'] == 0 for j in done['jobs'])
            assert {(j['task'], j['profile'], j['seed'], j['n']) for j in done['jobs']} == {(*k, k[2] - 18000) for k in expected}
        else:
            for name, state in d['launches'].items():
                phase, task = name.split('/'); lo, count = (17000, 5) if phase == 'initial' else (17005, 15)
                jobs = [j for j in state['status']['completed'] if j['task'] == task]
                assert len(jobs) == 3 * count and all(j['returncode'] == 0 for j in jobs)
                assert {(j['profile'], j['seed']) for j in jobs} == {(p, s) for p in PROFILES for s in range(lo, lo + count)}
                assert state['launch']['policy'] == version['policy'] and state['launch']['offline_ground_truth_audit'] is False
        rows = {}; qs = {}
        for case in d['cases']:
            key, row, q = validate_case(case, version, reg, scope)
            assert key in expected and key not in rows
            if scope == 'supplement':
                assert case['phase'] == ('initial' if key[2] < 17005 else 'extend')
                base = Path(data['protocol']['natural_root'] if key[0] == '2x5' else data['source_directory'])
                expected_source = base / case['phase'] / label / 'default' / f'{key[0]}_{key[1]}_{key[2]}'
                assert Path(case['source_directory']) == expected_source
            rows[key] = row; qs[key] = q
        assert set(rows) == expected
        if scope == 'supplement':
            merged = {(r['task'], r['profile'], r['seed']): r for r in d['merged_episodes']}
            assert len(merged) == len(d['merged_episodes']) == len(expected) and merged == rows
            summary = d['merged_summary']; m = metrics(list(rows.values()))
            assert summary['status'] == 'completed' and summary['overall']['total_score'] == m['final_count_sum']
            assert summary['overall']['successes'] == m['successes']
            assert abs(summary['overall']['mean_final_count'] - m['mean_final_count']) < 1e-12
        grouped = defaultdict(list)
        for r in rows.values():
            if r['task'] == '2x10':
                grouped[(r['task'], r['profile'], r['randomization']['first_grasp_count'])].append(r)
        results[label] = dict(overall=metrics(list(rows.values())),
            cells=[dict(task=t, profile=p, **metrics([r for k, r in rows.items() if k[:2] == (t, p)])) for t in tasks for p in PROFILES],
            by_n=[dict(task=t, profile=p, n=k, **metrics(values)) for (t, p, k), values in sorted(grouped.items())],
            episodes=[dict(task=r['task'], profile=r['profile'], seed=r['seed'], n=r['randomization'].get('first_grasp_count'),
                official_final_count=r['cookies_in_target'], official_success=r['success'], steps=r['steps']) for _, r in sorted(rows.items())])
        indexed[label] = rows; protocols[label] = qs
    assert set(indexed) == {'c0', 'v8'}
    for key in expected:
        x, y = indexed['c0'][key], indexed['v8'][key]
        scene = lambda r: {k: v for k, v in r['randomization'].items() if k not in TERMINAL}
        assert scene(x) == scene(y) and x['task_instruction'] == y['task_instruction']
        for field in ('source_commit', 'prompt_styles', 'first_grasp_2x10', 'randomization_settings'):
            assert protocols['c0'][key][field] == protocols['v8'][key][field]
    old, new = results['c0']['overall'], results['v8']['overall']
    out = dict(scope='stratified_18000_separate' if scope == 'stratified' else 'supplementary_uniform500_separate',
        phase=data.get('phase'), results=results, raw_evidence=str(a.input.resolve()),
        mean_count_delta=new['mean_final_count'] - old['mean_final_count'],
        normalized_delta_pp=100 * (new['normalized_completion'] - old['normalized_completion']),
        success_delta_pp=100 * (new['official_success_rate'] - old['official_success_rate']),
        validation=dict(episodes_per_policy=len(expected), unique=True, all_returncodes_zero=True,
            official_fields_unchanged=True, nested_runtime_sha_match=True, paired_initial_scenes_match=True,
            stratified_never_pooled_with_natural=scope == 'stratified',
            natural_2x5_rows_reused_exactly=scope == 'supplement'))
    a.output_stem.with_suffix('.json').write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
    title = '18000按n分层诊断（独立表）' if scope == 'stratified' else '统一500步运动预算补充表'
    lines = ['# ' + title, '', f'每版{len(expected)}回合，数量和成功直接读取官方终态记录。', '',
        '| 策略 | 任务 | 扰动档 | 回合数 | 平均终态数量 | 归一化完成率 | 官方成功 |',
        '|---|---|---|---:|---:|---:|---:|']
    for label in ('c0', 'v8'):
        overall = results[label]['overall']
        lines.append(f"| {label.upper()} | 全部 | 汇总 | {overall['episodes']} | {overall['mean_final_count']:.4f} | {overall['normalized_completion']:.2%} | {overall['successes']}/{overall['episodes']} |")
        for m in results[label]['cells']:
            lines.append(f"| {label.upper()} | {m['task']} | {m['profile']} | {m['episodes']} | {m['mean_final_count']:.4f} | {m['normalized_completion']:.2%} | {m['successes']}/{m['episodes']} |")
    lines += ['', '| 策略 | 任务 | 扰动档 | n | 回合数 | 平均终态数量 | 官方成功 |', '|---|---|---|---:|---:|---:|---:|']
    for label in ('c0', 'v8'):
        for m in results[label]['by_n']:
            lines.append(f"| {label.upper()} | {m['task']} | {m['profile']} | {m['n']} | {m['episodes']} | {m['mean_final_count']:.4f} | {m['successes']}/{m['episodes']} |")
    lines += ['', '18000诊断按各n固定取样，单列解释。' if scope == 'stratified' else '2×5逐行复用自然主表；额外仿真仅为2×10的500步回合。']
    a.output_stem.with_suffix('.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps({k: out[k] for k in ('scope', 'mean_count_delta', 'normalized_delta_pp', 'success_delta_pp')}))


if __name__ == '__main__':
    main()
