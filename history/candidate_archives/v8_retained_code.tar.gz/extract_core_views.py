"""Export a few recorded development RGB frames for visual inspection."""
import argparse
import json
from pathlib import Path
import cv2
import numpy as np

p = argparse.ArgumentParser()
p.add_argument('case', type=Path)
p.add_argument('--steps', nargs='+', type=int)
a = p.parse_args()
rows = [json.loads(s) for f in (a.case/'policy_trace').glob('*.jsonl') for s in f.read_text().splitlines()]
if a.steps:
    chosen = [min(rows, key=lambda r: abs(r['step']-s)) for s in a.steps]
else:
    chosen=[]
    seen=set()
    for r in rows:
        key=(r['request'].get('batch_index'), r['phase'])
        if r['phase'] in ('XY_COARSE','ALIGN_OBSERVE','TRANSPORT','PLACE','RETRACT') and key not in seen:
            chosen.append(r);seen.add(key)
    if len(chosen)>9:
        chosen=[chosen[i] for i in np.linspace(0,len(chosen)-1,9).astype(int)]
images=[]
for row in chosen:
    strip=[]
    for cam in ('front','left_wrist','right_wrist'):
        cap=cv2.VideoCapture(str(a.case/'diagnostic'/(cam+'.mp4')))
        cap.set(cv2.CAP_PROP_POS_FRAMES, row['step']); ok, im=cap.read(); cap.release()
        if not ok: continue
        im=cv2.resize(im,(384,288))
        im=cv2.copyMakeBorder(im,28,0,0,0,cv2.BORDER_CONSTANT,value=(245,245,245))
        title=f"{row['step']} b{row['request'].get('batch_index')} {row['phase']} {cam}"
        cv2.putText(im,title,(5,18),cv2.FONT_HERSHEY_SIMPLEX,.40,(20,20,20),1,cv2.LINE_AA)
        strip.append(im)
    if len(strip)==3:images.append(np.concatenate(strip,axis=1))
if not images:raise SystemExit('No recorded frames available')
out=a.case/'inspection.png';cv2.imwrite(str(out),np.concatenate(images,axis=0))
print(out)
