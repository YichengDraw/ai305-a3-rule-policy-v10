"""Archive completed stratified or supplementary records without simulation."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


def read(path):
    return json.loads(path.read_text())


def cases(source, phase, origin, task):
    result = []
    paths = [source / 'episodes.jsonl'] if (source / 'episodes.jsonl').exists() else sorted((source / 'default').glob(f'{task}_*/episodes.jsonl'))
    for path in paths:
        result.append(dict(phase=phase, origin=origin, source_directory=str(path.parent),
            original_rows_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
            protocol=read(path.parent / 'protocol.json'),
            summary_status=read(path.parent / 'summary.json')['status'],
            episodes=[json.loads(line) for line in path.read_text().splitlines() if line.strip()]))
    return result


def runtime(version):
    code = Path(version['code'])
    return {name: hashlib.sha256((code / name).read_bytes()).hexdigest()
        for name in version['runtime_sha256']}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--scope', choices=('stratified', 'supplement'), required=True)
    p.add_argument('--root', type=Path)
    p.add_argument('--c0-root', type=Path)
    p.add_argument('--candidate-root', type=Path)
    p.add_argument('--phase', choices=('initial', 'full'), default='initial')
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    payload = dict(scope=a.scope, collected_utc=datetime.now(timezone.utc).isoformat(), policies={})
    if a.scope == 'stratified':
        if not a.c0_root or not a.candidate_root:
            p.error('stratified requires --c0-root and --candidate-root')
        for label, given in (('c0', a.c0_root), ('v8', a.candidate_root)):
            root = given.resolve(); protocol = read(root / 'protocol.json')
            reg = protocol.get('natural_registration') or read(Path(protocol['natural_protocol']))
            if 'registration' in payload:
                assert payload['registration'] == reg
            payload['registration'] = reg
            version = next(v for v in reg['versions'] if v['name'] == label)
            shards = []
            for job in protocol['jobs']:
                folder = root / f"2x10_{job['profile']}_{job['seed']}_n{job['n']}"
                shards += cases(folder, 'stratified', 'new_stratified_18000', '2x10')
            payload['policies'][label] = dict(protocol=protocol, complete=read(root / 'complete.json'),
                runtime_sha256=runtime(version), cases=shards)
    else:
        if not a.root:
            p.error('supplement requires --root')
        root = a.root.resolve(); protocol = read(root / 'protocol.json')
        natural = Path(protocol['natural_root']); reg = read(natural / 'protocol.json')
        phases = ('initial',) if a.phase == 'initial' else ('initial', 'extend')
        payload.update(phase=a.phase, source_directory=str(root), protocol=protocol, registration=reg,
            stages={phase: dict(status=read(root / phase / 'status.json'),
                complete=read(root / phase / 'complete.json')) for phase in phases})
        if a.phase == 'full':
            payload['complete'] = read(root / 'complete.json')
        for version in reg['versions']:
            label = version['name']; shards = []; launches = {}
            for phase in phases:
                for base, origin, task in ((natural, 'reused_natural_2x5', '2x5'),
                        (root, 'new_supplement_2x10', '2x10')):
                    source = base / phase / label
                    launches[f'{phase}/{task}'] = dict(launch=read(source / 'launch_protocol.json'),
                        status=read(source / 'launch_status.json'))
                    shards += cases(source, phase, origin, task)
            final = root / 'initial' / label / 'supplementary_500' if a.phase == 'initial' else root / label / 'supplementary_500'
            payload['policies'][label] = dict(runtime_sha256=runtime(version), launches=launches,
                cases=shards, merged_episodes=[json.loads(line) for line in (final / 'episodes.jsonl').read_text().splitlines() if line.strip()],
                merged_summary=read(final / 'summary.json'))
    a.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(dict(scope=a.scope, raw_shards=sum(len(v['cases']) for v in payload['policies'].values()))))


if __name__ == '__main__':
    main()
