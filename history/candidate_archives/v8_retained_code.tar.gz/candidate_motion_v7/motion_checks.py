"""Public-state and path checks for M1; no environment stepping or rendering."""
import ast
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import mujoco
import numpy as np
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from rule_controller import RuleController, CANONICAL, opening_from_gap


def setup(cls):
    config=load_config(resource_root()/'configs/cookie_2x10.yaml')
    c=cls(config);c.reset(SimpleNamespace(task='transfer 20 cookies into target box; grasp 4 cookies first'))
    c.set_variant('b')
    q=np.empty(4);mujoco.mju_mat2Quat(q,CANONICAL.ravel())
    state=np.zeros(16);state[7]=state[15]=1.
    obs={'observation.eef_pose':np.r_[.1,.25,.82,q,.1,-.25,.92,q],
         'observation.state':state,'observation.velocity':np.zeros(16),'observation.force':np.zeros(18),'time':0.}
    positions=np.asarray(config.cookie_transfer.cookie_source_positions_m)
    center=np.r_[positions[:4].mean(0),config.cookie_transfer.cookie_model_z_m]
    scene={'group':{'indices':list(range(4)),'center':center,'rotation':np.eye(3),'confidence':.8,
                    'width_m':3*.008833333333333+2*c.half_size[1],'tilt_deg':0.,'position_error_m':.001},
           'target_box':{'center':config.cookie_transfer.target_bin_world_position_m,'yaw':0.,'confidence':.8},
           'held':{},'placement':{'state':'unknown','confidence':0.}}
    c._obs,c._scene=obs,scene;assert c._select(scene)
    return c,obs,scene


def run(parent_dir):
    parent_dir=Path(parent_dir)
    spec=importlib.util.spec_from_file_location('parent_controller',parent_dir/'rule_controller.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);Old=module.RuleController
    checks=[]
    for name in ['policy.py','perception.py','placement_audit.py']:
        assert (Path(__file__).parent/name).read_bytes()==(parent_dir/name).read_bytes()
    checks.append('all three non-motion runtime modules are identical to V7')

    old,oldobs,oldscene=setup(Old);new,obs,scene=setup(RuleController)
    for c,o,s in [(old,oldobs,oldscene),(new,obs,scene)]:
        o['observation.eef_pose'][:3]=c._trial+[0,0,-.0005]
        o['observation.velocity'][:7]=.3
        o['observation.force'][12:14]=1.3
        o['observation.state'][7]=opening_from_gap(c.count*2*c.half_size[1])
        c._grasp_reference_eef=o['observation.eef_pose'][:7].copy();c._grasp_reference_eef[2]-=.012
        s['held']={'count':c.count,'count_confidence':.8}
        c._advance('TRIAL_LIFT')
    before=old.act(oldobs,oldscene);after=new.act(obs,scene)
    assert old.stage=='TRIAL_LIFT' and new.stage=='LIFT' and after[2]>before[2]+.05
    checks.append('trial height is checked while the existing lift command continues upward with nonzero velocity')

    c,obs,scene=setup(RuleController)
    obs['observation.eef_pose'][:3]=c._high;obs['observation.velocity'][:7]=.3
    obs['observation.force'][12:14]=1.3
    obs['observation.state'][7]=opening_from_gap(c.count*2*c.half_size[1])
    c._grasp_reference_eef=obs['observation.eef_pose'][:7].copy();c._grasp_reference_eef[2]-=.04
    scene['held']={'count':c.count,'count_confidence':.8};c._advance('LIFT');c.act(obs,scene)
    assert c.stage=='TRANSPORT' and c._carry_source_high_pose is not None
    checks.append('a reached source clearance point is passed without an artificial zero-velocity stop')

    old,oldobs,oldscene=setup(Old);new,obs,scene=setup(RuleController)
    for c,o,s in [(old,oldobs,oldscene),(new,obs,scene)]:
        c._advance('DESCEND');c.current_report['alignment_verified']=True
        o['observation.eef_pose'][:3]=c._pick+[0,0,.016]
    assert np.array_equal(old.act(oldobs,oldscene),new.act(obs,scene)) and old.stage==new.stage
    checks.append('the contact insertion action remains identical for the same public state')

    c,obs,scene=setup(RuleController)
    c._put_position=np.array([.1,.1,.767]);c._put_rotation=CANONICAL.copy()
    c._retract=np.array([.1,.1,.808]);c._target_clear_pose=(c._retract.copy(),CANONICAL.copy())
    obs['observation.eef_pose'][:3]=c._retract
    c._release_goal=.4;obs['observation.state'][7]=.4
    scene['held']={'following':False,'released':True,'motion_confidence':.8}
    c._advance('RETRACT');c._motion_verify_samples=5;c.act(obs,scene)
    assert c.stage=='SELECT' and c.batch_index==1
    assert c.batch_reports[-1]['motion_parallel_verify_samples']==6
    checks.append('the existing six release observations overlap safe withdrawal rather than add a stationary pause')

    c,obs,scene=setup(RuleController)
    z=c._preinsert[2]+.012
    path=[(np.array([.1+x,.25,z]),CANONICAL.copy()) for x in [0.,.003,.006]]
    path.append((np.array([.106,.256,z]),CANONICAL.copy()))
    assert c._motion_recovery_target(path)==2
    low=[(p-[0,0,.025],r) for p,r in path]
    assert c._motion_recovery_target(low)==0
    checks.append('lookahead blends only reached high straight points and keeps corners and low insertion corridors')

    def blocks(path):
        tree=ast.parse(Path(path).read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef))
        act=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='act')
        result={}
        for node in act.body:
            if isinstance(node,ast.If):result[ast.unparse(node.test)]=ast.dump(node,include_attributes=False)
        return result
    a,b=blocks(parent_dir/'rule_controller.py'),blocks(Path(__file__).with_name('rule_controller.py'))
    for stage in ['DESCEND','OPEN','TRANSPORT']:
        key=next(k for k in a if (k==f"self.stage == '{stage}'" if stage!='TRANSPORT' else k=="self.stage in ('TRANSPORT', 'PLACE')"))
        if stage!='OPEN':assert a[key]==b[key]
    checks.append('DESCEND and full TRANSPORT/PLACE dispatch blocks retain exactly the V7 AST')
    return {'passed':len(checks),'checks':checks,'physical_simulation_run':False}

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--parent-dir',required=True)
    print(json.dumps(run(parser.parse_args().parent_dir),indent=2))
