"""Build a self-contained task-only router: fixed V7 2x5 plus a four-file 2x10 candidate.

Only package-local imports change inside the parent modules. This builder never
starts an environment, simulation, rendering or evaluation.
"""
from __future__ import annotations
import argparse
import ast
import copy
import hashlib
import importlib
import importlib.util
import json
from pathlib import Path
import re
import sys
from types import SimpleNamespace

RUNTIME_FILES=('policy.py','perception.py','rule_controller.py','placement_audit.py')
PROJECT=Path(__file__).resolve().parent
LOCAL_MODULES={Path(name).stem for name in RUNTIME_FILES}


def digest(data):
    return hashlib.sha256(data).hexdigest()


class CanonicalImports(ast.NodeTransformer):
    """Normalize only equivalent local imports; leave all executable logic intact."""
    def visit_Import(self,node):
        return [ast.Import(names=[copy.deepcopy(alias)]) for alias in node.names]
    def visit_ImportFrom(self,node):
        node=copy.deepcopy(node)
        if node.module in LOCAL_MODULES and node.level in (0,1):
            node.level=0
        elif node.module is None and node.level==1 and all(alias.name in LOCAL_MODULES for alias in node.names):
            return [ast.Import(names=[copy.deepcopy(alias)]) for alias in node.names]
        return node


def canonical_ast(source):
    tree=CanonicalImports().visit(ast.parse(source))
    return ast.dump(tree,include_attributes=False)


def rewrite_local_imports(source):
    data=source.encode('utf-8');lines=data.splitlines(keepends=True);offsets=[0]
    for line in lines:offsets.append(offsets[-1]+len(line))
    edits=[];records=[]
    for node in ast.walk(ast.parse(source)):
        replacement=None
        start=offsets[node.lineno-1]+node.col_offset if hasattr(node,'lineno') else 0
        end=offsets[node.end_lineno-1]+node.end_col_offset if hasattr(node,'end_lineno') else 0
        if isinstance(node,ast.ImportFrom) and node.level==0 and node.module in LOCAL_MODULES:
            segment=data[start:end]
            pattern=rb'\bfrom(\s+)'+re.escape(node.module.encode())+rb'(\s+)import'
            replacement,count=re.subn(pattern,lambda m:b'from'+m[1]+b'.'+node.module.encode()+m[2]+b'import',segment,count=1)
            if count!=1:raise ValueError(f'Cannot rewrite local import at line {node.lineno}')
            records.append({'line':node.lineno,'kind':'from','module':node.module,'change':'absolute to package-relative'})
        elif isinstance(node,ast.Import) and any(alias.name in LOCAL_MODULES for alias in node.names):
            indent=b' '*node.col_offset;pieces=[]
            for alias in node.names:
                if alias.name in LOCAL_MODULES:
                    text='from . import '+alias.name+(' as '+alias.asname if alias.asname else '')
                else:
                    text='import '+alias.name+(' as '+alias.asname if alias.asname else '')
                pieces.append(text.encode())
            replacement=(b'\n'+indent).join(pieces)
            records.append({'line':node.lineno,'kind':'import','modules':[a.name for a in node.names],
                            'change':'local aliases become package-relative imports'})
        if replacement is not None:edits.append((start,end,replacement))
    for start,end,replacement in sorted(edits,reverse=True):data=data[:start]+replacement+data[end:]
    result=data.decode('utf-8')
    assert canonical_ast(source)==canonical_ast(result), 'Non-import AST change during namespace conversion'
    return result,records


def runtime_dependencies(policy_source):
    tree=ast.parse(policy_source)
    node=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='RUNTIME_DEPENDENCIES' for t in n.targets))
    result=ast.literal_eval(node.value)
    for name in result:
        path=Path(name)
        if path.is_absolute() or '..' in path.parts or path.suffix!='.py':raise ValueError(name)
    return result


def make_router(template,namespace,dependencies,label,factory):
    source=template
    source=source.replace('C0 reference: select V7 for 10-cookie tasks and V6 for 20-cookie tasks.',
                          'Task-only router: fixed V7 for 10-cookie tasks and the selected candidate for 20-cookie tasks.')
    source=source.replace('from c0_parents.v6.policy import make_policy_b as make_v6',
                          f'from {namespace}.candidate20.policy import {factory} as make_2x10')
    source=source.replace('from c0_parents.v7.policy import make_policy_b as make_v7',
                          f'from {namespace}.v7.policy import make_policy_b as make_v7')
    source=source.replace('make_v6()', 'make_2x10()')
    source=source.replace('name="c0_task_only_v7_2x5_v6_2x10"',f'name={json.dumps("task_only_v7_2x5_"+label+"_2x10",ensure_ascii=False)}')
    source=source.replace('self.selected_parent="v6" if is20 else "v7"',
                          f'self.selected_parent={json.dumps(label,ensure_ascii=False)} if is20 else "v7"')
    tree=ast.parse(source);assign=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='RUNTIME_DEPENDENCIES' for t in n.targets))
    lines=source.splitlines(keepends=True)
    lines[assign.lineno-1:assign.end_lineno]=['RUNTIME_DEPENDENCIES = '+repr(dependencies)+'\n']
    return ''.join(lines)


def verify_router_template(source,template,namespace,label,factory):
    """Whitelist import destinations and metadata; routing/delegation stays C0."""
    actual=ast.parse(source);expected=ast.parse(template)
    def normalize(tree,generated):
        tree=copy.deepcopy(tree)
        if tree.body and isinstance(tree.body[0],ast.Expr) and isinstance(tree.body[0].value,ast.Constant):tree.body=tree.body[1:]
        class Normalize(ast.NodeTransformer):
            def visit_ImportFrom(self,node):
                if generated:
                    if node.module==namespace+'.candidate20.policy':
                        node.module='c0_parents.v6.policy';node.names=[ast.alias(name='make_policy_b',asname='make_v6')]
                    elif node.module==namespace+'.v7.policy':node.module='c0_parents.v7.policy'
                return node
            def visit_Name(self,node):
                if generated and node.id=='make_2x10':node.id='make_v6'
                return node
            def visit_Assign(self,node):
                if any(isinstance(t,ast.Name) and t.id=='RUNTIME_DEPENDENCIES' for t in node.targets):node.value=ast.List(elts=[],ctx=ast.Load())
                if any(isinstance(t,ast.Name) and t.id=='name' for t in node.targets):node.value=ast.Constant(value='task_router_metadata')
                if generated and any(isinstance(t,ast.Attribute) and t.attr=='selected_parent' for t in node.targets):
                    if isinstance(node.value,ast.IfExp) and isinstance(node.value.body,ast.Constant) and node.value.body.value==label:node.value.body=ast.Constant(value='v6')
                return self.generic_visit(node)
        return ast.dump(Normalize().visit(tree),include_attributes=False)
    assert normalize(actual,True)==normalize(expected,False), 'Router differs from C0 task-only delegation'
    return True


def verify_package(output,metadata):
    output=Path(output);deps=runtime_dependencies((output/'policy.py').read_text())
    assert digest((output/'policy.py').read_bytes())==metadata['router_sha256']
    actual=['policy.py']+sorted(p.relative_to(output).as_posix() for p in (output/metadata['namespace']).rglob('*.py'))
    assert sorted(deps)==sorted(actual) and len(deps)==12
    rows=[]
    for item in metadata['files']:
        path=output/item['packaged_path'];text=path.read_text()
        assert digest(path.read_bytes())==item['packaged_sha256']
        assert digest(canonical_ast(text).encode())==item['canonical_ast_sha256']
        rows.append({**item,'ast_equal_except_local_imports':True})
    return {'status':'passed','scope':'12-file runtime closure and parent AST equality except local imports',
            'runtime_dependencies':deps,'files':rows,'simulation_steps':0}


def check_runtime_imports(output,metadata):
    """Import real namespaced factories, then test routing with inert stubs."""
    output=Path(output);sys.path.insert(0,str(output))
    try:
        spec=importlib.util.spec_from_file_location('_built_task_router_'+metadata['namespace'],output/'policy.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        router=module.make_policy_b();ns=metadata['namespace']
        for key,branch in [('2x5','v7'),('2x10','candidate20')]:
            policy=router._parents[key]
            assert policy.__class__.__module__==ns+'.'+branch+'.policy'
            parent_module=sys.modules[policy.__class__.__module__]
            assert parent_module.RuleController.__module__==ns+'.'+branch+'.rule_controller'
            assert parent_module.VisionEstimator.__module__==ns+'.'+branch+'.perception'
            importlib.import_module(ns+'.'+branch+'.placement_audit')
        router.close()
        class Stub:
            finished=False;phase_name='stub';controller='public-controller-stub'
            def __init__(self):self.context=None;self.observation=None;self.closed=False
            def reset(self,context):self.context=context
            def act(self,observation,task=''):self.observation=observation;return [0.]*14
            def close(self):self.closed=True
        p5,p20=Stub(),Stub();router._parents={'2x5':p5,'2x10':p20};cases=[]
        contexts=[('transfer 10 cookies into target box',0,'v7',p5),
                  ('Transfer 20 cookies from source column 1; grasp 1 cookies first',999,metadata['two_x10_label'],p20),
                  ('Transfer 20 cookies from source column 4; grasp 9 cookies first',2,metadata['two_x10_label'],p20)]
        for task,seed,label,parent in contexts:
            context=SimpleNamespace(task=task,seed=seed);router.reset(context);assert router._active is parent and router.selected_parent==label and parent.context is context
            observation=object();assert len(router.act(observation,task))==14 and parent.observation is observation
            assert router.controller=='public-controller-stub' and router.phase_name=='stub' and router.finished is False
            cases.append({'task':task,'seed':seed,'selected_parent':label})
        router.close();assert p5.closed and p20.closed
        return {'real_factory_imports_isolated':True,'router_checks':cases,'reset_act_properties_close_forwarded':True,
                'environment_created':False,'simulation_steps':0}
    finally:sys.path.pop(0)


def build_task_router(two_x10,output,*,label=None,factory='make_policy_b',check_imports=False):
    two_x10=Path(two_x10).resolve();output=Path(output).resolve();v7=(PROJECT/'parents/v7').resolve()
    if not re.fullmatch(r'[A-Za-z_]\w*',factory):raise ValueError('factory must be a Python identifier')
    label=label or two_x10.name
    originals={}
    for branch,folder in [('v7',v7),('candidate20',two_x10)]:
        originals[branch]={}
        for name in RUNTIME_FILES:
            data=(folder/name).read_bytes();ast.parse(data)
            originals[branch][name]=data
    factory_defs={n.name for n in ast.parse(originals['candidate20']['policy.py']).body if isinstance(n,ast.FunctionDef)}
    if factory not in factory_defs:raise ValueError(f'{factory} is not defined by candidate policy.py')
    signature=json.dumps({branch:{name:digest(data) for name,data in files.items()} for branch,files in originals.items()},sort_keys=True).encode()+factory.encode()
    namespace='task_route_parents_'+digest(signature)[:12]
    output.mkdir(parents=True,exist_ok=False)
    (output/namespace).mkdir();(output/namespace/'__init__.py').write_text('')
    records=[]
    for branch,files in originals.items():
        folder=output/namespace/branch;folder.mkdir();(folder/'__init__.py').write_text('')
        for name,data in files.items():
            original=data.decode();rewritten,changes=rewrite_local_imports(original)
            path=folder/name;path.write_text(rewritten)
            records.append({'branch':branch,'source_path':str((v7 if branch=='v7' else two_x10)/name),
                'packaged_path':path.relative_to(output).as_posix(),'source_sha256':digest(data),
                'packaged_sha256':digest(path.read_bytes()),'canonical_ast_sha256':digest(canonical_ast(original).encode()),'import_changes':changes})
    deps=['policy.py']+sorted(p.relative_to(output).as_posix() for p in (output/namespace).rglob('*.py'))
    template=(PROJECT/'candidate_c0/policy.py').read_text()
    router=make_router(template,namespace,deps,label,factory)
    verify_router_template(router,template,namespace,label,factory)
    (output/'policy.py').write_text(router)
    metadata={'status':'prepared_task_only_router','two_x5_fixed_parent':str(v7),'two_x10_parent':str(two_x10),
              'two_x10_label':label,'two_x10_factory':factory,'namespace':namespace,'files':records,
              'router_sha256':digest(router.encode()),'selection_scope':'task type only; no seed/profile/source-column routing'}
    (output/'router_parents.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
    verification=verify_package(output,metadata);verification['router_ast_matches_c0_except_imports_and_metadata']=True
    if check_imports:verification['runtime_import_checks']=check_runtime_imports(output,metadata)
    (output/'route_build_verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n')
    return metadata,verification


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--two-x10',type=Path,required=True,help='Four-file 2x10 candidate; 2x5 remains parents/v7')
    p.add_argument('--output',type=Path,required=True,help='New candidate directory; existing outputs are preserved')
    p.add_argument('--label');p.add_argument('--two-x10-factory',default='make_policy_b')
    p.add_argument('--check-imports',action='store_true',help='Optional real module import and stub routing checks in the project environment; no simulation')
    a=p.parse_args();metadata,verification=build_task_router(a.two_x10,a.output,label=a.label,factory=a.two_x10_factory,check_imports=a.check_imports)
    print(json.dumps({'output':str(a.output.resolve()),'status':verification['status'],'runtime_files':len(verification['runtime_dependencies']),
                      'two_x5':'fixed V7','two_x10':metadata['two_x10_label'],'imports_checked':a.check_imports,'simulation_steps':0},indent=2))


if __name__=='__main__':main()
