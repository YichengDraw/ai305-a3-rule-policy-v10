"""Wait for a new completed core result using Linux inotify, then exit.

A small seen-file prevents repeated delivery. No periodic progress scan runs.
"""
from __future__ import annotations
import argparse
import ctypes
import json
import os
from pathlib import Path
import struct


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--roots',type=Path,nargs='+')
    parser.add_argument('--base',type=Path,nargs='+',help='Automatically attach new core_*, grid_*, and budget500_* output directories')
    parser.add_argument('--seen',type=Path,required=True)
    a=parser.parse_args()
    if not a.roots and not a.base:
        parser.error('Specify --roots or --base')
    bases=[p.resolve() for p in a.base] if a.base else []
    roots=([p.resolve() for p in a.roots] if a.roots else
           sorted({p for base in bases for p in base.iterdir() if p.is_dir() and p.name.startswith(('core_','grid_','budget500_','replay_'))}))
    seen=set(json.loads(a.seen.read_text())) if a.seen.exists() else set()

    def deliver():
        events=[]
        for root in roots:
            progress=root/'progress.json'
            if progress.exists():
                try:
                    jobs=json.loads(progress.read_text()).get('jobs',[])
                except (ValueError,OSError):
                    jobs=[]
                for job in jobs:
                    if not job.get('returncode'):
                        continue
                    key=f"{progress}#error:{job['task']}:{job['profile']}:{job['seed']}"
                    if key not in seen:
                        seen.add(key)
                        events.append(dict(type='subprocess_error',root=str(root),job=job))
            for path in sorted(root.glob('2x*/result.json'))+[root/'result.json',root/'complete.json']:
                key=str(path)
                if key in seen or not path.exists():
                    continue
                try:
                    value=json.loads(path.read_text())
                except (ValueError,OSError):
                    continue
                seen.add(key)
                if path.name=='result.json':
                    events.append(dict(type='case_completed',root=str(root),case=path.parent.name,
                        **{k:value.get(k) for k in ('score','max_score','success','steps','phase','wall_seconds','policy_failure_reason','failure_reason')}))
                else:
                    event_type='budget_completed' if root.name.startswith('budget500_') else 'grid_completed' if root.name.startswith('grid_') else 'core_completed'
                    events.append(dict(type=event_type,root=str(root),status=value.get('status'),
                        wall_seconds=value.get('wall_seconds'),returncodes=[j['returncode'] for j in value.get('jobs',[])]))
        for base in bases:
            for log in base.glob('replay_*.log'):
                key=str(log)+'#python_error'
                if key in seen:continue
                with log.open('rb') as stream:
                    stream.seek(max(0,log.stat().st_size-65536));tail=stream.read().decode(errors='replace')
                if 'Traceback (most recent call last):' in tail:
                    seen.add(key);events.append(dict(type='replay_python_error',log=str(log),tail=tail[-3000:]))
        if events:
            a.seen.write_text(json.dumps(sorted(seen),indent=2)+'\n')
            for event in events:
                print(json.dumps(event,ensure_ascii=False),flush=True)
            return True
        return False

    if deliver():
        return
    lib=ctypes.CDLL('libc.so.6',use_errno=True)
    fd=lib.inotify_init1(0)
    if fd<0:
        raise OSError(ctypes.get_errno(),'inotify_init1')
    watched={}

    def add(path):
        wd=lib.inotify_add_watch(fd,os.fsencode(path),0x00000008|0x00000080|0x00000100)
        if wd<0:
            raise OSError(ctypes.get_errno(),f'inotify_add_watch:{path}')
        watched[wd]=path

    try:
        for base in bases:
            add(base)
        for root in roots:
            add(root)
            for path in root.glob('2x*'):
                if path.is_dir():
                    add(path)
        if deliver():
            return
        while True:
            data=os.read(fd,65536)
            offset=0
            relevant=False
            while offset<len(data):
                wd,mask,cookie,n=struct.unpack_from('iIII',data,offset)
                name=os.fsdecode(data[offset+16:offset+16+n].split(b'\0',1)[0])
                offset+=16+n
                path=watched[wd]/name
                if mask & 0x40000000:
                    if watched[wd] in bases and name.startswith(('core_','grid_','budget500_','replay_')):
                        if path not in roots:
                            roots.append(path)
                        add(path)
                        for child in path.glob('2x*'):
                            if child.is_dir():
                                add(child)
                        relevant=True
                    elif watched[wd] in roots and name.startswith('2x'):
                        add(path)
                if name in ('result.json','complete.json','progress.json') or (watched[wd] in bases and name.startswith('replay_') and name.endswith('.log')):
                    relevant=True
            if relevant and deliver():
                return
    finally:
        os.close(fd)


if __name__=='__main__':
    main()
