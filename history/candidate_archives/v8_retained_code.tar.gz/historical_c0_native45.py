"""Historical45 C0: task-route original V7 2x5 and V6 2x10 rows."""
from __future__ import annotations
import argparse
from fractions import Fraction
import json
from pathlib import Path
from historical_core_reference import metrics

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--v6',type=Path,required=True);p.add_argument('--v7',type=Path,required=True)
    p.add_argument('--parents',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    sources={'v6':a.v6,'v7':a.v7};cases=[]
    for version,path in sources.items():
        data=json.loads(path.read_text());manifest=json.loads((a.parents/version/'code_manifest.json').read_text());h=manifest.get('sha256',manifest)
        assert data['complete']['status']=='completed' and len(data['complete']['jobs'])==45
        assert all(not j['returncode'] for j in data['complete']['jobs'])
        assert all(h[n]==v for n,v in data['policy_code_sha256'].items())
        for case in data['cases']:
            row=case['episodes'][0]
            if row['task']!=('2x5' if version=='v7' else '2x10'):continue
            assert row['max_steps']==(500 if row['task']=='2x5' else 3200)
            assert row['score']==row['cookies_in_target'] and row['success_hold_steps']==5 and not row['strict_policy_completion']
            cases.append(dict(parent=version,source_raw=str(path.resolve()),**case))
    key=lambda r:(r['task'],r['profile'],r['seed'],5 if r['task']=='2x5' else r['randomization']['first_grasp_count'])
    expected={('2x5',p,14000+i,5) for p in ('basic','medium','advanced') for i in range(5)}|{('2x10',p,14000+n,n) for p in ('basic','medium','advanced') for n in range(10)}
    assert {key(c['episodes'][0]) for c in cases}==expected and len(cases)==45
    rows=[c['episodes'][0] for c in cases]
    payload=dict(scope='historical_task_recombination_only',new_experiment=False,task_route={'2x5':'v7B','2x10':'v6B'},
        protocol=dict(budgets={'2x5':500,'2x10':3200},source_column=1,success_hold_steps=5,strict_policy_completion=False),
        cases=cases,overall=metrics(rows),cells=[dict(task=t,profile=p,**metrics([r for r in rows if r['task']==t and r['profile']==p])) for t in ('2x5','2x10') for p in ('basic','medium','advanced')])
    payload['primary_metric']='equal mean of six task/profile raw final-count means'
    primary=sum((Fraction(c['final_count_sum'],c['episodes']) for c in payload['cells']),Fraction())/6
    payload['overall']['equal_six_cell_mean_final_count']=float(primary)
    payload['overall']['equal_six_cell_mean_final_count_fraction']=str(primary)
    payload['overall']['equal_six_cell_official_success_rate']=sum(c['official_success_rate'] for c in payload['cells'])/6
    a.output.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n');print(json.dumps(payload['overall']))

if __name__=='__main__':main()
