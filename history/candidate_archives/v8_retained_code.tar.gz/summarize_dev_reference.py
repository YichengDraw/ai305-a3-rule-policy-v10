"""Independently summarize a completed, evaluator-audited 45-case development grid."""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path


def fraction(passed, observed):
    return passed / observed if observed else None


def audited_rate(items, field):
    known = [item for item in items if item.get(field) is not None]
    passed = sum(item[field] is True for item in known)
    return {"passed": passed, "observed": len(known), "unknown": len(items) - len(known),
            "rate": fraction(passed, len(known))}


def diagnostics(rows):
    attempted = [batch for row in rows for batch in row.get("offline_batch_audit", []) if batch.get("attempted")]
    conditional = []
    timing_unknown = 0
    for row in rows:
        previous = []
        for batch in sorted(row.get("offline_batch_audit", []), key=lambda batch: batch["batch_index"]):
            if previous and batch.get("attempted") and all(prior.get("valid_placement") is True for prior in previous):
                start = batch.get("first_attempt_step")
                times = [prior.get("first_valid_placement_step") for prior in previous]
                if start is None or any(time is None for time in times):
                    timing_unknown += 1
                elif all(time <= start for time in times):
                    conditional.append(batch)
            previous.append(batch)
    events = [event for row in rows for event in row.get("policy_recovery_events", [])]
    known_events = [event for event in events if event.get("success") is not None or event.get("recovered") is not None]
    recovered = sum(bool(event["success"] if event.get("success") is not None else event.get("recovered")) for event in known_events)
    done = [row for row in rows if row.get("phase") == "DONE" or any(t.get("to") == "DONE" for t in row.get("policy_transitions", []))]
    return {
        "audited_episodes": sum(bool(row.get("offline_batch_audit")) for row in rows),
        "attempted_batches": len(attempted),
        "valid_grasp": audited_rate(attempted, "valid_grasp"),
        "valid_placement": audited_rate(attempted, "valid_placement"),
        "final_retention": audited_rate(attempted, "final_valid_placement"),
        "subsequent_given_prior_valid": audited_rate(conditional, "valid_placement"),
        "conditional_timing_unknown": timing_unknown,
        "local_recovery": {"passed": recovered, "observed": len(known_events),
                           "unknown": len(events) - len(known_events), "recorded_events": len(events),
                           "rate": fraction(recovered, len(known_events)),
                           "availability": ("explicit_event_labels" if known_events else
                                            "events_without_success_labels" if events else "not_recorded_by_reference_policy")},
        "done_episodes": len(done), "done_but_official_failure": sum(not row["success"] for row in done),
    }


def metrics(rows):
    n = len(rows)
    successes = sum(row["success"] is True for row in rows)
    counts = sum(row["cookies_in_target"] for row in rows)
    capacity = sum(row["max_score"] for row in rows)
    return {"episodes": n, "successes": successes, "success_rate": fraction(successes, n),
            "completion_rate": fraction(sum(row["cookies_in_target"] / row["max_score"] for row in rows), n),
            "cookie_weighted_completion_rate": fraction(counts, capacity),
            "final_cookies": counts, "capacity": capacity,
            "mean_final_count": fraction(counts, n), "mean_steps": fraction(sum(row["steps"] for row in rows), n),
            "phase_counts": dict(Counter(row["phase"] for row in rows)), "diagnostics": diagnostics(rows)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--expected-policy-manifest", type=Path, required=True)
    parser.add_argument("--output-stem", type=Path, required=True)
    args = parser.parse_args()
    data = json.loads(args.input.read_text())
    manifest = json.loads(args.expected_policy_manifest.read_text())
    expected_hashes = {name: manifest[name] for name in ("policy.py", "rule_controller.py", "perception.py")}
    assert data["policy_code_sha256"] == expected_hashes, "Reference policy differs from frozen v5"
    complete = data["complete"]
    assert complete["status"] == "completed" and len(complete["jobs"]) == 45
    assert all(job["returncode"] == 0 for job in complete["jobs"])
    expected = {("2x5", profile, seed, 5) for profile in ("basic", "medium", "advanced") for seed in range(14000, 14005)}
    expected |= {("2x10", profile, 14000 + n, n) for profile in ("basic", "medium", "advanced") for n in range(10)}
    rows = []
    keys = []
    for case in data["cases"]:
        protocol = case["protocol"]
        assert len(case["episodes"]) == 1
        row = case["episodes"][0]
        task, profile, seed = row["task"], row["profile"], row["seed"]
        n = 5 if task == "2x5" else row["randomization"]["first_grasp_count"]
        key = task, profile, seed, n
        keys.append(key)
        assert protocol["tasks"] == [task] and protocol["profiles"] == [profile]
        assert protocol["seed_start"] == seed and protocol["episodes_per_cell"] == 1
        assert row["max_steps"] == (500 if task == "2x5" else 3200)
        assert protocol["max_steps_by_task"][task] == row["max_steps"]
        assert row["score"] == row["cookies_in_target"] and row["max_score"] == (10 if task == "2x5" else 20)
        assert isinstance(row["success"], bool) and 0 <= row["score"] <= row["max_score"]
        assert 0 < row["steps"] <= row["max_steps"]
        assert protocol["source_column"] == "1" and row["source_column"] == 1
        assert protocol["render_cameras"] is True and protocol["offline_ground_truth_audit"] is True
        assert protocol["strict_policy_completion"] is False and protocol["success_hold_steps"] == 5
        assert int(protocol["first_grasp_2x10"]) == n
        hashes = protocol["code_sha256"]
        assert hashes["policy_module"] == expected_hashes["policy.py"]
        assert hashes["rule_controller.py"] == expected_hashes["rule_controller.py"]
        assert hashes["perception.py"] == expected_hashes["perception.py"]
        audit = row.get("offline_batch_audit", [])
        assert sum(batch["planned_count"] for batch in audit) == row["max_score"]
        for batch in audit:
            for field in ("first_valid_grasp_step", "first_valid_placement_step", "first_attempt_step"):
                assert batch.get(field) is None or 0 <= batch[field] <= row["steps"]
        rows.append(row)
    assert len(keys) == len(set(keys)) == 45 and set(keys) == expected
    jobs = {(job["task"], job["profile"], job["seed"], job["n"]) for job in complete["jobs"]}
    assert jobs == expected
    rows.sort(key=lambda row: (row["task"], row["profile"], row["seed"]))
    cells = []
    for task in ("2x5", "2x10"):
        for profile in ("basic", "medium", "advanced"):
            selected = [row for row in rows if row["task"] == task and row["profile"] == profile]
            cells.append({"task": task, "profile": profile, **metrics(selected)})
    overall = metrics(rows)
    overall["cell_macro_completion_rate"] = sum(cell["completion_rate"] for cell in cells) / len(cells)
    payload = {
        "policy": "frozen_v5_reference", "development_only": True,
        "protocol": {"episodes": 45, "source_column": 1, "budgets": {"2x5": 500, "2x10": 3200},
                     "2x5_seeds": [14000, 14004], "2x10_seeds": [14000, 14009],
                     "2x10_first_grasps": list(range(10)), "official_non_strict": True, "success_hold_steps": 5},
        "validation": {"unique_cases": 45, "missing": 0, "duplicates": 0, "all_returncodes_zero": True,
                       "frozen_policy_hashes_match": True, "policy_code_sha256": expected_hashes},
        "source_directory": data["source_directory"], "raw_evidence": str(args.input.resolve()),
        "wall_seconds": complete.get("wall_seconds"), "overall": overall, "cells": cells,
        "episodes": [{key: row.get(key) for key in ("task", "profile", "seed", "max_steps", "score", "max_score", "success", "steps", "phase", "policy_failure_reason")} for row in rows],
        "diagnostic_scope": "Evaluator-owned truth sampled at transitions and every five controls; official success and final count remain unchanged. Missing recovery labels stay unknown.",
    }
    out = args.output_stem
    out.parent.mkdir(parents=True, exist_ok=True)
    out.with_suffix(".json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n")
    percent = lambda value: "未知" if value is None else f"{value:.2%}"
    lines = ["# V5：45 次开发参照", "",
             "旧版冻结策略；来源列 1；2×5 为 500 步、2×10 为 3200 步；官方非严格判定。",
             "2×5 三档各 5 次；2×10 三档各 10 次，首夹数量覆盖 0–9。", "",
             "| 任务 | 难度 | 回合数 | 完成率 | 成功 | 平均入盒 |",
             "|---|---|---:|---:|---:|---:|"]
    for cell in cells:
        lines.append(f"| {cell['task']} | {cell['profile']} | {cell['episodes']} | {percent(cell['completion_rate'])} | {cell['successes']}/{cell['episodes']} | {cell['mean_final_count']:.2f} |")
    lines += ["", f"按回合等权完成率：{percent(overall['completion_rate'])}；成功率：{percent(overall['success_rate'])}（{overall['successes']}/45）。",
              f"按饼干数加权完成率：{percent(overall['cookie_weighted_completion_rate'])}（{overall['final_cookies']}/{overall['capacity']}）。六格等权完成率：{percent(overall['cell_macro_completion_rate'])}。",
              "", "| 离线真实诊断 | 通过/有观测 | 比例 | 未知 |", "|---|---:|---:|---:|"]
    diag = overall["diagnostics"]
    for label, key in [("有效整批抓取", "valid_grasp"), ("有效整批放置", "valid_placement"),
                       ("前批有效条件下的后批放置", "subsequent_given_prior_valid"), ("局部恢复成功", "local_recovery")]:
        metric = diag[key]
        lines.append(f"| {label} | {metric['passed']}/{metric['observed']} | {percent(metric['rate'])} | {metric['unknown']} |")
    retained = diag["final_retention"]
    lines += ["", f"终态仍有效的整批：{retained['passed']}/{retained['observed']}。控制器 DONE 但官方失败：{diag['done_but_official_failure']}/{diag['done_episodes']}。",
              f"旧版保存了 {diag['local_recovery']['recorded_events']} 条恢复事件，其成功结算标签缺失，恢复率保留未知。离线诊断按阶段切换及每 5 步采样，适用范围为实际保存的样本。",
              "", "已核对 45 个唯一条件、全部返回码、预算、种子、实际首夹数量和三份冻结策略代码指纹。"]
    out.with_suffix(".md").write_text("\n".join(lines) + "\n")
    print(json.dumps({"episodes": len(rows), "completion_rate": overall["completion_rate"],
                      "successes": overall["successes"], "success_rate": overall["success_rate"],
                      "diagnostics": diag}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
