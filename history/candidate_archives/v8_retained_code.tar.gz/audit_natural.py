"""Independent official-count audit; no extra physical-success conditions."""
from __future__ import annotations
import argparse
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path

PROFILES=('basic','medium','advanced')
TERMINAL={'grasp_reports','final_expert_phase','target_column_counts','cookies_in_target','cookies_in_source'}

def metrics(rows):
    n=len(rows);count=sum(r['cookies_in_target'] for r in rows);cap=sum(r['max_score'] for r in rows)
    mean=Fraction(count,n);normalized=sum((Fraction(r['cookies_in_target'],r['max_score']) for r in rows),Fraction())/n
    return dict(episodes=n,final_count_sum=count,mean_final_count=float(mean),mean_final_count_fraction=str(mean),
        normalized_completion=float(normalized),normalized_completion_fraction=str(normalized),
        quantity_weighted_completion=count/cap,successes=sum(r['success'] for r in rows),
        official_success_rate=sum(r['success'] for r in rows)/n,mean_steps=sum(r['steps'] for r in rows)/n)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True);p.add_argument('--output-stem',type=Path,required=True)
    a=p.parse_args();data=json.loads(a.input.read_text());reg=data['registration']
    assert data['scope']=='natural_sampling_only' and reg['scope']=='v8_frozen_natural_paired'
    assert reg['seed_start']==17000 and reg['seeds']==[17000,17019]
    assert reg['max_steps_by_task']=={'2x5':500,'2x10':3200} and reg['source_column']==1
    assert reg['strict_policy_completion'] is False and reg['success_hold_steps']==5
    full=data['phase']=='full';n=20 if full else 5
    phases=('initial','extend') if full else('initial',)
    expected={(t,p,s) for t in ('2x5','2x10') for p in PROFILES for s in range(17000,17000+n)}
    for phase in phases:
        assert data['stages'][phase]['complete']['status']=='completed'
        status=data['stages'][phase]['status']['results'];assert len(status)==2 and all(x['returncode']==0 for x in status)
    if full:assert data['complete']['status']=='completed' and data['complete']['episodes']==240
    indexed={};protocols={};results={}
    for version in reg['versions']:
        label=version['name'];d=data['policies'][label];assert d['runtime_sha256']==version['runtime_sha256']
        assert len(d['cases'])==len(expected)
        for phase in phases:
            state=d['launches'][phase];wanted=30 if phase=='initial' else 90
            assert state['complete']['status']=='completed' and state['complete']['episodes']==wanted
            assert state['status']['finished_shards']==state['status']['planned_shards']==wanted
            assert len(state['status']['completed'])==wanted and all(x['returncode']==0 for x in state['status']['completed'])
            assert state['launch']['policy']==version['policy']
            assert state['launch']['offline_ground_truth_audit'] is False
        rows={};ps={}
        for case in d['cases']:
            assert case['summary_status']=='completed' and len(case['episodes'])==1
            row=case['episodes'][0];q=case['protocol'];key=(row['task'],row['profile'],row['seed'])
            assert key in expected and key not in rows
            task,profile,seed=key;budget=500 if task=='2x5' else 3200
            assert row['max_steps']==budget and 0<row['steps']<=budget
            assert row['max_score']==(10 if task=='2x5' else 20)
            assert row['score']==row['cookies_in_target'] and row['score']>=0
            assert isinstance(row['success'],bool)
            assert q['policy']==version['policy'] and q['seed_start']==seed and q['episodes_per_cell']==1
            assert q['tasks']==[task] and q['profiles']==[profile]
            assert q['max_steps_by_task']=={'2x5':500,'2x10':3200}
            assert q['source_column']=='1' and row['source_column']==1
            assert q['success_hold_steps']==row['success_hold_steps']==5
            assert q['strict_policy_completion'] is row['strict_policy_completion'] is False
            assert q['render_cameras'] is True and q['offline_ground_truth_audit'] is False
            assert not row.get('oracle_source_target') and not row.get('development_scope')
            if task=='2x10':assert q['first_grasp_2x10']=='random'
            if label=='c0':assert row['policy_task_parent']==('v7' if task=='2x5' else'v6')
            fingerprints=q['code_sha256'];runtime=version['runtime_sha256']
            assert fingerprints['policy_module']==runtime['policy.py']
            for name,digest in runtime.items():
                if '/' in name:assert fingerprints['runtime/'+name]==digest
                elif name!='policy.py':assert fingerprints.get(name,fingerprints.get('runtime/'+name))==digest
            for name,digest in fingerprints.items():
                if name.startswith('runtime/'):assert runtime[name[len('runtime/'):]]==digest
            for name in ('evaluate_policy.py','batch_metrics.py','diagnostic_support.py'):
                assert fingerprints['evaluation_script' if name=='evaluate_policy.py' else name]==reg['evaluator_sha256'][name]
            rows[key]=row;ps[key]=q
        assert set(rows)==expected
        merged={(r['task'],r['profile'],r['seed']):r for r in d['merged_episodes']}
        assert len(merged)==len(d['merged_episodes'])==len(expected) and merged==rows
        summary=d['merged_summary'];m=metrics(list(rows.values()))
        assert summary['status']=='completed' and summary['overall']['total_score']==m['final_count_sum']
        assert summary['overall']['successes']==m['successes']
        assert abs(summary['overall']['mean_final_count']-m['mean_final_count'])<1e-12
        indexed[label]=rows;protocols[label]=ps
        results[label]=dict(overall=m,cells=[dict(task=t,profile=p,**metrics([r for k,r in rows.items() if k[:2]==(t,p)])) for t in ('2x5','2x10') for p in PROFILES],
            failure_reasons=dict(Counter(r.get('failure_reason') for r in rows.values() if not r['success'])))
    assert set(indexed)=={'c0','v8'}
    for key in expected:
        x,y=indexed['c0'][key],indexed['v8'][key]
        scene=lambda r:{k:v for k,v in r['randomization'].items() if k not in TERMINAL}
        assert scene(x)==scene(y) and x['task_instruction']==y['task_instruction']
        for field in ('source_commit','prompt_styles','first_grasp_2x10','randomization_settings'):
            assert protocols['c0'][key][field]==protocols['v8'][key][field]
    commits={q['source_commit'] for values in protocols.values() for q in values.values()}
    assert commits=={'0729068ee1e75a562cfbc4f2c83ab9539cf75081'}
    old,new=results['c0']['overall'],results['v8']['overall']
    payload=dict(scope='official_natural_sampling_only',phase=data['phase'],results=results,
        mean_count_delta=new['mean_final_count']-old['mean_final_count'],
        normalized_delta_pp=100*(new['normalized_completion']-old['normalized_completion']),
        success_delta_pp=100*(new['official_success_rate']-old['official_success_rate']),
        validation=dict(raw_shards=2*len(expected),episodes_per_policy=len(expected),unique=True,all_returncodes_zero=True,
            budgets_500_3200=True,non_strict_hold5=True,nested_runtime_sha_match=True,
            initial_scenes_match=True,raw_and_merged_identical=True,c0_task_only_parent_verified=True),
        source_commit=next(iter(commits)),raw_evidence=str(a.input.resolve()))
    a.output_stem.with_suffix('.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    lines=['# V8自然抽样独立验收','',f'每版{len(expected)}回合，2×5=500步、2×10=3200步，官方非严格、hold5。主指标为真实终态入盒数量平均，所有失败和超时保留。','',
        '| 策略 | 平均终态数量（块/回合） | 归一化完成率 | 官方成功 |','|---|---:|---:|---:|']
    for label in ('c0','v8'):
        m=results[label]['overall'];lines.append(f"| {label.upper()} | {m['mean_final_count']:.4f} | {m['normalized_completion']:.2%} | {m['successes']}/{m['episodes']}（{m['official_success_rate']:.2%}） |")
    lines+=['',f"平均数量变化{payload['mean_count_delta']:+.4f}块/回合，成功率变化{payload['success_delta_pp']:+.2f}个百分点。",'',
        '逐一核对全部原始分片、嵌套parent依赖指纹、初始场景、任务路由、预算与官方终态字段。18000按n诊断与500步补充数据均未混入本表。']
    a.output_stem.with_suffix('.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:payload[k] for k in ('phase','mean_count_delta','normalized_delta_pp','success_delta_pp')},indent=2))

if __name__=='__main__':main()
