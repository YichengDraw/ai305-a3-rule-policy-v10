"""Validate a completed V8 core subset and compare official quantities."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
from historical_core_reference import metrics

TERMINAL={'grasp_reports','final_expert_phase','target_column_counts','cookies_in_target','cookies_in_source','first_grasp_mode'}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root','--roots',dest='roots',type=Path,nargs='+',required=True);p.add_argument('--reference',type=Path,required=True)
    p.add_argument('--output-stem',type=Path,required=True);a=p.parse_args()
    ref=json.loads(a.reference.read_text());before={c['label']:c for c in ref['cases']}
    pairs=[];oldrows=[];newrows=[];seen=set();runtime_maps=[];sources=[]
    for given_root in a.roots:
        root=given_root.resolve();sources.append(str(root))
        launch=json.loads((root/'protocol.json').read_text());done=json.loads((root/'complete.json').read_text())
        assert done['status']=='completed' and all(j['returncode']==0 for j in done['jobs'])
        assert len(done['jobs'])==len(launch['jobs'])
        for name,digest in launch['code_sha256'].items():assert hashlib.sha256((root/'code'/name).read_bytes()).hexdigest()==digest
        names=launch.get('runtime_dependencies',('policy.py','perception.py','rule_controller.py','placement_audit.py'))
        runtime_maps.append({n:launch['code_sha256'][n] for n in names})
        for j in launch['jobs']:
            assert j['label'] not in seen,'Duplicate core case across groups'
            seen.add(j['label'])
            prior=before[j['label']];old=prior['row']
            case=root/f"{j['task']}_{j['profile']}_{j['seed']}_n{j['n']}"
            new=json.loads((case/'result.json').read_text());q=json.loads((case/'development_protocol.json').read_text())
            assert (j['task'],j['profile'],j['seed'],j['n'])==(prior['task'],prior['profile'],prior['seed'],prior['n'])
            assert new['max_steps']==old['max_steps']==q['max_steps']
            assert new['source_column']==old['source_column']==1 and not new['strict_policy_completion'] and new['success_hold_steps']==5
            assert new['task_instruction']==old['task_instruction']
            scene=lambda r:{k:v for k,v in r['randomization'].items() if k not in TERMINAL}
            assert scene(new)==scene(old),(j['label'],'initial scene differs')
            if j['task']=='2x10':assert new['randomization']['first_grasp_count']==j['n']
            assert new['cookies_in_target']==new['score'] and isinstance(new['success'],bool)
            oldrows.append(old);newrows.append(new)
            pairs.append(dict(label=j['label'],task=j['task'],profile=j['profile'],seed=j['seed'],n=j['n'],
                baseline_parent=prior['parent'],old_count=old['cookies_in_target'],new_count=new['cookies_in_target'],
                max_score=new['max_score'],old_success=old['success'],new_success=new['success'],
                old_steps=old['steps'],new_steps=new['steps'],new_phase=new['phase'],
                new_failure_reason=new.get('policy_failure_reason') or new.get('failure_reason'),source_directory=str(case)))
    assert all(r==runtime_maps[0] for r in runtime_maps),'Runtime changed between core subsets'
    old,new=metrics(oldrows),metrics(newrows)
    matched=[c for c in pairs if c['old_success'] and c['new_success']]
    matched_time=dict(episodes=len(matched),
        old_mean_steps=sum(c['old_steps'] for c in matched)/len(matched) if matched else None,
        new_mean_steps=sum(c['new_steps'] for c in matched)/len(matched) if matched else None)
    observed={c['label']:c for c in pairs}
    gates={}
    for label,required,limit in (('normal_medium',20,500),('normal_advanced',20,500),('place_basic',20,None),('regression_basic',10,None)):
        c=observed.get(label)
        gates[label]=None if c is None else bool(c['new_count']==required and c['new_success'] and (limit is None or c['new_steps']<=limit))
    gate_status='failed' if any(v is False for v in gates.values()) else 'passed' if all(v is True for v in gates.values()) else 'incomplete'
    payload=dict(scope='development_only_against_historical_C0',new_experiment_reference=False,
        source_directories=sources,reference=str(a.reference.resolve()),runtime_sha256=runtime_maps[0],
        validation=dict(all_returncodes_zero=True,snapshot_matches=True,initial_scenes_match=True,official_contract_matches=True),
        old=old,new=new,pairs=pairs,matched_success_time=matched_time,
        development_regression_gates=dict(status=gate_status,checks=gates,official_scores_changed=False),
        mean_count_delta=new['mean_final_count']-old['mean_final_count'])
    a.output_stem.with_suffix('.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    lines=['# 核心开发对照','',f"共{len(pairs)}回合，参照为C0历史记录重组；只比较实际相同预算与初始场景。主指标为官方终态有效数量。",'',
        '| 案例 | C0数量 | 候选数量 | C0成功 | 候选成功 | C0步数 | 候选步数 |','|---|---:|---:|---:|---:|---:|---:|']
    for c in pairs:lines.append(f"| {c['label']} | {c['old_count']} | {c['new_count']} | {int(c['old_success'])} | {int(c['new_success'])} | {c['old_steps']} | {c['new_steps']} |")
    lines+=['',f"平均终态数量{old['mean_final_count']:.4f} → {new['mean_final_count']:.4f}块/回合；官方成功{old['successes']}/{len(pairs)} → {new['successes']}/{len(pairs)}；归一化完成{old['normalized_completion']:.2%} → {new['normalized_completion']:.2%}。"]
    a.output_stem.with_suffix('.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'old':old,'new':new}))

if __name__=='__main__':main()
