"""M2 public-state contracts; uses existing V7 control targets, no physics."""
import ast
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import mujoco
import numpy as np
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from rule_controller import RuleController,CANONICAL,opening_from_gap


def setup(cls):
    config=load_config(resource_root()/'configs/cookie_2x10.yaml')
    c=cls(config);c.reset(SimpleNamespace(task='transfer 20 cookies into target box; grasp 4 cookies first'))
    c.set_variant('b');q=np.empty(4);mujoco.mju_mat2Quat(q,CANONICAL.ravel())
    state=np.zeros(16);state[7]=state[15]=1.
    obs={'observation.eef_pose':np.r_[.1,.25,.82,q,.1,-.25,.92,q],
         'observation.state':state,'observation.velocity':np.zeros(16),'observation.force':np.zeros(18),'time':0.}
    layout=np.asarray(config.cookie_transfer.cookie_source_positions_m)
    center=np.r_[layout[:4].mean(0),config.cookie_transfer.cookie_model_z_m]
    scene={'group':{'indices':list(range(4)),'center':center,'rotation':np.eye(3),'confidence':.8,'width_m':.032833333,
                    'tilt_deg':0.,'position_error_m':.001},
           'target_box':{'center':config.cookie_transfer.target_bin_world_position_m,'yaw':0.,'confidence':.8},
           'held':{},'placement':{'state':'unknown','confidence':0.}}
    c._obs,c._scene=obs,scene;c._select(scene)
    return c,obs,scene


def load_class(path):
    spec=importlib.util.spec_from_file_location('parent_m1_controller',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module.RuleController


def run(parent_dir):
    parent_dir=Path(parent_dir);Old=load_class(parent_dir/'rule_controller.py');checks=[]
    for name in ['policy.py','perception.py','placement_audit.py']:
        assert (Path(__file__).parent/name).read_bytes()==(parent_dir/name).read_bytes()
    checks.append('non-motion runtime modules remain byte-identical to the tested M1/V7 parent')
    c,obs,scene=setup(RuleController);position=obs['observation.eef_pose'][:3].copy()
    for speed in [.018,.0045,.006,.015,.0035]:
        for delta in [.002,.010,.030,.200]:
            target=position+[0,0,delta]
            action,_=c._servo_free_transit(obs,target,CANONICAL,speed)
            assert np.linalg.norm(action[:3]*c.translation_scale)<=speed+1e-12
            assert float(action[2]*c.translation_scale)<delta
            parent,_=c._servo(obs,target,CANONICAL,speed)
            assert np.array_equal(action[3:],parent[3:])
    checks.append('every free command stays below its existing stage speed and target, with identical rotation/gripper actions')
    for distance in [.012,.030]:
        old,o,s=setup(Old);new,ob,sc=setup(RuleController)
        for ctrl,oo,ss in [(old,o,s),(new,ob,sc)]:
            ctrl._advance('TRANSPORT');oo['observation.force'][12:14]=1.3
            goal=oo['observation.eef_pose'][:3]+[0,-distance,0]
            ctrl._place_pose=lambda scene,clearance=0.,g=goal:(g,CANONICAL.copy())
        parent=old.act(o,s);candidate=new.act(ob,sc)
        if distance<.020:assert np.array_equal(parent,candidate)
        else:assert abs(candidate[1])>abs(parent[1]) and np.array_equal(candidate[3:],parent[3:])
    checks.append('near-target transport stays identical; only its >20 mm free approach removes early proportional braking')
    for cls in [Old,RuleController]:
        c,obs,scene=setup(cls);c._advance('DESCEND');c.current_report['alignment_verified']=True
        obs['observation.eef_pose'][:3]=c._pick+[0,0,.016]
        action=c.act(obs,scene)
        if cls is Old:original=action
        else:assert np.array_equal(original,action)
    checks.append('the same contact insertion state produces exactly the M1 action')
    old,o,s=setup(Old);new,ob,sc=setup(RuleController)
    for c,oo,ss in [(old,o,s),(new,ob,sc)]:
        c._advance('PLACE');c._placement_goal=(oo['observation.eef_pose'][:3]+[0,0,-.012],CANONICAL.copy())
        oo['observation.force'][12:14]=1.3
    assert np.array_equal(old.act(o,s),new.act(ob,sc))
    checks.append('frozen placement descent actions stay exactly M1/V7')
    c,obs,scene=setup(RuleController);obs['observation.eef_pose'][:3]=c._trial
    obs['observation.velocity'][:7]=.3;obs['observation.force'][12:14]=1.3
    obs['observation.state'][7]=opening_from_gap(c.count*2*c.half_size[1])
    c._grasp_reference_eef=obs['observation.eef_pose'][:7].copy();c._grasp_reference_eef[2]-=.012
    scene['held']={'count':c.count,'count_confidence':.8};c._advance('TRIAL_LIFT');c.act(obs,scene)
    assert c.stage=='LIFT'
    checks.append('the tested M1 trial checkpoint and original force/count checks still run')
    return {'passed':len(checks),'checks':checks,'physical_simulation_run':False}

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--parent-dir',required=True)
    print(json.dumps(run(p.parse_args().parent_dir),indent=2))
