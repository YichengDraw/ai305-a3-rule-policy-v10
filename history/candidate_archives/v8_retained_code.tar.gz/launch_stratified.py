"""18000-series n=0..9 diagnostic; kept separate from natural test results."""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from launch_core_cases import runtime_files


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--policy-code',type=Path,required=True)
    p.add_argument('--policy',default='policy:make_policy_b')
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--label',choices=('c0','v8'),default='v8')
    p.add_argument('--natural-protocol',type=Path,required=True)
    p.add_argument('--workers',type=int,default=12)
    p.add_argument('--egl-devices',type=int,nargs='+',default=[5])
    a=p.parse_args();root=a.output.resolve();root.mkdir(parents=True,exist_ok=False)
    code=a.policy_code.resolve();scripts=Path(__file__).resolve().parent
    hashes={n:hashlib.sha256((code/n).read_bytes()).hexdigest() for n in runtime_files(code)}
    natural=json.loads(a.natural_protocol.read_text());selected=next(v for v in natural['versions'] if v['name']==a.label)
    assert selected['runtime_sha256']==hashes and selected['policy']==a.policy
    helpers={name:hashlib.sha256((scripts/name).read_bytes()).hexdigest() for name in natural['evaluator_sha256']}
    assert helpers==natural['evaluator_sha256'],'Frozen natural evaluator changed'
    jobs=[dict(task='2x10',profile=profile,n=n,seed=18000+n,gpu=a.egl_devices[i%len(a.egl_devices)])
        for i,(profile,n) in enumerate((p,n) for p in ('basic','medium','advanced') for n in range(10))]
    (root/'protocol.json').write_text(json.dumps(dict(scope='stratified_n_diagnostic_not_natural',
        policy=a.policy,label=a.label,code=str(code),runtime_sha256=hashes,natural_protocol=str(a.natural_protocol.resolve()),
        natural_registration=natural,evaluator_sha256=helpers,
        source_column=1,strict_policy_completion=False,success_hold_steps=5,max_steps=3200,jobs=jobs,
        primary_metric='mean official final_count, cookies/episode',merge_with_natural=False),indent=2)+'\n')
    start=time.monotonic();done=[]
    def run(job):
        output=root/f"2x10_{job['profile']}_{job['seed']}_n{job['n']}"
        env=dict(os.environ,MUJOCO_GL='egl',MUJOCO_EGL_DEVICE_ID=str(job['gpu']),CUDA_VISIBLE_DEVICES=str(job['gpu']),
            OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
        command=[sys.executable,str(scripts/'evaluate_policy.py'),'--policy',a.policy,'--policy-code',str(code),
            '--tasks','2x10','--profiles',job['profile'],'--episodes','1','--seed-start',str(job['seed']),
            '--first-grasp-2x10',str(job['n']),'--max-steps','500','--max-steps-2x10','3200',
            '--render-cameras','--output',str(output)]
        with (root/(output.name+'.log')).open('w') as log:
            result=subprocess.run(command,cwd=scripts,env=env,stdout=log,stderr=subprocess.STDOUT)
        return dict(job,output=str(output),returncode=result.returncode)
    with ThreadPoolExecutor(max_workers=a.workers) as pool:
        for future in as_completed([pool.submit(run,j) for j in jobs]):
            done.append(future.result());(root/'progress.json').write_text(json.dumps(dict(jobs=done,total=30,finished=len(done)),indent=2)+'\n')
    (root/'complete.json').write_text(json.dumps(dict(status='completed' if all(not j['returncode'] for j in done) else 'failed',
        jobs=done,episodes=30,wall_seconds=time.monotonic()-start,scope='stratified_n_diagnostic_not_natural'),indent=2)+'\n')
    if any(j['returncode'] for j in done):raise SystemExit('Diagnostic shard error')


if __name__=='__main__':main()
