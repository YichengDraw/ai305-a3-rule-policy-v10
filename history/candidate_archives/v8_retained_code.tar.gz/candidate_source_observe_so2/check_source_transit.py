"""SO2 public-state speed/endpoint checks, zero physics and no extra observations."""
from pathlib import Path
from types import SimpleNamespace
import ast,importlib.util,json
import numpy as np
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from rule_controller import RuleController,CANONICAL
root=Path(__file__).resolve().parents[1];record=json.loads((root/'source_observe_diagnosis/source_observe_public_state.json').read_text());config=load_config(resource_root()/'configs/cookie_2x10.yaml')
spec=importlib.util.spec_from_file_location('so1_parent',root/'candidate_source_observe/rule_controller.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def setup(cls):
 c=cls(config);c.reset(SimpleNamespace(task='Transfer 20 cookies from source column 1. Grasp 4 cookies first.'));c.set_variant('b');c.batch_index=1
 c._source_observe_pose=c._source_observation_target(record['perception']);c._advance('SOURCE_OBSERVE')
 pose=np.asarray(record['eef']);state=np.zeros(16);state[7]=state[15]=1.
 obs={'observation.eef_pose':np.r_[pose,pose],'observation.state':state,'observation.velocity':np.zeros(16),'observation.force':np.zeros(18),'time':0.}
 return c,obs,record['perception']
a,o,s=setup(m.RuleController);b,p,t=setup(RuleController)
old=a.act(o,s);new=b.act(p,t)
assert np.linalg.norm(new[:3]*b.translation_scale)>.0149 and np.linalg.norm(new[:3]*b.translation_scale)<=.015+1e-12
assert np.array_equal(old[3:],new[3:]) and a.stage==b.stage=='SOURCE_OBSERVE'
for touching in [False,True]:
 a,o,s=setup(m.RuleController);b,p,t=setup(RuleController)
 if touching:
  o['observation.force'][12]=p['observation.force'][12]=.3
 else:
  o['observation.eef_pose'][:3]=a._source_observe_pose[0]+[0,.010,0]
  p['observation.eef_pose'][:3]=b._source_observe_pose[0]+[0,.010,0]
 assert np.array_equal(a.act(o,s),b.act(p,t))
b,p,t=setup(RuleController);p['observation.eef_pose'][:3]=b._source_observe_pose[0]+[0,0,.10]
vertical=b.act(p,t);assert np.linalg.norm(vertical[:3]*b.translation_scale)<=.010+1e-12
# Geometric and zero-velocity observation requirements remain unchanged.
for cls in [m.RuleController,RuleController]:
 c,obs,scene=setup(cls);obs['observation.eef_pose'][:3]=c._source_observe_pose[0]
 q=np.empty(4);import mujoco;mujoco.mju_mat2Quat(q,c._source_observe_pose[1].ravel());obs['observation.eef_pose'][3:7]=q
 obs['observation.velocity'][:7]=.3;c.act(obs,scene);assert c.stage=='SOURCE_OBSERVE'
 obs['observation.velocity'][:]=0.;c.act(obs,scene);assert c.stage=='SELECT'
def parts(path):
 tree=ast.parse(path.read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef));methods={n.name:ast.dump(n,include_attributes=False) for n in cls.body if isinstance(n,ast.FunctionDef)};act=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='act');blocks={ast.unparse(n.test):ast.dump(n,include_attributes=False) for n in act.body if isinstance(n,ast.If)};return methods,blocks
old,oldblocks=parts(root/'candidate_source_observe/rule_controller.py');new,newblocks=parts(Path(__file__).with_name('rule_controller.py'))
assert [k for k in old if old[k]!=new[k]]==['act']
assert [k for k in oldblocks if oldblocks[k]!=newblocks[k]]==["self.stage == 'SOURCE_OBSERVE'"]
for name in ['policy.py','perception.py','placement_audit.py']:
 assert (Path(__file__).parent/name).read_bytes()==(root/'candidate_source_observe'/name).read_bytes()
result={'passed':6,'real_public_case':'MT advanced16018 step124; SO1 source-high destination',
 'far_horizontal_max_m':.015,'far_vertical_max_m':.010,'final_20mm_identical_to_so1':True,
 'contact_fallback_identical_to_so1':True,'exact_observation_zero_velocity_requirement_unchanged':True,
 'only_dispatch_change':'SOURCE_OBSERVE speed before existing observation endpoint','simulation_steps':0}
print(json.dumps(result,indent=2));Path(__file__).with_name('source_transit_checks.json').write_text(json.dumps(result,indent=2)+'\n')
