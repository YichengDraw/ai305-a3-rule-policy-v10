"""Orchestrate frozen V8 launchers; never choose or modify a policy from test scores.

Initial30 is collected/audited independently, then the same frozen code extends.
Final natural/supplement/stratified audit commands are left for the root owner.
"""
from __future__ import annotations
import argparse
from concurrent.futures import Future,ThreadPoolExecutor
import ctypes
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import select
import subprocess
import sys
import threading
import time

PROJECT=Path(__file__).resolve().parent


def now():return datetime.now(timezone.utc).isoformat()


def wait_for_protocol(path,initial_done):
    """Wait for valid protocol close/create or initial-process exit, without polling."""
    path=Path(path);lib=ctypes.CDLL('libc.so.6',use_errno=True)
    fd=lib.inotify_init1(0)
    if fd<0:raise OSError(ctypes.get_errno(),'inotify_init1')
    read_end,write_end=os.pipe();lock=threading.Lock();state={'closed':False};watched=set()
    def finished(_future):
        with lock:
            if not state['closed']:os.write(write_end,b'x')
    initial_done.add_done_callback(finished)
    def ready():
        try:return isinstance(json.loads(path.read_text()),dict)
        except (FileNotFoundError,json.JSONDecodeError):return False
    try:
        while True:
            # Watch the nearest existing directory, then the new natural root.
            directory=path.parent
            while not directory.exists():directory=directory.parent
            if directory not in watched:
                if lib.inotify_add_watch(fd,os.fsencode(directory),0x8|0x80|0x100)<0:
                    raise OSError(ctypes.get_errno(),str(directory))
                watched.add(directory)
            if ready():return True
            if initial_done.done():return False
            available,_,_=select.select([fd,read_end],[],[])
            if fd in available:os.read(fd,65536)
            if read_end in available:os.read(read_end,1024)
    finally:
        with lock:
            state['closed']=True;os.close(write_end)
        os.close(read_end);os.close(fd)


def commands(args,scripts=PROJECT):
    root=Path(args.output).resolve();natural=root/'natural';supp=root/'supplementary_500';strat=root/'stratified';audits=root/'audits'
    python=sys.executable;gpus=[str(g) for g in args.egl_devices]
    natural_base=['--c0-code',str(Path(args.c0_code).resolve()),'--candidate-code',str(Path(args.candidate_code).resolve()),
                  '--c0-policy',args.c0_policy,'--candidate-policy',args.candidate_policy,'--output',str(natural),
                  '--egl-devices',*gpus]
    plan={
      'natural_initial':[python,str(scripts/'launch_staged_pair.py'),'--phase','initial',*natural_base,'--workers',str(args.initial_workers)],
      'collect_natural_initial':[python,str(scripts/'collect_natural_raw.py'),'--root',str(natural),'--phase','initial','--output',str(audits/'natural_initial_raw.json')],
      'audit_natural_initial':[python,str(scripts/'audit_natural.py'),'--input',str(audits/'natural_initial_raw.json'),'--output-stem',str(audits/'natural_initial_verification')],
      'natural_extend':[python,str(scripts/'launch_staged_pair.py'),'--phase','extend',*natural_base,'--workers',str(args.extend_workers)],
    }
    for phase in ['initial','extend']:
        plan['supplement_'+phase]=[python,str(scripts/'launch_500_supplement.py'),'--natural-root',str(natural),
            '--output',str(supp),'--phase',phase,'--workers',str(args.supp_workers),'--egl-devices',*gpus]
    for label,code,policy in [('c0',args.c0_code,args.c0_policy),('v8',args.candidate_code,args.candidate_policy)]:
        plan['stratified_'+label]=[python,str(scripts/'launch_stratified.py'),'--policy-code',str(Path(code).resolve()),
            '--policy',policy,'--output',str(strat/label),'--label',label,'--natural-protocol',str(natural/'protocol.json'),
            '--workers',str(args.strat_workers),'--egl-devices',*gpus]
    final=[
      {'name':'collect_natural_full','command':[python,str(scripts/'collect_natural_raw.py'),'--root',str(natural),'--phase','full','--output',str(audits/'natural_full_raw.json')]},
      {'name':'audit_natural_full','command':[python,str(scripts/'audit_natural.py'),'--input',str(audits/'natural_full_raw.json'),'--output-stem',str(audits/'natural_full_verification')]},
      {'name':'collect_supplement_full','command':[python,str(scripts/'collect_additional_raw.py'),'--scope','supplement','--root',str(supp),'--phase','full','--output',str(audits/'supplement_full_raw.json')]},
      {'name':'audit_supplement_full','command':[python,str(scripts/'audit_additional.py'),'--input',str(audits/'supplement_full_raw.json'),'--output-stem',str(audits/'supplement_full_verification')]},
      {'name':'collect_stratified','command':[python,str(scripts/'collect_additional_raw.py'),'--scope','stratified','--c0-root',str(strat/'c0'),'--candidate-root',str(strat/'v8'),'--output',str(audits/'stratified_raw.json')]},
      {'name':'audit_stratified','command':[python,str(scripts/'audit_additional.py'),'--input',str(audits/'stratified_raw.json'),'--output-stem',str(audits/'stratified_verification')]},
    ]
    return plan,final


class Pipeline:
    def __init__(self,args,scripts=PROJECT):
        self.args=args;self.scripts=Path(scripts).resolve();self.root=Path(args.output).resolve()
        self.root.mkdir(parents=True,exist_ok=False)
        for folder in ['logs','audits','stratified']:(self.root/folder).mkdir()
        self.plan,self.final_commands=commands(args,self.scripts);self.lock=threading.Lock()
        self.manifest={'scope':'frozen_test_orchestration_only','started_utc':now(),'status':'running',
            'arguments':{key:str(value) if isinstance(value,Path) else value for key,value in vars(args).items()},
            'stages':{},'errors':[],'initial30_independent_audit':str(self.root/'audits/natural_initial_verification.json'),
            'selection_rule':'All valid initial30 results are preserved; same frozen code extends regardless of scores.',
            'final_audits':{'status':'pending_root_execution','commands_file':str(self.root/'final_audit_commands.json')},
            'failure_behavior':'Do not terminate or cancel other started computations; wait for their exit.'}
        (self.root/'final_audit_commands.json').write_text(json.dumps({'cwd':str(self.scripts),'commands':self.final_commands},indent=2)+'\n')
        self._write_manifest()

    def _write_manifest(self):
        temporary=self.root/'pipeline_manifest.json.tmp'
        temporary.write_text(json.dumps(self.manifest,indent=2)+'\n');temporary.replace(self.root/'pipeline_manifest.json')

    def record(self,name,**fields):
        with self.lock:
            entry=self.manifest['stages'].setdefault(name,{})
            entry.update(fields)
            if fields.get('status')=='failed':
                error={'stage':name,'utc':now(),'returncode':entry.get('returncode'),'error':entry.get('error'),'log':entry.get('log')}
                self.manifest['errors'].append(error)
                with (self.root/'errors.jsonl').open('a') as output:output.write(json.dumps(error)+'\n')
            self._write_manifest()

    def skip(self,name,reason):
        self.record(name,status='skipped',reason=reason,finished_utc=now())
        return {'status':'skipped','returncode':None,'reason':reason}

    def run_stage(self,name,on_spawn=None):
        command=self.plan[name];log_path=self.root/'logs'/(name+'.log');start=time.monotonic()
        self.record(name,status='starting',command=command,log=str(log_path),started_utc=now())
        process=None
        try:
            with log_path.open('x') as log:
                process=subprocess.Popen(command,cwd=self.scripts,stdout=log,stderr=subprocess.STDOUT)
                self.record(name,status='running',pid=process.pid)
                if on_spawn is not None:on_spawn()
                code=process.wait()
            result={'status':'completed' if code==0 else 'failed','returncode':code,
                    'wall_seconds':time.monotonic()-start,'finished_utc':now()}
            if code:result['error']=f'Process exited with return code {code}; inspect its independent log'
        except Exception as error:
            # A startup/recording error does not kill an already-running child.
            code=process.wait() if process is not None else None
            result={'status':'failed','returncode':code,'error':repr(error),'wall_seconds':time.monotonic()-start,'finished_utc':now()}
        self.record(name,**result)
        return result

    @staticmethod
    def ok(result):return result.get('status')=='completed' and result.get('returncode')==0

    def run(self):
        extend_started=Future()
        with ThreadPoolExecutor(max_workers=4) as pool:
            initial=pool.submit(self.run_stage,'natural_initial')
            def supplement_chain():
                try:
                    ready=wait_for_protocol(self.root/'natural/protocol.json',initial)
                    if not ready or (initial.done() and not self.ok(initial.result())):
                        self.skip('supplement_initial','Natural protocol unavailable or initial stage already failed')
                        return self.skip('supplement_extend','Supplement initial was not started')
                    first=self.run_stage('supplement_initial')
                    if not self.ok(first):return self.skip('supplement_extend','Supplement initial failed')
                    if not extend_started.result():return self.skip('supplement_extend','Natural initial/audit or extend startup failed')
                    return self.run_stage('supplement_extend')
                except Exception as error:
                    self.record('supplement_chain',status='failed',error=repr(error),finished_utc=now())
                    raise
            def stratified_chain(label):
                if not extend_started.result():return self.skip('stratified_'+label,'Natural initial/audit or extend startup failed')
                return self.run_stage('stratified_'+label)
            sides=[pool.submit(supplement_chain),pool.submit(stratified_chain,'c0'),pool.submit(stratified_chain,'v8')]
            try:
                first=initial.result()
                if self.ok(first):
                    collected=self.run_stage('collect_natural_initial')
                    audited=self.run_stage('audit_natural_initial') if self.ok(collected) else self.skip('audit_natural_initial','Initial collection failed')
                    if self.ok(audited):
                        # Existing launcher enforces unchanged runtime/helper fingerprints.
                        self.run_stage('natural_extend',on_spawn=lambda:extend_started.set_result(True))
                    else:self.skip('natural_extend','Independent initial30 collection/audit failed')
                else:
                    for name in ['collect_natural_initial','audit_natural_initial','natural_extend']:
                        self.skip(name,'Natural initial process failed')
            except Exception as error:
                self.record('natural_chain',status='failed',error=repr(error),finished_utc=now())
            finally:
                if not extend_started.done():extend_started.set_result(False)
                # Never cancel or terminate independent jobs after another failure.
                for future in sides:
                    try:future.result()
                    except Exception as error:
                        self.record('pipeline_side_error_'+str(sides.index(future)),status='failed',error=repr(error),finished_utc=now())
        failed=bool(self.manifest['errors'])
        self.manifest.update(status='failed' if failed else 'completed_compute_final_audits_pending',finished_utc=now(),
            all_started_processes_waited=True,scores_used_for_adaptive_decision=False)
        with self.lock:self._write_manifest()
        (self.root/'complete.json').write_text(json.dumps({k:self.manifest[k] for k in
            ['status','finished_utc','all_started_processes_waited','scores_used_for_adaptive_decision','final_audits']},indent=2)+'\n')
        return 1 if failed else 0


def parser():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--candidate-code',type=Path,required=True);p.add_argument('--c0-code',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--egl-devices',type=int,nargs='+',default=[0,2,5])
    p.add_argument('--initial-workers',type=int,default=48);p.add_argument('--extend-workers',type=int,default=40)
    p.add_argument('--supp-workers',type=int,default=12);p.add_argument('--strat-workers',type=int,default=10,help='Workers per policy (20 total at default)')
    p.add_argument('--c0-policy',default='policy:make_policy');p.add_argument('--candidate-policy',default='policy:make_policy_b')
    return p


def main():
    p=parser();args=p.parse_args()
    if min(args.initial_workers,args.extend_workers,args.supp_workers)<2 or args.strat_workers<1:p.error('Invalid worker counts')
    for path in [args.candidate_code,args.c0_code]:
        if not (path/'policy.py').is_file():p.error(f'Missing policy.py in {path}')
    raise SystemExit(Pipeline(args).run())

if __name__=='__main__':main()
