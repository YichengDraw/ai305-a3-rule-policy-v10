"""Watch pipeline metadata for completion/errors, with one scheduled check deadline.

No episode rows, score files, or periodic progress scans are read.
"""
from __future__ import annotations
import argparse
import ctypes
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import select


def read(path):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return None


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--seen', type=Path, required=True)
    p.add_argument('--deadline-utc', help='One planned inspection time, ISO8601; no periodic timer')
    a = p.parse_args(); root = a.root.resolve()
    seen = set(read(a.seen) or [])
    deadline = datetime.fromisoformat(a.deadline_utc.replace('Z', '+00:00')) if a.deadline_utc else None
    if deadline is not None:
        assert deadline.tzinfo is not None

    def paths():
        directories = [root, root / 'natural', root / 'supplementary_500', root / 'stratified']
        statuses = []
        for scope in ('natural', 'supplementary_500'):
            for phase in ('initial', 'extend'):
                directories.append(root / scope / phase)
                for label in ('c0', 'v8'):
                    folder = root / scope / phase / label
                    directories.append(folder); statuses.append(folder / 'launch_status.json')
        for label in ('c0', 'v8'):
            folder = root / 'stratified' / label
            directories.append(folder); statuses.append(folder / 'progress.json')
        return directories, statuses

    def deliver(timer=False):
        events = []
        def emit(key, event):
            if key not in seen:
                seen.add(key); events.append(event)
        manifest = read(root / 'pipeline_manifest.json') or {}
        for name, stage in manifest.get('stages', {}).items():
            if stage.get('status') in ('completed', 'failed', 'skipped'):
                emit('stage:' + name + ':' + stage['status'], dict(event='pipeline_stage_' + stage['status'],
                    stage=name, **{k: stage.get(k) for k in ('returncode', 'finished_utc', 'wall_seconds', 'error', 'log')}))
        for path in paths()[1]:
            value = read(path)
            if not value:
                continue
            for job in value.get('completed', value.get('jobs', [])):
                if job.get('returncode'):
                    key = str(path) + ':' + str((job.get('task'), job.get('profile'), job.get('seed')))
                    emit(key, dict(event='actual_shard_error', source=str(path),
                        job={k: job.get(k) for k in ('task', 'profile', 'seed', 'returncode', 'output')}))
        complete = read(root / 'complete.json')
        if complete:
            emit('pipeline_complete', dict(event='pipeline_complete', root=str(root),
                **{k: complete.get(k) for k in ('status', 'finished_utc', 'all_started_processes_waited', 'scores_used_for_adaptive_decision')}))
        if timer:
            emit('deadline:' + a.deadline_utc, dict(event='planned_deadline_reached', root=str(root),
                deadline_utc=a.deadline_utc, pipeline_status=manifest.get('status'),
                stage_statuses={k: v.get('status') for k, v in manifest.get('stages', {}).items()}))
        if not events:
            return False
        a.seen.write_text(json.dumps(sorted(seen), indent=2) + '\n')
        for event in events:
            print(json.dumps(event, ensure_ascii=False), flush=True)
        return True

    if deliver():
        return
    lib = ctypes.CDLL('libc.so.6', use_errno=True)
    fd = lib.inotify_init1(0)
    if fd < 0:
        raise OSError(ctypes.get_errno(), 'inotify_init1')
    watched = set()
    def attach():
        for path in paths()[0]:
            if path.is_dir() and path not in watched:
                if lib.inotify_add_watch(fd, os.fsencode(path), 0x8 | 0x80 | 0x100) < 0:
                    raise OSError(ctypes.get_errno(), str(path))
                watched.add(path)
    try:
        attach()
        if deliver():
            return
        while True:
            timeout = max(0., (deadline - datetime.now(timezone.utc)).total_seconds()) if deadline is not None else None
            ready, _, _ = select.select([fd], [], [], timeout)
            if not ready:
                deadline = None
                if deliver(timer=True):
                    return
                continue
            os.read(fd, 65536)
            attach()
            if deliver():
                return
    finally:
        os.close(fd)


if __name__ == '__main__':
    main()
