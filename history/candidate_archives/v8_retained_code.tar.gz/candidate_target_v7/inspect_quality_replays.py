"""Offline developer diagnostics; never imported by runtime policy."""
from pathlib import Path
import argparse,json,cv2,numpy as np
from scipy.spatial.transform import Rotation
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--case');a=p.parse_args();out=a.root/'candidate_target_v7/diagnostics';out.mkdir(parents=True,exist_ok=True)
def norm(a,b):return float(np.linalg.norm(np.asarray(a)-np.asarray(b)))
results=[]
for name,focus in [('replay_basic16003_v7',3),('replay_medium16006_v7',0)]:
 if a.case is not None and name!=a.case:continue
 folder=a.root/name
 if not (folder/'result.json').exists():print('PENDING',name,flush=True);continue
 result=json.loads((folder/'result.json').read_text());P=[json.loads(l) for l in next((folder/'policy_trace').glob('*.jsonl')).open()];D={r['step']:r for r in map(json.loads,(folder/'diagnostic/trace.jsonl').open())};metrics=[]
 for row in P:
  step=row['step'];request=row['request'];b=int(request.get('batch_index',0));n=int(request.get('count',0));start=int(request.get('source_start_index',0));before=D[step-1]['after'] if step>0 and step-1 in D else D[step]['after'];box=row['perception']['target_box'];held=row['perception'].get('held',{});gt=np.asarray(before['cookie_positions'])[start:start+n]
  eef=np.asarray(row['eef']);R=Rotation.from_quat(np.r_[eef[4:7],eef[3]]).as_matrix();gt_tool=None if not len(gt) else R.T@(gt.mean(0)-eef[:3]);est=held.get('center_tool');error=None if est is None or gt_tool is None else np.asarray(est)-gt_tool
  metric={'step':step,'batch':b,'count':n,'stage':request.get('stage'),'phase':row['phase'],'eef_position':eef[:3].tolist(),'target_box':box,'target_error_before_mm':norm(box['center'],before['target_position'])*1000,'target_truth_before':before['target_position'],'target_yaw_truth_before':before.get('target_quaternion'),'held':held,'held_center_tool_truth_before':None if gt_tool is None else gt_tool.tolist(),'held_center_tool_error_mm':None if error is None else (error*1000).tolist(),'official_count_before':before['cookies_in_target'],'official_mask_before':before.get('cookies_in_target_mask'),'batch_official_count_before':None if not len(gt) else int(np.asarray(before.get('cookies_in_target_mask',[]))[start:start+n].sum()),'finger_touch':row['force'][12:14]}
  metrics.append(metric)
 summary={k:result.get(k) for k in ['score','max_score','success','steps','cookies_in_source','failure_reason','policy_failure_reason','policy_reports','offline_batch_audit']}
 report={'name':name,'scope':'new development replay of former test case; not a replacement for original formal result','summary':summary,'metrics':metrics,'original_run_ownership':'frozen V7, diagnostic truth outer only'};results.append(report)
 (out/(name+'_metrics.json')).write_text(json.dumps(report,indent=2))
 # Focus on the transition into placement, then release and its native outcome.
 chosen=[]
 for stage in ['TRANSPORT','PLACE','OPEN','RETRACT']:
  candidates=[row for row in P if int(row['request'].get('batch_index',0))==focus and row['request'].get('stage')==stage]
  if not candidates:continue
  if stage in ['TRANSPORT','PLACE']:chosen.extend([candidates[0],candidates[-1]])
  else:chosen.append(candidates[-1])
 unique={row['step']:row for row in chosen};chosen=list(unique.values())
 if not chosen:continue
 images=[];caps={cam:cv2.VideoCapture(str(folder/'diagnostic'/(cam+'.mp4'))) for cam in ['front','left_wrist','right_wrist']}
 for row in chosen:
  strip=[]
  for cam,cap in caps.items():
   cap.set(cv2.CAP_PROP_POS_FRAMES,row['step']);ok,im=cap.read()
   if not ok:continue
   im=cv2.resize(im,(384,384),interpolation=cv2.INTER_NEAREST);im=cv2.copyMakeBorder(im,24,0,0,0,cv2.BORDER_CONSTANT,value=(245,245,245));cv2.putText(im,f"{row['step']} b{row['request'].get('batch_index')} {row['request'].get('stage')} {cam}",(4,16),cv2.FONT_HERSHEY_SIMPLEX,.42,(20,20,20),1,cv2.LINE_AA);strip.append(im)
  if len(strip)==3:images.append(np.concatenate(strip,axis=1))
 for cap in caps.values():cap.release()
 if images:cv2.imwrite(str(out/(name+'_focus.png')),np.concatenate(images,axis=0))
 print('COMPLETED',name,'score',result['score'],'steps',result['steps'],'selected_frames',[r['step'] for r in chosen],flush=True)
(a.root/'candidate_target_v7/diagnostics/quality_replay_summary.json').write_text(json.dumps([{'name':r['name'],'scope':r['scope'],'summary':r['summary']} for r in results],indent=2))
