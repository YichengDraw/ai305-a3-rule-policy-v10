"""Isolated frozen task parents; import wiring is the only change."""
