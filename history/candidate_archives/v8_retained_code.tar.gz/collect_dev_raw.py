"""Collect a completed 45-case development grid for portable verification."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from launch_core_cases import runtime_files


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    a=parser.parse_args()
    root=a.root.resolve()
    read=lambda p:json.loads(p.read_text())
    code=root/'code'
    launch=read(root/'protocol.json')
    dependencies=launch.get('runtime_dependencies',runtime_files(code))
    payload=dict(source_directory=str(root),collected_at_utc=datetime.now(timezone.utc).isoformat(),
        launch=launch,complete=read(root/'complete.json'),
        policy_code_sha256={n:hashlib.sha256((code/n).read_bytes()).hexdigest()
            for n in dependencies},
        snapshot_sha256={n:hashlib.sha256((code/n).read_bytes()).hexdigest() for n in launch.get('code_sha256',dependencies)},
        cases=[dict(name=p.parent.name,summary_status=read(p.parent/'summary.json')['status'],protocol=read(p.parent/'protocol.json'),
            episodes=[json.loads(s) for s in p.read_text().splitlines() if s.strip()])
            for p in sorted(root.glob('2x*/*episodes.jsonl'))])
    a.output.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(output=str(a.output.resolve()),cases=len(payload['cases']))))


if __name__=='__main__':
    main()
