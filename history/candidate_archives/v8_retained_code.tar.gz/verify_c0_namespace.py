"""Verify frozen-parent AST equivalence after only qualifying sibling imports."""
from __future__ import annotations
import argparse
import ast
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace


class Normalize(ast.NodeTransformer):
    def visit_ImportFrom(self,node):
        if node.level==1 and node.module in ('perception','rule_controller','placement_audit'):node.level=0
        return node


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--parents',type=Path,required=True)
    p.add_argument('--candidate',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();rows=[]
    for version in ('v6','v7'):
        manifest=json.loads((a.parents/version/'code_manifest.json').read_text());hashes=manifest.get('sha256',manifest)
        for name in ('policy.py','perception.py','rule_controller.py','placement_audit.py'):
            old=(a.parents/version/name).read_text();new=(a.candidate/'c0_parents'/version/name).read_text()
            digest=hashlib.sha256(old.encode()).hexdigest();assert digest==hashes[name]
            assert ast.dump(ast.parse(old),include_attributes=False)==ast.dump(Normalize().visit(ast.parse(new)),include_attributes=False)
            rows.append(dict(parent=version,file=name,parent_sha256=digest,namespace_sha256=hashlib.sha256(new.encode()).hexdigest(),ast_equal_except_import_level=True))
    class Parent:
        finished=False;phase_name='TEST';controller=None
        def __init__(self,name):self.name=name
        def reset(self,context):self.task=context.task
        def act(self,observation,task=''):return self.name
        def close(self):pass
    tree=ast.parse((a.candidate/'policy.py').read_text())
    tree.body=[node for node in tree.body if not isinstance(node,(ast.Import,ast.ImportFrom))]
    namespace={'make_v6':lambda:Parent('v6'),'make_v7':lambda:Parent('v7')}
    exec(compile(tree,'c0_router_ast_test','exec'),namespace)
    policy=namespace['make_policy']()
    checks=[]
    for task,expected in (('transfer 10 cookies into target box','v7'),
                          ('Transfer 20 cookies from source column 1, grasp 1 then9','v6'),
                          ('Transfer 20 cookies from source column 4, grasp9 then1','v6')):
        policy.reset(SimpleNamespace(task=task))
        assert policy.selected_parent==expected and policy.act({})==expected
        checks.append(dict(task=task,parent=expected))
    payload=dict(status='passed',scope='AST equality and task-only router test; no simulation',files=rows,router_checks=checks)
    a.output.write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps({'files_checked':len(rows),'router_checks':len(checks),'status':'passed'}))


if __name__=='__main__':main()
