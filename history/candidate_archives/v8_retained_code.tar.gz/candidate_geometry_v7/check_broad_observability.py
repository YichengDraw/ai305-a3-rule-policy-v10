"""Diagnose broad-end evidence from recorded public wrist frames only."""
from pathlib import Path
import sys,json,cv2,numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'parents/v7'));from perception import VisionEstimator,_project
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
results=[];fig,axes=plt.subplots(2,2,figsize=(11,6),constrained_layout=True)
for ax,(name,step) in zip(axes.ravel(),[('replay_medium16006_v7',0),('replay_medium16006_v7',24),('replay_basic16003_v7',5),('replay_basic16003_v7',24)]):
 folder=root/name;P=list(map(json.loads,next((folder/'policy_trace').glob('*.jsonl')).open()));D={x['step']:x for x in map(json.loads,(folder/'diagnostic/trace.jsonl').open())};row=min(P,key=lambda p:abs(p['step']-step));obs=dict(D[step]['observation_before']);cap=cv2.VideoCapture(str(folder/'diagnostic/left_wrist.mp4'));cap.set(cv2.CAP_PROP_POS_FRAMES,step);ok,im=cap.read();cap.release();assert ok;image=im[:,:,::-1]
 v=VisionEstimator(load_config(resource_root()/'configs/cookie_2x10.yaml'));cal=row['perception']['wrist_calibration'];v.wrist_mount=np.asarray(cal.get('mount_parameters',np.zeros(7)));nom=v._robot_cameras(obs)['left_wrist'];camera=v._v6_wrist_camera(nom,obs)
 group=row['perception']['group'];center=np.asarray(group['center']);R=np.asarray(group['rotation']);n=int(row['request']['count']);xs=np.linspace(-.052,.052,521);ys=np.arange(n)*.0088333333333-(n-1)*.0088333333333/2;points=np.array([center+R@np.array([x,y+d,v.cookie_half[2]]) for x in xs for y in ys for d in [-.0005,0,.0005]])
 uv,z=_project(points,camera,image.shape);valid=(z>0)&(uv[:,0]>1)&(uv[:,0]<image.shape[1]-2)&(uv[:,1]>1)&(uv[:,1]<image.shape[0]-2);patch=cv2.remap(image,uv[:,0].astype(np.float32).reshape(len(xs),n*3),uv[:,1].astype(np.float32).reshape(len(xs),n*3),cv2.INTER_LINEAR);support=(v._v6_color_mask(patch)>0).astype(float);visible=valid.reshape(len(xs),n*3);values=np.sum(support*visible,axis=1)/np.maximum(np.sum(visible,axis=1),1);coverage=visible.mean(1);values[coverage<.8]=np.nan
 expected=[]
 for side in [-1,1]:
  k=int(np.argmin(abs(xs-side*v.cookie_half[0])));expected.append({'side':side,'nominal_endpoint_relative_m':float(xs[k]),'color_support':None if not np.isfinite(values[k]) else float(values[k]),'pixel_visibility':float(coverage[k])})
 result={'case':name,'frame':step,'count':n,'row_confidence':row['perception'].get('local_align',{}).get('confidence'),'group_center':center.tolist(),'expected_broad_endpoints':expected,'profile_x_m':xs.tolist(),'profile_cookie_support':[None if not np.isfinite(x) else float(x) for x in values],'profile_visible_fraction':coverage.tolist()};results.append(result)
 ax.plot(xs*1000,values,label='cookie color support');ax.plot(xs*1000,coverage,alpha=.5,label='visible fraction');ax.axvline(-25,color='r',ls='--');ax.axvline(25,color='r',ls='--');ax.set(title=f'{name} frame{step}',xlabel='broad x relative to estimated center (mm)',ylabel='fraction',ylim=(-.05,1.05));ax.legend(fontsize=7)
(root/'candidate_geometry_v7/broad_observability.json').write_text(json.dumps(results,indent=2));fig.savefig(root/'candidate_geometry_v7/broad_observability.png',dpi=150);print('4 same-frame broad profiles saved')
