"""Same recorded public frames, alternative source-box width-view selection."""
from pathlib import Path
from types import SimpleNamespace
import sys,json,importlib.util,cv2,numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'parents/v7'));from perception import VisionEstimator as Parent
spec=importlib.util.spec_from_file_location('geometry_candidate',root/'candidate_geometry_v7/perception.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
results=[]
for name in ['replay_medium16006_v7','replay_basic16003_v7']:
 folder=root/name;policy=list(map(json.loads,next((folder/'policy_trace').glob('*.jsonl')).open()));D={x['step']:x for x in map(json.loads,(folder/'diagnostic/trace.jsonl').open())};caps={cam:cv2.VideoCapture(str(folder/'diagnostic'/(cam+'.mp4'))) for cam in ['front','left_wrist','right_wrist']}
 images={}
 for step in [0,5,10,15,20,24]:
  for cam,cap in caps.items():cap.set(cv2.CAP_PROP_POS_FRAMES,step);ok,im=cap.read();assert ok;images[(step,cam)]=im[:,:,::-1]
 for cap in caps.values():cap.release()
 for label,cls in [('parent',Parent),('G1',m.VisionEstimator)]:
  v=cls(load_config(resource_root()/'configs/cookie_2x10.yaml'));v.reset(SimpleNamespace(task='transfer 20 cookies'))
  for step in [0,5,10,15,20,24]:
   row=min(policy,key=lambda p:abs(p['step']-step));obs=dict(D[step]['observation_before']);obs.update({'observation.images.'+cam:images[(step,cam)] for cam in caps});request=dict(row['request']);request['force_refit']=True;v.step=0 if step==0 else step;estimate=v.estimate(obs,request);group=estimate['group'];n=int(request.get('count',0));start=int(request.get('source_start_index',0));before=D[max(0,step-1)]['after'];truth=np.asarray(before['cookie_positions'])[start:start+n];error=None if n<1 else (np.asarray(group['center'])-truth.mean(0))*1000
   record={'recording':name,'version':label,'frame':step,'count':n,'source_camera':estimate['source_box'].get('pose_camera'),'source_center':np.asarray(estimate['source_box']['center']).tolist(),'group_center':np.asarray(group['center']).tolist(),'group_error_mm':None if error is None else error.tolist(),'group_confidence':group['confidence'],'local_align':estimate['local_align'],'target_error_mm':float(np.linalg.norm(np.asarray(estimate['target_box']['center'])-np.asarray(before['target_position']))*1000)};results.append(record);print(name,label,step,record['source_camera'],None if error is None else np.round(error,2).tolist(),round(record['target_error_mm'],2),flush=True)
def encode(x):
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,np.generic):return x.item()
 return str(x)
(root/'candidate_geometry_v7/source_width_public_replay.json').write_text(json.dumps(results,default=encode,indent=2))
