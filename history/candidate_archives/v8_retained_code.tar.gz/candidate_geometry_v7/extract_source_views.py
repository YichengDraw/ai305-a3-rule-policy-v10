from pathlib import Path
import cv2,numpy as np
root=Path('/nvme-ssd1/zhaoyicheng/a3_rule_policy_v8_20261102');case=root/'replay_medium16006_v7';out=root/'candidate_geometry_v7';out.mkdir(exist_ok=True)
caps={n:cv2.VideoCapture(str(case/'diagnostic'/(n+'.mp4'))) for n in ['front','left_wrist','right_wrist']};rows=[]
for step in [0,24,55,75]:
 imgs=[]
 for name,cap in caps.items():
  cap.set(cv2.CAP_PROP_POS_FRAMES,step);ok,im=cap.read();assert ok
  im=cv2.resize(im,(384,384),interpolation=cv2.INTER_NEAREST);im=cv2.copyMakeBorder(im,24,0,0,0,cv2.BORDER_CONSTANT,value=(245,245,245));cv2.putText(im,f'{step} {name}',(4,16),cv2.FONT_HERSHEY_SIMPLEX,.45,(20,20,20),1);imgs.append(im)
 rows.append(np.concatenate(imgs,axis=1))
for cap in caps.values():cap.release()
cv2.imwrite(str(out/'medium16006_source_views.png'),np.concatenate(rows,axis=0));print(out/'medium16006_source_views.png')
