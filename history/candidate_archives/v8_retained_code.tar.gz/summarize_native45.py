"""Independent native45 comparison using official terminal count and success."""
from __future__ import annotations
import argparse
from fractions import Fraction
import json
from pathlib import Path
from historical_core_reference import metrics

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--candidate',type=Path,required=True);p.add_argument('--reference',type=Path,required=True)
    p.add_argument('--output-stem',type=Path,required=True);a=p.parse_args()
    ref=json.loads(a.reference.read_text());data=json.loads(a.candidate.read_text());assert ref['new_experiment'] is False
    assert data['complete']['status']=='completed' and len(data['complete']['jobs'])==45 and all(not j['returncode'] for j in data['complete']['jobs'])
    assert data['launch']['scope']=='v8_native45_development' and data['launch']['offline_ground_truth_audit'] is False
    assert data['snapshot_sha256']==data['launch']['code_sha256']
    key=lambda r:(r['task'],r['profile'],r['seed'],5 if r['task']=='2x5' else r['randomization']['first_grasp_count'])
    old={key(c['episodes'][0]):c['episodes'][0] for c in ref['cases']};new={};cases=[]
    terminal={'grasp_reports','final_expert_phase','target_column_counts','cookies_in_target','cookies_in_source'}
    for case in data['cases']:
        assert len(case['episodes'])==1 and case['summary_status']=='completed'
        row=case['episodes'][0];q=case['protocol'];k=key(row);assert k in old and k not in new
        assert row['max_steps']==old[k]['max_steps']==(500 if row['task']=='2x5' else 3200)
        assert row['score']==row['cookies_in_target'] and isinstance(row['success'],bool)
        assert q['strict_policy_completion'] is row['strict_policy_completion'] is False
        assert q['success_hold_steps']==row['success_hold_steps']==5
        assert q['source_column']=='1' and row['source_column']==1 and q['render_cameras'] is True
        assert q['offline_ground_truth_audit'] is False and q['policy']==data['launch']['policy']
        assert row['task_instruction']==old[k]['task_instruction']
        initial=lambda x:{n:v for n,v in x['randomization'].items() if n not in terminal}
        assert initial(row)==initial(old[k]),(k,'initial scene differs')
        for name,digest in data['policy_code_sha256'].items():
            mapped='policy_module' if name=='policy.py' else ('runtime/'+name if '/' in name else name)
            assert q['code_sha256'].get(mapped,q['code_sha256'].get('runtime/'+name))==digest
        new[k]=row;cases.append(dict(task=k[0],profile=k[1],seed=k[2],n=k[3],old_count=old[k]['cookies_in_target'],new_count=row['cookies_in_target'],old_success=old[k]['success'],new_success=row['success']))
    assert len(new)==45 and set(new)==set(old)
    before,after=metrics(list(old.values())),metrics(list(new.values()))
    cells=[dict(task=t,profile=p,old=metrics([r for k,r in old.items() if k[:2]==(t,p)]),new=metrics([r for k,r in new.items() if k[:2]==(t,p)])) for t in ('2x5','2x10') for p in ('basic','medium','advanced')]
    for label,value in (('old',before),('new',after)):
        primary=sum((Fraction(c[label]['final_count_sum'],c[label]['episodes']) for c in cells),Fraction())/6
        value['equal_six_cell_mean_final_count']=float(primary)
        value['equal_six_cell_mean_final_count_fraction']=str(primary)
        value['equal_six_cell_official_success_rate']=sum(c[label]['official_success_rate'] for c in cells)/6
    matched=[(old[k],new[k]) for k in old if old[k]['success'] and new[k]['success']]
    matched_time=dict(episodes=len(matched),old_mean_steps=sum(x['steps'] for x,y in matched)/len(matched) if matched else None,
        new_mean_steps=sum(y['steps'] for x,y in matched)/len(matched) if matched else None)
    payload=dict(scope='development_native45_vs_historical_C0',reference_new_experiment=False,old=before,new=after,cells=cells,pairs=cases,
        primary_metric='equal mean of six raw final-count cell means',matched_success_time=matched_time,
        primary_mean_count_delta=after['equal_six_cell_mean_final_count']-before['equal_six_cell_mean_final_count'],
        pooled_mean_count_delta=after['mean_final_count']-before['mean_final_count'],validation=dict(unique_cases=45,all_returncodes_zero=True,initial_scenes_match=True,runtime_hashes_match=True,official_contract_matches=True),raw_evidence=str(a.candidate.resolve()))
    a.output_stem.with_suffix('.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    lines=['# Native45开发覆盖','', '2×5各档5例，2×10各档n0–9共10例；500/3200步，官方非严格、hold5。C0为历史记录按任务重组，候选为新开发运行。','',
        '| 任务 / 档位 | C0块/回合 | 候选块/回合 | C0成功 | 候选成功 |','|---|---:|---:|---:|---:|']
    for c in cells:
        x,y=c['old'],c['new'];lines.append(f"| {c['task']} / {c['profile']} | {x['mean_final_count']:.4f} | {y['mean_final_count']:.4f} | {x['successes']}/{x['episodes']} | {y['successes']}/{y['episodes']} |")
    lines+=['',f"主指标：六格等权原始数量{before['equal_six_cell_mean_final_count']:.4f} → {after['equal_six_cell_mean_final_count']:.4f}块/回合。",
        f"全45回合直接平均数量{before['mean_final_count']:.4f} → {after['mean_final_count']:.4f}块/回合；归一化完成{before['normalized_completion']:.2%} → {after['normalized_completion']:.2%}；官方成功{before['successes']}/45 → {after['successes']}/45。",'', '本组任务数为15个2×5、30个2×10，选择按六格等权原始数量；pooled45指标单列。自然新测试保持六格各20，单独报告。']
    a.output_stem.with_suffix('.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'old':before,'new':after}))

if __name__=='__main__':main()
