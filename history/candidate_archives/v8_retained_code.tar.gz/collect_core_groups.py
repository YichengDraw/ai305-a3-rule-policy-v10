"""Portable original core result/protocol records and server-side trace indices."""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path

def index(path):
    if not path.exists():return None
    s=path.stat();return dict(path=str(path),bytes=s.st_size,mtime_utc=datetime.fromtimestamp(s.st_mtime,timezone.utc).isoformat())

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--roots',type=Path,nargs='+',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    groups=[]
    for given in a.roots:
        root=given.resolve();launch=json.loads((root/'protocol.json').read_text());done=json.loads((root/'complete.json').read_text())
        assert done['status']=='completed' and all(not j['returncode'] for j in done['jobs'])
        for name,digest in launch['code_sha256'].items():assert hashlib.sha256((root/'code'/name).read_bytes()).hexdigest()==digest
        cases=[]
        for j in launch['jobs']:
            folder=root/f"{j['task']}_{j['profile']}_{j['seed']}_n{j['n']}"
            case=dict(label=j['label'],source_directory=str(folder),
                result=json.loads((folder/'result.json').read_text()),
                protocol=json.loads((folder/'development_protocol.json').read_text()),
                original_json_sha256={n:hashlib.sha256((folder/n).read_bytes()).hexdigest() for n in ('result.json','development_protocol.json')},
                trace_index={n:index(folder/'diagnostic'/n) for n in ('frames.jsonl','recording.json','front.mp4','left_wrist.mp4','right_wrist.mp4','trace.jsonl','success_diagnostics.json')},
                public_policy_trace=index(folder/'policy_trace'/f"seed_{j['seed']}.jsonl"),log=index(root/(folder.name+'.log')))
            if (folder/'diagnostic/recording.json').exists():case['recording']=json.loads((folder/'diagnostic/recording.json').read_text())
            cases.append(case)
        groups.append(dict(name=root.name,source_directory=str(root),launch=launch,complete=done,cases=cases))
    payload=dict(scope='completed_development_core_only',collected_utc=datetime.now(timezone.utc).isoformat(),groups=groups,
        total_cases=sum(len(g['cases']) for g in groups),media_and_step_traces_copied=False,
        note='Original result/protocol fields embedded unchanged; RGB/quality traces stay on server with explicit synchronization metadata.')
    a.output.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'groups':len(groups),'cases':payload['total_cases']}))

if __name__=='__main__':main()
