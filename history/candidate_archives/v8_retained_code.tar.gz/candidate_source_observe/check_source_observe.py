"""Completed public-state replay and evaluator-only view projection; no physics."""
from pathlib import Path
from types import SimpleNamespace
import ast,copy,json
import numpy as np
import mujoco
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from rule_controller import RuleController,CANONICAL
root=Path(__file__).resolve().parents[1]
record=json.loads((root/'source_observe_diagnosis/source_observe_public_state.json').read_text())
config=load_config(resource_root()/'configs/cookie_2x10.yaml')
c=RuleController(config);c.reset(SimpleNamespace(task='Transfer 20 cookies from source column 1. Grasp 4 cookies first.'));c.set_variant('b');c.batch_index=1
c._last_safe_pose=(np.asarray(record['eef'][:3]),CANONICAL.copy())
scene=record['perception'];view,rotation=c._source_observation_target(scene)
assert view[1]>.25 and np.linalg.norm(view[:2]-np.asarray(record['eef'])[:2])>.15
assert c._source_observe_basis['planned_indices']==list(range(4,10))
first=view.copy();c._source_recovery_count=1;other,_=c._source_observation_target(scene)
assert abs(first[0]-other[0]-.008)<1e-12 and np.allclose(first[1:],other[1:])
# Fallback stays in a genuinely reached source neighborhood.
c._safe_source_high=(np.array([.11,.24,.804]),CANONICAL.copy())
fallback,_=c._source_observation_target({'source_box':{'confidence':0.}})
assert fallback[1]==.24
# Verify all existing method definitions and dispatcher blocks except SELECT.
def parts(path):
 tree=ast.parse(path.read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef));methods={n.name:ast.dump(n,include_attributes=False) for n in cls.body if isinstance(n,ast.FunctionDef)}
 act=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='act')
 blocks={ast.unparse(n.test):ast.dump(n,include_attributes=False) for n in act.body if isinstance(n,ast.If)}
 return methods,blocks
old,oldblocks=parts(root/'candidate_mt_v7/rule_controller.py');new,newblocks=parts(Path(__file__).with_name('rule_controller.py'))
assert [k for k in old if old[k]!=new[k]]==['act']
assert [k for k in oldblocks if oldblocks[k]!=newblocks[k]]==["self.stage == 'SELECT'"]
for name in ['policy.py','perception.py','placement_audit.py']:
 assert (Path(__file__).parent/name).read_bytes()==(root/'candidate_mt_v7'/name).read_bytes()
result={'passed':4,'public_case_step':record['step'],'original_target_region_eef':record['eef'][:3],
        'new_source_view':first.tolist(),'new_source_indices':list(range(4,10)),
        'only_existing_dispatch_change':'SELECT observation target helper',
        'source_observe_servo_and_wait_unchanged':True,'simulation_steps':0,'policy_truth_access':False}
projection=root/'source_observe_diagnosis/source_observe_projection_inputs.json'
if projection.exists():
 q=json.loads(projection.read_text());old_eef=np.asarray(q['eef_position']);old_rot=np.asarray(q['eef_rotation']).reshape(3,3)
 camera_pos=np.asarray(q['camera_position']);camera_rot=np.asarray(q['camera_rotation']).reshape(3,3)
 mount=old_rot.T@(camera_pos-old_eef);mount_rot=old_rot.T@camera_rot
 future_pos=first+rotation@mount;future_rot=rotation@mount_rot
 points=np.asarray(q['requested_top_corners']);p=(points-future_pos)@future_rot;depth=-p[:,2];h,w=q['shape'][:2];f=h/2/np.tan(np.deg2rad(q['fovy'])/2)
 uv=np.column_stack([(w-1)/2+f*p[:,0]/np.maximum(depth,1e-5),(h-1)/2-f*p[:,1]/np.maximum(depth,1e-5)])
 fraction=float(np.mean((depth>0)&(uv[:,0]>0)&(uv[:,0]<w)&(uv[:,1]>0)&(uv[:,1]<h)))
 result['offline_predicted_left_wrist_top_corner_visible_fraction']=fraction
 result['projection_scope']='evaluator-owned fixed camera mount/world points, only offline diagnosis'
 assert fraction>.9
 result['passed']+=1
print(json.dumps(result,indent=2));(Path(__file__).with_name('source_observe_checks.json')).write_text(json.dumps(result,indent=2)+'\n')
