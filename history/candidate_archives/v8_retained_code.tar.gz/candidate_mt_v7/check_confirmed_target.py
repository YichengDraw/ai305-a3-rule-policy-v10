"""Public-data regression for the actual basic16003 pre-place target view."""
from pathlib import Path
import sys,json,copy,importlib.util
from types import SimpleNamespace
import numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'candidate_mt_v7'))
from rule_controller import RuleController
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
spec=importlib.util.spec_from_file_location('old_target_controller',root/'parents/v7/rule_controller.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
record=json.loads((root/'candidate_target_v7/diagnostics/replay_basic16003_v7_metrics.json').read_text());row=next(x for x in record['metrics'] if x['step']==336);old=next(x for x in record['summary']['policy_reports'] if x.get('batch_index')==3)['target_box_reference'];candidate=row['target_box'];config=load_config(resource_root()/'configs/cookie_2x10.yaml')
def make(cls):
 c=cls(config);c.reset(SimpleNamespace(task='Transfer 20 cookies from source column 1. Grasp 0 cookies first.'));c.batch_index=3;c.total_steps=337;c.current_report={};c._target_box_reference=copy.deepcopy(old);c._held_center_local=np.asarray(row['held']['center_tool']);c._held_cookie_local=np.asarray(row['held']['rotation_tool']);return c
c=make(RuleController);o=make(m.RuleController);c._place_pose({'target_box':candidate},.04);o._place_pose({'target_box':candidate},.04)
assert np.allclose(c._target_box_reference['center'],candidate['center'])
assert np.allclose(o._target_box_reference['center'],old['center'])
c._place_box_frozen=True;locked=copy.deepcopy(c._target_box_reference);new={**candidate,'center':(np.asarray(candidate['center'])+[.01,0,0]).tolist()};c._place_pose({'target_box':new},0.);assert c._target_box_reference==locked
u=make(RuleController);u._place_pose({'target_box':{**candidate,'anchor_confirmed':False}},.04);assert u._target_box_reference==old
low=make(RuleController);low._place_pose({'target_box':{**candidate,'confidence':.4}},.04);assert low._target_box_reference==old
result={'actual_public_case':'basic16003 b3 step336, confirmed close wrist with rim .5417/conf .8704','old_target_reference_retained':o._target_box_reference,'new_target_reference':c._target_box_reference,'new_confident_reference_consumed':True,'frozen_descent_reference_preserved':True,'unconfirmed_partial_view_retains_old':True,'low_confidence_still_retains_old':True,'simulation_steps':0,'ground_truth_used_for_control':False}
(root/'candidate_mt_v7/confirmed_target_contract.json').write_text(json.dumps(result,indent=2));print('4 public-view/frozen-target contracts passed; zero simulation steps')
