import ast,json
from pathlib import Path
root=Path(__file__).resolve().parents[1];here=Path(__file__).resolve().parent
for name in ['policy.py','perception.py','placement_audit.py']:
 assert (here/name).read_bytes()==(root/'parents/v7'/name).read_bytes()==(root/'candidate_motion_v7'/name).read_bytes()
def methods(path):
 tree=ast.parse(path.read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef));return {n.name:ast.dump(n,include_attributes=False) for n in cls.body if isinstance(n,ast.FunctionDef)}
a=methods(root/'candidate_motion_v7/rule_controller.py');b=methods(here/'rule_controller.py');t=methods(root/'candidate_target_v7/rule_controller.py')
changed=[name for name in a if a[name]!=b[name]]
assert changed==['_place_pose'] and b['_place_pose']==t['_place_pose']
result={'non_motion_modules_identical_to_v7':True,'controller_relative_to_m1_changed_methods':changed,'place_pose_identical_to_t1':True,'m2_and_geometry_branch_not_included':True,'simulation_steps':0}
(here/'composition_check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
