"""Temporary build/import test; no frozen candidate and no physics execution."""
from pathlib import Path
import json,tempfile
from build_task_router import build_task_router,verify_package
root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='a3_task_router_check_') as tmp:
    metadata,verification=build_task_router(root/'candidate_source_observe_so2',Path(tmp)/'task_route',label='SO2',check_imports=True)
    (Path(tmp)/'task_route'/'non_runtime_check_helper.py').write_text('# external verification helper, not a policy dependency\n')
    verify_package(Path(tmp)/'task_route',metadata)
    result={'extra_root_helper_does_not_change_runtime_closure':True,'status':'passed','scope':'temporary self-contained task-router build/import; directory removed after checks',
            'runtime_files':len(verification['runtime_dependencies']),
            'parent_module_ast_checks':len(verification['files']),
            'router_ast_matches_c0_except_imports_and_metadata':verification['router_ast_matches_c0_except_imports_and_metadata'],
            'runtime_import_checks':verification['runtime_import_checks'],
            'environment_created':False,'formal_frozen_created':False,'simulation_steps':0}
(root/'task_router_builder_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
