"""Write the V8 report from completed independent audits and official rows."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from audit_natural import metrics


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--formal-root',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();root=a.formal_root.resolve();base=Path(__file__).resolve().parent
    read=lambda name:json.loads((root/'audits'/name).read_text())
    natural=read('natural_full_verification.json')
    supplement=read('supplement_full_verification.json')
    strat=read('stratified_verification.json')
    raw=read('natural_full_raw.json')
    assert natural['phase']=='full' and natural['validation']['episodes_per_policy']==120
    assert supplement['validation']['episodes_per_policy']==120
    assert strat['validation']['episodes_per_policy']==30
    rows={k:raw['policies'][k]['merged_episodes'] for k in ('c0','v8')}
    for label in rows:
        assert metrics(rows[label])==natural['results'][label]['overall']
    old,new=[natural['results'][k]['overall'] for k in ('c0','v8')]
    summary=dict(protocol='official native500/3200, non-strict, hold5',natural=natural,
                 supplementary_500=supplement,stratified_18000=strat)
    a.output.with_suffix('.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    rate=lambda m:f"{m['successes']}/{m['episodes']}（{m['official_success_rate']:.2%}）"
    lines=['# V8策略优化与最终评测','',
        f"新种子配对评测每版120局，V8平均终态数量为{new['mean_final_count']:.4f}块/局，完成率{new['normalized_completion']:.2%}，官方成功{rate(new)}。参照C0采用2×5 V7、2×10 V6，平均{old['mean_final_count']:.4f}块/局，完成率{old['normalized_completion']:.2%}，成功{rate(old)}。",'',
        '## 最终策略与评测范围','',
        'V8按任务选择：2×5沿用V7；2×10采用动作衔接、近景目标位置接入、首次源列几何跨批缓存和明确源观察位。输入为三路RGB彩色图像、公开机器人状态与力反馈、固定物体几何模型（CAD）。策略工厂为`policy:make_policy_b`，代码见[冻结策略](frozen_policy_v8/README.md)。','',
        '按助教2026-11-02确认口径，主表2×5最多500步、2×10最多3200步，均使用源盒第1列，官方非严格模式、稳定5步，保留任务原生条件。数量取官方回合结束时的有效入盒数量；成功取官方评测程序结果。完成率为每局“有效数量/本任务总数”的平均。','',
        '自然抽样使用17000–17019，basic、medium、advanced三档扰动，每任务每档20局。先每格5局，再保持策略和评测代码不变补至20局，前30局原行复用。冻结、开发选型与预算约定分别见[选型记录](final_selection.json)和[评测约定](evaluation_protocol.md)。','',
        '## 自然抽样正式结果','',
        '| 任务 | 策略 | 平均有效数量（块/局） | 完成率 | 官方成功 |',
        '|---|---|---:|---:|---:|']
    for task in ('2x5','2x10'):
        for label in ('c0','v8'):
            m=metrics([r for r in rows[label] if r['task']==task])
            lines.append(f"| {task} | {label.upper()} | {m['mean_final_count']:.4f} | {m['normalized_completion']:.2%} | {rate(m)} |")
    for label,m in [('c0',old),('v8',new)]:
        lines.append(f"| 合计 | {label.upper()} | {m['mean_final_count']:.4f} | {m['normalized_completion']:.2%} | {rate(m)} |")
    lines+=['',f"配对变化：平均数量{natural['mean_count_delta']:+.4f}块/局，完成率{natural['normalized_delta_pp']:+.2f}个百分点，官方成功率{natural['success_delta_pp']:+.2f}个百分点。",'',
        '| 任务 / 扰动 | C0块/局 | V8块/局 | C0成功 | V8成功 |',
        '|---|---:|---:|---:|---:|']
    cells={k:{(c['task'],c['profile']):c for c in natural['results'][k]['cells']} for k in ('c0','v8')}
    for key in cells['c0']:
        x,y=[cells[k][key] for k in ('c0','v8')]
        lines.append(f"| {key[0]} / {key[1]} | {x['mean_final_count']:.3f} | {y['mean_final_count']:.3f} | {x['successes']}/20 | {y['successes']}/20 |")
    adv_old,adv_new=[cells[k][('2x10','advanced')] for k in ('c0','v8')]
    basic_old,basic_new=[cells[k][('2x10','basic')] for k in ('c0','v8')]
    lines+=['',f"主要数量增益来自2×10 advanced：{adv_old['mean_final_count']:.2f}→{adv_new['mean_final_count']:.2f}块/局，官方成功{adv_old['successes']}/20→{adv_new['successes']}/20。2×10 basic平均数量提高，官方成功为{basic_old['successes']}/20→{basic_new['successes']}/20；这部分成功回退保留在主表。"]
    lines+=['','## 开发验收与两张独立附表','',
        '动作与放置修复将两个正常四批样例从566/575步压到490/500步，并保持20块官方成功；basic放置样例从10块恢复20块、363步成功。加入源列缓存和源观察后，八例开发集达到15.5块/局、6/8成功。开发覆盖按数量选出最终任务组合，六格等权数量10.7833→11.15块/局；该选型使用14000/16000系列，与正式新种子分开。正常四批430–450步仍是后续开发目标。','',
        '| 独立表 | 策略 | 平均有效数量 | 完成率 | 官方成功 |',
        '|---|---|---:|---:|---:|']
    for title,data in [('统一500步补充',supplement),('18000按首批数量分层',strat)]:
        for label in ('c0','v8'):
            m=data['results'][label]['overall']
            lines.append(f"| {title} | {label.upper()} | {m['mean_final_count']:.4f} | {m['normalized_completion']:.2%} | {rate(m)} |")
    lines+=['','统一500步补充表复用自然主表的2×5原行，额外运行2×10。分层诊断的首批抓取参数为\\(n\\)：1–9表示第一批抓取的数量，0按官方规则整组拿取。18000系列覆盖\\(n=0,\\ldots,9\\)与三档扰动，各版30局。两表的逐档与逐参数记录见[500步审计](formal_v8_17000/audits/supplement_full_verification.md)和[分层审计](formal_v8_17000/audits/stratified_verification.md)。']
    positives={k:[r for r in supplement['results'][k]['episodes'] if r['task']=='2x10' and r['n']>0] for k in ('c0','v8')}
    assert len(positives['c0'])==len(positives['v8'])
    lines+=['',f"统一500步补充中，首批参数\\(n>0\\)的2×10共有{len(positives['v8'])}局/版，官方成功由{sum(r['official_success'] for r in positives['c0'])}局增至{sum(r['official_success'] for r in positives['v8'])}局。"]
    def strat_n(label,n):
        group=[r for r in strat['results'][label]['episodes'] if r['n']==n]
        return sum(r['official_final_count'] for r in group)/len(group),sum(r['official_success'] for r in group),len(group)
    n1,n2,n9=strat_n('v8',1),strat_n('v8',2),strat_n('v8',9)
    lines+=['',f"分层结果中，\\(n=1\\)平均{n1[0]:.2f}块；\\(n=2\\)由C0的{strat_n('c0',2)[0]:.2f}降至{n2[0]:.2f}块；\\(n=9\\)官方成功{n9[1]}/{n9[2]}。这些抓取构成是当前的主要剩余难点，每个参数包含三档各一局。"]
    lines+=['',
        '全部正式分片正常结束；独立审计核对了初始场景、实际运行依赖、预算、官方终态字段与原始行合并。详细证据见[自然主表审计](formal_v8_17000/audits/natural_full_verification.md)，原始记录位于同目录的JSON归档。官方仿真源码版本为`0729068ee1e75a562cfbc4f2c83ab9539cf75081`。']
    a.output.write_text('\n'.join(lines)+'\n')
    print(json.dumps({'output':str(a.output),'v8':new,'c0':old},ensure_ascii=False))


if __name__=='__main__':main()
