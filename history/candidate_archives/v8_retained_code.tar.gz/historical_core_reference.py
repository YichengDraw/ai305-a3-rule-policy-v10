"""Exact task-only recombination of old official rows; no new experiment."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from launch_core_cases import CASES

def metrics(rows):
    n=len(rows)
    return dict(episodes=n,final_count_sum=sum(r['cookies_in_target'] for r in rows),
        mean_final_count=sum(r['cookies_in_target'] for r in rows)/n,
        normalized_completion=sum(r['cookies_in_target']/r['max_score'] for r in rows)/n,
        successes=sum(r['success'] for r in rows),official_success_rate=sum(r['success'] for r in rows)/n,
        mean_steps=sum(r['steps'] for r in rows)/n)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--v6',type=Path,required=True);p.add_argument('--v7',type=Path,required=True)
    p.add_argument('--max-steps-2x10',type=int,choices=(500,3200),required=True)
    p.add_argument('--output-stem',type=Path,required=True);a=p.parse_args()
    sources={'v6':a.v6,'v7':a.v7};lookup={k:{(r['task'],r['profile'],r['seed']):r for r in
        (json.loads(x) for x in path.read_text().splitlines() if x.strip())} for k,path in sources.items()}
    cases=[]
    for label,task,profile,seed,n in CASES:
        parent='v7' if task=='2x5' else'v6';row=lookup[parent][task,profile,seed]
        assert row['max_steps']==(500 if task=='2x5' else a.max_steps_2x10)
        assert not row['strict_policy_completion'] and row['success_hold_steps']==5 and row['source_column']==1
        if task=='2x10':assert row['randomization']['first_grasp_count']==n
        cases.append(dict(label=label,task=task,profile=profile,seed=seed,n=n,parent=parent,
            source=str(sources[parent].resolve()),row=row))
    payload=dict(scope='development_historical_recombination_only',new_experiment=False,
        code_route={'2x5':'v7B','2x10':'v6B'},protocol=dict(max_steps_by_task={'2x5':500,'2x10':a.max_steps_2x10},
        strict_policy_completion=False,success_hold_steps=5,source_column=1),cases=cases,
        overall=metrics([c['row'] for c in cases]))
    a.output_stem.with_suffix('.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    lines=['# C0八例历史对照','',f'2×5=500、2×10={a.max_steps_2x10}步；按任务重组原16000记录，供开发比较。new_experiment=false。','',
        '| 案例 | 父版本 | 官方数量 | 官方成功 | 步数 |','|---|---|---:|---:|---:|']
    for c in cases:
        r=c['row'];lines.append(f"| {c['label']} | {c['parent']} | {r['cookies_in_target']}/{r['max_score']} | {int(r['success'])} | {r['steps']} |")
    m=payload['overall'];lines+=['',f"平均终态数量{m['mean_final_count']:.4f}块/回合；归一化完成{m['normalized_completion']:.2%}；官方成功{m['successes']}/8。"]
    a.output_stem.with_suffix('.md').write_text('\n'.join(lines)+'\n');print(json.dumps(m))

if __name__=='__main__':main()
