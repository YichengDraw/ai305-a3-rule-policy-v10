"""Verify the 12 development pairs and produce a compact oracle comparison."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from batch_metrics import diagnostic_summary

INITIAL_FIELDS = ("source_column", "seed", "task_instruction", "configuration", "parameters",
                  "cookie_color", "cameras", "light_diffuse", "source_bin_position",
                  "target_bin_position", "target_bin_quaternion", "cookie_positions",
                  "cookie_quaternions", "reset_options")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output-prefix", type=Path, required=True)
    args = parser.parse_args()
    original = json.loads((args.input / "summary.json").read_text())
    records, protocols = {}, []
    for path in args.input.glob("*/result.json"):
        result = json.loads(path.read_text())
        protocol = json.loads((path.parent / "development_protocol.json").read_text())
        assert result["development_scope"] and not protocol["controller_changed_by_evaluator"]
        assert protocol["policy_code"].endswith("/frozen_policy_v5")
        key = (protocol["task"], protocol["profile"], protocol["seed"], int(protocol["first_grasp"]))
        oracle = bool(protocol["oracle_source_target"])
        assert (key, oracle) not in records
        records[key, oracle] = (result, path)
        protocols.append(protocol)
        # Derive timing from saved offline samples for runs started before the
        # first_attempt_step field was added. Preserve every raw file unchanged.
        measurements = path.parent / "offline_truth" / f"seed_{protocol['seed']}_measurements.jsonl"
        first_attempts = {}
        if measurements.exists():
            for line in measurements.read_text().splitlines():
                row = json.loads(line)
                if row["phase"] not in ("SELECT", "DONE"):
                    first_attempts.setdefault(row["batch_index"], row["step"])
        for batch in result.get("offline_batch_audit", []):
            if batch.get("first_attempt_step") is None:
                batch["first_attempt_step"] = first_attempts.get(batch["batch_index"])
    assert len(records) == 24 and len(protocols) == 24
    pairs, visual_rows, oracle_rows = [], [], []
    for source in original["pairs"]:
        key = (source["task"], source["profile"], source["seed"], source["first_grasp"])
        visual, vp = records[key, False]
        oracle, op = records[key, True]
        assert all(visual["randomization"].get(field) == oracle["randomization"].get(field)
                   for field in INITIAL_FIELDS), key
        visual_rows.append(visual)
        oracle_rows.append(oracle)
        fields = ("score", "max_score", "success", "steps", "phase", "policy_failure_reason")
        pairs.append(dict(task=key[0], profile=key[1], seed=key[2], first_grasp=key[3],
                          visual={field: visual.get(field) for field in fields},
                          oracle={field: oracle.get(field) for field in fields},
                          visual_source=str(vp), oracle_source=str(op),
                          initial_randomization_identical=True))
    payload = dict(scope="selected_development_cases_only", pairs=pairs,
                   unchanged_controller="frozen_policy_v5/rule_controller.py",
                   oracle_replacements=["selected source-group geometry", "target-bin pose"],
                   retained_visual_components=["held count", "target count", "force feedback", "timeouts", "recovery logic"],
                   visual_successes=sum(row["success"] for row in visual_rows),
                   oracle_successes=sum(row["success"] for row in oracle_rows),
                   visual_mean_completion=sum(row["score"]/row["max_score"] for row in visual_rows)/12,
                   oracle_mean_completion=sum(row["score"]/row["max_score"] for row in oracle_rows)/12,
                   visual_batch_diagnostics=diagnostic_summary(visual_rows),
                   oracle_batch_diagnostics=diagnostic_summary(oracle_rows),
                   wall_seconds=original["wall_seconds"],
                   verification="24 unique outputs; 12 paired initial scene/appearance/robot-camera randomizations equal; all results explicitly development/oracle labeled")
    args.output_prefix.with_suffix(".json").write_text(json.dumps(payload, ensure_ascii=False, indent=2)+"\n")
    lines = ["# V5 几何估计的离线 oracle 对照", "",
             "选取12个开发条件，各重跑一次普通视觉策略和一次几何真值替换；旧v5控制器保持不变。",
             "仅替换选中源组的位置、朝向、宽度和目标盒位姿；数量视觉判断、力反馈、时限与恢复逻辑保留。",
             "2×5上限500步，2×10上限3200步。两边的初始几何、相机与外观随机化逐对一致。", "",
             "| 任务 | 难度 | seed | 首夹n | 视觉入盒/要求 | 视觉成功 | oracle入盒/要求 | oracle成功 |",
             "|---|---|---:|---:|---:|---|---:|---|"]
    for pair in pairs:
        a,b=pair["visual"],pair["oracle"]
        lines.append(f"| {pair['task']} | {pair['profile']} | {pair['seed']} | {pair['first_grasp']} | "
                     f"{a['score']}/{a['max_score']} | {'是' if a['success'] else '否'} | "
                     f"{b['score']}/{b['max_score']} | {'是' if b['success'] else '否'} |")
    lines += ["", f"普通视觉成功{payload['visual_successes']}/12，逐回合平均完成率{payload['visual_mean_completion']:.2%}；"
              f"几何oracle成功{payload['oracle_successes']}/12，逐回合平均完成率{payload['oracle_mean_completion']:.2%}。",
              "六个2×5样本都由5/10提高到10/10；n=0的两个2×10样本两边都成功。",
              "唯一oracle失败为2×10/medium/seed12000/n9：前三批已入盒19块，最后单片在下插阶段持续受阻。",
              "这些选择过的开发案例支持优先改善几何定位；正式成绩由冻结后的新种子评测给出。",
              "", "批次真值审计与控制器自报分开保存在JSON。早期诊断缺失的first_attempt_step由已有离线采样重建，原始记录保持原样。",
              f"运行墙钟{payload['wall_seconds']:.2f}秒；原始记录目录：`{args.input}`。"]
    args.output_prefix.with_suffix(".md").write_text("\n".join(lines)+"\n")
    print(json.dumps({key:payload[key] for key in ("visual_successes","oracle_successes","visual_mean_completion","oracle_mean_completion","verification")},ensure_ascii=False))


if __name__ == "__main__":
    main()
