"""Write the final Chinese readout from independently verified terminal results."""
from __future__ import annotations
import argparse
import json
from pathlib import Path


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--verification',type=Path,required=True)
    p.add_argument('--formal-root',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    root=a.output.resolve()
    audit=json.loads(a.verification.read_text())
    assert audit['validation']['raw_shards']==240
    assert audit['validation']['raw_and_merged_identical']
    old,new=(audit['results'][v]['overall'] for v in ('v5','v6'))
    summary=json.loads((a.formal_root/'comparison/paired_results.json').read_text())
    for label,m in (('old',old),('new',new)):
        for key in ('completion_rate','success_rate'):
            assert abs(summary[label][key]-m[key])<1e-12
    rows=[json.loads(s) for s in (a.formal_root/'v6/final_default/episodes.jsonl').read_text().splitlines()]
    full_failed=sum(r['cookies_in_target']==r['max_score'] and not r['success'] for r in rows)
    reasons=audit['results']['v6']['failure_reason_counts']
    termination=dict(budget_exhausted=reasons.get('max_steps_exceeded',0),
        recovery_no_progress=reasons.get('previously reached recovery path made no observed progress',0),
        source_unobserved=reasons.get('source group unavailable with no useful reached observation pose',0),
        slot_or_hold=sum(v for k,v in reasons.items() if 'slots not one-to-one' in k))
    termination['count_or_source_contract']=120-new['successes']-sum(termination.values())
    dev=json.loads((root/'dev_comparison_r6.json').read_text())
    manifest=json.loads((root/'frozen_policy_v6/code_manifest.json').read_text())
    payload=dict(protocol=summary['protocol'],selected_policy='policy:make_policy_b',
        old=old,new=new,completion_delta_pp=audit['completion_delta_pp'],
        success_delta_pp=audit['success_delta_pp'],cells=audit['results']['v6']['cells'],
        paired=audit['paired'],full_target_but_official_failure=full_failed,
        failure_termination_counts=termination,
        validation=audit['validation'],code_manifest=manifest,
        development_summary={k:v['overall'] for k,v in dev['results'].items()})
    (root/'final_results.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    pct=lambda x:f'{x:.2%}'
    lines=['# 策略优化与最终评测','',
        f"**优化后完成率 {pct(new['completion_rate'])}，官方成功率 {pct(new['success_rate'])}（{new['successes']}/120）。** 同种子旧版分别为 {pct(old['completion_rate'])}、{pct(old['success_rate'])}（{old['successes']}/120），提升 {audit['completion_delta_pp']:.2f} 和 {audit['success_delta_pp']:.2f} 个百分点。",'',
        '## 正式结果','',
        '来源列1，2×5最多500步、2×10最多3200步；basic、medium、advanced各20回合。新种子15000–15019在开发选版后运行，两版共240回合。采用原官方非严格判定，连续满足成功条件5步。','',
        '完成率先计算每回合终态入盒数占要求数量的比例，再平均120回合；成功率直接统计官方success。2×5的非严格判定可在释放前结束，释放与落座诊断另列。','',
        '| 任务 / 难度 | 旧版完成率 | 新版完成率 | 旧版成功 | 新版成功 |',
        '|---|---:|---:|---:|---:|']
    for x,y in zip(audit['results']['v5']['cells'],audit['results']['v6']['cells']):
        lines.append(f"| {x['task']} / {x['profile']} | {pct(x['completion_rate'])} | {pct(y['completion_rate'])} | {x['successes']}/20 | {y['successes']}/20 |")
    lines+=['',
        f"按饼干数量加权的完成率为 {pct(new['cookie_weighted_completion_rate'])}（{new['final_cookies']}/{new['capacity']}）；旧版为 {pct(old['cookie_weighted_completion_rate'])}。",'',
        f"同场景最终得分提高、持平、下降分别为 {audit['paired']['score_improved']}、{audit['paired']['score_equal']}、{audit['paired']['score_worsened']} 回合；新增官方成功 {audit['paired']['success_gained']} 回合，丢失 {audit['paired']['success_lost']} 回合。",'',
        '旧版本次在15000系列重跑；上轮13000系列成绩保留在原报告。所有失败、超时和恢复耗时均计入。','',
        '## 采用的修改','',
        '- 接触前用腕图重新定位端部与邻片缝隙，先修粗偏差，再联合调整夹爪位置和开口。',
        '- 用真实夹指几何换算开度，检查实测开口、双侧力和压紧宽度；卡住后保持开度，沿实际到达的路径退回。',
        '- 夹起后重新测量持物相对夹爪的姿态；近目标时用同一腕相机估计盒子与持物，减小相对误差。',
        '- 搬运高位完成对准后固定完整下放位置和旋转，防止接触后的轮廓拟合波动让目标继续变化。',
        '- 修复多路径点恢复的错误停滞判断、空条纹数组异常、单片对齐无限等待和持物低位横穿盒沿的恢复路径。','',
        '运行输入为三路RGB、公开机器人状态及力反馈；固定CAD提供已知尺寸。评测器独立使用物体真值与接触图计分和诊断；真实相机参数用于离线标定核对及初始随机场景记录。','',
        '## 开发选择与剩余问题','',
        '| 同条件45回合开发对照 | 完成率 | 官方成功 |',
        '|---|---:|---:|']
    for key,label in (('v5','旧规则策略'),('v6b','视觉与控制优化，正式采用'),('v6c','加入放置审计硬门控')):
        m=dev['results'][key]['overall'];lines.append(f"| {label} | {pct(m['completion_rate'])} | {m['successes']}/45 |")
    lines+=['',
        '放置审计在单片、相邻组遮挡等条件下仍常给出未知，硬门控限制了后续批次。正式策略保留审计作为诊断，未经确认的放置记为未验证；门控与目标附近重放分支保留在对照工厂中。开发阶段已用严格上下界确定选版，全部45回合收齐后再次确认；正式测试开始后保持策略固定。','',
        f"正式新版仍有 {120-new['successes']} 回合未通过官方成功，其中 {full_failed} 回合终态入盒数量已满。官方整局成功还检查源区数量及相应任务的槽位、分列和稳定条件。具体程序终因保存在验收JSON中。",'',
        f"按程序终止字段统计：{termination['budget_exhausted']}局用尽步数，{termination['recovery_no_progress']}局恢复路径未继续进展，{termination['source_unobserved']}局源组和有效观察位姿不可用，{termination['slot_or_hold']}局未满足槽位或保持判定，{termination['count_or_source_contract']}局未满足目标或源区数量条件。",'',
        '## 批次诊断','',
        '| 诊断 | 旧版 | 新版 |','|---|---:|---:|']
    for title,key in (('观测到有效整批抓起','valid_grasp'),('观测到有效整批放置','valid_placement'),
                      ('此前各批有效条件下的后批放置','subsequent_given_prior_valid'),('局部恢复，程序明确结算','local_recovery')):
        cells=[]
        for m in (old,new):
            d=m['diagnostics'][key];rate='未知' if d['rate'] is None else pct(d['rate'])
            cells.append(f"{d['passed']}/{d['observed']}（{rate}，未知{d['unknown']}）")
        lines.append(f"| {title} | {' | '.join(cells)} |")
    lines+=['',
        '前三项由评测器在阶段切换及每5步采样，用真实几何和接触关系独立计算；放置检查覆盖入盒、直立、落座、静止和释放。抓取、放置率以实际尝试的非零计划批次为分母；条件后批率只统计此前各批已有效放置后开始的后续批次。最后一项来自控制器明确结算的恢复事件，分母为具有明确结算标签的事件，缺失标签保留未知。','',
        '## 验证与复现','',
        '独立验收逐一核对240个单回合分片：两版各120个唯一条件，六格各20，初始随机场景、预算、原官方分数、冻结代码和合并文件一致，全部子进程正常退出。16组控制器回归检查已通过。','',
        f"- [最终数据]({root/'final_results.json'}) · [独立验收]({a.verification.resolve()})",
        f"- [使用说明]({root/'README.md'}) · [冻结代码]({root/'frozen_policy_v6/policy.py'}) · [运行环境]({root/'run_environment.json'})",
        f"- [逐回合记录]({a.formal_root.resolve()/'v6/final_default/episodes.jsonl'}) · [开发对照]({root/'dev_comparison_r6.md'})",
        f"- [数据来源与接口范围]({root/'perception_interfaces.md'}) · [完整开发记录]({root/'status.md'})",'',
        f"[策略代码、原始记录与复现工具包]({root/'rule_policy_v6_release_20261102.zip'})",'',
        '正式入口为`policy:make_policy_b`；目录根部的`make_policy`也指向该版本。冻结副本保留正式运行时的原始代码。官方模拟器提交为`0729068ee1e75a562cfbc4f2c83ab9539cf75081`。']
    (root/'最终评测结果.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:payload[k] for k in ('completion_delta_pp','success_delta_pp','full_target_but_official_failure')},ensure_ascii=False))


if __name__=='__main__':main()
