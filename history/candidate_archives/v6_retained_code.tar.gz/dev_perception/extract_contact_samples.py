from pathlib import Path
import json,cv2
base=Path('/nvme-ssd2/zhaoyicheng/a3_rule_policy_v6_20261102');outbase=Path(__file__).resolve().parent
for case in ['2x5_basic_12001_n5','2x5_advanced_12001_n5']:
 root=base/'dev_c_smoke_r4'/case;out=outbase/('c4_'+case);out.mkdir(exist_ok=True);policy={};wanted={0,4,5,9,10}
 allrows=[json.loads(l) for l in next((root/'policy_trace').glob('*.jsonl')).open()]
 for r in allrows:
  if r['request']['stage']=='TRANSPORT' and r['request']['batch_index']==1:wanted.add(r['step'])
  if r['request']['stage']=='PLACE' and r['request']['batch_index']==1:wanted.add(r['step'])
  if r['request']['stage']=='TRANSPORT' and r['request']['batch_index']==0 and r.get('perception',{}).get('held',{}).get('pose_confidence',0)>.6:wanted.add(r['step'])
 for r in allrows:
  if r['step'] in wanted:policy[r['step']]=r
 rows={};before={};previous=None
 for line in (root/'diagnostic/trace.jsonl').open():
  r=json.loads(line)
  if r['step'] in wanted:rows[r['step']]={'observation':r['observation_before'],'policy':policy.get(r['step'],{}),'stage':r['expert_phase']};before[r['step']]=previous if previous is not None else r['after']
  previous=r['after']
 for camera in ['front','left_wrist','right_wrist']:
  cap=cv2.VideoCapture(str(root/'diagnostic'/(camera+'.mp4')))
  for i in rows:
   cap.set(cv2.CAP_PROP_POS_FRAMES,i);ok,image=cap.read()
   if ok:cv2.imwrite(str(out/(str(i)+'_'+camera+'.png')),image)
  cap.release()
 (out/'samples.json').write_text(json.dumps(rows));(out/'offline_before.json').write_text(json.dumps(before));print(case,sorted(rows))
