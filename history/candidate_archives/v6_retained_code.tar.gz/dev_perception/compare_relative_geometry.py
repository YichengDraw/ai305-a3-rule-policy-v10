from pathlib import Path
import sys,json,cv2,numpy as np
from scipy.spatial.transform import Rotation
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root));sys.path.insert(0,str(root/'dev_perception'))
from perception import VisionEstimator as Base
from perception_bevel_candidate import VisionEstimator as Candidate
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
results=[]
def load_observation(folder,item,idx):
 obs=dict(item['observation'])
 for camera in ['front','left_wrist','right_wrist']:obs['observation.images.'+camera]=cv2.imread(str(folder/(str(idx)+'_'+camera+'.png')))[:,:,::-1]
 return obs
for case in ['2x5_basic_12001_n5','2x5_advanced_12001_n5']:
 folder=root/'dev_perception'/('c4_'+case);samples=json.load(open(folder/'samples.json'));truth=json.load(open(folder/'offline_before.json'));variants={name:cls(load_config(resource_root()/'configs/cookie_batch.yaml')) for name,cls in [('current',Base),('candidate',Candidate)]}
 for idx in [0,5,10]:
  item=samples[str(idx)];obs=load_observation(folder,item,idx)
  for v in variants.values():v.step=idx if idx==0 else idx-1;v.estimate(obs,item['policy']['request'])
 for idx in sorted(map(int,samples)):
  if idx<60:continue
  item=samples[str(idx)];obs=load_observation(folder,item,idx);request=item['policy']['request'];group=item['policy']['perception']['group'];start=request['source_start_index'];n=request['count'];gtruth=truth[str(idx)];eef,R=variants['current']._eef_rotation(obs);gtpos=np.asarray(gtruth['cookie_positions'])[start:start+n].mean(0);gtct=R.T@(gtpos-eef);qt=np.asarray(gtruth['cookie_quaternions'])[start+n//2];gtr=R.T@Rotation.from_quat(np.r_[qt[1:],qt[0]]).as_matrix();gtbox=np.asarray(gtruth['target_position']);oldheld=item['policy']['perception'].get('held') or {};number=oldheld.get('count',n);count_conf=oldheld.get('count_confidence',.7)
  row={'case':case,'frame':idx,'stage':request['stage'],'batch':request['batch_index'],'variants':{}}
  for name,v in variants.items():
   cams=v._robot_cameras(obs);cams['left_wrist']=v._v6_wrist_camera(cams['left_wrist'],obs);cams={k:v._adjust_camera(c,v.camera_adjustments.get(k,np.zeros(7))) for k,c in cams.items()}
   v.v6_target_anchor=None;v.v6_request_stage='TRANSPORT';v.boxes={'source_box':item['policy']['perception']['source_box'],'target_box':item['policy']['perception']['target_box']};boxes=v._fit_boxes(obs,cams);held=v._v6_held_observation(obs,cams,group,request,number,count_conf)
   result={'target_error_mm':((np.asarray(boxes['target_box']['center'])-gtbox)*1000).tolist(),'target_confidence':boxes['target_box']['confidence'],'target_pose_camera':boxes['target_box'].get('pose_camera'),'held_confidence':held['pose_confidence']}
   if held['center_tool'] is not None:
    world=eef+R@held['center_tool'];err_rel=(world-np.asarray(boxes['target_box']['center']))-(gtpos-gtbox)
    result.update(held_error_mm=((held['center_tool']-gtct)*1000).tolist(),relative_error_mm=(err_rel*1000).tolist(),relative_error_norm_mm=float(np.linalg.norm(err_rel)*1000),held_rotation_error_deg=float(np.rad2deg(np.linalg.norm(Rotation.from_matrix(gtr.T@held['rotation_tool']).as_rotvec()))))
   row['variants'][name]=result
  results.append(row);print(json.dumps(row),flush=True)
(root/'dev_perception/relative_geometry_comparison.json').write_text(json.dumps(results,indent=2))
