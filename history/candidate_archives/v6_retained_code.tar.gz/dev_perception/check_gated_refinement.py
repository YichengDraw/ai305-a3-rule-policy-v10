from pathlib import Path
import sys,json,cv2,numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root));from perception import VisionEstimator
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
results=[]
for case in ['2x5_basic_12001_n5','2x5_advanced_12001_n5']:
 folder=root/'dev_perception'/('c4_'+case);samples=json.load(open(folder/'samples.json'));truth=json.load(open(folder/'offline_before.json'));v=VisionEstimator(load_config(resource_root()/'configs/cookie_batch.yaml'))
 frames=[0,5,10]+[i for i in sorted(map(int,samples)) if i>200]
 for idx in frames:
  row=samples[str(idx)];obs=dict(row['observation']);request=dict(row['policy']['request'])
  for camera in ['front','left_wrist','right_wrist']:obs['observation.images.'+camera]=cv2.imread(str(folder/(str(idx)+'_'+camera+'.png')))[:,:,::-1]
  # Sparse replay skips SELECT/CLOSE frames. Restore only the recorded public
  # group hypothesis from that actual run rather than refitting absent objects.
  group=row['policy']['perception'].get('group');key=(request.get('batch_index'),request.get('source_column',1),request.get('source_start_index',0),request.get('count',5))
  if idx>200 and v.selected_group_key!=key and group is not None:
   copied={k:np.asarray(value) if k in ('center','rotation') else value for k,value in group.items()};n=request['count'];copied['centers']=np.tile(copied['center'],(n,1))+np.arange(n)[:,None]*0
   v.selected_group_key=key;v.selected_group=copied;v.v6_held_previous=None;v.v6_held_reference=None;v.v6_held_method=None;v.v6_held_generation=0;v.v6_use_bevel_held=False;v.v6_held_cache=None
  v.step=0 if idx==0 else idx-1;p=v.estimate(obs,request);h=p['held'];gt=np.asarray(truth[str(idx)]['cookie_positions'])[request['source_start_index']:request['source_start_index']+request['count']].mean(0);eef,R=v._eef_rotation(obs);boxgt=np.asarray(truth[str(idx)]['target_position']);error=None if h['center_tool'] is None else float(np.linalg.norm((eef+R@h['center_tool']-p['target_box']['center'])-(gt-boxgt))*1000)
  record={'case':case,'frame':idx,'method':h.get('geometry_method'),'generation':h.get('geometry_generation'),'pose_confidence':h['pose_confidence'],'slip_m':h.get('slip_m'),'reference_reset_reason':h.get('reference_reset_reason'),'box_camera':p['target_box'].get('pose_camera'),'box_error_mm':float(np.linalg.norm(p['target_box']['center']-boxgt)*1000),'relative_error_mm':error};results.append(record);print(json.dumps(record),flush=True)
(root/'dev_perception/gated_refinement_validation.json').write_text(json.dumps(results,indent=2))
