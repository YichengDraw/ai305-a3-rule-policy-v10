from pathlib import Path
import json,cv2
base=Path('/nvme-ssd2/zhaoyicheng/a3_rule_policy_20261102');outbase=Path(__file__).resolve().parent
cases=[('advanced_12001','dev_2x5_advanced_12001_n5_v5',[0,5,10,15,44,54,64,85,99,108,118,125,146,168,194,214,234,245]),('basic_12000','dev_2x10_basic_12000_v3',[0,5,10,15,120,185,200,220,240,260,280,300,423,438,447,457,465,590])]
for name,dirname,wanted in cases:
 root=base/dirname;out=outbase/name;out.mkdir(exist_ok=True);policy={};rows={};offline={}
 for file in (root/'policy_trace').glob('*.jsonl'):
  for line in file.open():
   r=json.loads(line)
   if r['step'] in wanted:policy[r['step']]=r
 for line in (root/'diagnostic/trace.jsonl').open():
  r=json.loads(line)
  if r['step'] in wanted:
   rows[r['step']]={'observation':r['observation_before'],'stage':r['expert_phase'],'policy':policy.get(r['step'],{})};offline[r['step']]=r['after']
 for cam in ['front','left_wrist','right_wrist']:
  cap=cv2.VideoCapture(str(root/'diagnostic'/(cam+'.mp4')))
  for i in rows:
   cap.set(cv2.CAP_PROP_POS_FRAMES,i);ok,im=cap.read()
   if ok:cv2.imwrite(str(out/(str(i)+'_'+cam+'.png')),im)
  cap.release()
 (out/'samples.json').write_text(json.dumps(rows));(out/'offline_evidence.json').write_text(json.dumps(offline));print(name,len(rows))
