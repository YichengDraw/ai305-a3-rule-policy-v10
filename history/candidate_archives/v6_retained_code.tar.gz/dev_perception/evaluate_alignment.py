from pathlib import Path
import sys,json,time,cv2,numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root));from perception import VisionEstimator
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
results=[]
for case,task,frames in [('advanced_12001','2x5',[0,5,10,15,125,146]),('basic_12000','2x10',[0,5,10,15])]:
 folder=root/'dev_perception'/case;samples=json.load(open(folder/'samples.json'));truth=json.load(open(folder/'offline_before.json'));v=VisionEstimator(load_config(resource_root()/('configs/cookie_batch.yaml' if task=='2x5' else 'configs/cookie_2x10.yaml')))
 for idx in frames:
  item=samples[str(idx)];obs=item['observation']
  for camera in ['front','left_wrist','right_wrist']:obs['observation.images.'+camera]=cv2.imread(str(folder/(str(idx)+'_'+camera+'.png')))[:,:,::-1]
  request=dict(item.get('policy',{}).get('request',{}));request.update(stage='LOCAL_ALIGN' if idx in [10,15,146] else 'APPROACH',force_refit=True)
  request.setdefault('count',5);request.setdefault('source_column',1);request.setdefault('source_start_index',0)
  if idx==0:v.step=0
  else:v.step=idx-1
  t=time.perf_counter();p=v.estimate(obs,request);elapsed=time.perf_counter()-t
  start=request['source_start_index'];n=request['count'];positions=np.array(truth[str(idx)]['cookie_positions']);gtcenter=positions[start:start+n].mean(0);gtgap=(positions[start+n-1]+positions[start+n])/2 if start+n<20 else None
  row={'case':case,'frame':idx,'wall_seconds':elapsed,'group_error_mm':((p['group']['center']-gtcenter)*1000).tolist(),'calibration':p['wrist_calibration'],'local_align':p['local_align']}
  if gtgap is not None and p['local_align'].get('rear_gap_center') is not None:row['gap_xy_error_mm']=((np.array(p['local_align']['rear_gap_center'])[:2]-gtgap[:2])*1000).tolist()
  def encode(x):
   if isinstance(x,np.ndarray):return x.tolist()
   if isinstance(x,np.generic):return x.item()
   return str(x)
  print(json.dumps(row,default=encode),flush=True);results.append(json.loads(json.dumps(row,default=encode)))
  if hasattr(v,'v6_local_debug'):
   patch=v.v6_local_debug['patch'];cv2.imwrite(str(folder/(str(idx)+'_alignment_patch.png')),cv2.resize(patch[:,:,::-1],(160,len(patch)),interpolation=cv2.INTER_NEAREST))
  alignment=p['local_align']
  if alignment.get('rear_gap_center') is not None:
   from perception import _project
   cam=v.last_cameras['left_wrist'];im=obs['observation.images.left_wrist'][:,:,::-1].copy();gap=np.asarray(alignment['rear_gap_center']);axis=np.asarray(alignment['observable_axis_world']);eef,rot=v._eef_rotation(obs)
   middle=eef+rot@np.array([0.,-.014676,0.]);opening=float(obs['observation.state'][7]);distance=.0063616+.085*opening
   sign=1 if float(rot[:,0]@axis)>0 else -1
   before=middle+sign*rot[:,0]*distance/2;before[2]=gap[2]
   after=before+np.asarray(alignment['correction_world'])+axis*(.085*(alignment['recommended_opening']-opening)/2)
   candidates=[('gap RGB',gap,(0,0,255)),('pad down-proj',before,(0,255,255)),('requested correction',after,(0,255,0))]
   if gtgap is not None:
    gt_point=np.r_[gtgap[:2],gap[2]];candidates.append(('gap GT offline',gt_point,(255,255,0)))
   scale=3;canvas=cv2.resize(im,None,fx=scale,fy=scale,interpolation=cv2.INTER_NEAREST)
   pixels=[]
   for j,(label,world,color) in enumerate(candidates):
    uv,z=_project(world[None],cam,im.shape);xy=tuple(np.rint(uv[0]*scale).astype(int));pixels.append(xy);cv2.drawMarker(canvas,xy,color,cv2.MARKER_CROSS,12,1);cv2.putText(canvas,label,(8,18+20*j),cv2.FONT_HERSHEY_SIMPLEX,.45,color,1,cv2.LINE_AA)
   cv2.arrowedLine(canvas,pixels[1],pixels[2],(0,255,0),1,tipLength=.25)
   cv2.imwrite(str(folder/(str(idx)+'_alignment_overlay.png')),canvas)

(root/'dev_perception/alignment_saved.json').write_text(json.dumps(results,indent=2))
