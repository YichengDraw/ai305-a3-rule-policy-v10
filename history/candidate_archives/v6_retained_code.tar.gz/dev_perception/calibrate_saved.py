from pathlib import Path
import sys,json,cv2,numpy as np,time
from scipy.spatial.transform import Rotation
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root));from perception import VisionEstimator
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
old=Path('/nvme-ssd2/zhaoyicheng/a3_rule_policy_20261102/dev_perception');out=root/'dev_perception';rows=[]
for name in ['basic','medium','advanced']:
 folder=old/name;m=json.load(open(folder/'metadata.json'));obs=m['observation']
 for camera in ['front','left_wrist','right_wrist']:obs['observation.images.'+camera]=cv2.imread(str(folder/(camera+'.png')))[:,:,::-1]
 v=VisionEstimator(load_config(resource_root()/'configs/cookie_batch.yaml'));cs=v._robot_cameras(obs);t=time.perf_counter();v._v6_calibrate_wrist(obs,cs['left_wrist']);elapsed=time.perf_counter()-t
 true=m['camera']['left_wrist'];nom=cs['left_wrist'];_,mount=v._eef_rotation(obs)
 tp=np.r_[mount.T@(np.array(true['pos'])-nom['pos']),Rotation.from_matrix(nom['rotation'].T@np.array(true['rotation'])).as_rotvec(),true['fovy']-nom['fovy']]
 row={'profile':name,'wall_seconds':elapsed,'calibration':v.wrist_calibration,'gt_parameters':tp.tolist(),'translation_error_mm':float(np.linalg.norm(v.wrist_mount[:3]-tp[:3])*1000),'rotation_error_deg':float(np.rad2deg(np.linalg.norm(v.wrist_mount[3:6]-tp[3:6]))),'fovy_error_deg':float(abs(v.wrist_mount[6]-tp[6]))};rows.append(row);print(json.dumps(row),flush=True)
 debug=v.v6_calibration_debug;overlay=np.zeros((256,256,3),np.uint8);overlay[:,:,0]=debug['predicted'];overlay[:,:,1]=debug['observed'];cv2.imwrite(str(out/(name+'_gripper_masks.png')),overlay)
(root/'dev_perception/calibration_saved.json').write_text(json.dumps(rows,indent=2))
