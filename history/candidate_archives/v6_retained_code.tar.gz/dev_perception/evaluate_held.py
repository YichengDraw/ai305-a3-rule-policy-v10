from pathlib import Path
import sys,json,time,cv2,numpy as np
from scipy.spatial.transform import Rotation
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root));from perception import VisionEstimator,_project
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
folder=root/'dev_perception/basic_12000';samples=json.load(open(folder/'samples.json'));truth=json.load(open(folder/'offline_before.json'));v=VisionEstimator(load_config(resource_root()/'configs/cookie_2x10.yaml'));results=[]
for idx in [0,5,185,200,220,240,280]:
 item=samples[str(idx)];obs=item['observation']
 for camera in ['front','left_wrist','right_wrist']:obs['observation.images.'+camera]=cv2.imread(str(folder/(str(idx)+'_'+camera+'.png')))[:,:,::-1]
 request=dict(item.get('policy',{}).get('request',{}));request.setdefault('count',5);request.setdefault('source_column',1);request.setdefault('source_start_index',0)
 request['stage']='APPROACH' if idx<10 else 'TRANSPORT';request['force_refit']=idx<10
 if idx==0:v.step=0
 else:v.step=idx-1
 t=time.perf_counter();p=v.estimate(obs,request);elapsed=time.perf_counter()-t;held=p['held'];eef,R=v._eef_rotation(obs)
 start=int(request.get('source_start_index',0));pos=np.array(truth[str(idx)]['cookie_positions'])[start:start+5].mean(0);ct=R.T@(pos-eef)
 q=np.asarray(truth[str(idx)]['cookie_quaternions'])[start+2];rgt=R.T@Rotation.from_quat(np.r_[q[1:],q[0]]).as_matrix();angle=None if held['rotation_tool'] is None else float(np.rad2deg(np.linalg.norm(Rotation.from_matrix(rgt.T@held['rotation_tool']).as_rotvec())))
 row={'rotation_error_deg':angle,'frame':idx,'wall_seconds':elapsed,'held':held,'gt_center_tool':ct.tolist(),'center_error_mm':None if held['center_tool'] is None else ((held['center_tool']-ct)*1000).tolist()}
 def encode(x):
  if isinstance(x,np.ndarray):return x.tolist()
  if isinstance(x,np.generic):return x.item()
  return str(x)
 print(json.dumps(row,default=encode),flush=True);results.append(json.loads(json.dumps(row,default=encode)))
 if hasattr(v,'v6_held_debug'):
  f=v.v6_held_debug;im=obs['observation.images.left_wrist'][:,:,::-1].copy();cam=v._v6_wrist_camera(v._robot_cameras(obs)['left_wrist'],obs);uv,z=_project(f['corners'],cam,im.shape);cv2.polylines(im,[np.rint(cv2.convexHull(uv.astype(np.float32))).astype(int)],True,(255,0,255),1);cv2.imwrite(str(folder/(str(idx)+'_held_fit.png')),im)
(root/'dev_perception/held_saved.json').write_text(json.dumps(results,indent=2))
