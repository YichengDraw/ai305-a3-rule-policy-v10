"""Validate and compare paired 45-case development grids from raw episode records."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

from summarize_dev_reference import metrics


PROFILES = ("basic", "medium", "advanced")
EXPECTED = {("2x5", p, s, 5) for p in PROFILES for s in range(14000, 14005)}
EXPECTED |= {("2x10", p, 14000 + n, n) for p in PROFILES for n in range(10)}
RUNTIME_FILES = ("policy.py", "perception.py", "rule_controller.py", "placement_audit.py")


def initial_randomization(row):
    # Official episode metadata also appends terminal counts/reports. Those
    # describe the outcome rather than the randomized initial scene.
    terminal = {"grasp_reports", "final_expert_phase", "target_column_counts",
                "cookies_in_target", "cookies_in_source"}
    return {name: value for name, value in row["randomization"].items() if name not in terminal}


def case_key(row):
    n = 5 if row["task"] == "2x5" else row["randomization"]["first_grasp_count"]
    return row["task"], row["profile"], row["seed"], n


def validate(data, policy, hashes, reference=None):
    complete = data["complete"]
    assert complete["status"] == "completed" and len(complete["jobs"]) == 45
    assert all(job["returncode"] == 0 for job in complete["jobs"])
    assert {(j["task"], j["profile"], j["seed"], j["n"]) for j in complete["jobs"]} == EXPECTED
    assert data["launch"]["policy"] == policy
    assert data["policy_code_sha256"] == hashes
    rows, protocols = {}, {}
    for case in data["cases"]:
        assert len(case["episodes"]) == 1
        row, protocol = case["episodes"][0], case["protocol"]
        key = case_key(row)
        assert key not in rows and key in EXPECTED
        task, profile, seed, n = key
        assert protocol["policy"] == policy
        assert protocol["tasks"] == [task] and protocol["profiles"] == [profile]
        assert protocol["seed_start"] == seed and protocol["episodes_per_cell"] == 1
        assert row["max_steps"] == (500 if task == "2x5" else 3200)
        assert protocol["max_steps_by_task"][task] == row["max_steps"]
        assert row["score"] == row["cookies_in_target"] and row["max_score"] == (10 if task == "2x5" else 20)
        assert isinstance(row["success"], bool) and 0 <= row["score"] <= row["max_score"]
        assert 0 < row["steps"] <= row["max_steps"]
        assert protocol["source_column"] == "1" and row["source_column"] == 1
        assert protocol["render_cameras"] is True and protocol["offline_ground_truth_audit"] is True
        assert protocol["strict_policy_completion"] is False and protocol["success_hold_steps"] == 5
        assert int(protocol["first_grasp_2x10"]) == n
        for filename, digest in hashes.items():
            assert protocol["code_sha256"]["policy_module" if filename == "policy.py" else filename] == digest
        audit = row["offline_batch_audit"]
        assert sum(batch["planned_count"] for batch in audit) == row["max_score"]
        assert len({batch["batch_index"] for batch in audit}) == len(audit)
        for batch in audit:
            for field in ("first_valid_grasp_step", "first_valid_placement_step", "first_attempt_step"):
                assert batch.get(field) is None or 0 <= batch[field] <= row["steps"]
        if reference is not None:
            prior = reference[key]
            assert initial_randomization(row) == initial_randomization(prior), (key, "initial randomized scene differs")
            assert row["task_instruction"] == prior["task_instruction"]
        rows[key], protocols[key] = row, protocol
    assert set(rows) == EXPECTED and len(rows) == 45
    return rows, protocols


def summarize(rows):
    values = list(rows.values())
    cells = [{"task": t, "profile": p, **metrics([r for r in values if r["task"] == t and r["profile"] == p])}
             for t in ("2x5", "2x10") for p in PROFILES]
    overall = metrics(values)
    overall["cell_macro_completion_rate"] = sum(c["completion_rate"] for c in cells) / 6
    reasons = Counter(r.get("policy_failure_reason") or r.get("failure_reason") or "no recorded reason" for r in values if not r["success"])
    return {"overall": overall, "cells": cells, "failure_reason_counts": dict(reasons)}


def paired(left, right):
    cases = []
    for key in sorted(EXPECTED):
        a, b = left[key], right[key]
        cases.append({"task": key[0], "profile": key[1], "seed": key[2], "n": key[3],
                      "score_before": a["score"], "score_after": b["score"],
                      "success_before": a["success"], "success_after": b["success"]})
    return {"score_improved": sum(c["score_after"] > c["score_before"] for c in cases),
            "score_equal": sum(c["score_after"] == c["score_before"] for c in cases),
            "score_worsened": sum(c["score_after"] < c["score_before"] for c in cases),
            "success_gained": sum(c["success_after"] and not c["success_before"] for c in cases),
            "success_lost": sum(c["success_before"] and not c["success_after"] for c in cases),
            "cases": cases}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--candidate-b", type=Path, required=True)
    parser.add_argument("--candidate-c", type=Path, required=True)
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--output-stem", type=Path, required=True)
    args = parser.parse_args()
    inputs = {"v5": args.reference, "v6b": args.candidate_b, "v6c": args.candidate_c}
    data = {name: json.loads(path.read_text()) for name, path in inputs.items()}
    snapshot_hashes = {name: hashlib.sha256((args.snapshot / name).read_bytes()).hexdigest() for name in RUNTIME_FILES}
    rows, protocols = {}, {}
    rows["v5"], protocols["v5"] = validate(data["v5"], "policy:make_policy", data["v5"]["policy_code_sha256"])
    for label, factory in (("v6b", "policy:make_policy_b"), ("v6c", "policy:make_policy_c")):
        rows[label], protocols[label] = validate(data[label], factory, snapshot_hashes, rows["v5"])
    for key in EXPECTED:
        assert protocols["v6b"][key]["code_sha256"] == protocols["v6c"][key]["code_sha256"]
        for field in ("evaluation_script", "batch_metrics.py", "diagnostic_support.py"):
            assert protocols["v5"][key]["code_sha256"][field] == protocols["v6b"][key]["code_sha256"][field]
    results = {name: {"factory": data[name]["launch"]["policy"], "source_directory": data[name]["source_directory"],
                      "raw_evidence": str(inputs[name].resolve()), "wall_seconds": data[name]["complete"]["wall_seconds"],
                      **summarize(rows[name])} for name in rows}
    payload = {"development_only": True, "cases_per_policy": 45,
               "validation": {"unique_cases_per_policy": 45, "missing": 0, "duplicates": 0,
                              "all_returncodes_zero": True, "identical_initial_randomization": True,
                              "identical_evaluator": True, "b_c_identical_runtime_snapshot": True,
                              "candidate_code_sha256": snapshot_hashes},
               "budgets": {"2x5": 500, "2x10": 3200}, "results": results,
               "paired": {"v5_to_v6b": paired(rows["v5"], rows["v6b"]),
                          "v5_to_v6c": paired(rows["v5"], rows["v6c"]),
                          "v6b_to_v6c": paired(rows["v6b"], rows["v6c"])},
               "diagnostic_scope": "Evaluator-owned truth sampled at transitions and every five controls. Recovery requires explicit event success labels. Official success and terminal count are unchanged."}
    args.output_stem.with_suffix(".json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n")
    pct = lambda x: "未知" if x is None else f"{x:.2%}"
    lines = ["# 同条件 45 次开发对照", "",
             "每版 45 个条件：来源列 1；2×5 三档各 5 次、500 步；2×10 三档各 10 次、3200 步，首夹数覆盖 0–9。",
             "官方非严格判定，连续保持 5 步。完成率按回合等权计算。", "",
             "| 策略 | 完成率 | 成功率 | 饼干加权完成率 | DONE 后官方失败 |",
             "|---|---:|---:|---:|---:|"]
    for name, result in results.items():
        m, d = result["overall"], result["overall"]["diagnostics"]
        lines.append(f"| {name} | {pct(m['completion_rate'])} | {m['successes']}/45（{pct(m['success_rate'])}） | {m['final_cookies']}/{m['capacity']}（{pct(m['cookie_weighted_completion_rate'])}） | {d['done_but_official_failure']}/{d['done_episodes']} |")
    lines += ["", "| 任务 / 难度 | v5 完成 / 成功 | v6b 完成 / 成功 | v6c 完成 / 成功 |",
              "|---|---:|---:|---:|"]
    for i in range(6):
        cell = results["v5"]["cells"][i]
        values = [results[name]["cells"][i] for name in results]
        lines.append(f"| {cell['task']} / {cell['profile']} | " + " | ".join(f"{pct(c['completion_rate'])} / {c['successes']}/{c['episodes']}" for c in values) + " |")
    lines += ["", "| 离线真实诊断 | v5 | v6b | v6c |", "|---|---:|---:|---:|"]
    for title, key in (("有效整批抓取", "valid_grasp"), ("有效整批放置", "valid_placement"),
                       ("前批有效条件下的后批放置", "subsequent_given_prior_valid"), ("局部恢复成功", "local_recovery")):
        values = [result["overall"]["diagnostics"][key] for result in results.values()]
        lines.append(f"| {title} | " + " | ".join(f"{m['passed']}/{m['observed']}，{pct(m['rate'])}；未知 {m['unknown']}" for m in values) + " |")
    lines += ["", "| 配对变化 | 得分升 / 平 / 降 | 官方成功新增 / 丢失 |", "|---|---:|---:|"]
    for name, pair in payload["paired"].items():
        lines.append(f"| {name} | {pair['score_improved']} / {pair['score_equal']} / {pair['score_worsened']} | {pair['success_gained']} / {pair['success_lost']} |")
    lines += ["", "三组均已核对 45 个唯一条件、返回码、种子、预算、初始随机化与逐回合原字段。b/c 使用相同四份运行代码，区别为工厂选择的策略阶段。",
              "离线诊断按阶段切换与每 5 步采样；恢复率按明确成功标签计算，缺失标签保留未知。这组结果用于开发选版。"]
    args.output_stem.with_suffix(".md").write_text("\n".join(lines) + "\n")
    print(json.dumps({name: {k: r["overall"][k] for k in ("completion_rate", "successes", "success_rate", "final_cookies")} for name, r in results.items()}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
