from pathlib import Path
import sys,json,cv2,numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from perception import VisionEstimator
from placement_audit import PlacementAuditor,_project
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
folder=root/'dev_c_smoke_r4/2x10_basic_12011_n1'
trace={r['step']:r for r in map(json.loads,(folder/'diagnostic/trace.jsonl').read_text().splitlines())};policy={r['step']:r for r in map(json.loads,next((folder/'policy_trace').glob('*.jsonl')).read_text().splitlines())}
caps={name:cv2.VideoCapture(str(folder/'diagnostic'/f'{name}.mp4')) for name in ('front','left_wrist','right_wrist')}
def obs_at(idx):
 obs=dict(trace[idx]['observation_before'])
 for name,cap in caps.items():cap.set(cv2.CAP_PROP_POS_FRAMES,idx);ok,im=cap.read();assert ok;obs['observation.images.'+name]=im[:,:,::-1]
 return obs
config=load_config(resource_root()/'configs/cookie_2x10.yaml');v=VisionEstimator(config);v.estimate(obs_at(0),policy[0]['request']);audit=PlacementAuditor(config,color_mask=v._v6_color_mask)
for idx in (100,120,150,250,270):
 obs=obs_at(idx);row=policy[idx];cs=v._robot_cameras(obs)
 for name,cam in list(cs.items()):
  if name=='left_wrist':cs[name]=v._v6_wrist_camera(cam,obs)
  elif name in v.camera_adjustments:cs[name]=v._adjust_camera(cam,v.camera_adjustments[name])
 p=audit.estimate(obs,cs,row['perception']['target_box'],row['request'],row['perception'].get('held'))
 print('FIT_PARAMETERS',audit.debug.get('parameters'),flush=True)
 print(idx,'chrom',audit.episode_chrom,'reference',audit.held_reference,'result',p,flush=True)
 if idx==250:
  for view in audit.debug.get('views',[]):
   name=view['name'].split('@')[0];im=obs['observation.images.'+name][:,:,::-1].copy();cv2.polylines(im,[np.rint(view['polygon']).astype(np.int32)],True,(0,255,0),1)
   uv,z=_project(audit.debug['corners'],view['camera'],im.shape);cv2.polylines(im,[np.rint(cv2.convexHull(uv.astype(np.float32))).astype(np.int32)],True,(255,0,255),1);cv2.imwrite(str(root/'dev_placement'/f'isolated_n1_250_{name}.png'),im)
