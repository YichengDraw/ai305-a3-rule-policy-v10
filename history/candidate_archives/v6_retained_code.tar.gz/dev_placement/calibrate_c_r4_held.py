from pathlib import Path
import sys,json,cv2,time,numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from perception import VisionEstimator
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
from placement_audit import _project
records=[]
for name in (sys.argv[1:] or ('2x5_basic_12001_n5','2x10_basic_12011_n1','2x10_basic_12019_n9','2x10_basic_12010_n0')):
 folder=root/'dev_c_smoke_r4'/name
 trace={r['step']:r for r in map(json.loads,(folder/'diagnostic/trace.jsonl').read_text().splitlines())}
 policy={r['step']:r for r in map(json.loads,next((folder/'policy_trace').glob('*.jsonl')).read_text().splitlines())}
 gt={r['step']:r for r in map(json.loads,next((folder/'offline_truth').glob('*measurements.jsonl')).read_text().splitlines())}
 videos={camera:cv2.VideoCapture(str(folder/'diagnostic'/f'{camera}.mp4')) for camera in ('front','left_wrist','right_wrist')}
 config=load_config(resource_root()/'configs'/('cookie_2x10.yaml' if '2x10' in name else 'cookie_batch.yaml'))
 vision=VisionEstimator(config)
 started=time.perf_counter()
 for idx,row in sorted(policy.items()):
  obs=dict(trace[idx]['observation_before'])
  for camera,cap in videos.items():
   cap.set(cv2.CAP_PROP_POS_FRAMES,idx);ok,image=cap.read();assert ok
   obs['observation.images.'+camera]=image[:,:,::-1]
  vision.step=0 if idx==0 else idx-1
  p=vision.estimate(obs,row['request']);audit=vision.placement_auditor.estimate(obs,vision.last_cameras,p['target_box'],row['request'],row['perception'].get('held'))
  if row['request']['stage'] not in ('OPEN','RETRACT','VERIFY','TARGET_OBSERVE'):continue
  near=min(gt,key=lambda i:abs(i-(idx+1)));g=gt[near];batch=int(row['request']['batch_index']);ids=row['request'].get('planned_indices',[])
  result=dict(case=name,frame=idx,stage=row['request']['stage'],batch=batch,audit=audit,
              gt_sample_step=near,gt_valid=bool(ids and all(i in g['valid_placed_ids'] for i in ids)))
  records.append(result)
  print(json.dumps(result,default=lambda x:x.tolist() if hasattr(x,'tolist') else str(x)),flush=True)
  if idx%25==0 and vision.placement_auditor.debug.get('corners') is not None:
   d=vision.placement_auditor.debug
   for view in d['views']:
    camera=view['name'].split('@')[0]
    im=obs['observation.images.'+camera][:,:,::-1].copy();uv,z=_project(d['corners'],view['camera'],im.shape)
    cv2.polylines(im,[np.rint(view['polygon']).astype(np.int32)],True,(0,255,0),1)
    cv2.polylines(im,[np.rint(cv2.convexHull(uv.astype(np.float32))).astype(np.int32)],True,(255,0,255),1)
    cv2.imwrite(str(root/'dev_placement'/f'{name}_{idx}_{camera}.png'),im)
 for cap in videos.values():cap.release()
 print(name,'elapsed',time.perf_counter()-started,flush=True)
(root/'dev_placement/c_r4_saved_public_held_calibration.json').write_text(json.dumps(records,indent=2,default=lambda x:x.tolist() if hasattr(x,'tolist') else str(x)))
