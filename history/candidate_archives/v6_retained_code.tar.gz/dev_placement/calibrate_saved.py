from pathlib import Path
import sys,json,cv2,time,numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from placement_audit import PlacementAuditor,_project
from perception import VisionEstimator
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
folder=root/'dev_a_smoke_r1/2x5_basic_12001_n5'
trace={r['step']:r for r in map(json.loads,(folder/'diagnostic/trace.jsonl').read_text().splitlines())}
policy={r['step']:r for r in map(json.loads,(folder/'policy_trace/seed_12001.jsonl').read_text().splitlines())}
truth={r['step']:r for r in map(json.loads,(folder/'offline_truth/seed_12001_measurements.jsonl').read_text().splitlines())}
videos={name:cv2.VideoCapture(str(folder/'diagnostic'/f'{name}.mp4')) for name in ('front','left_wrist','right_wrist')}
def observation(idx):
 obs=dict(trace[idx]['observation_before'])
 for name,cap in videos.items():
  cap.set(cv2.CAP_PROP_POS_FRAMES,idx);ok,image=cap.read();assert ok
  obs['observation.images.'+name]=image[:,:,::-1]
 return obs
config=load_config(resource_root()/'configs/cookie_batch.yaml');vision=VisionEstimator(config)
initial=observation(0);vision.estimate(initial,policy[0]['request'])
auditor=PlacementAuditor(config,color_mask=vision._v6_color_mask)
results=[]
for step in (105,110,115,120,125,260,265,270,275,280):
 idx=step-1
 if step not in truth:continue
 obs=observation(idx);state=truth[step]
 prior=policy[max(i for i in policy if i<=idx)];request=dict(prior['request']);request['stage']=state['phase'];request['batch_index']=state['batch_index'];request['target_column']=state['batch_index']
 box=prior['perception']['target_box'];cameras=vision._robot_cameras(obs)
 for name,cam in list(cameras.items()):
  if name=='left_wrist':cameras[name]=vision._v6_wrist_camera(cam,obs)
  elif name in vision.camera_adjustments:cameras[name]=vision._adjust_camera(cam,vision.camera_adjustments[name])
 started=time.perf_counter();result=auditor.estimate(obs,cameras,box,request)
 ids=list(range(5*state['batch_index'],5*state['batch_index']+5));actual=np.asarray(state['cookie_positions'])[ids].mean(0)
 row=dict(frame=idx,step=step,batch=state['batch_index'],phase=state['phase'],wall_seconds=time.perf_counter()-started,
          result=result,gt_valid_placement=all(i in state['valid_placed_ids'] for i in ids),
          center_error_mm=None if result.get('center') is None else float(np.linalg.norm(np.asarray(result['center'])-actual)*1000))
 results.append(row)
 print(json.dumps(row,default=lambda x:x.tolist() if hasattr(x,'tolist') else str(x)),flush=True)
 if auditor.debug.get('corners') is not None:
  for view in auditor.debug['views']:
   image=obs['observation.images.'+view['name']][:,:,::-1].copy();uv,z=_project(auditor.debug['corners'],view['camera'],image.shape)
   cv2.polylines(image,[np.rint(view['polygon']).astype(np.int32)],True,(0,255,0),1)
   cv2.polylines(image,[np.rint(cv2.convexHull(uv.astype(np.float32))).astype(np.int32)],True,(255,0,255),1)
   cv2.imwrite(str(root/'dev_placement'/f'{step}_{view["name"]}_fit.png'),image)
(root/'dev_placement/calibration_results.json').write_text(json.dumps(results,indent=2,default=lambda x:x.tolist() if hasattr(x,'tolist') else str(x)))
