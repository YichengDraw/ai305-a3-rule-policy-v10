exec(open(__file__.replace('debug_views.py','calibrate_saved.py')).read().split('results=[]')[0])
from placement_audit import _corners,_rz,_hull,_distances
idx=124;obs=observation(idx);prior=policy[max(i for i in policy if i<=idx)];request=prior['request'];box=prior['perception']['target_box'];cs=vision._robot_cameras(obs)
for name,cam in list(cs.items()):
 if name=='left_wrist':cs[name]=vision._v6_wrist_camera(cam,obs)
 elif name in vision.camera_adjustments:cs[name]=vision._adjust_camera(cam,vision.camera_adjustments[name])
bp=np.asarray(box['center']);br=_rz(box['yaw']);col=request['target_column'];expected=np.asarray(request['batch_expected_local_center']);rc=np.array([auditor.columns[col],0.,auditor.floor+.025]);rh=np.array([auditor.half[0]+.01,auditor.bin_half[1]+.012,.035]);world=(rc+_corners(rh))@br.T+bp
for name,cam in cs.items():
 im=obs['observation.images.'+name];uv,z=_project(world,cam,im.shape);ep,ez=_project((expected@br.T+bp)[None],cam,im.shape);roi=np.zeros(im.shape[:2],np.uint8);cv2.fillConvexPoly(roi,np.rint(_hull(uv[z>.025])).astype(np.int32),255);colors=vision._v6_color_mask(im);mask=cv2.bitwise_and(colors,roi);mask=cv2.morphologyEx(mask,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8));num,labels,stats,centers=cv2.connectedComponentsWithStats(mask)
 print(name,'depth',z,'expected',ep,ez,'components',stats[:,4].tolist())
 for c in range(1,num):
  contours=cv2.findContours((labels==c).astype(np.uint8),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)[0]
  poly=_hull(np.vstack(contours).reshape(-1,2));print(c,'area',stats[c,4],'dist',_distances(ep,poly)[0],'poly',poly)
 out=im[:,:,::-1].copy();cv2.polylines(out,[np.rint(_hull(uv[z>.025])).astype(np.int32)],True,(0,255,0),1);cv2.circle(out,tuple(np.rint(ep[0]).astype(int)),3,(255,0,255),1);out[:,:,2]=np.maximum(out[:,:,2],mask);cv2.imwrite(str(root/'dev_placement'/f'roi_{name}.png'),out)
