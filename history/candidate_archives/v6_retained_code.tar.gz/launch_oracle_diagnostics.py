"""Run preselected paired visual/oracle development cases; no formal results."""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--policy-code", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=12)
    parser.add_argument("--egl-devices", nargs="+", default=[4, 5], type=int)
    args = parser.parse_args()
    code = Path(__file__).resolve().parent
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    cases = []
    for profile in ("basic", "medium", "advanced"):
        for seed in (13000, 13004):
            cases.append(dict(task="2x5", profile=profile, seed=seed, first_grasp=5, max_steps=500))
    for profile, counts in (("basic", (0, 1)), ("medium", (1, 9)), ("advanced", (0, 9))):
        for count in counts:
            cases.append(dict(task="2x10", profile=profile, seed=12000,
                              first_grasp=count, max_steps=3200))
    jobs = []
    for index, case in enumerate(cases):
        for oracle in (False, True):
            name = f"{case['task']}_{case['profile']}_{case['seed']}_n{case['first_grasp']}_{'oracle' if oracle else 'visual'}"
            jobs.append(dict(case, pair=index, oracle=oracle, name=name,
                             device=args.egl_devices[len(jobs) % len(args.egl_devices)]))
    protocol = dict(scope="development_only_paired_oracle_ablation", cases=cases, jobs=jobs,
                    policy_code=str(args.policy_code.resolve()), controller_changed=False,
                    oracle_replacements=["selected-source-group geometry", "target-bin pose"],
                    workers=args.workers, started_unix=time.time(), argv=sys.argv)
    (output / "protocol.json").write_text(json.dumps(protocol, indent=2) + "\n")
    start = time.monotonic()

    def run(job):
        destination = output / job["name"]
        command = [sys.executable, str(code / "run_dev.py"), "--code-dir", str(args.policy_code.resolve()),
                   "--task", job["task"], "--profile", job["profile"], "--seed", str(job["seed"]),
                   "--max-steps", str(job["max_steps"]), "--first-grasp", str(job["first_grasp"]),
                   "--output", str(destination), "--no-video"]
        if job["oracle"]:
            command.append("--oracle-source-target")
        environment = dict(os.environ, MUJOCO_GL="egl", MUJOCO_EGL_DEVICE_ID=str(job["device"]),
                           CUDA_VISIBLE_DEVICES=str(job["device"]), OMP_NUM_THREADS="1",
                           MKL_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1")
        print(f"START {job['name']}", flush=True)
        with (output / f"{job['name']}.log").open("w") as log:
            result = subprocess.run(command, cwd=code, env=environment, stdout=log, stderr=subprocess.STDOUT)
        print(f"DONE {job['name']} rc={result.returncode}", flush=True)
        return dict(job, returncode=result.returncode, command=command)

    done = []
    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        for future in as_completed([executor.submit(run, job) for job in jobs]):
            done.append(future.result())
            (output / "status.json").write_text(json.dumps(dict(completed=len(done), planned=len(jobs),
                                                                 wall_seconds=time.monotonic() - start,
                                                                 jobs=done), indent=2) + "\n")
    failures = [job for job in done if job["returncode"]]
    if failures:
        raise RuntimeError(f"Diagnostic process errors: {failures}")
    pairs = []
    for index, case in enumerate(cases):
        pair = dict(case)
        for oracle, label in ((False, "visual"), (True, "oracle")):
            job = next(job for job in jobs if job["pair"] == index and job["oracle"] == oracle)
            result = json.loads((output / job["name"] / "result.json").read_text())
            pair[label] = {key: result.get(key) for key in (
                "score", "max_score", "success", "steps", "wall_seconds", "phase", "policy_failure_reason",
                "policy_reports", "policy_recovery_events", "offline_batch_audit", "diagnostic_summary")}
        pair["score_difference"] = pair["oracle"]["score"] - pair["visual"]["score"]
        pairs.append(pair)
    summary = dict(scope="development_only", pairs=pairs, wall_seconds=time.monotonic() - start,
                   visual_successes=sum(pair["visual"]["success"] for pair in pairs),
                   oracle_successes=sum(pair["oracle"]["success"] for pair in pairs),
                   visual_mean_completion=sum(pair["visual"]["score"] / pair["visual"]["max_score"] for pair in pairs) / len(pairs),
                   oracle_mean_completion=sum(pair["oracle"]["score"] / pair["oracle"]["max_score"] for pair in pairs) / len(pairs))
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
