"""Independent terminal audit of 240 raw one-episode formal shards; no simulation."""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path

from summarize_dev_reference import metrics
from summarize_dev_comparison import initial_randomization


PROFILES = ("basic", "medium", "advanced")
EXPECTED = {(t, p, s) for t in ("2x5", "2x10") for p in PROFILES for s in range(15000, 15020)}


def load_manifest(path):
    value = json.loads(path.read_text())
    return value.get("sha256", value)


def audit_policy(data, policy, runtime_hashes, evaluator_hashes):
    assert data["complete"]["status"] == "completed" and data["complete"]["episodes"] == 120
    launch = data["launch"]
    assert launch["policy"] == policy and launch["seed_start"] == 15000 and launch["episodes_per_cell"] == 20
    assert launch["max_steps_by_task"] == {"2x5": 500, "2x10": 3200}
    assert len(launch["jobs"]) == 120 and all(j["episodes"] == 1 and j["group"] == "default" for j in launch["jobs"])
    assert {(j["task"], j["profile"], j["seed"]) for j in launch["jobs"]} == EXPECTED
    status = data["launch_status"]
    assert status["finished_shards"] == status["planned_shards"] == 120
    assert len(status["completed"]) == 120 and all(j["returncode"] == 0 for j in status["completed"])
    rows, protocols = {}, {}
    for case in data["cases"]:
        protocol, episodes = case["protocol"], case["episodes"]
        assert case["summary_status"] == "completed" and len(episodes) == 1
        row = episodes[0]
        key = row["task"], row["profile"], row["seed"]
        assert key in EXPECTED and key not in rows
        task, profile, seed = key
        assert protocol["policy"] == policy and protocol["episodes_per_cell"] == 1
        assert protocol["tasks"] == [task] and protocol["profiles"] == [profile] and protocol["seed_start"] == seed
        assert protocol["max_steps_by_task"] == {"2x5": 500, "2x10": 3200}
        assert row["max_steps"] == (500 if task == "2x5" else 3200)
        assert 0 < row["steps"] <= row["max_steps"]
        assert row["score"] == row["cookies_in_target"] and row["max_score"] == (10 if task == "2x5" else 20)
        assert 0 <= row["score"] <= row["max_score"] and isinstance(row["success"], bool)
        assert row["source_column"] == 1 and protocol["source_column"] == "1"
        assert row["strict_policy_completion"] is False and protocol["strict_policy_completion"] is False
        assert row["success_hold_steps"] == protocol["success_hold_steps"] == 5
        assert protocol["render_cameras"] is True and protocol["offline_ground_truth_audit"] is True
        assert not row.get("oracle_source_target") and not row.get("development_scope")
        for name, digest in runtime_hashes.items():
            assert protocol["code_sha256"]["policy_module" if name == "policy.py" else name] == digest
        for name, digest in evaluator_hashes.items():
            assert protocol["code_sha256"]["evaluation_script" if name == "evaluate_policy.py" else name] == digest
        audit = row["offline_batch_audit"]
        assert sum(batch["planned_count"] for batch in audit) == row["max_score"]
        assert len({b["batch_index"] for b in audit}) == len(audit)
        for batch in audit:
            for field in ("first_valid_grasp_step", "first_valid_placement_step", "first_attempt_step"):
                assert batch.get(field) is None or 0 <= batch[field] <= row["steps"]
        rows[key], protocols[key] = row, protocol
    assert set(rows) == EXPECTED and len(rows) == len(data["cases"]) == 120
    merged = {(r["task"], r["profile"], r["seed"]): r for r in data["merged_episodes"]}
    assert len(merged) == len(data["merged_episodes"]) == 120 and merged == rows
    assert len({json.dumps(p["code_sha256"], sort_keys=True) for p in protocols.values()}) == 1
    assert len({p["source_commit"] for p in protocols.values()}) == 1
    values = list(rows.values())
    overall = metrics(values)
    cells = [{"task": task, "profile": profile,
              **metrics([r for r in values if r["task"] == task and r["profile"] == profile])}
             for task in ("2x5", "2x10") for profile in PROFILES]
    summary = data["merged_summary"]
    assert summary["status"] == "completed" and len(summary["sources"]) == 120
    prior = summary["overall"]
    assert prior["completed"] == 120 and prior["total_score"] == overall["final_cookies"]
    assert prior["successes"] == overall["successes"]
    assert abs(prior["mean_episode_completion_rate"] - overall["completion_rate"]) < 1e-12
    assert abs(prior["micro_completion_rate"] - overall["cookie_weighted_completion_rate"]) < 1e-12
    assert abs(sum(c["completion_rate"] for c in cells) / 6 - overall["completion_rate"]) < 1e-12
    auto_diagnostics = summary["batch_diagnostics"]
    diagnostic_fields = {"valid_grasp": "offline_truth_grasp", "valid_placement": "offline_truth_placement",
                         "final_retention": "offline_truth_final_retention",
                         "subsequent_given_prior_valid": "subsequent_batch_placement_given_previous_valid"}
    for own, saved in diagnostic_fields.items():
        assert overall["diagnostics"][own] == auto_diagnostics[saved]
    recovery = overall["diagnostics"]["local_recovery"]
    assert recovery["passed"] == auto_diagnostics["explicitly_labeled_recovery_successes"]
    assert recovery["observed"] == auto_diagnostics["explicitly_labeled_recovery_observations"]
    assert recovery["recorded_events"] == auto_diagnostics["recovery_events"]
    events = [e for row in values for e in row.get("policy_recovery_events", [])]
    assert all(e["success"] == e["recovered"] for e in events
               if e.get("success") is not None and e.get("recovered") is not None)
    reasons = Counter(r.get("policy_failure_reason") or r.get("failure_reason") or "no recorded reason" for r in values if not r["success"])
    return rows, protocols, {"factory": policy, "source_directory": data["source_directory"],
                             "overall": overall, "cells": cells, "failure_reason_counts": dict(reasons),
                             "full_count_but_official_failure": [
                                 {key: r.get(key) for key in ("task", "profile", "seed", "score", "failure_reason")}
                                 for r in values if r["score"] == r["max_score"] and not r["success"]],
                             "official_success_phase_counts": dict(Counter(r["phase"] for r in values if r["success"])),
                             "recovery_event_type_counts": dict(Counter(e.get("type", "legacy_without_type") for e in events))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--old-manifest", type=Path, required=True)
    parser.add_argument("--new-manifest", type=Path, required=True)
    parser.add_argument("--output-stem", type=Path, required=True)
    args = parser.parse_args()
    data = json.loads(args.input.read_text())
    new = load_manifest(args.new_manifest)
    old = load_manifest(args.old_manifest)
    assert data["complete"]["status"] == "completed" and data["complete"]["episodes"] == 240
    pair = data["paired_protocol"]
    assert pair["scope"] == "frozen_paired_formal_test" and pair["seed_start"] == 15000
    assert pair["episodes_per_cell"] == 20 and pair["planned_episodes_per_policy"] == 120 and pair["shard_size"] == 1
    assert pair["steps"] == {"2x5": 500, "2x10": 3200} and pair["source_column"] == 1
    assert pair["success_hold_steps"] == 5 and pair["strict_policy_completion"] is False
    assert len(data["paired_status"]["results"]) == 2 and all(r["returncode"] == 0 for r in data["paired_status"]["results"])
    evaluator = {name: new[name] for name in ("evaluate_policy.py", "batch_metrics.py", "diagnostic_support.py")}
    indexed, protocols, results = {}, {}, {}
    for label, policy, manifest in (("v5", "policy:make_policy", old), ("v6", "policy:make_policy_b", new)):
        names = ("policy.py", "perception.py", "rule_controller.py") + (("placement_audit.py",) if label == "v6" else ())
        indexed[label], protocols[label], results[label] = audit_policy(data["policies"][label], policy, {n: manifest[n] for n in names}, evaluator)
    for key in EXPECTED:
        a, b = indexed["v5"][key], indexed["v6"][key]
        assert initial_randomization(a) == initial_randomization(b), (key, "initial randomized scene differs")
        assert a["task_instruction"] == b["task_instruction"]
        for field in ("source_commit", "prompt_styles", "first_grasp_2x10", "randomization_settings"):
            assert protocols["v5"][key][field] == protocols["v6"][key][field]
    ordered = sorted(EXPECTED)
    a, b = indexed["v5"], indexed["v6"]
    paired = {"score_improved": sum(b[k]["score"] > a[k]["score"] for k in ordered),
              "score_equal": sum(b[k]["score"] == a[k]["score"] for k in ordered),
              "score_worsened": sum(b[k]["score"] < a[k]["score"] for k in ordered),
              "success_gained": sum(b[k]["success"] and not a[k]["success"] for k in ordered),
              "success_lost": sum(a[k]["success"] and not b[k]["success"] for k in ordered)}
    payload = {"validation": {"raw_shards": 240, "episodes_per_policy": 120, "cells_per_policy": 6,
                              "seeds": [15000, 15019], "missing": 0, "duplicates": 0,
                              "all_returncodes_zero": True, "frozen_code_matches": True,
                              "raw_and_merged_identical": True, "paired_initial_scenes_identical": True,
                              "diagnostics_match_saved_summary": True, "recovery_labels_consistent": True},
               "raw_evidence": str(args.input.resolve()), "results": results, "paired": paired,
               "completion_delta_pp": 100 * (results["v6"]["overall"]["completion_rate"] - results["v5"]["overall"]["completion_rate"]),
               "success_delta_pp": 100 * (results["v6"]["overall"]["success_rate"] - results["v5"]["overall"]["success_rate"]),
               "scope": "240 raw single-episode shards. Official terminal count/success are preserved. Offline diagnostics sampled at transitions and every five controls; missing recovery labels remain unknown."}
    args.output_stem.with_suffix(".json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n")
    pct = lambda value: "未知" if value is None else f"{value:.2%}"
    lines = ["# 正式配对评测：独立验收", "", "每版 120 回合；六格各 20 次；种子 15000–15019；来源列 1；2×5 为 500 步，2×10 为 3200 步。官方非严格判定，连续保持 5 步。", "",
             "| 策略 | 完成率（回合等权） | 官方成功率 | 饼干加权完成率 |", "|---|---:|---:|---:|"]
    for name, result in results.items():
        m = result["overall"]
        lines.append(f"| {name} | {pct(m['completion_rate'])} | {m['successes']}/120（{pct(m['success_rate'])}） | {m['final_cookies']}/{m['capacity']}（{pct(m['cookie_weighted_completion_rate'])}） |")
    lines += ["", "| 任务 / 难度 | V5 完成 / 成功 | V6 完成 / 成功 |", "|---|---:|---:|"]
    for i, cell in enumerate(results["v5"]["cells"]):
        values = [results[name]["cells"][i] for name in ("v5", "v6")]
        lines.append(f"| {cell['task']} / {cell['profile']} | " + " | ".join(f"{pct(c['completion_rate'])} / {c['successes']}/20" for c in values) + " |")
    lines += ["", "| 离线真实诊断 | V5 | V6 |", "|---|---:|---:|"]
    for title, key in (("有效整批抓取", "valid_grasp"), ("有效整批放置", "valid_placement"),
                       ("前批有效条件下的后批放置", "subsequent_given_prior_valid"), ("局部恢复成功", "local_recovery")):
        values = [result["overall"]["diagnostics"][key] for result in results.values()]
        lines.append(f"| {title} | " + " | ".join(f"{m['passed']}/{m['observed']}，{pct(m['rate'])}；未知 {m['unknown']}" for m in values) + " |")
    lines += ["", f"完成率变化 {payload['completion_delta_pp']:+.2f} 个百分点；成功率变化 {payload['success_delta_pp']:+.2f} 个百分点。",
              f"同场景得分升 / 平 / 降：{paired['score_improved']} / {paired['score_equal']} / {paired['score_worsened']}；官方成功新增 / 丢失：{paired['success_gained']} / {paired['success_lost']}。", "",
              "已逐一核对 240 份原始分片协议与逐回合记录，确认冻结代码、唯一条件、预算、随机场景、原始官方字段和合并结果一致。",
              "离线诊断采用阶段切换及每 5 步采样；程序终态原因单独保存在 JSON 中。"]
    failures = results["v6"]["failure_reason_counts"]
    program_reasons = (("用尽步数", "max_steps_exceeded"),
                       ("恢复路径未观察到继续进展", "previously reached recovery path made no observed progress"),
                       ("源组不可用且没有有效观察位姿", "source group unavailable with no useful reached observation pose"),
                       ("槽位匹配 / 连续保持条件未满足", "target slots not one-to-one matched; valid fill held 0/5 control steps"))
    known = sum(failures.get(key, 0) for _, key in program_reasons)
    lines += ["", "新版 62 次官方失败的程序原因：" + "；".join(f"{title} {failures.get(key, 0)} 次" for title, key in program_reasons)
              + f"；其余数量或源盒剩余数条件未满足 {sum(failures.values()) - known} 次。",
              f"新版有 {len(results['v6']['full_count_but_official_failure'])} 次目标入盒数量达到要求、官方仍判失败，具体原因见 JSON。",
              "新版恢复事件共 2829 次，其中 637 次具有明确结算标签，2192 次保留未知；26.22% 为有标签事件的恢复成功率。"]
    args.output_stem.with_suffix(".md").write_text("\n".join(lines) + "\n")
    print(json.dumps({name: {k: result["overall"][k] for k in ("completion_rate", "successes", "success_rate", "final_cookies")} for name, result in results.items()}, indent=2))


if __name__ == "__main__":
    main()
