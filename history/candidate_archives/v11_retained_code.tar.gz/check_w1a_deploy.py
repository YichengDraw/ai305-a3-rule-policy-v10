#!/usr/bin/env python3
"""Deployment checks for candidate_w1_conflict_v11 on PRO (no simulation).

Usage:
  check_w1a_deploy.py deploy   - freeze-receipt identity of the 76 unchanged
                                 runtime files + py_compile of all 79 files.
  check_w1a_deploy.py closure  - every RUNTIME_DEPENDENCIES entry exists on disk
                                 and the list covers all .py files present.
"""
import hashlib
import json
import py_compile
import sys
from pathlib import Path

ROOT = Path('/home/ai305/ai305group3/a3_rule_policy_v11_20261106/candidate_w1_conflict_v11')
RECEIPT = Path('/home/ai305/ai305group3/a3_rule_policy_v10_20261104/contracts/final_freeze_v10_20261106.json')
CHANGED = {'policy.py', 'v10_leaves_17e0363838a9/two10_source1/target_occupancy.py', 'v10_leaves_17e0363838a9/two10_source1/perception.py', 'v10_leaves_17e0363838a9/two10_source1/policy.py'}
NEW = {'v10_leaves_17e0363838a9/two10_source1/fusion_conflict.py'}


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else 'deploy'
    receipt = json.loads(RECEIPT.read_text())
    hashes = receipt['runtime_sha256']
    files = receipt['runtime_files']
    if mode == 'deploy':
        bad = []
        for rel in files:
            if rel in CHANGED:
                continue
            p = ROOT / rel
            if not p.exists():
                bad.append((rel, 'missing'))
                continue
            digest = hashlib.sha256(p.read_bytes()).hexdigest()
            if digest != hashes[rel]:
                bad.append((rel, 'sha_mismatch'))
        print(f'unchanged-runtime identity: {"PASS" if not bad else bad} ({len(files) - len(CHANGED)} files checked)')
        if bad:
            sys.exit(1)
        compiled = 0
        for p in sorted(ROOT.rglob('*.py')):
            py_compile.compile(str(p), doraise=True)
            compiled += 1
        print(f'py_compile: PASS ({compiled} files, expect 79)')
        sys.exit(0 if compiled == 79 else 1)
    if mode == 'closure':
        sys.path.insert(0, str(ROOT))
        import importlib.util
        spec = importlib.util.spec_from_file_location('candidate_policy', ROOT / 'policy.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        deps = set(module.RUNTIME_DEPENDENCIES)
        present = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*.py')}
        print('RUNTIME_DEPENDENCIES count:', len(deps))
        print('missing from disk:', sorted(deps - present) or 'none')
        print('py files not registered:', sorted(present - deps - {'legacy_unused'}) or 'none')
        ok = deps == present
        print('closure:', 'PASS' if ok else 'MISMATCH')
        sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
