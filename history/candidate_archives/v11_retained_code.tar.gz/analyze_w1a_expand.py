#!/usr/bin/env python3
"""Analyze the W1a 127-case expansion replay against the frozen-V10 (NoYCommon)
parent 127-case CPU results.

Parent source: source_broad_r3_related127_NoY_parent_raw.json (groups with
cases[].result). Candidate source: the new replay root (cases as directories
with result.json, labels from protocol.json jobs). Emits per-case deltas,
gained/lost successes, quantity regressions, trigger counts (NO_OP awareness),
and a markdown summary.

Usage: python analyze_w1a_expand.py REPLAY_ROOT PARENT_RAW_JSON
"""
import json
import sys
from pathlib import Path


def load_parent(path):
    rows = {}
    data = json.loads(Path(path).read_text())
    for group in data.get('groups', []):
        for case in group.get('cases', []):
            label = case.get('label')
            result = case.get('result') or {}
            if label and result:
                rows[label] = dict(score=result.get('score'), success=result.get('success'), steps=result.get('steps'), source=result.get('cookies_in_source'), phase=result.get('phase'))
    return rows


def count_triggers(case_dir):
    trace_dir = case_dir / 'policy_trace'
    if not trace_dir.exists():
        return dict(trace_found=False, conflict_states=0, max_extent=None, retained=[])
    states = 0
    max_extent = None
    retained = []
    for path in sorted(trace_dir.glob('seed_*.jsonl')):
        with path.open() as handle:
            for line in handle:
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue
                columns = (((row.get('perception') or {}).get('target_visibility')) or {}).get('columns') or {}
                for diag in columns.values():
                    if not isinstance(diag, dict):
                        continue
                    if diag.get('inadmissible_for_entry_update') or diag.get('state') == 'conflicting_views':
                        states += 1
                        prior = diag.get('retained_prior')
                        if prior and prior not in retained:
                            retained.append(prior)
                    fusion = diag.get('row_fusion') or {}
                    extent = fusion.get('conflict_extent_m')
                    if extent is not None:
                        max_extent = extent if max_extent is None else max(max_extent, extent)
    return dict(trace_found=True, conflict_states=states, max_extent=max_extent, retained=retained)


def main():
    root = Path(sys.argv[1])
    parent = load_parent(sys.argv[2])
    protocol = json.loads((root / 'protocol.json').read_text())
    cases = []
    for job in protocol.get('jobs', []):
        label = job['label']
        result_path = root / label / 'result.json'
        if result_path.exists():
            result = json.loads(result_path.read_text())
            current = dict(score=result.get('score'), success=result.get('success'), steps=result.get('steps'), source=result.get('cookies_in_source'), phase=result.get('phase'))
        else:
            current = dict(score=None, success=None, steps=None, source=None, phase='MISSING')
        row = dict(label=label, **{f'candidate_{k}': v for k, v in current.items()})
        p = parent.get(label)
        if p:
            row.update(**{f'parent_{k}': v for k, v in p.items()})
            row['score_delta'] = None if current['score'] is None else current['score'] - p['score']
            row['success_change'] = None if current['success'] is None else int(bool(current['success'])) - int(bool(p['success']))
        row['triggers'] = count_triggers(root / label)
        cases.append(row)
    gained = [c['label'] for c in cases if c.get('success_change') == 1]
    lost = [c['label'] for c in cases if c.get('success_change') == -1]
    regressions = [c['label'] for c in cases if (c.get('score_delta') or 0) < 0]
    missing = [c['label'] for c in cases if c.get('candidate_score') is None]
    score_sum_delta = sum(c.get('score_delta') or 0 for c in cases)
    triggered = [c['label'] for c in cases if c['triggers'].get('conflict_states')]
    lines = ['# W1a 127例扩展对比（候选 vs 冻结V10 NoYCommon 父版同CPU）', '', f'- 回放根：{root}', f'- 例数：{len(cases)}（缺失 {len(missing)}）；分数差合计 {score_sum_delta:+d}', f'- 新增成功 {len(gained)}；旧成功丢失 {len(lost)}；数量回退 {len(regressions)}', f'- 冲突分支实际触发：{len(triggered)} 例（未触发例记 NO_OP）', '']
    lines.append('| label | parent | candidate | Δscore | success | steps p→c | triggers |')
    lines.append('|---|---:|---:|---:|---|---|---:|')
    for c in sorted(cases, key=lambda x: (x.get('score_delta') or 0)):
        lines.append(f"| {c['label']} | {c.get('parent_score')} | {c.get('candidate_score')} | {c.get('score_delta')} | {c.get('parent_success')}→{c.get('candidate_success')} | {c.get('parent_steps')}→{c.get('candidate_steps')} | {c['triggers'].get('conflict_states', 0)} |")
    report = dict(summary=dict(total=len(cases), missing=missing, gained_successes=gained, lost_successes=lost, quantity_regressions=regressions, score_sum_delta=score_sum_delta, triggered_cases=triggered), cases=cases)
    (Path(__file__).with_name('w1a_expand_report.json')).write_text(json.dumps(report, indent=2, ensure_ascii=False))
    (Path(__file__).with_name('w1a_expand_report.md')).write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps(report['summary'], indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
