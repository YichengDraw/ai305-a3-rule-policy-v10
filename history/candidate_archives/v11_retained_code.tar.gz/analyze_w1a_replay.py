#!/usr/bin/env python3
"""Analyze a W1a candidate replay directory against frozen-V10 parent baselines.

Reads each case's result.json (native outcome) and policy_trace/seed_*.jsonl
(per-step policy rows, written every 5 steps / stage change). Counts actual
conflicting_views triggers, conflict extents, retained priors and the stored
entry evolution. Emits a JSON report and a markdown summary. Runs on PRO with
the project venv (or anywhere with numpy-free stdlib).

Usage: python analyze_w1a_replay.py /data/.../replay_v11_w1a_core6_YYYYMMDD_HHMMSS
"""
import json
import sys
from pathlib import Path

PARENT = {
    'priority_2x10_advanced_fixedn1_s1_native_scene21006': dict(profile='advanced', n=1, score=10, source=69, success=False, steps=3200, phase='TRANSPORT', basis='r2 CPU3 + dev120 NoYCommon (identical)'),
    'priority_2x10_basic_fixedn1_s1_native_scene21007': dict(profile='basic', n=1, score=20, source=60, success=True, steps=646, phase='UNVERIFIED', basis='r2 CPU3 success guard'),
    'priority_2x10_medium_fixedn2_s1_native_scene21001': dict(profile='medium', n=2, score=20, source=60, success=True, steps=674, phase='UNVERIFIED', basis='r2 CPU3 success guard'),
    'priority_2x10_advanced_fixedn1_s1_native_scene21004': dict(profile='advanced', n=1, score=0, source=79, success=False, steps=3200, phase='TRANSPORT', basis='dev120 NoYCommon'),
    'priority_2x10_medium_fixedn1_s1_native_scene21004': dict(profile='medium', n=1, score=11, source=68, success=False, steps=3200, phase='TRANSPORT', basis='dev120 NoYCommon'),
    'priority_2x10_basic_fixedn1_s1_native_scene21003': dict(profile='basic', n=1, score=11, source=68, success=False, steps=3200, phase='TRANSPORT', basis='dev120 NoYCommon'),
}


def analyze_trace(case_dir):
    """Count conflict-branch triggers and entry evolution from the policy trace."""
    info = dict(trace_found=False, rows=0, conflict_rows=0, conflicting_views_states=0, max_conflict_extent_m=None, retained_priors=[], entry_ids_by_column={}, bounds_rows_by_column={})
    trace_dir = case_dir / 'policy_trace'
    files = sorted(trace_dir.glob('seed_*.jsonl')) if trace_dir.exists() else []
    if not files:
        return info
    info['trace_found'] = True
    for path in files:
        with path.open() as handle:
            for line in handle:
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue
                info['rows'] += 1
                visibility = ((row.get('perception') or {}).get('target_visibility')) or {}
                columns = visibility.get('columns') or {}
                saw_conflict = False
                for key, diag in columns.items():
                    if not isinstance(diag, dict):
                        continue
                    fusion = diag.get('row_fusion') or {}
                    extent = fusion.get('conflict_extent_m')
                    if extent is not None:
                        current = info['max_conflict_extent_m']
                        info['max_conflict_extent_m'] = extent if current is None else max(current, extent)
                    if diag.get('inadmissible_for_entry_update') or diag.get('state') == 'conflicting_views':
                        saw_conflict = True
                        info['conflicting_views_states'] += 1
                        prior = diag.get('retained_prior')
                        if prior is not None and prior not in info['retained_priors']:
                            info['retained_priors'].append(prior)
                if saw_conflict:
                    info['conflict_rows'] += 1
                occupancy = (row.get('perception') or {}).get('target_occupancy') or {}
                for key, entry in occupancy.items():
                    if not isinstance(entry, dict):
                        continue
                    mid = entry.get('measurement_id')
                    sequence = info['entry_ids_by_column'].setdefault(key, [])
                    if not sequence or sequence[-1] != mid:
                        sequence.append(mid)
                    info['bounds_rows_by_column'][key] = info['bounds_rows_by_column'].get(key, 0) + (1 if entry.get('bounds') is not None else 0)
    return info


def main():
    root = Path(sys.argv[1] if len(sys.argv) > 1 else '.')
    protocol = json.loads((root / 'protocol.json').read_text())
    cases = {}
    for job in protocol.get('jobs', []):
        label = job['label']
        case_dir = root / label
        result_path = case_dir / 'result.json'
        entry = dict(label=label, task=job.get('task'), profile=job.get('profile'), seed=job.get('seed'), n=job.get('n'))
        if result_path.exists():
            result = json.loads(result_path.read_text())
            entry.update(score=result.get('score'), max_score=result.get('max_score'), success=result.get('success'), steps=result.get('steps'), source=result.get('cookies_in_source'), phase=result.get('phase'), failure_reason=result.get('failure_reason'))
        else:
            entry.update(score=None, success=None, steps=None, source=None, phase='MISSING', failure_reason='result.json missing')
        parent = PARENT.get(label)
        if parent:
            entry['parent'] = {k: parent[k] for k in ('score', 'source', 'success', 'steps', 'phase', 'basis')}
            entry['delta'] = dict(score=None if entry['score'] is None else entry['score'] - parent['score'], steps=None if entry['steps'] is None else entry['steps'] - parent['steps'], success_change=None if entry['success'] is None else bool(entry['success']) - bool(parent['success']))
        entry['trace'] = analyze_trace(case_dir)
        entry['triggered'] = bool(entry['trace'].get('conflicting_views_states'))
        cases[label] = entry
    complete = (root / 'complete.json')
    report = dict(replay_root=str(root), status=(json.loads(complete.read_text()).get('status') if complete.exists() else 'incomplete'), code_sha256_entries=len(protocol.get('code_sha256') or {}), cases=cases)
    guard_loss = [c for c in cases.values() if c.get('parent') and c['parent']['success'] and c.get('success') is not True]
    improvement = [c for c in cases.values() if c.get('parent') and not c['parent']['success'] and c.get('success') is True]
    report['summary'] = dict(total=len(cases), completed=sum(1 for c in cases.values() if c.get('score') is not None), guard_losses=[c['label'] for c in guard_loss], new_successes=[c['label'] for c in improvement], score_delta_sum=sum((c.get('delta') or {}).get('score') or 0 for c in cases.values()), triggered_cases=[c['label'] for c in cases.values() if c.get('triggered')], no_op_cases=[c['label'] for c in cases.values() if not c.get('triggered')])
    (Path(__file__).with_name('w1a_replay_report.json')).write_text(json.dumps(report, indent=2, ensure_ascii=False))
    print(json.dumps(report['summary'], indent=2, ensure_ascii=False))
    for label, c in cases.items():
        print(f"{label}: score={c.get('score')} parent={None if not c.get('parent') else c['parent']['score']} success={c.get('success')} steps={c.get('steps')} conflicts={c['trace'].get('conflicting_views_states')} max_extent={c['trace'].get('max_conflict_extent_m')} retained={c['trace'].get('retained_priors')}")
    print('report written:', Path(__file__).with_name('w1a_replay_report.json'))


if __name__ == '__main__':
    main()
