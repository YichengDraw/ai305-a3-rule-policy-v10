#!/usr/bin/env python3
"""W0 baseline review generator for formal_v9_v10_cpu_attempt2.

Reads the completed+audited formal artifacts and writes baseline_review.md:
six-cell official main table for both versions, overall metrics, paired
changes with bootstrap intervals, gained/lost successes, quantity
regressions, first-grasp n distribution, and the full V10 failure list for
the next development round. Read-only; no scoring or evaluation is changed.

Usage: python w0_baseline_review.py [FORMAL_ROOT] (default attempt2 root on Q)
"""
import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else '/data/AI305/ai305group3/a3_rule_policy_v10_20261104/formal_v9_v10_cpu_attempt2')
OUT = Path(__file__).with_name('baseline_review.md')


def fmt(v, pct=False):
    if v is None:
        return 'unknown'
    return f'{v:.2%}' if pct else str(v)


def episode_n(case, episode):
    for source in (episode, case):
        for key in ('first_grasp_count', 'n', 'first_grasp'):
            if isinstance(source, dict) and source.get(key) is not None:
                return source.get(key)
        rand = (source or {}).get('randomization') if isinstance(source, dict) else None
        if rand and rand.get('first_grasp_count') is not None:
            return rand.get('first_grasp_count')
    return None


def main():
    manifest = json.loads((ROOT / 'pipeline_manifest.json').read_text())
    complete_path = ROOT / 'complete.json'
    complete = json.loads(complete_path.read_text()) if complete_path.exists() else None
    audit_path = ROOT / 'audits' / 'natural_main_verification.json'
    audit = json.loads(audit_path.read_text())
    raw_path = ROOT / 'audits' / 'natural_main_raw.json'
    raw = json.loads(raw_path.read_text()) if raw_path.exists() else None
    stats_path = ROOT / 'audits' / 'final_paired_statistics.json'
    stats = json.loads(stats_path.read_text()) if stats_path.exists() else None
    csv_path = ROOT / 'audits' / 'final_regression_cases.csv'
    regression_rows = list(csv.DictReader(csv_path.open())) if csv_path.exists() else []

    lines = []
    lines.append('# W0 基线评审：formal_v9_v10_cpu_attempt2（冻结V9/V10 CPU正式配对）')
    lines.append('')
    lines.append(f'- pipeline 状态：manifest={manifest.get("status")}，complete.json 存在={complete_path.exists()}，phase={audit.get("phase")}')
    lines.append(f'- 审计原件：{audit_path}')
    lines.append(f'- 后处理配对统计：{stats_path if stats else "尚未生成"}；回退CSV行数={len(regression_rows)}')
    lines.append(f'- 种子：{len(audit.get("seed_values", []))} 个场景种子（{audit.get("seed_values", [])[:3]}…），每版 {audit.get("results", {}).get("v9", {}).get("overall", {}).get("episodes", "?")} 局')
    lines.append(f'- 口径：非严格、hold5、2×5=500 / 2×10=3200 步、官方原生 success 与 cookies_in_target，未改动任何评分/预算/种子/扩样规则。')
    lines.append('')
    lines.append('## 1. 六格官方主表')
    lines.append('')
    for label in ('v9', 'v10'):
        res = audit['results'][label]
        overall = res['overall']
        lines.append(f'### {label.upper()} overall')
        lines.append(f'- episodes={overall["episodes"]}，count_sum={overall.get("final_count_sum")}，mean_final_count={overall.get("mean_final_count"):.4f}，normalized_completion={overall["normalized_completion"]:.4f}，successes={overall["successes"]}/{overall["episodes"]}（{overall["official_success_rate"]:.2%}）')
        lines.append('')
        lines.append('| task | profile | episodes | count_sum | mean_count | completion | successes |')
        lines.append('|---|---|---:|---:|---:|---:|---:|')
        for cell in res['cells']:
            lines.append(f"| {cell['task']} | {cell['profile']} | {cell['episodes']} | {cell.get('final_count_sum')} | {cell.get('mean_final_count'):.4f} | {cell['normalized_completion']:.4f} | {cell['successes']}/{cell['episodes']} |")
        lines.append('')
    if audit.get('normalized_delta_pp') is not None:
        lines.append(f"- 配对差：completion {audit.get('normalized_delta_pp'):+.2f}pp，success {audit.get('success_delta_pp'):+.2f}pp")
        lines.append('')
    if stats:
        lines.append('## 2. 配对统计（整场景种子聚类自助95%区间）')
        lines.append('')
        for name, change in (stats.get('changes') or {}).items():
            lines.append(f"- {name}: estimate={change['estimate']:+.4f}，95%CI=[{change['percentile_95_interval'][0]:+.4f}, {change['percentile_95_interval'][1]:+.4f}]")
        lines.append(f"- 新增成功 {len(stats.get('gained_successes', []))} 例；旧成功丢失 {len(stats.get('lost_successes', []))} 例；数量回退 {len(stats.get('quantity_regressions', []))} 例")
        lines.append('')
        for title, key in (('新增成功', 'gained_successes'), ('旧成功丢失', 'lost_successes'), ('数量回退', 'quantity_regressions')):
            rows = stats.get(key) or []
            if rows:
                lines.append(f'### {title}')
                for p in rows:
                    lines.append(f"- {p['task']}/{p['profile']}/seed{p['seed']}: {p['before_count']}→{p['after_count']}，success {p['before_success']}→{p['after_success']}")
                lines.append('')
    if raw:
        lines.append('## 3. 2×10 首批 n 分布（自然随机）')
        for label in ('v9', 'v10'):
            counts = Counter()
            for case in raw['policies'][label]['cases']:
                for episode in case.get('episodes', []):
                    if episode.get('task') == '2x10':
                        counts[episode_n(case, episode)] += 1
            total = sum(counts.values())
            lines.append(f"- {label}: " + '，'.join(f'n={k}:{v}' for k, v in sorted(counts.items(), key=lambda kv: (kv[0] is None, kv[0]))) + f'（共{total}局）')
        lines.append('')
        lines.append('## 4. V10 全部失败回合（下轮开发反例集；一旦用于改规则即转为开发集，不再是未见测试）')
        lines.append('')
        lines.append('| task | profile | seed | n | count | source | steps | phase |')
        lines.append('|---|---|---|---|---:|---:|---:|---|')
        v10rows = [ep for case in raw['policies']['v10']['cases'] for ep in case.get('episodes', []) if not ep.get('success')]
        for ep in sorted(v10rows, key=lambda e: (e['task'], e['profile'], e['seed'])):
            n = episode_n(None, ep)
            lines.append(f"| {ep['task']} | {ep['profile']} | {ep['seed']} | {n} | {ep.get('cookies_in_target')} | {ep.get('cookies_in_source', '?')} | {ep.get('steps')} | {ep.get('phase', '?')} |")
        lines.append('')
        by_phase = Counter(ep.get('phase', '?') for ep in v10rows)
        lines.append('终止阶段分布（症状入口，非因果）：' + '，'.join(f'{k}:{v}' for k, v in by_phase.most_common()))
        lines.append('')
    lines.append('## 5. 边界与下轮输入')
    lines.append('')
    lines.append('- 本表为正式初始阶段（或含条件扩展，以 phase 字段为准）完整分母结果；缺结果保留 unknown，未用部分分数选补丁。')
    lines.append('- V10 六格是否全部 20/20 决定 610000–610079 扩样是否已执行；以 manifest/audit phase 为准，未改动该条件。')
    lines.append('- 上一节失败回合进入 V11 开发反例集（G1/G4 等分组见 05_CASES_INDEX；正式失败按同规则并入），成功回合作为保护例。')
    lines.append('- CPU/OSMesa、同初始化/配置/指令由审计 validation 字段背书：' + json.dumps(audit.get('validation', {}), ensure_ascii=False)[:600])
    OUT.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('written:', OUT)
    print('v10 failures:', sum(1 for c in (raw or {}).get('policies', {}).get('v10', {}).get('cases', []) for e in c.get('episodes', []) if not e.get('success')) if raw else 'raw missing')


if __name__ == '__main__':
    main()
