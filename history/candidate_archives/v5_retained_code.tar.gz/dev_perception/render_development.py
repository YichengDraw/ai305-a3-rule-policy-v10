from pathlib import Path
import json
import numpy as np
import cv2
from a3_dual_arm_sim.workflows.benchmark import make_cookie_benchmark

out=Path(__file__).resolve().parent
for profile in ('basic','medium','advanced'):
    bench=make_cookie_benchmark('2x5',profile=profile,source_column='1')
    env=bench.create_env(render_cameras=True)
    obs,info=env.reset(seed=12000,options={
       'randomize_cookies':True,'randomize_boxes':True,
       'randomize_source_bin':True,'randomize_target_bin':True,
       'source_bin_noise_m':bench.source_bin_noise_m,
       'target_bin_noise_m':bench.target_bin_noise_m,
       'target_bin_yaw_noise_rad':bench.target_bin_yaw_noise_rad,
       'randomization_profile':profile,'appearance_seed':12000,
       'randomization_settings':bench.randomization_settings})
    folder=out/profile;folder.mkdir(exist_ok=True)
    for camera in ('front','left_wrist','right_wrist'):
        cv2.imwrite(str(folder/(camera+'.png')),obs['observation.images.'+camera][:,:,::-1])
    metadata={
       'observation':{k:np.asarray(v).tolist() if isinstance(v,np.ndarray) else v for k,v in obs.items() if 'images' not in k},
       'camera':{n:{'pos':env.data.cam_xpos[i].tolist(),'rotation':env.data.cam_xmat[i].reshape(3,3).tolist(),'fovy':float(env.model.cam_fovy[i])} for n,i in env._camera_ids.items()},
       'source_pos':env.data.xpos[env._source_bin_body].tolist(),
       'target_pos':env.data.xpos[env._target_bin_body].tolist(),
       'target_rotation':env.data.xmat[env._target_bin_body].reshape(3,3).tolist(),
       'cookie_positions':env.cookie_positions.tolist(),
       'cookie_rotations':env.data.xmat[list(env._cookie_bodies)].reshape(-1,3,3).tolist(),
       'config':{'source_center':env.config.cookie_transfer.source_bin_center_m,'source_half':env.config.cookie_transfer.source_bin_half_size_m,'target_center':env.config.cookie_transfer.target_bin_world_position_m,'target_half':env.config.cookie_transfer.target_bin_half_size_m,'cookie_half':env.config.cookie_transfer.cookie_half_size_m}}
    (folder/'metadata.json').write_text(json.dumps(metadata,indent=2))
    env.close()
