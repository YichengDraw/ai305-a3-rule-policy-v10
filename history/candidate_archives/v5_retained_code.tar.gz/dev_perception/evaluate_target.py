from pathlib import Path
import json,sys,cv2,numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'dev_perception'));from perception_candidate import VisionEstimator
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
folder=root/'dev_perception/v3_public_samples';samples=json.load(open(folder/'samples.json'));offline=json.load(open(folder/'offline_evidence.json'));v=VisionEstimator(load_config(resource_root()/'configs/cookie_2x10.yaml'));res=[]
for idx in ['260','300','423','438','447','457','465','590']:
 if idx not in samples:continue
 item=samples[idx];o=item['observation']
 for c in ['front','left_wrist','right_wrist']:o['observation.images.'+c]=cv2.imread(str(folder/(idx+'_'+c+'.png')))[:,:,::-1]
 cs=v._robot_cameras(o);v.boxes={'target_box':item['original_target_estimate']};n,conf=v._count_target(o,cs,{'stage':'VERIFY'})
 row={'frame':int(idx),'stage':item['stage'],'rgb_target_count':n,'confidence':conf,'placement_valid':v.target_placement_valid,'gt_inside':offline[idx]['cookies_in_target'],'diagnostics':v.target_count_diagnostics};res.append(row);print(json.dumps(row))
(folder/'target_count_validation.json').write_text(json.dumps(res,indent=2))
