import sys,json,cv2,numpy as np,mujoco
from pathlib import Path
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root));from perception import VisionEstimator,_project
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
v=VisionEstimator(load_config(resource_root()/'configs/cookie_batch.yaml'));p=root/'dev_perception/basic';m=json.loads((p/'metadata.json').read_text());obs=m['observation'];cam=v._robot_cameras(obs)
im=cv2.imread(str(p/'left_wrist.png'))
for name in ('L_finger_inner_pad_visual','L_finger_outer_pad_visual'):
 i=mujoco.mj_name2id(v.robot_model,mujoco.mjtObj.mjOBJ_GEOM,name);verts=np.array([[x,y,z] for x in (-1,1) for y in (-1,1) for z in (-1,1)])*v.robot_model.geom_size[i]
 world=verts@v.robot_data.geom_xmat[i].reshape(3,3).T+v.robot_data.geom_xpos[i];uv,z=_project(world,cam['left_wrist'],im.shape)
 print(name,uv.tolist())
 for j,xy in enumerate(uv):cv2.circle(im,tuple(np.rint(xy).astype(int)),2,(255,0,255),-1);cv2.putText(im,str(j),tuple(np.rint(xy).astype(int)),cv2.FONT_HERSHEY_PLAIN,.6,(0,255,255),1)
cv2.imwrite(str(p/'pad_projection.png'),cv2.resize(im,None,fx=3,fy=3,interpolation=cv2.INTER_NEAREST))
