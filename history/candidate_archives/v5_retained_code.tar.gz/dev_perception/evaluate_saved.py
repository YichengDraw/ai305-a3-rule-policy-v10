from pathlib import Path
import sys,json,time
import numpy as np,cv2
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from perception import VisionEstimator,_project
from a3_dual_arm_sim.config import load_config
from a3_dual_arm_sim.paths import resource_root
root=Path(__file__).resolve().parent
results=[]
for name in ('basic','medium','advanced'):
    m=json.loads((root/name/'metadata.json').read_text());obs=m['observation']
    for camera in ('front','left_wrist','right_wrist'):obs['observation.images.'+camera]=cv2.imread(str(root/name/(camera+'.png')))[:,:,::-1]
    v=VisionEstimator(load_config(resource_root()/'configs/cookie_batch.yaml'));t=time.time();p=v.estimate(obs,{'count':5,'source_column':1,'source_start_index':0,'stage':'SELECT'})
    result={'group_center':p['group']['center'].tolist(),'group_error':(p['group']['center']-np.array(m['cookie_positions'])[:5].mean(axis=0)).tolist(),'group_confidence':p['group']['confidence'],'group_edge_error':p['group']['edge_residual_px'],'profile':name,'wall':time.time()-t,'source_xy_error':(p['source_box']['center'][:2]-np.array(m['source_pos'])[:2]).tolist(),'target_xy_error':(p['target_box']['center'][:2]-np.array(m['target_pos'])[:2]).tolist(),'source':{k:val.tolist() if isinstance(val,np.ndarray) else val for k,val in p['source_box'].items()},'target':{k:val.tolist() if isinstance(val,np.ndarray) else val for k,val in p['target_box'].items()},'calibration':p['camera_calibration']}
    cams=v._robot_cameras(obs);cams={n:v._adjust_camera(c,v.camera_adjustments.get(n,np.zeros(7))) for n,c in cams.items()}
    for camera in ('front','left_wrist'):
        image=obs['observation.images.'+camera][:,:,::-1].copy()
        for kind,color in [('source',(0,255,0)),('target',(255,0,255))]:
            box=p[kind+'_box'];pts=v._box_points(kind);from perception import _rot_z
            uv,z=_project(pts@_rot_z(box['yaw']).T+box['center'],cams[camera],image.shape)
            for xy,depth in zip(uv,z):
                if depth>0 and np.all(xy>=0) and xy[0]<image.shape[1] and xy[1]<image.shape[0]:cv2.circle(image,tuple(np.rint(xy).astype(int)),1,color,-1)
        uv,z=_project(p['group']['center'][None],cams[camera],image.shape)
        cv2.circle(image,tuple(np.rint(uv[0]).astype(int)),4,(0,0,255),1)
        cv2.imwrite(str(root/name/(camera+'_estimate.png')),image)
    results.append(result);print(json.dumps(result),flush=True)
(root/'first_fit_results.json').write_text(json.dumps(results,indent=2))
