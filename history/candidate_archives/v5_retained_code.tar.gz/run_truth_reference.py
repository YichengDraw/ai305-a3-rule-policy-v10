"""Official privileged-state expert reference; separate from the RGB/force policy."""
from __future__ import annotations

import argparse
import json
import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict
from pathlib import Path


def run_cell(arguments):
    task, profile, episodes, seed_start, max_steps, output = arguments
    from a3_dual_arm_sim.paths import resource_root
    from a3_dual_arm_sim.sim.randomization import load_randomization_config
    from a3_dual_arm_sim.tasks.cookie_2x10_settings import load_cookie_2x10_settings
    from a3_dual_arm_sim.workflows.benchmark import make_cookie_benchmark

    root = resource_root()
    settings5 = load_randomization_config(root / "configs/randomization.yaml")
    settings10, first_grasp = load_cookie_2x10_settings(root / "configs/randomization_2x10.yaml")
    settings = dict(settings5 if task == "2x5" else settings10, profile=profile, source_column="1")
    extra = {"first_grasp": first_grasp} if task == "2x10" else {}
    benchmark = make_cookie_benchmark(
        task=task, profile=profile, source_column="1", randomization_settings=settings,
        max_steps=max_steps, success_hold_steps=5, strict_policy_completion=False, **extra,
    )
    cell_dir = Path(output) / f"{task}_{profile}"
    cell_dir.mkdir(parents=True, exist_ok=False)
    rows = []
    started = time.monotonic()

    def save_episode(score):
        row = {**asdict(score), "task": task, "profile": profile,
               "task_instruction": benchmark._episode_task(score.source_column, score.seed),
               "max_steps": max_steps, "privileged_state_reference": True}
        with (cell_dir / "episodes.jsonl").open("a") as stream:
            stream.write(json.dumps(row) + "\n")
            stream.flush()
        rows.append(row)

    result = benchmark.evaluate("expert", num_episodes=episodes, seed_start=seed_start,
                                workers=1, verbose=True, on_episode_end=save_episode)
    payload = result.to_dict()
    payload["reference_scope"] = "official expert reading privileged scene state; not RGB/force policy"
    payload["completion_rate"] = result.total_score / result.max_possible_score
    payload["task"] = task
    payload["profile"] = profile
    payload["wall_seconds"] = time.monotonic() - started
    (cell_dir / "result.json").write_text(json.dumps(payload, indent=2) + "\n")
    return {key: payload[key] for key in ("task", "profile", "completion_rate", "summary", "wall_seconds")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--episodes", type=int, default=20)
    parser.add_argument("--seed-start", type=int, default=13000)
    parser.add_argument("--max-steps", type=int, default=500)
    parser.add_argument("--tasks", nargs="+", default=["2x5", "2x10"], choices=["2x5", "2x10"])
    parser.add_argument("--profiles", nargs="+", default=["basic", "medium", "advanced"],
                        choices=["basic", "medium", "advanced"])
    parser.add_argument("--workers", type=int, default=6)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    protocol = {"policy": "official expert", "privileged_state_reference": True,
                "tasks": args.tasks, "profiles": args.profiles, "episodes_per_cell": args.episodes,
                "seed_start": args.seed_start, "max_steps": args.max_steps, "source_column": "1",
                "strict_policy_completion": False, "success_hold_steps": 5,
                "render_cameras": False, "pid": os.getpid()}
    (args.output / "protocol.json").write_text(json.dumps(protocol, indent=2) + "\n")
    jobs = [(task, profile, args.episodes, args.seed_start, args.max_steps, str(args.output))
            for task in args.tasks for profile in args.profiles]
    started = time.monotonic()
    cells = []
    with ProcessPoolExecutor(max_workers=min(args.workers, len(jobs))) as executor:
        for future in as_completed([executor.submit(run_cell, job) for job in jobs]):
            cells.append(future.result())
            (args.output / "cells.json").write_text(json.dumps(cells, indent=2) + "\n")
    cells.sort(key=lambda cell: (args.tasks.index(cell["task"]), args.profiles.index(cell["profile"])))
    n = sum(cell["summary"]["total_episodes"] for cell in cells)
    total = sum(cell["summary"]["total_score"] for cell in cells)
    capacity = sum(cell["summary"]["max_possible_score"] for cell in cells)
    successes = sum(round(cell["summary"]["success_rate"] * cell["summary"]["total_episodes"])
                    for cell in cells)
    summary = {"status": "completed", "privileged_state_reference": True, "cells": cells,
               "episodes": n, "total_score": total, "max_possible_score": capacity,
               "successes": successes, "success_rate": successes / n,
               "micro_completion_rate": total / capacity,
               "macro_completion_rate": sum(cell["completion_rate"] for cell in cells) / len(cells),
               "wall_seconds": time.monotonic() - started}
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
